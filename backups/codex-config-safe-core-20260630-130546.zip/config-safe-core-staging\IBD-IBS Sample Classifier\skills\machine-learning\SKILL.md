---
name: machine-learning
description: Learn simple detector-specific threshold bars from known IBS samples for the IBD-IBS Sample Classifier agent. Use at the start of each run to calculate one independent bar per detector from current Study cases files using IBS average, standard deviation, and maximum only.
---

# Machine Learning

## Overview

Use this skill first on every IBD-IBS Sample Classifier run. Learn one independent threshold bar for each detector from known labeled IBS samples in `Study cases`.

## Folder Contract

Use these folders relative to `C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier`:

- Input study cases: `Study cases`
- Unknown samples: `Unknown sampels`
- Classification outputs: `Classified sampels`

Read only study-case files from `Study cases`. Do not modify original files. Recalculate bars from the current study-case data every run.

## Study-Case Schema

Study-case files should contain:

- `Sample name` or equivalent patient/sample identifier
- detector measurement columns such as `PA447`, `araE`, and future detectors
- `Diagnosis`, where `IBS` identifies samples used for bar learning; `CDf` is treated as `IBD` but is not used for bar calculation

## Bar Learning And Selection

For each detector independently:

1. Use only known `IBS` samples.
2. Calculate:
   - IBS average
   - IBS standard deviation
   - IBS maximum value
3. Calculate several possible IBS-based bars:
   - sensitive bar: `IBS average + 0.5 * SD`
   - balanced bar: `IBS average + 1 * SD`
   - moderately strict bar: `IBS average + 1.5 * SD`
   - strict bar: `IBS average + 2 * SD`
4. If the number of IBS samples is too small or standard deviation is unreliable, use only the max-based bar.
5. Evaluate candidate bars using the known labeled samples.
6. Select the lowest bar that does not create more than `5%` IBS false positives in the known labeled samples.
7. Prefer lower bars when they recover more known IBD samples. Use `IBS average + 2 * SD` only if lower bars clearly create too many IBS false positives.
8. If no candidate can meet the `5%` IBS false-positive maximum, choose the candidate with the fewest IBS false positives; if tied, choose the highest bar.
9. Store the detector-specific bar, selected candidate, method, and candidate evaluation metrics.

Do not use a global bar across detectors. Do not use probability models or complex machine-learning systems.
