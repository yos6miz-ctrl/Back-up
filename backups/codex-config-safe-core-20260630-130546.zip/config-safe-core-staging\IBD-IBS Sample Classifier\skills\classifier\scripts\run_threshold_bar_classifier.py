import json
import math
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


BASE_DIR = Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
STUDY_DIR = BASE_DIR / "Study cases"
UNKNOWN_DIR = BASE_DIR / "Unknown sampels"
RUN_DIR = BASE_DIR / "skills" / "classifier" / "scripts" / ".run"


def normalize_label(value):
    label = str(value).strip()
    if label.lower() in {"cdf", "ibd"}:
        return "IBD"
    if label.upper() == "IBS":
        return "IBS"
    return label


def excel_files(folder):
    for path in sorted(folder.iterdir()):
        if path.suffix.lower() in {".xlsx", ".xls", ".csv"} and not path.name.startswith("~$"):
            yield path


def read_sheets(path):
    if path.suffix.lower() == ".csv":
        return [("CSV", pd.read_csv(path))]
    workbook = pd.ExcelFile(path)
    return [(sheet, pd.read_excel(path, sheet_name=sheet)) for sheet in workbook.sheet_names]


def detector_columns(df, sample_col=None):
    excluded = {"Diagnosis"}
    if sample_col:
        excluded.add(sample_col)
    columns = []
    for col in df.columns:
        if str(col).strip() in excluded:
            continue
        numeric = pd.to_numeric(df[col], errors="coerce")
        if numeric.notna().any():
            columns.append(col)
    return columns


def load_training():
    frames = []
    sources = []
    for path in excel_files(STUDY_DIR):
        for sheet, df in read_sheets(path):
            if "Diagnosis" not in df.columns:
                continue

            sample_col = "Sample name" if "Sample name" in df.columns else None
            if sample_col is None and "Sample code" in df.columns:
                sample_col = "Sample code"
            if sample_col is None:
                sample_col = df.columns[0]

            features = detector_columns(df, sample_col)
            if not features:
                continue

            part = df[[sample_col, *features, "Diagnosis"]].copy()
            part = part.rename(columns={sample_col: "Sample name"})
            part["Diagnosis"] = part["Diagnosis"].map(normalize_label)
            part = part[part["Diagnosis"].isin(["IBD", "IBS"])]
            frames.append(part)
            sources.append({"file": path.name, "sheet": sheet, "rows": int(len(part)), "features": [str(f) for f in features]})

    if not frames:
        raise RuntimeError("No usable study-case rows found.")

    combined = pd.concat(frames, ignore_index=True)
    feature_cols = [
        col
        for col in combined.columns
        if col not in {"Sample name", "Diagnosis"} and pd.to_numeric(combined[col], errors="coerce").notna().any()
    ]
    combined[feature_cols] = combined[feature_cols].apply(pd.to_numeric, errors="coerce")
    combined = combined.dropna(subset=["Diagnosis"])
    fill_values = combined[feature_cols].median(numeric_only=True)
    combined[feature_cols] = combined[feature_cols].fillna(fill_values)
    return combined, feature_cols, fill_values, sources


def load_unknown(path, feature_cols):
    for sheet, df in read_sheets(path):
        if "Sample name" in df.columns:
            available = [col for col in feature_cols if col in df.columns]
            if available:
                return sheet, df[["Sample name", *available]].copy()

        first_col = df.columns[0]
        detector_names = df[first_col].astype(str).str.strip().tolist()
        if set(feature_cols).issubset(set(detector_names)):
            transposed = df.set_index(first_col).T.reset_index().rename(columns={"index": "Sample name"})
            transposed.columns = [str(c).strip() for c in transposed.columns]
            return sheet, transposed[["Sample name", *feature_cols]].copy()

    raise RuntimeError(f"No usable unknown-sample sheet found in {path.name}.")


def learn_detector_bars(training, feature_cols):
    ibs_rows = training[training["Diagnosis"] == "IBS"]
    ibd_rows = training[training["Diagnosis"] == "IBD"]
    if ibs_rows.empty:
        raise RuntimeError("No IBS training samples found; cannot learn IBS-based threshold bars.")
    if ibd_rows.empty:
        raise RuntimeError("No IBD training samples found; cannot evaluate detector bars.")

    bars = {}
    for feature in feature_cols:
        ibs_values = pd.to_numeric(ibs_rows[feature], errors="coerce").dropna().astype(float)
        ibd_values = pd.to_numeric(ibd_rows[feature], errors="coerce").dropna().astype(float)
        if ibs_values.empty:
            raise RuntimeError(f"No usable IBS values found for detector {feature}.")
        if ibd_values.empty:
            raise RuntimeError(f"No usable IBD values found for detector {feature}.")

        count = int(ibs_values.count())
        average = float(ibs_values.mean())
        std = float(ibs_values.std(ddof=1)) if count > 1 else float("nan")
        maximum = float(ibs_values.max())

        if count < 3 or not math.isfinite(std) or std <= 0:
            candidates = [{"name": "max-based", "bar": maximum * 1.05, "formula": "IBS max + 5%"}]
        else:
            candidates = [
                {"name": "sensitive", "bar": average + (0.5 * std), "formula": "IBS average + 0.5xSD"},
                {"name": "balanced", "bar": average + std, "formula": "IBS average + 1xSD"},
                {"name": "moderately-strict", "bar": average + (1.5 * std), "formula": "IBS average + 1.5xSD"},
                {"name": "strict", "bar": average + (2 * std), "formula": "IBS average + 2xSD"},
            ]

        evaluated = []
        for candidate in candidates:
            bar = float(candidate["bar"])
            ibs_false_positive_count = int((ibs_values > bar * 1.05).sum())
            ibd_detected_count = int((ibd_values > bar * 1.05).sum())
            evaluated.append(
                {
                    **candidate,
                    "bar": bar,
                    "ibs_false_positive_count": ibs_false_positive_count,
                    "ibs_false_positive_rate": float(ibs_false_positive_count / len(ibs_values)),
                    "ibd_detected_count": ibd_detected_count,
                    "ibd_detected_rate": float(ibd_detected_count / len(ibd_values)),
                }
            )

        unacceptable_ibs_false_positive_rate = 0.05
        acceptable = [
            candidate
            for candidate in evaluated
            if candidate["ibs_false_positive_rate"] <= unacceptable_ibs_false_positive_rate
        ]
        if not acceptable:
            min_fp = min(candidate["ibs_false_positive_rate"] for candidate in evaluated)
            acceptable = [candidate for candidate in evaluated if candidate["ibs_false_positive_rate"] == min_fp]
            selected = sorted(
                acceptable,
                key=lambda candidate: (
                    -candidate["bar"],
                    -candidate["ibd_detected_rate"],
                ),
            )[0]
        else:
            selected = sorted(
                acceptable,
                key=lambda candidate: (
                    candidate["bar"],
                    -candidate["ibd_detected_rate"],
                    candidate["ibs_false_positive_rate"],
                ),
            )[0]

        bars[feature] = {
            "bar": float(selected["bar"]),
            "ibs_count": count,
            "ibs_average": average,
            "ibs_std": std if math.isfinite(std) else None,
            "ibs_maximum": maximum,
            "method": selected["formula"],
            "selected_candidate": selected["name"],
            "unacceptable_ibs_false_positive_rate": unacceptable_ibs_false_positive_rate,
            "candidate_evaluation": evaluated,
        }
    return bars


def detector_call(value, bar):
    value = float(value)
    if bar == 0:
        margin_percent = float("inf") if value > 0 else 0.0
    else:
        margin_percent = ((value - bar) / bar) * 100

    if value > bar * 1.05:
        call = "IBD-like"
    elif value < bar * 0.95:
        call = "IBS-like"
    else:
        call = "inconclusive"
    return call, float(margin_percent)


def final_classification(calls):
    if any(call == "IBD-like" for call in calls):
        return "IBD"
    if any(call == "inconclusive" for call in calls):
        return "inconclusive"
    return "IBS"


def confidence_level(verdict, detector_results):
    margins = [result["margin"] for result in detector_results]
    if verdict == "IBD":
        ibd_margins = [result["margin"] for result in detector_results if result["call"] == "IBD-like"]
        if len(ibd_margins) >= 3:
            return "high"
        if len(ibd_margins) == 2:
            return "high" if max(ibd_margins) >= 15 else "mid"
        strongest_margin = max(ibd_margins)
        if strongest_margin >= 25:
            return "high"
        if strongest_margin >= 15:
            return "mid"
        return "low"

    if verdict == "IBS":
        closest_to_bar = max(margins)
        if closest_to_bar <= -25:
            return "high"
        if closest_to_bar <= -15:
            return "mid"
        return "low"

    return ""


def main():
    RUN_DIR.mkdir(parents=True, exist_ok=True)
    training, feature_cols, fill_values, sources = load_training()
    bars = learn_detector_bars(training, feature_cols)
    trained_at = datetime.now(timezone.utc)
    run_date = trained_at.astimezone(ZoneInfo("Asia/Jerusalem")).strftime("%Y-%m-%d")

    run_summary = {
        "trained_at_utc": trained_at.isoformat(),
        "run_date": run_date,
        "training_rows": int(len(training)),
        "feature_order": [str(c) for c in feature_cols],
        "detector_bars": bars,
        "sources": sources,
        "outputs": [],
    }

    all_records = []
    for path in excel_files(UNKNOWN_DIR):
        sheet, unknown = load_unknown(path, feature_cols)
        unknown[feature_cols] = unknown[feature_cols].apply(pd.to_numeric, errors="coerce")
        unknown[feature_cols] = unknown[feature_cols].fillna(fill_values)

        for _, row in unknown.iterrows():
            calls = {}
            crossed = []
            detector_results = []
            record = {
                "Sample name": row["Sample name"],
            }
            for feature in feature_cols:
                bar = bars[feature]["bar"]
                call, margin = detector_call(row[feature], bar)
                calls[feature] = call
                detector_results.append({"detector": str(feature), "call": call, "margin": margin})
                record[f"{feature} bar"] = bar
                record[f"{feature} measurement"] = float(row[feature])
                record[f"{feature} assumption"] = call
                record[f"{feature} margin vs bar %"] = margin
                if call == "IBD-like":
                    crossed.append(str(feature))

            verdict = final_classification(calls.values())
            record["Verdict"] = verdict
            record["Confidence level"] = confidence_level(verdict, detector_results)
            record["Detector(s) crossed above bar"] = ", ".join(crossed) if crossed else "No detector crossed above bar"
            record["Source file"] = path.name
            record["Source sheet"] = sheet
            all_records.append(record)

    result = pd.DataFrame(all_records)
    output_json = RUN_DIR / "run-records.json"
    result.to_json(output_json, orient="records", indent=2)
    run_summary["outputs"].append(
        {
            "output_xlsx": f"results {run_date}.xlsx",
            "output_json": output_json.name,
            "rows": int(len(result)),
            "predictions": result["Verdict"].value_counts().to_dict(),
        }
    )

    summary_path = RUN_DIR / "threshold-bar-run-summary.json"
    summary_path.write_text(json.dumps(run_summary, indent=2), encoding="utf-8")
    print(json.dumps(run_summary, indent=2))


if __name__ == "__main__":
    main()
