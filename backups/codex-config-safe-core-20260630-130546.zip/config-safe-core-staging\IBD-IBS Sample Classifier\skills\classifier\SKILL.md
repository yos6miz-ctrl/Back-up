---
name: classifier
description: Classify unknown Excel samples with a simple per-detector threshold-bar model for the IBD-IBS Sample Classifier agent. Use when Codex needs to process files from Unknown sampels using detector-specific bars learned from IBS samples and write analyzed Excel outputs.
---

# Classifier

## Overview

Use this skill to classify unknown Excel sample files with the detector bars learned by the `machine-learning` skill in the same run. Keep the implementation simple and avoid probability models or complex machine-learning systems.

## Folder Contract

Use these folders relative to `C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier`:

- Unknown sample input: `Unknown sampels`
- Analyzed output: agent root folder
- Study-case source: `Study cases`

Read input files from `Unknown sampels`. Write one run-level Excel workbook directly to `C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier`.

## Detector Calls

For each unknown sample and each detector:

- If detector value is above `105%` of that detector's bar, call the detector `IBD-like`.
- If detector value is below `95%` of that detector's bar, call the detector `IBS-like`.
- If detector value is between `95%` and `105%` of that detector's bar, call the detector `inconclusive`.

Each detector uses only its own detector-specific bar.

## Final Classification

- If at least one detector is `IBD-like`, classify the sample as `IBD`.
- If no detector is `IBD-like` but at least one detector is `inconclusive`, classify the sample as `inconclusive`.
- If all detectors are `IBS-like`, classify the sample as `IBS`.

## Output

Create a single Excel file in the agent root folder named `results YYYY-MM-DD.xlsx`, for example `results 2026-05-28.xlsx`.

The workbook should contain one sheet with one row per unknown sample and these values:

1. Sample name
2. Detector values and detector assumptions, with `PA447` before `araE` when both are present
3. Final classification
4. Confidence level: `high`, `mid`, or `low`, at the far right of the sheet

Calculate confidence from how far the detector margins are from the 95% to 105% decision zone. IBD calls become high confidence when three or more detectors are IBD-like, or when two IBD-like detectors include at least one moderate/strong margin. Two weak IBD-like detectors should be mid confidence. IBD calls also become more confident when one detector is far above the IBD-like boundary. IBS calls become more confident when every detector is well below the bar. Inconclusive verdicts should leave confidence blank.

Color detector assumption cells as light red for `IBD-like`, light yellow for `IBS-like`, and light purple for `inconclusive`. Color final verdict cells red for `IBD`, yellow for `IBS`, and purple for `inconclusive`.
Color confidence cells green for `high`, yellow for `mid`, and light red for `low`.

Do not write JSON files, preview images, or one workbook per input file to the agent root folder. Do not recreate the old `Classified sampels` folder.
