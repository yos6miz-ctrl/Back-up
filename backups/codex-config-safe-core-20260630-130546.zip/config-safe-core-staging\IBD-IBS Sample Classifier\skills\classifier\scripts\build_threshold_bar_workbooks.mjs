import fs from "node:fs/promises";
import { createRequire } from "node:module";
import path from "node:path";

const require = createRequire(import.meta.url);
const { SpreadsheetFile, Workbook } = require("@oai/artifact-tool");

const baseDir = "C:\\Users\\Popovtzer lab\\.codex\\IBD-IBS Sample Classifier";
const outputDir = baseDir;
const legacyOutputDir = path.join(baseDir, "Classified sampels");
const runDir = path.join(baseDir, "skills", "classifier", "scripts", ".run");
const summary = JSON.parse(await fs.readFile(path.join(runDir, "threshold-bar-run-summary.json"), "utf8"));

await fs.mkdir(outputDir, { recursive: true });
await fs.rm(legacyOutputDir, { recursive: true, force: true });
for (const entry of await fs.readdir(outputDir, { withFileTypes: true })) {
  if (entry.isFile() && /^results \d{4}-\d{2}-\d{2}\.xlsx$/i.test(entry.name)) {
    await fs.rm(path.join(outputDir, entry.name), { force: true });
  }
}

const output = summary.outputs[0];
const records = JSON.parse(await fs.readFile(path.join(runDir, output.output_json), "utf8"));
const detectors = summary.feature_order ?? [];
const detectorMeasurementHeader = (detector) => `${detector}`;
const detectorAssumptionHeader = (detector) => `${detector} assumption`;
const headers = [
  "Sample name",
  ...detectors.flatMap((detector) => [detectorMeasurementHeader(detector), detectorAssumptionHeader(detector)]),
  "Verdict",
  "Confidence level",
];
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const displayLength = (value) => {
  if (value === null || value === undefined) {
    return 0;
  }
  if (typeof value === "number") {
    return Number.isInteger(value) ? String(value).length : value.toPrecision(8).replace(/0+$/, "").length;
  }
  return String(value).length;
};

const workbook = Workbook.create();
const results = workbook.worksheets.add("Classified samples");
const verdictColors = {
  IBD: { fill: "#E6A6A1", font: { bold: true, color: "#7F0000" }, horizontalAlignment: "center" },
  IBS: { fill: "#BDD7EE", font: { bold: true, color: "#17365D" }, horizontalAlignment: "center" },
  inconclusive: { fill: "#D7BDEB", font: { bold: true, color: "#5F497A" }, horizontalAlignment: "center" },
};
const detectorCallColors = {
  "IBD-like": { fill: "#F4C7C3", font: { bold: true, color: "#7F0000" }, horizontalAlignment: "center" },
  "IBS-like": { fill: "#DDEBF7", font: { bold: true, color: "#17365D" }, horizontalAlignment: "center" },
  inconclusive: { fill: "#EADCF8", font: { bold: true, color: "#5F497A" }, horizontalAlignment: "center" },
};
const confidenceColors = {
  high: { fill: "#E2F0D9", font: { bold: true, color: "#375623" }, horizontalAlignment: "center" },
  mid: { fill: "#FFF2CC", font: { bold: true, color: "#7F6000" }, horizontalAlignment: "center" },
  low: { fill: "#FCE4D6", font: { bold: true, color: "#833C0C" }, horizontalAlignment: "center" },
};

results.getRangeByIndexes(0, 0, 1, headers.length).values = [headers];
if (records.length) {
  results.getRangeByIndexes(1, 0, records.length, headers.length).values = records.map((row) =>
    headers.map((header) => {
      for (const detector of detectors) {
        if (header === detectorMeasurementHeader(detector)) {
          return row[`${detector} measurement`] ?? null;
        }
        if (header === detectorAssumptionHeader(detector)) {
          return row[`${detector} assumption`] ?? null;
        }
      }
      return row[header] ?? null;
    }),
  );
}
results.getRangeByIndexes(0, 0, 1, headers.length).format = {
  fill: "#D9D9D9",
  font: { bold: true, color: "#000000" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
};
results.getRangeByIndexes(0, 0, Math.max(records.length + 1, 2), headers.length).format = {
  borders: {
    all: { color: "#D9D9D9", style: "Continuous", weight: "Thin" },
  },
  font: { color: "#000000" },
  verticalAlignment: "center",
};
results.getRangeByIndexes(0, 0, 1, headers.length).format = {
  fill: "#D9D9D9",
  font: { bold: true, color: "#000000" },
  horizontalAlignment: "center",
  verticalAlignment: "center",
  borders: {
    all: { color: "#D9D9D9", style: "Continuous", weight: "Thin" },
  },
};
records.forEach((row, rowIndex) => {
  const sheetRow = rowIndex + 1;
  const verdictFormat = verdictColors[row.Verdict];
  if (verdictFormat) {
    results.getRangeByIndexes(sheetRow, headers.indexOf("Verdict"), 1, 1).format = verdictFormat;
  }
  const confidenceFormat = confidenceColors[row["Confidence level"]];
  if (confidenceFormat) {
    results.getRangeByIndexes(sheetRow, headers.indexOf("Confidence level"), 1, 1).format = confidenceFormat;
  }

  detectors.forEach((detector, detectorIndex) => {
    const assumption = row[`${detector} assumption`];
    const assumptionFormat = detectorCallColors[assumption];
    if (assumptionFormat) {
      const assumptionColumn = headers.indexOf(detectorAssumptionHeader(detector));
      results.getRangeByIndexes(sheetRow, assumptionColumn, 1, 1).format = assumptionFormat;
    }
  });
});
results.freezePanes.freezeRows(1);
headers.forEach((header, columnIndex) => {
  const longest = Math.max(
    displayLength(header),
    ...records.map((row) => displayLength(row[header])),
  );
  const minimumWidth = header.includes("assumption") ? 145 : 105;
  const widthPx = clamp((longest * 9) + 34, minimumWidth, 260);
  const columnRange = results.getRangeByIndexes(0, columnIndex, Math.max(records.length + 1, 2), 1);
  columnRange.format.columnWidthPx = widthPx;
  columnRange.format.wrapText = false;
});

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
const savedXlsx = output.output_xlsx;
await xlsx.save(path.join(outputDir, savedXlsx));

console.log(JSON.stringify({ generated: [savedXlsx] }, null, 2));
