# IBD-IBS Sample Classifier

Agent for classifying unknown samples as IBD, IBS, or inconclusive using detector-specific threshold bars learned from known study cases.

## Folder Layout

- `Study cases/` contains known labeled Excel files with sample names, detector measurements, and diagnosis.
- `Unknown sampels/` contains unknown Excel files to classify.
- `skills/machine-learning/` describes the learning workflow.
- `skills/classifier/` contains the classifier workflow and scripts.
- `results YYYY-MM-DD.xlsx` is the generated result workbook for a run.

## Classification Method

Each detector is treated independently. For each detector, the classifier learns an IBS-based threshold bar from the known labeled study cases, evaluates candidate bars against known IBD and IBS samples, and chooses a detector-specific bar.

For each unknown sample:

- Values above `105%` of the detector bar are called `IBD-like`.
- Values below `95%` of the detector bar are called `IBS-like`.
- Values between `95%` and `105%` are called `inconclusive`.

Final verdict:

- At least one `IBD-like` detector gives an `IBD` verdict.
- No `IBD-like` detectors but at least one `inconclusive` detector gives an `inconclusive` verdict.
- All detectors `IBS-like` gives an `IBS` verdict.

## Output

The output workbook is saved in the agent root folder as:

`results YYYY-MM-DD.xlsx`

The workbook includes sample name, detector values, detector assumptions, final verdict, and confidence level.
