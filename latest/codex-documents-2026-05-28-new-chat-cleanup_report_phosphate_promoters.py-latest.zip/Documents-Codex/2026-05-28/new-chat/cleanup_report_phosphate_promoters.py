from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
REPORT = "\u05d3\u05d5\u05d7 \u05d0\u05d1\u05e0\u05d9 \u05d3\u05e8\u05da - \u05d3\u05d9\u05e8\u05d5\u05d2 \u05e4\u05e8\u05d5\u05de\u05d5\u05d8\u05d5\u05e8\u05d9\u05dd \u05de\u05e9\u05d5\u05d1\u05d8\u05d9\u05dd.docx"
LRM = "\u200e"
PP_2656 = f"{LRM}PP_2656{LRM}"
PP_5329 = f"{LRM}PP_5329{LRM}"
PHOSPHATE = "\u05e4\u05d5\u05e1\u05e4\u05d8"
INK = RGBColor(20, 20, 20)


def set_run_font(run, size=10.8, color=INK, name="Arial") -> None:
    run.font.name = name
    r_pr = run._element.get_or_add_rPr()
    fonts = r_pr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        r_pr.append(fonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        fonts.set(qn(attr), name)
    run.font.size = Pt(size)
    run.font.color.rgb = color
    lang = r_pr.find(qn("w:lang"))
    if lang is None:
        lang = OxmlElement("w:lang")
        r_pr.append(lang)
    lang.set(qn("w:bidi"), "he-IL")


def set_rtl(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_pr = paragraph._p.get_or_add_pPr()
    if p_pr.find(qn("w:bidi")) is None:
        p_pr.append(OxmlElement("w:bidi"))


def replace_paragraph_text(paragraph, text: str, size=10.8) -> None:
    paragraph.text = ""
    set_rtl(paragraph)
    run = paragraph.add_run(text)
    set_run_font(run, size=size)


def plain(text: str) -> str:
    return text.replace(LRM, "")


def main() -> None:
    path = Path.home() / ".codex" / PROJECT / REPORT
    doc = Document(path)

    section_text = (
        f"\u05d1\u05d3\u05d8\u05e7\u05d8\u05d5\u05e8\u05d9 {PHOSPHATE}, "
        f"\u05e0\u05d1\u05e0\u05d5 \u05d5\u05e0\u05d1\u05d3\u05e7\u05d5 \u05e9\u05e0\u05d9 \u05e4\u05e8\u05d5\u05de\u05d5\u05d8\u05d5\u05e8\u05d9\u05dd, {PP_2656} \u05d5-{PP_5329}, "
        "\u05d0\u05da \u05e9\u05e0\u05d9\u05d4\u05dd \u05dc\u05d0 \u05e2\u05d1\u05d3\u05d5 \u05d5\u05dc\u05d0 \u05e1\u05d9\u05e4\u05e7\u05d5 \u05ea\u05d2\u05d5\u05d1\u05d4 \u05e1\u05e4\u05e6\u05d9\u05e4\u05d9\u05ea \u05de\u05e1\u05e4\u05e7\u05ea. "
        f"\u05dc\u05db\u05df \u05d0\u05d9\u05df \u05e2\u05d3\u05d9\u05d9\u05df \u05de\u05d3\u05d9\u05d3\u05d4 \u05db\u05de\u05d5\u05ea\u05d9\u05ea \u05ea\u05e7\u05e4\u05d4 \u05dc\u05d3\u05d9\u05e8\u05d5\u05d2 \u05e2\u05d1\u05d5\u05e8 {PHOSPHATE}. "
        "\u05d1\u05d3\u05d8\u05e7\u05d8\u05d5\u05e8 \u05d4\u05d0\u05dc\u05e7\u05e0\u05d9\u05dd, \u05e7\u05d9\u05d9\u05de\u05ea \u05e2\u05d3\u05d9\u05d9\u05df \u05d1\u05e2\u05d9\u05d9\u05ea \u05d9\u05e6\u05d9\u05d1\u05d5\u05ea \u05d1\u05e7\u05d5\u05e0\u05e1\u05d8\u05e8\u05e7\u05d8, "
        "\u05d5\u05dc\u05db\u05df \u05d0\u05d9\u05df \u05e2\u05d3\u05d9\u05d9\u05df \u05de\u05d3\u05d9\u05d3\u05d4 \u05db\u05de\u05d5\u05ea\u05d9\u05ea \u05ea\u05e7\u05e4\u05d4 \u05dc\u05d3\u05d9\u05e8\u05d5\u05d2."
    )
    for paragraph in doc.paragraphs:
        text = plain(paragraph.text)
        if text.startswith(f"\u05d1\u05d3\u05d8\u05e7\u05d8\u05d5\u05e8\u05d9 {PHOSPHATE},"):
            replace_paragraph_text(paragraph, section_text)

    label = f"{PHOSPHATE} ({PP_2656}, {PP_5329})"
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if plain(cell.text).strip() == PHOSPHATE:
                    replace_paragraph_text(cell.paragraphs[0], label, size=8.2)

    doc.save(path)
    print(str(path).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
