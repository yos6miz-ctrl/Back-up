from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import re

import openpyxl


ALIQUOTS = Path("aliqauts 20260801 working copy.xlsx")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
REPORT = Path("longitudinal_diagnosis_audit_report.json")


def clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def norm(value):
    return re.sub(r"[^A-Z0-9]+", "", clean(value).upper())


def parse_date(value):
    if hasattr(value, "date"):
        return value.date()
    text = clean(value)
    for fmt in ("%d.%m.%y", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def final_header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def source_records():
    wb = openpyxl.load_workbook(ALIQUOTS, data_only=True, read_only=True)
    records = []

    ws = wb["מתלקחים CD (blind)"]
    groups = {}
    for row in range(2, ws.max_row + 1):
        patient = clean(ws.cell(row, 6).value)
        sample = clean(ws.cell(row, 8).value)
        synonym = clean(ws.cell(row, 12).value)
        sample_date = parse_date(ws.cell(row, 7).value)
        if not patient or not sample or sample.lower() in {"sample name (f)", "sample"}:
            continue
        groups.setdefault(patient, []).append(
            {
                "sheet": ws.title,
                "aliquot_row": row,
                "patient": patient,
                "sample": sample,
                "synonym": synonym,
                "date": sample_date,
            }
        )

    for patient, items in groups.items():
        items.sort(key=lambda item: (item["date"] or datetime.max.date(), item["aliquot_row"]))
        for index, item in enumerate(items, start=1):
            records.append(
                {
                    **item,
                    "expected_diagnosis": "CDf" if index == len(items) else "CDr",
                    "expected_longitudinal": index,
                    "set_count": len(items),
                }
            )

    ws = wb["CD רמיסיה (blind)"]
    for row in range(2, ws.max_row + 1):
        sample = clean(ws.cell(row, 6).value)
        synonym = clean(ws.cell(row, 10).value)
        sample_date = parse_date(ws.cell(row, 5).value)
        if not sample or sample.lower() == "sample" or not norm(sample):
            continue
        records.append(
            {
                "sheet": ws.title,
                "aliquot_row": row,
                "patient": re.sub(r"\D", "", synonym) or synonym,
                "sample": sample,
                "synonym": synonym,
                "date": sample_date,
                "expected_diagnosis": "CDr",
                "expected_longitudinal": None,
                "set_count": None,
            }
        )
    return records


def main():
    records = source_records()
    try:
        wb = openpyxl.load_workbook(FINAL, data_only=True, read_only=True)
        final_path = FINAL
    except PermissionError:
        wb = openpyxl.load_workbook(CODEX_FINAL, data_only=True, read_only=True)
        final_path = CODEX_FINAL
    ws = wb["Final"]
    headers = final_header_map(ws)

    by_key = {}
    for row in range(2, ws.max_row + 1):
        keys = {
            norm(ws.cell(row, headers["Primary name"]).value),
            norm(ws.cell(row, headers["Secondary / other name"]).value),
        } - {""}
        for key in keys:
            by_key.setdefault(key, []).append(row)

    matches = []
    missing = []
    diagnosis_mismatches = []
    longitudinal_mismatches = []
    for record in records:
        keys = {norm(record["sample"]), norm(record["synonym"])} - {""}
        found = sorted({row for key in keys for row in by_key.get(key, [])})
        if not found:
            missing.append(record)
            continue
        for row in found:
            item = {
                **record,
                "final_row": row,
                "primary": ws.cell(row, headers["Primary name"]).value,
                "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                "current_diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                "current_longitudinal": ws.cell(row, headers["Longitudinal sample"]).value,
                "final_decision": ws.cell(row, headers["Final classification / decision"]).value,
                "sample_date": ws.cell(row, headers["Sample date"]).value,
            }
            matches.append(item)
            if item["current_diagnosis"] != item["expected_diagnosis"]:
                diagnosis_mismatches.append(item)
            expected_longitudinal = item["expected_longitudinal"]
            if expected_longitudinal is not None and item["current_longitudinal"] != expected_longitudinal:
                longitudinal_mismatches.append(item)

    report = {
        "final_path_read": str(final_path),
        "records": len(records),
        "matches": matches,
        "missing": missing,
        "diagnosis_mismatches": diagnosis_mismatches,
        "longitudinal_mismatches": longitudinal_mismatches,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, default=str, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
