from __future__ import annotations

import json
import shutil
import zipfile
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ALIQUOTS_ONEDRIVE = ROOT / "aliqauts 20260801.xlsx"
ALIQUOTS_WORKING = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
REPORT = WORKSPACE / "make_aliquot_box_numbers_visible_report.json"

BOX_BY_SAMPLE_CDF = {
    "F-SB-2067": "1,4,2",
    "F-IP-20191": "1,4,2",
    "F-PM-20543": "1,4,2",
    "CT-132": "1,4,3",
    "CT-238": "1,4,3",
    "CT-344": "1,4,3",
    "CT-130": "1,4,4",
    "CT-412": "1,4,4",
    "CT-203": "2,1,1",
    "CT-233": "2,1,1",
    "DY-247": "2,1,1",
    "CT-235": "2,1,1",
    "CT-156": "2,1,2",
    "CT1156; F-YD-21156": "2,1,2",
    "CT-463": "2,1,3",
    "CT535": "2,1,3",
    "F-DBH-164": "2,1,3",
    "F-AM-170": "2,1,3",
    "CT-433": "2,1,3",
    "CT-459": "2,1,3",
}

BOX_BY_SAMPLE_UC = {
    "F-DS-20527": "1,4,2",
    "CT113": "2,1,2",
    "CT-163": "3,1,2",
    "CT-167": "3,1,2",
    "CT-187": "3,1,2",
    "CT-229": "3,1,2",
    "CT-270": "3,1,2",
    "CT-222": "3,1,3",
    "CT-241": "3,1,3",
    "CT-245": "3,1,3",
    "CT-247": "3,1,3",
    "CT-258": "3,1,3",
}


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def sample_key(value):
    return clean(value).upper()


def health(path):
    with zipfile.ZipFile(path) as zf:
        return {"bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def unmerge_box_column(ws):
    removed = []
    for merged in list(ws.merged_cells.ranges):
        if merged.min_col <= 2 <= merged.max_col:
            removed.append(str(merged))
            ws.unmerge_cells(str(merged))
    return removed


def fill_boxes(ws, mapping):
    changed = []
    missing_expected = []
    for row in range(2, ws.max_row + 1):
        sample = sample_key(ws.cell(row, 4).value)
        expected = None
        for name, box in mapping.items():
            if sample_key(name) == sample:
                expected = box
                break
        if expected:
            before = ws.cell(row, 2).value
            ws.cell(row, 2).value = expected
            ws.cell(row, 2).alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            if before != expected:
                changed.append({"row": row, "sample": ws.cell(row, 4).value, "before": before, "after": expected})
        elif sample:
            # Leave rows without a known box untouched/blank; record for transparency.
            if ws.cell(row, 2).value not in (None, ""):
                ws.cell(row, 2).value = None
    for name, box in mapping.items():
        found = False
        for row in range(2, ws.max_row + 1):
            if sample_key(ws.cell(row, 4).value) == sample_key(name) and ws.cell(row, 2).value == box:
                found = True
                break
        if not found:
            missing_expected.append({"sample": name, "expected_box": box})
    return changed, missing_expected


def sheet_rows(ws):
    return [
        {
            "row": row,
            "group": ws.cell(row, 1).value,
            "box": ws.cell(row, 2).value,
            "patient": ws.cell(row, 3).value,
            "sample": ws.cell(row, 4).value,
        }
        for row in range(1, ws.max_row + 1)
    ]


def main():
    wb = openpyxl.load_workbook(ALIQUOTS_ONEDRIVE)
    report = {"sheets": {}}
    for sheet_name, mapping in {"CDf": BOX_BY_SAMPLE_CDF, "UC": BOX_BY_SAMPLE_UC}.items():
        ws = wb[sheet_name]
        before = sheet_rows(ws)
        removed_merges = unmerge_box_column(ws)
        changed, missing_expected = fill_boxes(ws, mapping)
        after = sheet_rows(ws)
        report["sheets"][sheet_name] = {
            "removed_box_merges": removed_merges,
            "changed_count": len(changed),
            "changed": changed,
            "missing_expected_count": len(missing_expected),
            "missing_expected": missing_expected,
            "before": before,
            "after": after,
        }

    wb.save(ALIQUOTS_ONEDRIVE)
    wb.close()
    shutil.copy2(ALIQUOTS_ONEDRIVE, ALIQUOTS_WORKING)
    report["health"] = {
        "onedrive": health(ALIQUOTS_ONEDRIVE),
        "working_copy": health(ALIQUOTS_WORKING),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
