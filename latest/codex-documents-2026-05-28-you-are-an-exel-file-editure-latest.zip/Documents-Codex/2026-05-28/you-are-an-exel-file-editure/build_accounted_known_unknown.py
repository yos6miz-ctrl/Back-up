from collections import Counter, defaultdict
from pathlib import Path
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


FOLDER = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
SOURCE_FOLDER = FOLDER / "deta" if (FOLDER / "deta").exists() else FOLDER
OUTPUT_PATH = FOLDER / "Merged Unknowns trial 6.26.xlsx"
NAMES_PATH = SOURCE_FOLDER / "UN stool names.xlsx"
TRIAL_PATH = SOURCE_FOLDER / "Unknowns trial 6.26.xlsx"
OLD_PATH = SOURCE_FOLDER / "IBD IBS OLD.xlsx"
ALIQUOTS_PATH = SOURCE_FOLDER / "aliqauts 20250112.xlsx"
ALL_PATH = SOURCE_FOLDER / "447 and araE ALL.xlsx"
OLD_447_ROOT = FOLDER / "447-old"
NEW_447_ROOT = FOLDER / "447 new"
NOT_CHECKED = "לא נבדק"
MISSING = "missing"
OLD_METERING_SYSTEM = "old metering system"
IGNORED_MISSING_SAMPLE_CODES = {"F-KH-2133"}

MANUAL_SAMPLE_ALIASES = [
    ("F-HS-2153", "UN153"),
    ("F-LB-18373", "CDf 373", "CD 373"),
    ("F-ES-23103", "UN F ES23103", "UN FES103", "447 UN F ES23103"),
    ("F-MM-25109", "UN FMM109", "F-MM-109", "447 UN FMM109"),
    ("F-AA-19113", "UN FAA113", "CDf F-AA-19113"),
    ("UN F AP24104", "UN104"),
    ("UN F IS19195", "UN195"),
    ("UN F SL18363", "UN363"),
    ("UN F DB19557", "UN557"),
    ("UN F DM19582", "UN582"),
    ("UN F AL181", "UN181"),
    ("UN F MR2056", "UN56"),
    ("SHR-22194", "CDf 157SHR", "CDf 157SHR3"),
    ("CT535", "CDf 535", "535"),
    ("F-AS19535", "CDf F-AS19535", "CDf 535 old", "old 535"),
    ("F-RA-21458", "UN FBA 548", "UN FBA 458"),
    ("F-ALA-20671", "CDf 78AL2", "CDf 78ALA2"),
    ("CT113", "CDf old 113", "CDf 113"),
    ("CT1156", "CDf old 1156", "CDf 1156 old"),
    ("F-ALA-20455", "CDr 78AL1", "CDr 78ALA1"),
    ("CT621", "HS 621", "HS621"),
    ("CT642", "HS642", "HS 642"),
    ("CT-694", "HS 649", "HS649"),
    ("CT661", "HS 661", "HS661"),
    ("CT683", "HS 683", "HS683"),
    ("CT684", "HS 684", "HS684"),
    ("F-YG-2386", "IBS 2386", "IBS8623", "IBS 8623", "IBS YG2386"),
    ("F-AP-2390", "IBS 2390", "IBS 9023", "IBS AP2390", "IBS AP-2390"),
    ("F-BZ-2387", "IBS 2387", "IBS8723", "IBS 8723", "IBS BZ2387", "IBS BZ-2387"),
]

MANUAL_KNOWN_RECORDS = [
    ("CT621", "HS 621", "Healthy"),
    ("CT642", "HS642", "Healthy"),
    ("CT661", "HS 661", "Healthy"),
    ("CT683", "HS 683", "Healthy"),
    ("CT684", "HS 684", "Healthy"),
]


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def norm(value):
    text = clean(value)
    if not text:
        return ""
    text = text.upper()
    text = re.sub(r"\([^)]*\)", "", text)
    text = re.sub(r"^UN[\s\-_]*", "", text)
    return re.sub(r"[^A-Z0-9]", "", text)


def old_core(value):
    text = clean(value)
    if not text:
        return ""
    text = text.upper()
    text = re.sub(r"^(P447|PA0447|PA447)\s*", "", text)
    text = re.sub(r"^(CDF|CDR|IBS|UCF|UCR|UC|CD|HS|H|HEALTHY)[\s\-]*", "", text)
    return norm(text)


def old_group(value):
    text = (clean(value) or "").upper()
    match = re.match(r"^(CDF|CDR|IBS|UCF|UCR|UC|HS|H|HEALTHY)\b", text)
    return canonical_group(match.group(1)) if match else None


def canonical_group(value):
    text = clean(value)
    if not text:
        return None
    lookup = {
        "CDF": "CDf",
        "CD F": "CDf",
        "CDR": "CDr",
        "CD R": "CDr",
        "IBS": "IBS",
        "(IBS CONTROLS)": "IBS",
        "IBS CONTROLS": "IBS",
        "IBS CONTROL": "IBS",
        "HEALTHY": "Healthy",
        "HS": "Healthy",
        "H": "Healthy",
        "UCF": "UCf",
        "UCR": "UCr",
        "UC": "UC",
        "IBD": "IBD",
    }
    return lookup.get(text.upper(), text)


def diagnosis_family(value):
    group = canonical_group(value)
    if not group:
        return None
    text = group.upper()
    if text in {"CDF", "CDR", "UCF", "UCR", "UC", "IBD"}:
        return "IBD"
    if text == "IBS":
        return "IBS"
    if text == "HEALTHY":
        return "Healthy"
    return text


def compatible(left, right):
    left_family = diagnosis_family(left)
    right_family = diagnosis_family(right)
    if not left_family or not right_family:
        return True
    if left_family == right_family:
        return True
    return canonical_group(left) == canonical_group(right)


def date_text(value):
    if value is None:
        return None
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return clean(value)


def numeric_variants(key):
    if not key or not key.isdigit():
        return set()
    number = str(int(key))
    return {number, number.zfill(3), number.zfill(4)}


def identifier_variants(*values):
    variants = set()
    for value in values:
        for key in {norm(value), old_core(value)}:
            if not key:
                continue
            variants.add(key)
            variants.update(numeric_variants(key))
            if key.startswith("F") and len(key) > 1:
                variants.add(key[1:])
            match = re.match(r"F([A-Z]+)(\d{2})(\d{3})$", key)
            if match:
                variants.add(f"{match.group(1)}{match.group(3)}")
            sample_match = re.match(r"(CT|HS)(\d+)$", key)
            if sample_match:
                number = sample_match.group(2)
                variants.add(number)
                variants.update(numeric_variants(number))
                variants.add(f"CT{number}")
                variants.add(f"HS{number}")
            old_sample_match = re.match(r"CD(\d+)$", key)
            if old_sample_match:
                number = old_sample_match.group(1)
                variants.add(number)
                variants.update(numeric_variants(number))
                variants.add(f"CT{number}")
                variants.add(f"HS{number}")
                variants.add(f"CD{number}")
    return {value for value in variants if value}


def strict_identifier_variants(*values):
    variants = set()
    for value in values:
        for key in {norm(value), old_core(value)}:
            if not key:
                continue
            variants.add(key)
            if key.startswith("F") and len(key) > 1:
                variants.add(key[1:])
    return variants


def keys_for_names(*names):
    keys = set()
    for name in names:
        keys.update(identifier_variants(name))
        keys.update(strict_identifier_variants(name))
    return {key for key in keys if key}


def apply_manual_aliases(aliases_by_key):
    for names in MANUAL_SAMPLE_ALIASES:
        keys = keys_for_names(*names)
        for key in keys:
            aliases_by_key[key].update(keys)


def manual_alias_match(record, item):
    record_keys = record.get("identifiers", set()) | record.get("strict_identifiers", set())
    item_keys = item.get("identifiers", set()) | item.get("strict_identifiers", set())
    for names in MANUAL_SAMPLE_ALIASES:
        keys = keys_for_names(*names)
        if record_keys & keys and item_keys & keys:
            return True
    return False


def final_decision(first, second):
    values = [
        str(value).strip().lower()
        for value in [first, second]
        if value is not None and str(value).strip()
    ]
    if not values:
        return None
    if "pos" in values:
        return "IBD"
    if len(values) == 2 and all(value == "neg" for value in values):
        return "IBS"
    if "int" in values:
        return "Int"
    return None


def detector_decision(value, detector):
    if value in (None, ""):
        return None
    threshold = 0.215 if detector == "PA447" else 0.15
    return "Pos" if float(value) >= threshold else "Neg"


def average(values):
    nums = [float(value) for value in values if isinstance(value, (int, float))]
    if not nums:
        return None
    return sum(nums) / len(nums)


def header_text(value):
    return (clean(value) or "").lower()


def is_header_row(values):
    headers = [header_text(value) for value in values]
    joined = " ".join(headers)
    return (
        ("sample" in joined or "patient" in joined or "מספר מטופל" in joined)
        and ("aliquot" in joined or "date" in joined or "תאריך" in joined or "sample" in joined)
    )


def first_col_diagnosis(sheet_name, value):
    text = clean(value)
    if text and text.upper() in {"UCF", "UCR", "UC", "CDF", "CDR", "IBS", "H"}:
        return canonical_group(text)
    if sheet_name == "CDf":
        return "CDf"
    if sheet_name == "CDr":
        return "CDr"
    if sheet_name == "IBS":
        return "IBS"
    if sheet_name == "Healthy":
        return "Healthy"
    if sheet_name == "UC":
        return "UC"
    if "מתלקחים" in sheet_name:
        return "CDf"
    if "רמיסיה" in sheet_name:
        return "CDr"
    return canonical_group(sheet_name)


def column_index(headers, predicate):
    for index, header in enumerate(headers):
        if predicate(header):
            return index
    return None


def patient_column_index(headers):
    # Prefer visit/sample aliases such as 25AA1 over separate numeric patient IDs.
    for predicate in [
        lambda header: "patient number" in header,
        lambda header: header == "name",
        lambda header: "מספר מטופל" in header,
    ]:
        index = column_index(headers, predicate)
        if index is not None:
            return index
    return None


def load_aliquots_inventory():
    wb = load_workbook(ALIQUOTS_PATH, data_only=True)
    records = []
    aliases_by_key = defaultdict(set)
    rows_by_key = defaultdict(list)

    for ws in wb.worksheets:
        headers = []
        carry_group = first_col_diagnosis(ws.title, None)
        for row_index, raw in enumerate(ws.iter_rows(values_only=True), start=1):
            row = list(raw)
            if is_header_row(row):
                headers = [header_text(value) for value in row]
                continue
            if not headers or not any(clean(value) for value in row):
                continue

            sample_col = column_index(
                headers,
                lambda header: "sample name" in header
                or "sample #" in header
                or header == "sample"
                or "קוד דגימה" in header,
            )
            patient_col = patient_column_index(headers)
            date_col = column_index(
                headers,
                lambda header: header == "date" or "תאריך ביקור" in header,
            )
            disease_col = column_index(
                headers,
                lambda header: header.strip() == "disease" or header.strip() == "disease ",
            )

            group_value = clean(row[0]) if row else None
            if group_value and group_value.upper() in {"UCF", "UCR", "UC", "CDF", "CDR", "IBS", "H"}:
                carry_group = canonical_group(group_value)

            sample = clean(row[sample_col]) if sample_col is not None and sample_col < len(row) else None
            patient = clean(row[patient_col]) if patient_col is not None and patient_col < len(row) else None
            if sample and sample.lower() in {"sample", "sample #", "sample name (f)"}:
                continue
            if patient and patient.lower() in {"patient number", "name", "מספר מטופל"}:
                continue
            if not sample and not patient:
                continue

            disease = clean(row[disease_col]) if disease_col is not None and disease_col < len(row) else None
            diagnosis = canonical_group(disease) or carry_group or first_col_diagnosis(ws.title, None)
            sample_date = date_text(row[date_col]) if date_col is not None and date_col < len(row) else None
            identifiers = identifier_variants(sample, patient)
            if not identifiers:
                continue

            record = {
                "sample_name": sample or patient,
                "other_name": patient if sample and patient and clean(sample) != clean(patient) else None,
                "raw_sample_name": sample,
                "patient_name": patient,
                "diagnosis": diagnosis,
                "sample_date": sample_date,
                "sent_date": None,
                "source_sheet": ws.title,
                "source_row": row_index,
                "identifiers": identifiers,
                "strict_identifiers": strict_identifier_variants(sample, patient),
                "source": "aliqauts 20250112",
                "not_checked": False,
            }
            records.append(record)
            for key in identifiers:
                rows_by_key[key].append(record)
                aliases_by_key[key].update(identifiers)

    existing_target_keys = set().union(*(record["identifiers"] for record in records)) if records else set()
    for sample_name, other_name, diagnosis in MANUAL_KNOWN_RECORDS:
        target_keys = keys_for_names(sample_name)
        if target_keys & existing_target_keys:
            continue
        identifiers = keys_for_names(sample_name, other_name)
        record = {
            "sample_name": sample_name,
            "other_name": other_name,
            "raw_sample_name": sample_name,
            "patient_name": other_name,
            "diagnosis": canonical_group(diagnosis),
            "sample_date": None,
            "sent_date": None,
            "source_sheet": "manual mappings",
            "source_row": None,
            "identifiers": identifiers,
            "strict_identifiers": strict_identifier_variants(sample_name, other_name),
            "source": "manual mapping from measurement-folder audit",
            "not_checked": False,
        }
        records.append(record)
        existing_target_keys.update(target_keys)
        for key in identifiers:
            rows_by_key[key].append(record)
            aliases_by_key[key].update(identifiers)

    apply_manual_aliases(aliases_by_key)

    return records, aliases_by_key, rows_by_key


def expand_with_aliases(keys, aliases_by_key):
    variants = set(keys)
    queue = list(keys)
    while queue:
        key = queue.pop()
        for alias in aliases_by_key.get(key, set()):
            if alias not in variants:
                variants.add(alias)
                queue.append(alias)
    return variants


def load_missing_rows():
    paths = list(SOURCE_FOLDER.glob("*5.7.26*.xlsx"))
    if not paths:
        return []
    wb = load_workbook(paths[0], data_only=True)
    ws = wb.active
    rows = []
    for row_index, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        group, code, sample_date, status, sent_date = row[:5]
        code = clean(code)
        if not code:
            continue
        if code in IGNORED_MISSING_SAMPLE_CODES:
            continue
        status_text = clean(status) or ""
        rows.append(
            {
                "sample_name": code,
                "other_name": None,
                "diagnosis": canonical_group(group),
                "sample_date": date_text(sample_date),
                "sent_date": date_text(sent_date),
                "source_sheet": "missing samples",
                "source_row": row_index,
                "identifiers": identifier_variants(code),
                "strict_identifiers": strict_identifier_variants(code),
                "source": paths[0].name,
                "not_checked": NOT_CHECKED in status_text,
            }
        )
    return rows


def load_old_rows():
    wb = load_workbook(OLD_PATH, data_only=True)
    ws = wb.active
    rows = []
    for row_index, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        sample_name, pa447, arae, diagnosis = row[:4]
        sample_name = clean(sample_name)
        if not sample_name:
            continue
        group = old_group(sample_name) or canonical_group(diagnosis)
        rows.append(
            {
                "sample_name": sample_name,
                "source_name": sample_name,
                "diagnosis": group,
                "classification": canonical_group(diagnosis),
                "pa447": pa447,
                "araE": arae,
                "record_id": f"old:{row_index}",
                "source_sheet": "Sheet1",
                "source_row": row_index,
                "identifiers": identifier_variants(sample_name),
                "strict_identifiers": strict_identifier_variants(sample_name),
                "source": "IBD IBS OLD",
            }
        )
    return rows


def is_numeric(value):
    return isinstance(value, (int, float))


def edited_measurement_files():
    roots = [FOLDER / "447 new", FOLDER / "447-old", FOLDER / "araE"]
    files = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*.xlsx"):
            name = path.name.lower()
            if "edit" in name or "eddit" in name:
                files.append(path)
    return sorted(files)


def detector_from_path(path):
    text = str(path).lower()
    return "araE" if "arae" in text else "PA447"


def has_ga_marker(workbook):
    for ws in workbook.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
            for value in row:
                text = (clean(value) or "").lower()
                if "glutaric" in text or re.search(r"\bga\b", text):
                    return True
    return False


def index_447_old_sources():
    index = defaultdict(list)
    if not OLD_447_ROOT.exists():
        return index
    for path in sorted(OLD_447_ROOT.rglob("*.xlsx")):
        try:
            wb = load_workbook(path, data_only=False, read_only=True)
        except Exception:
            continue
        has_ga = has_ga_marker(wb)
        rel_path = str(path.relative_to(FOLDER))
        for ws in wb.worksheets:
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
                for value in row:
                    if not is_sample_label(value):
                        continue
                    label = clean(value)
                    for key in identifier_variants(label):
                        index[key].append(
                            {
                                "file": rel_path,
                                "sheet": ws.title,
                                "label": label,
                                "has_ga": has_ga,
                            }
                        )
    return index


def index_447_new_sources():
    index = defaultdict(list)
    if not NEW_447_ROOT.exists():
        return index
    for path in sorted(NEW_447_ROOT.rglob("*.xlsx")):
        try:
            wb = load_workbook(path, data_only=False, read_only=True)
        except Exception:
            continue
        has_ga = has_ga_marker(wb)
        is_edited = "edit" in path.name.lower() or "eddit" in path.name.lower()
        rel_path = str(path.relative_to(FOLDER))
        for ws in wb.worksheets:
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
                for value in row:
                    if not is_sample_label(value):
                        continue
                    label = clean(value)
                    for key in identifier_variants(label):
                        index[key].append(
                            {
                                "file": rel_path,
                                "sheet": ws.title,
                                "label": label,
                                "has_ga": has_ga,
                                "is_edited": is_edited,
                            }
                        )
    return index


def classify_447_old_source(sample_name, old_447_index):
    hits = []
    for key in identifier_variants(sample_name):
        hits.extend(old_447_index.get(key, []))
    unique = []
    seen = set()
    for hit in hits:
        key = (hit["file"], hit["sheet"], hit["label"], hit["has_ga"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(hit)
    if not unique:
        return "not_found", []
    if any(hit["has_ga"] for hit in unique):
        return "found_ga", unique
    return "found_no_ga", unique


def classify_447_new_source(sample_name, new_447_index):
    hits = []
    for key in identifier_variants(sample_name):
        hits.extend(new_447_index.get(key, []))
    unique = []
    seen = set()
    for hit in hits:
        key = (hit["file"], hit["sheet"], hit["label"], hit["has_ga"], hit["is_edited"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(hit)
    if not unique:
        return "not_found", []
    if any(hit["has_ga"] and hit["is_edited"] for hit in unique):
        return "found_ga_edited", unique
    return "found_no_ga_edited", unique


def is_substrate_or_control(value):
    text = (clean(value) or "").lower()
    if not text:
        return True
    blocked = ["control", "cont", "glutaric", "ga ", " ga", "1mm ga", "447 ga", "ara ", " ara", "arabinose", "0.1mm"]
    return any(item in f" {text} " for item in blocked)


def is_sample_label(value):
    text = clean(value)
    if not text:
        return False
    low = text.lower()
    if text.startswith("="):
        return False
    if low in {"s", "µa", "ua"}:
        return False
    if is_substrate_or_control(text):
        return False
    if re.fullmatch(r"[-+]?\d+(\.\d+)?(?:E[-+]?\d+)?", text, flags=re.I):
        return False
    return bool(norm(text))


def header_for_normalized_cell(ws, row, col):
    for header_row in range(row - 1, 0, -1):
        value = ws.cell(header_row, col).value
        if is_sample_label(value):
            return clean(value)
    return None


def source_date_from_path(path):
    match = re.search(r"(20\d{6})", str(path))
    if not match:
        return None
    text = match.group(1)
    return f"{text[:4]}-{text[4:6]}-{text[6:]}"


def load_edited_normalized_measurements():
    records = []
    for path in edited_measurement_files():
        detector = detector_from_path(path)
        try:
            formula_wb = load_workbook(path, data_only=False, read_only=False)
            values_wb = load_workbook(path, data_only=True, read_only=False)
        except Exception:
            continue
        if detector == "PA447" and not has_ga_marker(formula_wb):
            continue
        rel_path = str(path.relative_to(FOLDER))
        for ws in formula_wb.worksheets:
            values_ws = values_wb[ws.title]
            max_row = min(ws.max_row, 10)
            for row in range(1, max_row + 1):
                for col in range(2, ws.max_column + 1):
                    formula = ws.cell(row, col).value
                    value = values_ws.cell(row, col).value
                    if not (isinstance(formula, str) and formula.startswith("=") and "/" in formula):
                        continue
                    if not is_numeric(value):
                        continue
                    sample_name = header_for_normalized_cell(ws, row, col)
                    if not sample_name:
                        continue
                    identifiers = identifier_variants(sample_name)
                    strict = strict_identifier_variants(sample_name)
                    if not identifiers:
                        continue
                    record = {
                        "record_key": (detector, norm(sample_name), rel_path, ws.title, row, col),
                        "record_id": f"edited:{detector}:{rel_path}:{ws.title}:{row}:{col}",
                        "source_name": sample_name,
                        "diagnosis": old_group(sample_name),
                        "pa447": value if detector == "PA447" else None,
                        "araE": value if detector == "araE" else None,
                        "source": "edited normalized files",
                        "source_file": rel_path,
                        "source_date": source_date_from_path(path),
                        "identifiers": identifiers,
                        "strict_identifiers": strict,
                        "source_rows": [f"{ws.title} {ws.cell(row=row, column=col).coordinate}"],
                    }
                    records.append(record)
    return records


def load_all_measurements():
    wb = load_workbook(ALL_PATH, data_only=True)
    records = []

    def add_record(sample_name, group, detector, values, sheet, row_index):
        measurement = average(values)
        if measurement is None:
            return
        name = clean(sample_name)
        if not name:
            return
        group = canonical_group(group)
        keys = identifier_variants(name)
        existing = None
        for item in records:
            if item["record_key"] == (group, old_core(name)):
                existing = item
                break
        if existing is None:
            existing = {
                "record_key": (group, old_core(name)),
                "record_id": f"all:{group}:{old_core(name)}",
                "source_name": name,
                "diagnosis": group,
                "pa447": None,
                "araE": None,
                "source": "447 and araE ALL",
                "identifiers": set(),
                "strict_identifiers": strict_identifier_variants(name),
                "source_rows": [],
            }
            records.append(existing)
        existing["identifiers"].update(keys)
        existing["source_rows"].append(f"{sheet} row {row_index}")
        if detector == "PA447":
            existing["pa447"] = measurement
        else:
            existing["araE"] = measurement

    for ws in wb.worksheets:
        detector = "PA447" if ws.title == "447" else "araE"
        group_starts = []
        for col in range(1, ws.max_column + 1):
            value = clean(ws.cell(row=1, column=col).value)
            if value:
                group_starts.append((col, canonical_group(value)))
        for row_index in range(2, ws.max_row + 1):
            sample_name = ws.cell(row=row_index, column=1).value
            if not clean(sample_name):
                continue
            for index, (start_col, group) in enumerate(group_starts):
                end_col = group_starts[index + 1][0] - 1 if index + 1 < len(group_starts) else ws.max_column
                values = [ws.cell(row=row_index, column=col).value for col in range(start_col, end_col + 1)]
                add_record(sample_name, group, detector, values, ws.title, row_index)

    old_447_index = index_447_old_sources()
    new_447_index = index_447_new_sources()
    for entry in records:
        if entry.get("pa447") is None:
            continue
        status, hits = classify_447_old_source(entry.get("source_name"), old_447_index)
        entry["pa447_447_old_status"] = status
        entry["pa447_447_old_hits"] = hits[:5]
        if status == "found_no_ga":
            entry["pa447_removed_reason"] = "Found in 447-old without GA/glutaric marker"
            entry["old_metering_pa447"] = entry["pa447"]
            entry["pa447"] = None
            continue
        if status == "not_found":
            new_status, new_hits = classify_447_new_source(entry.get("source_name"), new_447_index)
            entry["pa447_447_new_status"] = new_status
            entry["pa447_447_new_hits"] = new_hits[:5]
            if new_status == "found_no_ga_edited":
                entry["pa447_removed_reason"] = "Found in 447-new without GA/glutaric edited workbook"
                entry["pa447"] = None

    records.extend(load_edited_normalized_measurements())
    by_key = defaultdict(list)
    for item in records:
        for key in item["identifiers"]:
            by_key[key].append(item)
    return records, by_key


def load_unknown_trial_rows():
    names_wb = load_workbook(NAMES_PATH, data_only=True)
    name_by_key = {}
    for real, unknown in names_wb.active.iter_rows(min_row=1, max_col=2, values_only=True):
        real = clean(real)
        unknown = clean(unknown)
        if not real and not unknown:
            continue
        for key in identifier_variants(real, unknown):
            name_by_key[key] = {"real": real, "unknown": unknown}

    trial_wb = load_workbook(TRIAL_PATH, data_only=True)
    by_key = {}
    for row in trial_wb.active.iter_rows(min_row=2, max_col=9, values_only=True):
        unknown = clean(row[0])
        if not unknown:
            continue
        values = list(row[1:9])
        pa447_1, pa447_2, pa447_3, pa447_decision, arae_1, arae_2, arae_3, arae_decision = values
        name_item = None
        for key in identifier_variants(unknown):
            if key in name_by_key:
                name_item = name_by_key[key]
                break
        entry = {
            "real": name_item["real"] if name_item else None,
            "unknown": unknown,
            "values": [
                pa447_1,
                pa447_2,
                pa447_3,
                pa447_decision,
                arae_1,
                arae_2,
                arae_3,
                arae_decision,
                final_decision(pa447_decision, arae_decision),
            ],
        }
        for key in identifier_variants(unknown, entry["real"]):
            by_key[key] = entry
    return by_key


def match_tier(record, item, variants):
    if record.get("strict_identifiers", set()) & item.get("strict_identifiers", set()):
        return 0
    if norm(record.get("sample_name")) and norm(record.get("sample_name")) == norm(item.get("source_name")):
        return 0
    if item.get("strict_identifiers", set()) & variants:
        return 1
    return 2


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def measurement_id(item, detector):
    return f"{item.get('record_id', item.get('source_name'))}:{detector}"


def measurement_reuse_id(item, detector):
    value = detector_value(item, detector)
    if value is None:
        return None
    try:
        value_key = f"{float(value):.12g}"
    except Exception:
        value_key = str(value)
    return f"reuse:{detector}:{norm(item.get('source_name'))}:{value_key}"


def find_detector_measurement(record, detector, all_by_key, old_rows, aliases_by_key, used_measurements):
    variants = expand_with_aliases(record["identifiers"], aliases_by_key)
    candidates = []
    for key in variants:
        for item in all_by_key.get(key, []):
            if detector_value(item, detector) is None:
                continue
            reuse_id = measurement_reuse_id(item, detector)
            if measurement_id(item, detector) in used_measurements or reuse_id in used_measurements:
                continue
            if compatible(record.get("diagnosis"), item.get("diagnosis")) or manual_alias_match(record, item):
                tier = match_tier(record, item, variants)
                candidates.append((tier, item, item.get("source"), "exact sample match" if tier == 0 else "alias sample/patient match"))
    for old in old_rows:
        if detector_value(old, detector) is None:
            continue
        reuse_id = measurement_reuse_id(old, detector)
        if measurement_id(old, detector) in used_measurements or reuse_id in used_measurements:
            continue
        if not (compatible(record.get("diagnosis"), old.get("diagnosis")) or manual_alias_match(record, old)):
            continue
        if variants & old["identifiers"]:
            tier = match_tier(record, old, variants)
            candidates.append((tier, old, "IBD IBS OLD", "exact sample match" if tier == 0 else "alias sample/patient match"))
    if not candidates:
        return None, None, None
    candidates.sort(
        key=lambda candidate: (
            candidate[0],
            0 if candidate[2] == "edited normalized files" else 1 if candidate[2] == "447 and araE ALL" else 2,
            str(candidate[1].get("source_date") or ""),
            str(candidate[1].get("source_name") or ""),
        )
    )
    _tier, item, source, reason = candidates[0]
    used_measurements.add(measurement_id(item, detector))
    reuse_id = measurement_reuse_id(item, detector)
    if reuse_id:
        used_measurements.add(reuse_id)
    return item, source, reason


def old_metering_system_item(record, all_by_key, aliases_by_key):
    variants = expand_with_aliases(record["identifiers"], aliases_by_key)
    for key in variants:
        for item in all_by_key.get(key, []):
            if item.get("pa447_removed_reason") == "Found in 447-old without GA/glutaric marker":
                return item
    return None


def measured_known_row(record, all_by_key, old_rows, aliases_by_key, used_measurements):
    if record.get("not_checked"):
        return [
            record["sample_name"],
            record.get("other_name"),
            record.get("diagnosis"),
            None,
            None,
            None,
            None,
            NOT_CHECKED,
            NOT_CHECKED,
            record.get("sample_date"),
            record.get("sent_date"),
            None,
            record.get("source"),
        ]

    pa447_match, pa447_source, pa447_reason = find_detector_measurement(record, "PA447", all_by_key, old_rows, aliases_by_key, used_measurements)
    arae_match, arae_source, arae_reason = find_detector_measurement(record, "araE", all_by_key, old_rows, aliases_by_key, used_measurements)
    if pa447_match or arae_match:
        pa447 = pa447_match.get("pa447") if pa447_match else None
        arae = arae_match.get("araE") if arae_match else None
        pa447_decision = detector_decision(pa447, "PA447")
        arae_decision = detector_decision(arae, "araE")
        diagnosis = record.get("diagnosis") or (pa447_match or arae_match).get("diagnosis")
        final = final_decision(pa447_decision, arae_decision)
        other_name = record.get("other_name")
        reasons = []
        for detector, reason in [("PA447", pa447_reason), ("araE", arae_reason)]:
            if reason:
                reasons.append(f"{detector}: {reason}")
        sources = []
        for detector, source, match in [("PA447", pa447_source, pa447_match), ("araE", arae_source, arae_match)]:
            if source:
                detail = match.get("source_file") if match else None
                sources.append(f"{detector}: {source}" + (f" ({detail})" if detail else ""))
        return [
            record["sample_name"],
            other_name or record.get("other_name"),
            record.get("diagnosis") or (pa447_match or arae_match).get("diagnosis"),
            pa447,
            pa447_decision,
            arae,
            arae_decision,
            final,
            "measured",
            record.get("sample_date"),
            record.get("sent_date"),
            "; ".join(reasons),
            "; ".join(sources),
        ]

    old_system_item = old_metering_system_item(record, all_by_key, aliases_by_key)
    if old_system_item:
        return [
            record["sample_name"],
            record.get("other_name"),
            record.get("diagnosis"),
            old_system_item.get("old_metering_pa447"),
            None,
            None,
            None,
            None,
            OLD_METERING_SYSTEM,
            record.get("sample_date"),
            record.get("sent_date"),
            "PA447 value exists only in the old metering system",
            old_system_item.get("pa447_removed_reason"),
        ]

    return [
        record["sample_name"],
        record.get("other_name"),
        record.get("diagnosis"),
        None,
        None,
        None,
        None,
        MISSING,
        MISSING,
        record.get("sample_date"),
        record.get("sent_date"),
        None,
        record.get("source"),
    ]


def diagnosis_sort_value(diagnosis, final_value):
    diagnosis = clean(diagnosis)
    final_value = clean(final_value)
    value = diagnosis if diagnosis else final_value
    order = {
        "CDf": 0,
        "CDr": 1,
        "UCf": 2,
        "UCr": 3,
        "UC": 4,
        "IBD": 5,
        "IBS": 6,
        "Healthy": 7,
        "Unknown": 8,
        "(IBS controls)": 9,
    }
    return (order.get(value, 99), value or "")


def status_sort_value(status):
    if status == "measured":
        return 0
    if status == OLD_METERING_SYSTEM:
        return 1
    if status == MISSING:
        return 2
    if status == NOT_CHECKED:
        return 3
    return 0


def sort_unknown_rows(rows):
    return sorted(
        rows,
        key=lambda row: (
            diagnosis_sort_value(row[2], row[11]),
            clean(row[1]) or clean(row[0]) or "",
        ),
    )


def sort_known_rows(rows):
    return sorted(
        rows,
        key=lambda row: (
            status_sort_value(row[8]),
            diagnosis_sort_value(row[2], row[7]),
            clean(row[0]) or "",
            clean(row[1]) or "",
        ),
    )


def synonym_quality(record):
    synonym = clean(record.get("other_name"))
    if not synonym:
        return 0
    if synonym.isdigit():
        return 1
    return 2


def prefer_record(candidate, current):
    if current is None:
        return True
    if synonym_quality(candidate) != synonym_quality(current):
        return synonym_quality(candidate) > synonym_quality(current)
    # Prefer records with an actual sample date, then keep existing stable order.
    if bool(candidate.get("sample_date")) != bool(current.get("sample_date")):
        return bool(candidate.get("sample_date"))
    return False


def build_rows():
    aliquots, aliases_by_key, _rows_by_key = load_aliquots_inventory()
    old_rows = load_old_rows()
    old_keys = set().union(*(row["strict_identifiers"] for row in old_rows))
    all_rows, all_by_key = load_all_measurements()
    edited_measurement_count = sum(1 for row in all_rows if row.get("source") == "edited normalized files")
    trial_by_key = load_unknown_trial_rows()

    unknown_rows = []
    known_records = []
    accounted_keys = set()
    old_forced_from_unknown = 0

    for record in aliquots:
        is_unknown_tab = record["source_sheet"] == "Unknown"
        is_old_patient = bool(record["strict_identifiers"] & old_keys)
        if is_unknown_tab and not is_old_patient:
            trial = None
            for key in sorted(record["strict_identifiers"]):
                trial = trial_by_key.get(key)
                if trial:
                    break
            real_name = trial["real"] if trial and trial.get("real") else record.get("other_name")
            unknown_name = trial["unknown"] if trial else record["sample_name"]
            values = trial["values"] if trial else [None] * 9
            unknown_rows.append([real_name, unknown_name, record.get("diagnosis"), *values])
        else:
            if is_unknown_tab and is_old_patient:
                old_forced_from_unknown += 1
                record = {
                    **record,
                    "sample_name": record.get("patient_name") or record["sample_name"],
                    "other_name": record.get("raw_sample_name"),
                }
            known_records.append(record)
        accounted_keys.update(record["identifiers"])

    for missing in load_missing_rows():
        if not (missing["identifiers"] & accounted_keys):
            known_records.append(missing)
            accounted_keys.update(missing["identifiers"])

    for old in old_rows:
        if not (old["identifiers"] & accounted_keys):
            known_records.append(
                {
                    "sample_name": old["sample_name"],
                    "other_name": None,
                    "diagnosis": old.get("diagnosis") or old.get("classification"),
                    "sample_date": None,
                    "sent_date": None,
                    "source_sheet": "IBD IBS OLD",
                    "source_row": old["source_row"],
                    "identifiers": old["identifiers"],
                    "strict_identifiers": old["strict_identifiers"],
                    "source": "IBD IBS OLD",
                    "not_checked": False,
                }
            )
            accounted_keys.update(old["identifiers"])

    seen_unknown = set()
    deduped_unknown_rows = []
    for row in unknown_rows:
        key = norm(row[1]) or norm(row[0])
        if key in seen_unknown:
            continue
        seen_unknown.add(key)
        deduped_unknown_rows.append(row)
    unknown_rows = sort_unknown_rows(deduped_unknown_rows)

    best_known_records = {}
    for record in known_records:
        key = norm(record["sample_name"]) or next(iter(sorted(record["identifiers"])), "")
        if prefer_record(record, best_known_records.get(key)):
            best_known_records[key] = record

    known_rows = []
    used_measurements = set()
    for _key, record in best_known_records.items():
        known_rows.append(measured_known_row(record, all_by_key, old_rows, aliases_by_key, used_measurements))
    known_rows = sort_known_rows(known_rows)

    diagnostics = {
        "aliquots_records": len(aliquots),
        "aliquots_unknown_tab": sum(1 for row in aliquots if row["source_sheet"] == "Unknown"),
        "old_rows": len(old_rows),
        "old_forced_from_unknown": old_forced_from_unknown,
        "unknown_rows": len(unknown_rows),
        "known_rows": len(known_rows),
        "known_status_counts": Counter(row[8] for row in known_rows),
        "known_final_counts": Counter(row[7] for row in known_rows),
        "edited_normalized_measurements": edited_measurement_count,
        "used_detector_measurements": len(used_measurements),
    }
    return unknown_rows, known_rows, diagnostics


def style_sheet(ws, max_col, decision_cols, final_col=None):
    header_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
    white_fill = PatternFill(fill_type="solid", fgColor="FFFFFFFF")
    pos_fill = PatternFill(fill_type="solid", fgColor="FFF4C7C3")
    neg_fill = PatternFill(fill_type="solid", fgColor="FFCFE2F3")
    final_ibd_fill = PatternFill(fill_type="solid", fgColor="FFC00000")
    final_ibs_fill = PatternFill(fill_type="solid", fgColor="FF003399")
    int_fill = PatternFill(fill_type="solid", fgColor="FFFFE599")
    missing_fill = PatternFill(fill_type="solid", fgColor="FFE7E6E6")
    not_checked_fill = PatternFill(fill_type="solid", fgColor="FFD9D2E9")
    old_metering_fill = PatternFill(fill_type="solid", fgColor="FFFFE599")
    diagnosis_styles = {
        "CDf": (PatternFill(fill_type="solid", fgColor="FFE06666"), Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)),
        "CDr": (PatternFill(fill_type="solid", fgColor="FFF4CCCC"), Font(name="Calibri", size=11, color="FF5A1212", bold=True)),
        "HS": (PatternFill(fill_type="solid", fgColor="FFCFE2F3"), Font(name="Calibri", size=11, color="FF17365D", bold=True)),
        "Healthy": (PatternFill(fill_type="solid", fgColor="FFCFE2F3"), Font(name="Calibri", size=11, color="FF17365D", bold=True)),
        "IBS": (PatternFill(fill_type="solid", fgColor="FF3C78D8"), Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)),
    }
    thin = Side(style="thin", color="FFD9D9D9")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=max_col):
        for cell in row:
            cell.fill = white_fill
            cell.font = Font(name="Calibri", size=11, color="FF000000")
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
            cell.border = border

    for cell in ws[1][:max_col]:
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=11, color="FF000000", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 38
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{ws.cell(row=1, column=max_col).column_letter}{ws.max_row}"
    diagnosis_col = next(
        (col for col in range(1, max_col + 1) if ws.cell(row=1, column=col).value == "Diagnosis"),
        None,
    )
    status_col = next(
        (col for col in range(1, max_col + 1) if ws.cell(row=1, column=col).value == "Measurement status"),
        None,
    )

    for row in range(2, ws.max_row + 1):
        if diagnosis_col:
            cell = ws.cell(row=row, column=diagnosis_col)
            style = diagnosis_styles.get(cell.value)
            if style:
                cell.fill, cell.font = style
                cell.alignment = Alignment(horizontal="center", vertical="center")
        if status_col:
            cell = ws.cell(row=row, column=status_col)
            if cell.value == OLD_METERING_SYSTEM:
                cell.fill = old_metering_fill
                cell.font = Font(name="Calibri", size=11, color="FF7F6000", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
        for col in decision_cols:
            cell = ws.cell(row=row, column=col)
            if cell.value == "Pos":
                cell.fill = pos_fill
                cell.font = Font(name="Calibri", size=11, color="FF5A1212", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif cell.value == "Neg":
                cell.fill = neg_fill
                cell.font = Font(name="Calibri", size=11, color="FF17365D", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
        if final_col:
            cell = ws.cell(row=row, column=final_col)
            if cell.value == "IBD":
                cell.fill = final_ibd_fill
                cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
            elif cell.value == "IBS":
                cell.fill = final_ibs_fill
                cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
            elif cell.value == "Int":
                cell.fill = int_fill
                cell.font = Font(name="Calibri", size=11, color="FF7F6000", bold=True)
            elif cell.value == NOT_CHECKED:
                cell.fill = not_checked_fill
                cell.font = Font(name="Calibri", size=11, color="FF4C3868", bold=True)
            elif cell.value == MISSING:
                cell.fill = missing_fill
                cell.font = Font(name="Calibri", size=11, color="FF666666", bold=True)
            elif cell.value == OLD_METERING_SYSTEM:
                cell.fill = old_metering_fill
                cell.font = Font(name="Calibri", size=11, color="FF7F6000", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")


def autosize(ws):
    for col in range(1, ws.max_column + 1):
        letter = ws.cell(row=1, column=col).column_letter
        max_length = max(len(str(ws.cell(row=row, column=col).value or "")) for row in range(1, ws.max_row + 1))
        ws.column_dimensions[letter].width = min(max(max_length + 2, 12), 34)


def compact_unknown_measurement_columns(ws):
    widths = {
        "C": 9,
        "D": 9,
        "E": 9,
        "G": 9,
        "H": 9,
        "I": 9,
    }
    for column, width in widths.items():
        ws.column_dimensions[column].width = width
        for cell in ws[column]:
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
    ws.column_dimensions["F"].width = 11
    ws.column_dimensions["J"].width = 11
    ws.column_dimensions["K"].width = 13
    ws.column_dimensions["L"].width = 12


def main():
    unknown_rows, known_rows, diagnostics = build_rows()

    wb = Workbook()
    ws_unknown = wb.active
    ws_unknown.title = "Unknown"
    ws_unknown.append(
        [
            "Real name",
            "Unknown name",
            "PA447 measurement 1",
            "PA447 measurement 2",
            "PA447 measurement 3",
            "PA447 decision",
            "araE measurement 1",
            "araE measurement 2",
            "araE measurement 3",
            "araE decision",
            "Final decision",
            "Diagnosis",
        ]
    )
    for row in unknown_rows:
        ws_unknown.append([row[0], row[1], *row[3:12], row[2]])

    ws_known = wb.create_sheet("Known")
    ws_known.append(
        [
            "Sample name",
            "Synonym / other name",
            "PA447 measurement",
            "PA447 decision",
            "araE measurement",
            "araE decision",
            "Final classification",
            "Diagnosis",
            "Measurement status",
            "Sample date",
            "Date sent",
            "Match basis",
            "Measurement/source file",
        ]
    )
    for row in known_rows:
        ws_known.append([row[0], row[1], *row[3:8], row[2], *row[8:13]])

    ws_notes = wb.create_sheet("Match notes")
    ws_notes.append(["Item", "Value"])
    ws_notes.append(["Aliquots records accounted for", diagnostics["aliquots_records"]])
    ws_notes.append(["Aliquots Unknown-tab records", diagnostics["aliquots_unknown_tab"]])
    ws_notes.append(["IBD IBS OLD rows", diagnostics["old_rows"]])
    ws_notes.append(["Edited normalized detector measurements read", diagnostics["edited_normalized_measurements"]])
    ws_notes.append(["Detector measurements used once", diagnostics["used_detector_measurements"]])
    ws_notes.append(["Rows moved from Unknown to Known because they are in IBD IBS OLD", diagnostics["old_forced_from_unknown"]])
    ws_notes.append(["Final Unknown rows", diagnostics["unknown_rows"]])
    ws_notes.append(["Final Known rows", diagnostics["known_rows"]])
    ws_notes.append(["Known status counts", "; ".join(f"{key}: {value}" for key, value in diagnostics["known_status_counts"].items())])
    ws_notes.append(["Known final counts", "; ".join(f"{key or 'blank'}: {value}" for key, value in diagnostics["known_final_counts"].items())])
    ws_notes.append(["Placement rule", "Unknown only if the sample appears in the aliquots Unknown tab and is not present in IBD IBS OLD. All other aliquots and IBD IBS OLD samples are Known."])
    ws_notes.append(["Measurement rule", "Edited/eddited normalized files are preferred. A detector measurement source is used only once, so one patient-level measurement is not copied to multiple timepoint samples."])

    for ws in wb.worksheets:
        autosize(ws)
    compact_unknown_measurement_columns(ws_unknown)
    style_sheet(ws_unknown, 12, decision_cols=[6, 10], final_col=11)
    style_sheet(ws_known, 13, decision_cols=[4, 6], final_col=7)
    style_sheet(ws_notes, 2, decision_cols=[])
    ws_notes.column_dimensions["A"].width = 58
    ws_notes.column_dimensions["B"].width = 120

    try:
        wb.save(OUTPUT_PATH)
        output_path = OUTPUT_PATH
    except PermissionError:
        output_path = FOLDER / "Merged Unknowns trial 6.26 updated.xlsx"
        wb.save(output_path)
    print({**diagnostics, "output": str(output_path)})


if __name__ == "__main__":
    main()
