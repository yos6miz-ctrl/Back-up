import json
import re
from pathlib import Path

import openpyxl

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
FILES = [
    ROOT / "Final Known and Unknown merged.xlsx",
    ROOT / "aliqauts 20260801.xlsx",
    Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\aliqauts 20260801 working copy.xlsx"),
]


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def score(text):
    t = text.upper()
    value = 0
    if "DS" in t:
        value += 1
    if "527" in t or "0527" in t:
        value += 4
    if "2D" in t or "2 D" in t:
        value += 3
    return value


def main():
    out = {}
    for path in FILES:
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        matches = []
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                values = [cell.value for cell in row]
                text = " | ".join(clean(value) for value in values)
                s = score(text)
                if s >= 4 or re.search(r"\bDS\b|DS#|DS\s*\d", text, re.I):
                    matches.append(
                        {
                            "sheet": ws.title,
                            "row": row[0].row,
                            "score": s,
                            "values": values[: min(len(values), 35)],
                        }
                    )
        wb.close()
        out[str(path)] = matches[:200]
    print(json.dumps(out, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
