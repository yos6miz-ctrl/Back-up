from __future__ import annotations

import json
import re
import shutil
import zipfile
from copy import copy
from pathlib import Path

import openpyxl
from openpyxl.styles import Font

import import_2026_measurements as importer

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL_ONEDRIVE = ROOT / "Final Known and Unknown merged.xlsx"
FINAL_CODEX = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS_ONEDRIVE = ROOT / "aliqauts 20260801.xlsx"
ALIQUOTS_WORKING = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
REPORT = WORKSPACE / "fix_ucf_reclassification_and_aliquots_report.json"

TARGETS = {
    "CT113": {"sample_norms": {"CT113"}, "new_diagnosis": "UCf"},
    "F-DS-20527": {"sample_norms": {"FDS20527"}, "new_diagnosis": "UCf"},
}


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def resolved_merged_value(ws, row, col):
    cell = ws.cell(row, col)
    if cell.value not in (None, ""):
        return cell.value
    for merged in ws.merged_cells.ranges:
        if merged.min_row <= row <= merged.max_row and merged.min_col <= col <= merged.max_col:
            return ws.cell(merged.min_row, merged.min_col).value
    return cell.value


def sample_matches(value, sample_norms):
    return norm(value) in sample_norms


def xlsx_health(path):
    with zipfile.ZipFile(path) as zf:
        return {"bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def update_final():
    wb = openpyxl.load_workbook(FINAL_ONEDRIVE)
    ws = wb["Final"]
    headers = header_map(ws)
    changes = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        for canonical, spec in TARGETS.items():
            if sample_matches(primary, spec["sample_norms"]):
                before = ws.cell(row, headers["Diagnosis"]).value
                ws.cell(row, headers["Diagnosis"]).value = spec["new_diagnosis"]
                importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), spec["new_diagnosis"])
                changes.append(
                    {
                        "row_before_sort": row,
                        "target": canonical,
                        "primary": primary,
                        "secondary": secondary,
                        "diagnosis_before": before,
                        "diagnosis_after": spec["new_diagnosis"],
                    }
                )
                break
    if len(changes) != 2:
        raise RuntimeError(f"Expected 2 final diagnosis changes, found {len(changes)}: {changes}")
    importer.sort_records(ws, headers)
    wb.save(FINAL_ONEDRIVE)
    importer.remove_comment_and_table_parts(FINAL_ONEDRIVE)
    shutil.copy2(FINAL_ONEDRIVE, FINAL_CODEX)
    wb.close()
    return changes


def copy_row_style(src_ws, src_row, dst_ws, dst_row):
    for col in range(1, max(src_ws.max_column, dst_ws.max_column) + 1):
        src = src_ws.cell(src_row, min(col, src_ws.max_column))
        dst = dst_ws.cell(dst_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        dst.number_format = src.number_format
        dst.alignment = copy(src.alignment)
        dst.border = copy(src.border)
        dst.fill = copy(src.fill)
        dst.font = copy(src.font)


def update_aliquots(path):
    wb = openpyxl.load_workbook(path)
    cdf = wb["CDf"]
    uc = wb["UC"]

    moved = []
    delete_rows = []
    for row in range(2, cdf.max_row + 1):
        values = [cdf.cell(row, col).value for col in range(1, cdf.max_column + 1)]
        for canonical, spec in TARGETS.items():
            if sample_matches(cdf.cell(row, 4).value, spec["sample_norms"]):
                box = resolved_merged_value(cdf, row, 2)
                patient = cdf.cell(row, 3).value
                sample = cdf.cell(row, 4).value
                date = cdf.cell(row, 6).value
                aliquots = cdf.cell(row, 14).value

                insert_at = uc.max_row + 1
                # Keep UCf together above UCr rows.
                for uc_row in range(2, uc.max_row + 1):
                    if clean(uc.cell(uc_row, 1).value) == "UCr":
                        insert_at = uc_row
                        break
                uc.insert_rows(insert_at)
                style_source_row = max(2, insert_at - 1)
                copy_row_style(uc, style_source_row, uc, insert_at)
                uc.cell(insert_at, 1).value = "UCf"
                uc.cell(insert_at, 2).value = box
                uc.cell(insert_at, 3).value = patient
                uc.cell(insert_at, 4).value = sample
                uc.cell(insert_at, 5).value = date
                uc.cell(insert_at, 6).value = aliquots
                uc.cell(insert_at, 1).font = Font(name="Calibri", size=11, bold=True)
                delete_rows.append(row)
                moved.append(
                    {
                        "target": canonical,
                        "from_sheet": "CDf",
                        "from_row": row,
                        "to_sheet": "UC",
                        "to_row": insert_at,
                        "box": box,
                        "patient": patient,
                        "sample": sample,
                        "date": date,
                        "aliquots": aliquots,
                    }
                )
                break

    if len(moved) != 2:
        raise RuntimeError(f"Expected 2 aliquot rows to move in {path}, found {len(moved)}: {moved}")

    for row in sorted(delete_rows, reverse=True):
        cdf.delete_rows(row, 1)

    wb.save(path)
    wb.close()
    return moved


def verify_final_rows():
    wb = openpyxl.load_workbook(FINAL_ONEDRIVE, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = header_map(ws)
    found = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        for canonical, spec in TARGETS.items():
            if sample_matches(primary, spec["sample_norms"]):
                found.append(
                    {
                        "row": row,
                        "target": canonical,
                        "primary": primary,
                        "secondary": secondary,
                        "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                        "final": ws.cell(row, headers["Final classification / decision"]).value,
                    }
                )
                break
    wb.close()
    return found


def verify_aliquots(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    result = {"CDf_hits": [], "UC_hits": []}
    for sheet_name in ["CDf", "UC"]:
        ws = wb[sheet_name]
        for row in range(1, ws.max_row + 1):
            values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
            for canonical, spec in TARGETS.items():
                sample_value = ws.cell(row, 4).value if sheet_name in ["CDf", "UC"] else None
                if sample_matches(sample_value, spec["sample_norms"]):
                    result[f"{sheet_name}_hits"].append({"row": row, "target": canonical, "values": values[:19]})
                    break
    wb.close()
    return result


def main():
    final_changes = update_final()
    aliquots_onedrive_moves = update_aliquots(ALIQUOTS_ONEDRIVE)
    shutil.copy2(ALIQUOTS_ONEDRIVE, ALIQUOTS_WORKING)

    report = {
        "final_changes": final_changes,
        "aliquots_onedrive_moves": aliquots_onedrive_moves,
        "final_verification": verify_final_rows(),
        "aliquots_verification": verify_aliquots(ALIQUOTS_ONEDRIVE),
        "health": {
            "final_onedrive": xlsx_health(FINAL_ONEDRIVE),
            "final_codex": xlsx_health(FINAL_CODEX),
            "aliquots_onedrive": xlsx_health(ALIQUOTS_ONEDRIVE),
            "aliquots_working": xlsx_health(ALIQUOTS_WORKING),
        },
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
