from __future__ import annotations

from copy import copy
from datetime import datetime
from pathlib import Path
import json
import re
import shutil
import zipfile

import openpyxl
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "move_un_names_to_secondary_report.json"


def clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def norm(value):
    return re.sub(r"[^A-Z0-9]+", "", clean(value).upper())


def is_un_name(value):
    text = clean(value).upper()
    return bool(re.match(r"^UN(\b|\s|[-_])", text)) or text.startswith("UNKNOWN")


def split_aliases(value):
    return [part.strip() for part in re.split(r"\s*;\s*", clean(value)) if part.strip()]


def combine_aliases(parts):
    output = []
    seen = set()
    for part in parts:
        part = clean(part)
        key = norm(part)
        if not part or key in seen:
            continue
        seen.add(key)
        output.append(part)
    return "; ".join(output) if output else None


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def clone_cell_style(src, dest):
    if src.has_style:
        dest._style = copy(src._style)
    dest.number_format = src.number_format
    dest.alignment = copy(src.alignment)
    dest.border = copy(src.border)
    dest.fill = copy(src.fill)
    dest.font = copy(src.font)


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before moving UN names to secondary {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    wb = openpyxl.load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    primary_col = headers["Primary name"]
    secondary_col = headers["Secondary / other name"]

    changes = []
    unresolved = []
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, primary_col).value)
        secondary = clean(ws.cell(row, secondary_col).value)
        if not is_un_name(primary):
            continue

        aliases = split_aliases(secondary)
        non_un_aliases = [alias for alias in aliases if not is_un_name(alias)]
        promoted_primary = non_un_aliases[0] if non_un_aliases else None
        new_secondary = combine_aliases([primary] + [alias for alias in aliases if norm(alias) != norm(promoted_primary)])

        primary_cell = ws.cell(row, primary_col)
        secondary_cell = ws.cell(row, secondary_col)
        # Keep the existing visual style for both name columns.
        primary_style = copy(primary_cell._style)
        secondary_style = copy(secondary_cell._style)
        primary_cell.value = promoted_primary
        secondary_cell.value = new_secondary
        primary_cell._style = copy(primary_style)
        secondary_cell._style = copy(secondary_style)
        primary_cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
        secondary_cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)

        item = {
            "row_before_sort": row,
            "old_primary": primary,
            "old_secondary": secondary or None,
            "new_primary": promoted_primary,
            "new_secondary": new_secondary,
        }
        changes.append(item)
        if promoted_primary is None:
            unresolved.append(item)

    headers = header_map(ws)
    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = openpyxl.load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    remaining_un_primary = []
    primary_date = {}
    duplicate_primary_date = []
    for row in range(2, check_ws.max_row + 1):
        primary = clean(check_ws.cell(row, check_headers["Primary name"]).value)
        secondary = clean(check_ws.cell(row, check_headers["Secondary / other name"]).value)
        if is_un_name(primary):
            remaining_un_primary.append({"row": row, "primary": primary, "secondary": secondary})
        key = (norm(primary), clean(check_ws.cell(row, check_headers["Sample date"]).value))
        if key[0]:
            primary_date.setdefault(key, []).append(row)
    for key, rows in primary_date.items():
        if len(rows) > 1:
            duplicate_primary_date.append({"key": key, "rows": rows})

    report = {
        "workbook": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "changed_rows_count": len(changes),
        "changes_preview": changes[:50],
        "unresolved_no_real_primary_count": len(unresolved),
        "unresolved_no_real_primary": unresolved,
        "remaining_un_primary": remaining_un_primary,
        "duplicate_primary_date_count": len(duplicate_primary_date),
        "duplicate_primary_date_preview": duplicate_primary_date[:25],
        "dimensions": {"rows": check_ws.max_row, "columns": check_ws.max_column},
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, default=str, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
