from pathlib import Path

from openpyxl import load_workbook


folder = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
for path in sorted(folder.glob("*.xlsx")):
    if path.name.startswith("~$"):
        continue
    print(f"FILE\t{path.name}")
    wb = load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        print(f"SHEET\t{ws.title}\trows={ws.max_row}\tcols={ws.max_column}")
        max_rows = min(ws.max_row or 0, 8)
        max_cols = min(ws.max_column or 0, 14)
        for row in ws.iter_rows(min_row=1, max_row=max_rows, min_col=1, max_col=max_cols, values_only=True):
            print("\t" + "\t".join("" if value is None else str(value) for value in row))
    print()
