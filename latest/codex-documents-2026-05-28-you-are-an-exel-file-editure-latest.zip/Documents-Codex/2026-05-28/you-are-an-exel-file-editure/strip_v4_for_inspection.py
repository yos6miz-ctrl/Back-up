from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


SRC = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged - Ichilov v4.xlsx")
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\Final Known and Unknown merged - Ichilov v4 stripped temp.xlsx")


def main():
    with ZipFile(SRC, "r") as zin, ZipFile(OUT, "w", ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            if item.filename.startswith("xl/tables/"):
                continue
            if "comments" in item.filename.lower():
                continue
            if "vmlDrawing" in item.filename:
                continue
            zout.writestr(item, zin.read(item.filename))
    print(OUT)


if __name__ == "__main__":
    main()
