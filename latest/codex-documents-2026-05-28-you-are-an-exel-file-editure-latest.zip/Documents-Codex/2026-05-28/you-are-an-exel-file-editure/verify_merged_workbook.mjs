import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const file = "C:/Users/Popovtzer lab/.codex/Excel file editor/Merged Unknowns trial 6.26.xlsx";
const input = await FileBlob.load(file);
const workbook = await SpreadsheetFile.importXlsx(input);

const preview = await workbook.inspect({
  kind: "table",
  range: "Merged!A1:N12",
  include: "values,formulas",
  tableMaxRows: 12,
  tableMaxCols: 14,
});

const fuzzy = await workbook.inspect({
  kind: "match",
  searchTerm: "UN FSL 672",
  options: { maxResults: 5 },
  summary: "confirmed similar match",
});

const eim = await workbook.inspect({
  kind: "match",
  searchTerm: "UN EIM19262",
  options: { maxResults: 5 },
  summary: "confirmed EIM/FIM match",
});

const blanks = await workbook.inspect({
  kind: "match",
  searchTerm: "no trial measurements",
  options: { maxResults: 25 },
  summary: "blank measurement rows",
});

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 50 },
  summary: "formula error scan",
});

try {
  await workbook.render({ sheetName: "Merged", range: "A1:N30", scale: 1 });
  await workbook.render({ sheetName: "Match notes", range: "A1:B6", scale: 1 });
  console.log("RENDER\tok");
} catch (error) {
  console.log(`RENDER\t${error?.message ?? error}`);
}

console.log("PREVIEW");
console.log(preview.ndjson);
console.log("FUZZY_MATCH");
console.log(fuzzy.ndjson);
console.log("EIM_MATCH");
console.log(eim.ndjson);
console.log("BLANK_ROWS");
console.log(blanks.ndjson);
console.log("ERRORS");
console.log(errors.ndjson);
