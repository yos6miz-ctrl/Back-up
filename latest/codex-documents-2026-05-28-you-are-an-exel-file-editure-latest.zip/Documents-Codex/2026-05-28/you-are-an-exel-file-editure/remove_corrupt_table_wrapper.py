from datetime import datetime
from pathlib import Path
from shutil import copy2
from tempfile import NamedTemporaryFile
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
REPAIRED_COPY = EXCEL_DIR / "Final Known and Unknown merged no-table.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"

ET.register_namespace("", MAIN_NS)
ET.register_namespace("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")


def remove_table_parts_from_sheet(xml_bytes):
    root = ET.fromstring(xml_bytes)
    removed = 0
    for table_parts in list(root.findall(f"{{{MAIN_NS}}}tableParts")):
        root.remove(table_parts)
        removed += 1
    return ET.tostring(root, encoding="utf-8", xml_declaration=False), removed


def remove_table_relationship(xml_bytes):
    root = ET.fromstring(xml_bytes)
    removed = 0
    for rel in list(root):
        if rel.attrib.get("Type", "").endswith("/table") or rel.attrib.get("Target") == "/xl/tables/table1.xml":
            root.remove(rel)
            removed += 1
    ET.register_namespace("", REL_NS)
    return ET.tostring(root, encoding="utf-8", xml_declaration=False), removed


def remove_table_content_type(xml_bytes):
    root = ET.fromstring(xml_bytes)
    removed = 0
    for override in list(root):
        if override.attrib.get("PartName") == "/xl/tables/table1.xml":
            root.remove(override)
            removed += 1
    ET.register_namespace("", CONTENT_NS)
    return ET.tostring(root, encoding="utf-8", xml_declaration=False), removed


def build_repaired_copy(source, target):
    changes = []
    with ZipFile(source, "r") as zin:
        with NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            with ZipFile(tmp_path, "w", ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    if item.filename == "xl/tables/table1.xml":
                        changes.append((item.filename, "removed part"))
                        continue

                    data = zin.read(item.filename)
                    if item.filename == "xl/worksheets/sheet1.xml":
                        data, count = remove_table_parts_from_sheet(data)
                        if count:
                            changes.append((item.filename, f"removed {count} tableParts node(s)"))
                    elif item.filename == "xl/worksheets/_rels/sheet1.xml.rels":
                        data, count = remove_table_relationship(data)
                        if count:
                            changes.append((item.filename, f"removed {count} table relationship(s)"))
                    elif item.filename == "[Content_Types].xml":
                        data, count = remove_table_content_type(data)
                        if count:
                            changes.append((item.filename, f"removed {count} table content-type override(s)"))

                    zout.writestr(item, data)

            copy2(tmp_path, target)
        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    return changes


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before table removal {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    changes = build_repaired_copy(WORKBOOK, REPAIRED_COPY)
    try:
        copy2(REPAIRED_COPY, WORKBOOK)
        REPAIRED_COPY.unlink()
        saved_as = WORKBOOK
    except PermissionError:
        saved_as = REPAIRED_COPY

    print({"saved_as": str(saved_as), "backup": str(backup), "changes": changes})


if __name__ == "__main__":
    main()
