from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")


WIDTHS = {
    "A": 14,  # Original tab
    "B": 24,  # Primary name
    "C": 24,  # Secondary / other name
    "D": 20,  # Measurement status
    "E": 16,  # Diagnosis
    "F": 28,  # Final classification / decision
    "G": 20,  # Calprotectin level
    "H": 32,  # Disease location
    "I": 16,  # PA447 measurement 1
    "J": 16,  # PA447 measurement 2
    "K": 16,  # PA447 measurement 3
    "L": 16,  # PA447 decision
    "M": 16,  # araE measurement 1
    "N": 16,  # araE measurement 2
    "O": 16,  # araE measurement 3
    "P": 16,  # araE decision
    "Q": 18,  # Sample date
    "R": 70,  # Measurement/source file
}

MEASUREMENT_COLUMNS = ["I", "J", "K", "M", "N", "O"]


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]

    for column, width in WIDTHS.items():
        ws.column_dimensions[column].width = width

    for column in MEASUREMENT_COLUMNS:
        for cell in ws[column][1:]:
            if isinstance(cell.value, (int, float)):
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center")

    for cell in ws["G"][1:]:
        if isinstance(cell.value, (int, float)):
            cell.number_format = "0"

    for cell in ws["Q"][1:]:
        cell.alignment = Alignment(horizontal="left", vertical="center")

    for cell in ws["R"][1:]:
        cell.alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "updated_widths": WIDTHS})


if __name__ == "__main__":
    main()
