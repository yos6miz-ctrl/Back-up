from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import re

from openpyxl import load_workbook


FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CLASSIFIER_PATH = (
    Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
    / "skills"
    / "classifier"
    / "scripts"
    / "run_threshold_bar_classifier.py"
)
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\summary_with_single_and_old.json")


def load_classifier():
    spec = spec_from_file_location("classifier", CLASSIFIER_PATH)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def clean(value):
    if value is None:
        return ""
    return str(value).strip()


def numeric(value):
    try:
        if value in (None, ""):
            return None
        return float(value)
    except Exception:
        return None


def norm_dx(value):
    text = clean(value).upper()
    if text in {"CDF", "CD F"}:
        return "CDf"
    if text in {"CDR", "CD R"}:
        return "CDr"
    if text in {"IBS", "IBS CONTROL", "IBS CONTROLS", "(IBS CONTROLS)"}:
        return "IBS"
    if text in {"HEALTHY", "HS", "H"}:
        return "Healthy"
    if text == "UCF":
        return "UCf"
    if text == "UCR":
        return "UCr"
    if text == "UC":
        return "UC"
    return clean(value)


def is_ibd_final(value):
    return clean(value).upper().startswith("IBD")


def has_old_marker(value):
    return "old metering" in clean(value).lower()


def location_bucket(value):
    text = clean(value).lower()
    if not text:
        return "Unknown/not recorded"
    small = any(token in text for token in ["small", "ileal", "ileum", "ileocecal", "l1", "ileocolonic"])
    colon = any(token in text for token in ["large", "colon", "colonic", "pancolitis", "l2", "l3", "ileocolonic"])
    if small and colon:
        return "Both small bowel and colon"
    if small:
        return "Small bowel only"
    if colon:
        return "Colon only"
    return "Unknown/not recorded"


def detector_values(row, h, detector):
    cols = [h[f"{detector} measurement {i}"] for i in (1, 2, 3)]
    return [numeric(row[col]) for col in cols if numeric(row[col]) is not None]


def detector_call(classifier, value, bar):
    call, margin = classifier.detector_call(float(value), bar)
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    return "inconclusive"


def row_classifier_with_any_values(classifier, bars, row, h):
    calls = []
    details = []
    for detector in ("PA447", "araE"):
        vals = detector_values(row, h, detector)
        bar = bars[detector]["bar"]
        for val in vals:
            family = detector_call(classifier, val, bar)
            calls.append("IBD-like" if family == "IBD" else "IBS-like" if family == "IBS" else "inconclusive")
            details.append({"detector": detector, "value": val, "call": family})
    if not calls:
        return "", details
    return classifier.final_classification(calls), details


def measurement_kind(row, h):
    status = clean(row[h["Measurement status"]]).lower()
    old = has_old_marker(row[h["Measurement status"]]) or has_old_marker(row[h["Final classification / decision"]])
    total = len(detector_values(row, h, "PA447")) + len(detector_values(row, h, "araE"))
    one_detector_single = any(len(detector_values(row, h, d)) == 1 for d in ("PA447", "araE"))
    if old or status == "old metering system":
        return "old metering system"
    if total > 0 and one_detector_single:
        return "single-measurement evidence"
    return "regular"


def is_relevant_row(row, h):
    dx = norm_dx(row[h["Diagnosis"]])
    return dx in {"CDf", "CDr", "UCf", "IBS"}


def main():
    classifier = load_classifier()
    training, feature_cols, _fill_values, _sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    rows = list(ws.iter_rows(values_only=True))
    h = {clean(value): index for index, value in enumerate(rows[0])}

    data = []
    for excel_row, row in enumerate(rows[1:], start=2):
        dx = norm_dx(row[h["Diagnosis"]])
        if not is_relevant_row(row, h):
            continue
        current_final = clean(row[h["Final classification / decision"]])
        classifier_final, details = row_classifier_with_any_values(classifier, bars, row, h)
        kind = measurement_kind(row, h)
        data.append(
            {
                "excel_row": excel_row,
                "primary": clean(row[h["Primary name"]]),
                "secondary": clean(row[h["Secondary / other name"]]),
                "diagnosis": dx,
                "current_final": current_final,
                "classifier_final": classifier_final,
                "classifier_positive": classifier_final == "IBD",
                "kind": kind,
                "calprotectin": numeric(row[h["Calprotectin level"]]),
                "location": clean(row[h["Disease location"]]),
                "location_bucket": location_bucket(row[h["Disease location"]]),
                "source_file": clean(row[h["Measurement/source file"]]),
                "details": details,
            }
        )

    # Strict baseline: current workbook final decisions, matching the user's supplied summary definition.
    baseline = [r for r in data if clean(r["current_final"]).upper() in {"IBD", "IBS"}]
    # Expanded: keep baseline, and add excluded single/old rows only when the classifier itself returns IBD/IBS.
    extra = [
        r
        for r in data
        if r["kind"] in {"old metering system", "single-measurement evidence"}
        and clean(r["current_final"]).upper() not in {"IBD", "IBS"}
        and r["classifier_final"] in {"IBD", "IBS"}
    ]
    expanded_by_key = {(r["excel_row"]): r for r in baseline}
    for r in extra:
        expanded_by_key[r["excel_row"]] = r
    expanded = list(expanded_by_key.values())

    def final_positive(record, use_expanded=False):
        if use_expanded and record["excel_row"] in {r["excel_row"] for r in extra}:
            return record["classifier_final"] == "IBD"
        return clean(record["current_final"]).upper() == "IBD"

    def metrics(records, use_expanded=False):
        out = {}
        cdf_ibs = [r for r in records if r["diagnosis"] in {"CDf", "IBS"}]
        cdf = [r for r in cdf_ibs if r["diagnosis"] == "CDf"]
        ibs = [r for r in cdf_ibs if r["diagnosis"] == "IBS"]
        out["cdf_caught"] = sum(final_positive(r, use_expanded) for r in cdf)
        out["cdf_total"] = len(cdf)
        out["ibs_true_negative"] = sum(not final_positive(r, use_expanded) for r in ibs)
        out["ibs_total"] = len(ibs)
        for dx in ("CDr", "UCf"):
            subset = [r for r in records if r["diagnosis"] == dx]
            out[f"{dx}_caught"] = sum(final_positive(r, use_expanded) for r in subset)
            out[f"{dx}_total"] = len(subset)
        low_cdf = [r for r in records if r["diagnosis"] == "CDf" and r["calprotectin"] is not None and r["calprotectin"] < 150]
        out["low_cdf_caught"] = sum(final_positive(r, use_expanded) for r in low_cdf)
        out["low_cdf_total"] = len(low_cdf)
        caught_cdf = [r for r in records if r["diagnosis"] == "CDf" and final_positive(r, use_expanded)]
        out["caught_cdf_location_counts"] = dict(Counter(r["location_bucket"] for r in caught_cdf))
        out["caught_cdf_small_involvement"] = sum(r["location_bucket"] in {"Small bowel only", "Both small bowel and colon"} for r in caught_cdf)
        out["caught_cdf_total"] = len(caught_cdf)
        caught_low_cdf = [r for r in low_cdf if final_positive(r, use_expanded)]
        out["caught_low_cdf_small_involvement"] = sum(r["location_bucket"] in {"Small bowel only", "Both small bowel and colon"} for r in caught_low_cdf)
        out["caught_low_cdf_total"] = len(caught_low_cdf)
        caught_cdr = [r for r in records if r["diagnosis"] == "CDr" and final_positive(r, use_expanded)]
        out["caught_cdr_small_involvement"] = sum(r["location_bucket"] in {"Small bowel only", "Both small bowel and colon"} for r in caught_cdr)
        out["caught_cdr_total"] = len(caught_cdr)
        return out

    def pct(n, d):
        return None if not d else 100 * n / d

    report = {
        "bars": {key: value["bar"] for key, value in bars.items()},
        "baseline_metrics": metrics(baseline, use_expanded=False),
        "expanded_metrics": metrics(expanded, use_expanded=True),
        "added_rows": extra,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("BARS", report["bars"])
    print("BASELINE", report["baseline_metrics"])
    print("EXPANDED", report["expanded_metrics"])
    print("ADDED")
    for r in extra:
        vals = "; ".join(f"{d['detector']}={d['value']:.9g} {d['call']}" for d in r["details"])
        print(r["excel_row"], r["primary"], r["secondary"], r["diagnosis"], r["kind"], r["classifier_final"], vals)


if __name__ == "__main__":
    main()
