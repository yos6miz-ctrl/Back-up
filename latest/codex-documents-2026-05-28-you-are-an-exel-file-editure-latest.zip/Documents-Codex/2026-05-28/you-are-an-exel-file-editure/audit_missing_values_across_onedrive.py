from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import json
import math
import re
import zipfile
from xml.etree import ElementTree as ET

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
FINAL = ROOT / "Final Known and Unknown merged.xlsx"
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\missing_values_across_onedrive_report.json")

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def clean(value) -> str:
    return "" if value is None else str(value).replace("\xa0", " ").strip()


def norm(value) -> str:
    text = clean(value).upper()
    text = re.sub(r"\([^)]*\)", "", text)
    text = re.sub(r"^UN[\s\-_]*", "", text)
    return re.sub(r"[^A-Z0-9]", "", text)


def canonical_dx(value) -> str:
    text = norm(value)
    return {
        "CDF": "CDf",
        "CDR": "CDr",
        "IBS": "IBS",
        "HEALTHY": "Healthy",
        "HS": "Healthy",
        "UCF": "UCf",
        "UCR": "UCr",
        "UC": "UC",
    }.get(text, clean(value))


def numeric_variants(key: str) -> set[str]:
    if not key or not key.isdigit():
        return set()
    number = str(int(key))
    return {number, number.zfill(3), number.zfill(4)}


def identifier_variants(*values) -> set[str]:
    variants = set()
    for value in values:
        key = norm(value)
        if not key:
            continue
        variants.add(key)
        variants.update(numeric_variants(key))
        old_core = re.sub(r"^(P447|PA0447|PA447|CDF|CDR|IBS|UCF|UCR|UC|CD|HS|H|HEALTHY)", "", key)
        if old_core:
            variants.add(old_core)
            variants.update(numeric_variants(old_core))
        if key.startswith("F") and len(key) > 1:
            variants.add(key[1:])
        match = re.match(r"F([A-Z]+)(\d{2})(\d{3})$", key)
        if match:
            letters, _year, suffix = match.groups()
            variants.add(f"{letters}{suffix}")
            variants.add(f"F{letters}{suffix}")
        sample_match = re.match(r"(CT|HS)(\d+)$", key)
        if sample_match:
            number = sample_match.group(2)
            variants.add(number)
            variants.update(numeric_variants(number))
            variants.add(f"CT{number}")
            variants.add(f"HS{number}")
        variants.add(key.replace("ALA", "AL"))
    return {value for value in variants if value and len(value) >= 2}


MANUAL_ALIASES = [
    ("F-HS-2153", "UN153"),
    ("F-LB-18373", "CDf 373", "CD 373"),
    ("F-ES-23103", "UN F ES23103", "UN FES103", "447 UN F ES23103"),
    ("F-MM-25109", "UN FMM109", "F-MM-109", "447 UN FMM109"),
    ("F-AA-19113", "UN FAA113", "CDf F-AA-19113"),
    ("UN F AP24104", "UN104"),
    ("UN F IS19195", "UN195"),
    ("UN F SL18363", "UN363"),
    ("UN F DB19557", "UN557"),
    ("UN F DM19582", "UN582"),
    ("UN F AL181", "UN181"),
    ("UN F MR2056", "UN56"),
    ("SHR-22194", "CDf 157SHR", "CDf 157SHR3"),
    ("CT535", "CDf 535", "535"),
    ("F-AS19535", "CDf F-AS19535", "CDf 535 old", "old 535"),
    ("F-RA-21458", "UN FBA 548", "UN FBA 458"),
    ("F-ALA-20671", "CDf 78AL2", "CDf 78ALA2"),
    ("CT113", "CDf old 113", "CDf 113"),
    ("CT1156", "CDf old 1156", "CDf 1156 old"),
    ("F-ALA-20455", "CDr 78AL1", "CDr 78ALA1"),
    ("CT621", "HS 621", "HS621"),
    ("CT642", "HS642", "HS 642"),
    ("CT-694", "HS 649", "HS649"),
    ("CT661", "HS 661", "HS661"),
    ("CT683", "HS 683", "HS683"),
    ("CT684", "HS 684", "HS684"),
    ("F-YG-2386", "IBS 2386", "IBS8623", "IBS 8623", "IBS YG2386"),
    ("F-AP-2390", "IBS 2390", "IBS 9023", "IBS AP2390", "IBS AP-2390"),
    ("F-BZ-2387", "IBS 2387", "IBS8723", "IBS 8723", "IBS BZ2387", "IBS BZ-2387"),
]


def alias_groups() -> list[set[str]]:
    groups = []
    for names in MANUAL_ALIASES:
        keys = set()
        for name in names:
            keys.update(identifier_variants(name))
        groups.append(keys)
    return groups


def row_search_keys(primary: str, secondary: str, diagnosis: str) -> set[str]:
    keys = set()
    keys.update(identifier_variants(primary, secondary))
    dx = canonical_dx(diagnosis)
    prefixes = []
    if dx == "CDf":
        prefixes = ["CDF", "CD"]
    elif dx == "CDr":
        prefixes = ["CDR", "CD"]
    elif dx in {"UCf", "UCr", "UC"}:
        prefixes = [norm(dx), "UC"]
    elif dx == "Healthy":
        prefixes = ["HS", "HEALTHY"]
    elif dx == "IBS":
        prefixes = ["IBS"]
    for key in list(keys):
        digits = re.findall(r"\d+", key)
        if digits:
            number = digits[-1]
            for prefix in prefixes:
                keys.add(f"{prefix}{number}")
                keys.add(f"{prefix}{number.zfill(3)}")
    for group in alias_groups():
        if keys & group:
            keys.update(group)
    return {key for key in keys if len(key) >= 3}


def load_missing_rows() -> list[dict]:
    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    iterator = ws.iter_rows(values_only=True)
    header_values = next(iterator)
    headers = {clean(value): index for index, value in enumerate(header_values)}
    rows = []
    for row, values in enumerate(iterator, start=2):
        status = clean(values[headers["Measurement status"]]).lower()
        final = clean(values[headers["Final classification / decision"]]).lower()
        if status != "missing" and final != "missing":
            continue
        primary = clean(values[headers["Primary name"]])
        secondary = clean(values[headers["Secondary / other name"]])
        diagnosis = clean(values[headers["Diagnosis"]])
        keys = row_search_keys(primary, secondary, diagnosis)
        rows.append(
            {
                "row": row,
                "primary": primary,
                "secondary": secondary,
                "diagnosis": diagnosis,
                "keys": sorted(keys),
            }
        )
    return rows


def col_index(ref: str) -> int:
    letters = re.match(r"([A-Z]+)", ref).group(1)
    out = 0
    for ch in letters:
        out = out * 26 + ord(ch) - 64
    return out


def read_shared_strings(zf) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    return ["".join(t.text or "" for t in si.findall(".//m:t", NS)) for si in root.findall("m:si", NS)]


def file_quick_text(path: Path) -> str:
    with zipfile.ZipFile(path) as zf:
        parts = []
        try:
            parts.append(zf.read("xl/sharedStrings.xml").decode("utf-8", "ignore"))
        except KeyError:
            pass
        # Inline strings can live directly in sheet XML; cap huge workbooks after shared strings.
        if not parts:
            for name in zf.namelist():
                if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name):
                    parts.append(zf.read(name).decode("utf-8", "ignore")[:250000])
        return "\n".join(parts)


def normalized_text_hits(text: str, target_keys: set[str]) -> bool:
    normalized = norm(re.sub(r"<[^>]+>", " ", text))
    for key in target_keys:
        if len(key) >= 5 and key in normalized:
            return True
    return False


def stream_text_values(path: Path):
    with zipfile.ZipFile(path) as zf:
        try:
            with zf.open("xl/sharedStrings.xml") as handle:
                for _event, elem in ET.iterparse(handle, events=("end",)):
                    if elem.tag.endswith("}si"):
                        text = "".join(t.text or "" for t in elem.findall(".//m:t", NS))
                        if text:
                            yield text
                        elem.clear()
                return
        except KeyError:
            pass
        for name in zf.namelist():
            if not re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name):
                continue
            with zf.open(name) as handle:
                for _event, elem in ET.iterparse(handle, events=("end",)):
                    if elem.tag.endswith("}c"):
                        if elem.attrib.get("t") == "inlineStr":
                            text = "".join(t.text or "" for t in elem.findall(".//m:t", NS))
                            if text:
                                yield text
                        elem.clear()


def file_has_missing_label(path: Path, missing_rows: list[dict]) -> bool:
    for text in stream_text_values(path):
        if label_matches(text, missing_rows):
            return True
    return False


def cell_value(cell, shared):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(t.text or "" for t in cell.findall(".//m:t", NS))
    if cell_type == "str":
        node = cell.find("m:v", NS)
        return node.text if node is not None else None
    node = cell.find("m:v", NS)
    if node is None or node.text is None:
        return None
    raw = node.text
    if cell_type == "s":
        try:
            return shared[int(raw)]
        except Exception:
            return None
    try:
        return float(raw)
    except ValueError:
        return raw


def workbook_cells(path: Path):
    with zipfile.ZipFile(path) as zf:
        shared = read_shared_strings(zf)
        for sheet_file in sorted(name for name in zf.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name)):
            cells = {}
            for _event, elem in ET.iterparse(zf.open(sheet_file), events=("end",)):
                if not elem.tag.endswith("}row"):
                    continue
                row_num = int(elem.attrib.get("r", "0") or 0)
                for cell in elem.findall("m:c", NS):
                    ref = cell.attrib.get("r")
                    if not ref:
                        continue
                    value = cell_value(cell, shared)
                    if value is not None and value != "":
                        cells[(row_num, col_index(ref))] = (value, ref)
                elem.clear()
            yield sheet_file, cells


def is_measurement_number(value) -> bool:
    if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
        return False
    value = float(value)
    if value < -0.1 or value > 5:
        return False
    if value >= 100 and abs(value - round(value)) < 1e-9:
        return False
    return True


def detector_guess(path: Path, cells: dict, row: int, col: int) -> str:
    low = str(path).lower()
    nearby = " ".join(
        clean(value).lower()
        for (r, c), (value, _ref) in cells.items()
        if isinstance(value, str) and abs(r - row) <= 4 and abs(c - col) <= 4
    )
    if "arae" in low or "arae" in nearby or "arabinose" in nearby:
        return "araE"
    if "447" in low or "pa447" in nearby or "p447" in nearby or "glutaric" in nearby:
        return "PA447"
    return "unknown"


def nearby_values(cells: dict, row: int, col: int) -> list[dict]:
    out = []
    for (r, c), (value, ref) in cells.items():
        if not is_measurement_number(value):
            continue
        if abs(r - row) > 8 or abs(c - col) > 12:
            continue
        distance_type = 0 if c == col and r > row else 1 if r == row and c > col else 2
        out.append(
            {
                "cell": ref,
                "value": float(value),
                "row_delta": r - row,
                "col_delta": c - col,
                "rank": [distance_type, abs(r - row) + abs(c - col)],
            }
        )
    out.sort(key=lambda item: tuple(item["rank"]))
    for item in out:
        del item["rank"]
    return out[:10]


def label_matches(label: str, rows: list[dict]) -> list[dict]:
    label_key = norm(label)
    if len(label_key) < 3:
        return []
    hits = []
    for row in rows:
        for key in row["keys"]:
            if label_key == key:
                hits.append(row)
                break
            if len(label_key) >= 5 and len(key) >= 5 and (label_key.endswith(key) or key.endswith(label_key)):
                hits.append(row)
                break
    return hits


def is_excluded_file(path: Path) -> bool:
    low = str(path.relative_to(ROOT)).lower()
    if path.name.startswith("~$"):
        return True
    if path.resolve() == FINAL.resolve():
        return True
    # Keep previous/final products out of the source search; the goal is source material.
    final_like = [
        "final known and unknown merged",
        "gut sense one-slide",
        "gut sense performance",
        "powerpoint",
    ]
    return any(token in low for token in final_like)


def main():
    missing_rows = load_missing_rows()
    scanned = 0
    files_with_key = 0
    candidates = []
    errors = []

    for path in sorted(ROOT.rglob("*.xlsx")):
        if is_excluded_file(path):
            continue
        scanned += 1
        if scanned % 100 == 0:
            print(f"scanned {scanned} workbooks; label-hit files so far {files_with_key}", flush=True)
        try:
            if not file_has_missing_label(path, missing_rows):
                continue
            files_with_key += 1
            print(f"label hit: {path.relative_to(ROOT)}", flush=True)
            for sheet_file, cells in workbook_cells(path):
                text_cells = [
                    (r, c, value, ref)
                    for (r, c), (value, ref) in cells.items()
                    if isinstance(value, str) and len(norm(value)) >= 3
                ]
                for row_num, col_num, label, ref in text_cells:
                    rows = label_matches(label, missing_rows)
                    if not rows:
                        continue
                    values = nearby_values(cells, row_num, col_num)
                    if not values:
                        continue
                    for missing in rows:
                        candidates.append(
                            {
                                "final_row": missing["row"],
                                "primary": missing["primary"],
                                "secondary": missing["secondary"],
                                "diagnosis": missing["diagnosis"],
                                "matched_label": clean(label),
                                "detector_guess": detector_guess(path, cells, row_num, col_num),
                                "source_file": str(path.relative_to(ROOT)),
                                "sheet_xml": sheet_file,
                                "label_cell": ref,
                                "nearby_values": values,
                            }
                        )
        except Exception as exc:
            errors.append({"file": str(path.relative_to(ROOT)), "error": str(exc)})

    deduped = []
    seen = set()
    for item in candidates:
        key = (
            item["final_row"],
            item["matched_label"],
            item["source_file"],
            item["sheet_xml"],
            item["label_cell"],
            tuple((value["cell"], round(value["value"], 12)) for value in item["nearby_values"][:5]),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)

    grouped = defaultdict(list)
    for item in deduped:
        grouped[(item["final_row"], item["primary"], item["secondary"], item["diagnosis"])].append(item)

    rows = []
    for (final_row, primary, secondary, diagnosis), hits in sorted(grouped.items()):
        rows.append(
            {
                "final_row": final_row,
                "primary": primary,
                "secondary": secondary,
                "diagnosis": diagnosis,
                "hit_count": len(hits),
                "hits": sorted(hits, key=lambda hit: (hit["source_file"], hit["label_cell"]))[:30],
            }
        )

    report = {
        "final_workbook": str(FINAL),
        "scan_root": str(ROOT),
        "missing_rows_in_final": len(missing_rows),
        "source_workbooks_scanned": scanned,
        "source_workbooks_containing_missing_label": files_with_key,
        "missing_rows_with_candidate_values": len(rows),
        "candidate_hits": len(deduped),
        "rows": rows,
        "errors": errors[:200],
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in report if k not in {"rows", "errors"}}, ensure_ascii=False, indent=2))
    for row in rows:
        print(f"ROW {row['final_row']} | {row['primary']} | {row['secondary']} | {row['diagnosis']} | hits={row['hit_count']}")
        for hit in row["hits"][:8]:
            values = ", ".join(f"{v['cell']}={v['value']:.6g}" for v in hit["nearby_values"][:5])
            print(f"  {hit['detector_guess']} | {hit['matched_label']} | {hit['source_file']} | {hit['label_cell']} | {values}")
    if errors:
        print(f"ERRORS={len(errors)}")


if __name__ == "__main__":
    main()
