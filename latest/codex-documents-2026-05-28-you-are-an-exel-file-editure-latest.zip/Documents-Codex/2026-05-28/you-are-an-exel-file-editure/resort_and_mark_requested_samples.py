from copy import copy
from datetime import datetime
from pathlib import Path
from shutil import copy2

from openpyxl import load_workbook
from openpyxl.styles import PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

NOT_CHECKED = "לא נבדק"
OLD_METERING_SYSTEM = "old metering system"
MISSING = "missing"
MARK_FILL = PatternFill(fill_type="solid", fgColor="FFFFFF00")

REQUESTED = {
    "F-OE-24219": "24/12/2024",
    "F-ZS-25108": "24/06/2025",
    "F-IY-25113": "06/07/2025",
    "F-OK-25116": "15/07/2025",
    "F-DN-24186": "06/11/2024",
    "F-AT-23197": "10/09/2023",
}

# F-OE-24219 is currently present under the short alias FOE219.
ALIASES = {
    "F-OE-24219": ["F-OE-24219", "FOE219", "UN FOE219"],
    "F-ZS-25108": ["F-ZS-25108"],
    "F-IY-25113": ["F-IY-25113"],
    "F-OK-25116": ["F-OK-25116"],
    "F-DN-24186": ["F-DN-24186"],
    "F-AT-23197": ["F-AT-23197"],
}


def clean(value):
    return "" if value is None else str(value).strip()


def normalize(value):
    return clean(value).lower().replace("-", "").replace(" ", "")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def row_text(ws, row):
    return " | ".join(clean(ws.cell(row, col).value) for col in range(1, ws.max_column + 1))


def status_sort_value(status):
    status = clean(status)
    if status == "measured":
        return 0
    if status == OLD_METERING_SYSTEM:
        return 1
    if status == MISSING:
        return 2
    if status == NOT_CHECKED:
        return 3
    return 4


def diagnosis_sort_value(diagnosis, final_value):
    value = clean(diagnosis) or clean(final_value)
    order = {
        "CDf": 0,
        "CDr": 1,
        "UCf": 2,
        "UCr": 3,
        "UC": 4,
        "IBD": 5,
        "IBS": 6,
        "Healthy": 7,
        "HS": 7,
        "Unknown": 8,
        "(IBS controls)": 9,
    }
    return (order.get(value, 99), value)


def row_values(ws, row):
    return [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]


def row_styles(ws, row):
    styles = []
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(row, col)
        styles.append(
            {
                "style": copy(cell._style),
                "number_format": cell.number_format,
                "alignment": copy(cell.alignment),
                "border": copy(cell.border),
                "fill": copy(cell.fill),
                "font": copy(cell.font),
            }
        )
    return styles


def write_row(ws, row, values, styles):
    for col, value in enumerate(values, start=1):
        cell = ws.cell(row, col)
        cell.value = value
        style = styles[col - 1]
        cell._style = copy(style["style"])
        cell.number_format = style["number_format"]
        cell.alignment = copy(style["alignment"])
        cell.border = copy(style["border"])
        cell.fill = copy(style["fill"])
        cell.font = copy(style["font"])
        cell.comment = None


def table_sort_key(record, headers):
    values = record["values"]

    def val(header):
        col = headers[header] - 1
        return values[col] if col < len(values) else None

    return (
        status_sort_value(val("Measurement status")),
        diagnosis_sort_value(val("Diagnosis"), val("Final classification / decision")),
        clean(val("Primary name")),
        clean(val("Secondary / other name")),
    )


def find_row_for_sample(ws, sample):
    aliases = ALIASES[sample]
    hits = []
    for row in range(2, ws.max_row + 1):
        text = row_text(ws, row)
        norm_text = normalize(text)
        if any(alias.lower() in text.lower() or normalize(alias) in norm_text for alias in aliases):
            hits.append(row)
    return hits


def parse_date(value):
    return datetime.strptime(value, "%d/%m/%Y")


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before resort-mark samples {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    wb = load_workbook(WORKBOOK)
    ws = wb["Final"]
    headers = header_map(ws)

    marked = []
    for sample, date_text in REQUESTED.items():
        hits = find_row_for_sample(ws, sample)
        if len(hits) != 1:
            raise RuntimeError(f"Expected one match for {sample}, found {hits}")
        row = hits[0]
        primary_col = headers["Primary name"]
        secondary_col = headers["Secondary / other name"]
        date_col = headers["Sample date"]

        if sample == "F-OE-24219":
            secondary = clean(ws.cell(row, secondary_col).value)
            parts = [part.strip() for part in secondary.split(";") if part.strip()]
            if sample not in parts:
                parts.insert(0, sample)
            ws.cell(row, secondary_col).value = "; ".join(parts)

        ws.cell(row, date_col).value = parse_date(date_text)
        ws.cell(row, date_col).number_format = "dd/mm/yyyy"

        for col in [primary_col, secondary_col, date_col]:
            ws.cell(row, col).fill = copy(MARK_FILL)

        marked.append(
            {
                "sample": sample,
                "row_before_sort": row,
                "primary": ws.cell(row, primary_col).value,
                "secondary": ws.cell(row, secondary_col).value,
                "date": date_text,
                "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
            }
        )

    records = [
        {"values": row_values(ws, row), "styles": row_styles(ws, row)}
        for row in range(2, ws.max_row + 1)
    ]
    records.sort(key=lambda record: table_sort_key(record, headers))

    for offset, record in enumerate(records, start=2):
        write_row(ws, offset, record["values"], record["styles"])

    ws.auto_filter.ref = f"A1:{ws.cell(ws.max_row, ws.max_column).coordinate}"
    wb.save(WORKBOOK)

    # Locate samples after sort for reporting.
    wb_check = load_workbook(WORKBOOK, data_only=False)
    ws_check = wb_check["Final"]
    final_locations = {}
    for sample in REQUESTED:
        final_locations[sample] = find_row_for_sample(ws_check, sample)

    print(
        {
            "workbook": str(WORKBOOK),
            "backup": str(backup),
            "marked": marked,
            "final_locations": final_locations,
            "rows": ws.max_row - 1,
            "cols": ws.max_column,
            "auto_filter": ws.auto_filter.ref,
        }
    )


if __name__ == "__main__":
    main()
