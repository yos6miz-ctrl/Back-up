from __future__ import annotations

from pathlib import Path
import importlib.util
import json

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
HELPER = WORKSPACE / "audit_missing_values_across_onedrive.py"
OUT = WORKSPACE / "missing_values_summary_files_report.json"


spec = importlib.util.spec_from_file_location("helper", HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


SOURCE_FILES = [
    ROOT / "Excel file editor" / "deta" / "447 and araE ALL.xlsx",
    ROOT / "Excel file editor" / "deta" / "IBD IBS OLD.xlsx",
    ROOT / "Excel file editor" / "deta" / "Merged Unknowns trial 6.26 shir.xlsx",
    ROOT / "Excel file editor" / "deta" / "Merged Unknowns trial 6.26.xlsx",
    ROOT / "Excel file editor" / "deta" / "Unknowns trial 6.26.xlsx",
    ROOT / "not good" / "447 without GA 30 EXL שיר.xlsx",
    ROOT / "p447" / "השוואה 447 קלפרוטקטין שיר" / "447 without GA 30 EXL שיר.xlsx",
    ROOT / "p447" / "השוואה 447 קלפרוטקטין שיר" / "CDf and IBS metherments.xlsx",
    ROOT / "דוח כמין" / "חזרה שניה" / "447 all old.xlsx",
    ROOT / "דוח כמין" / "חזרה שניה" / "araE all old.xlsx",
    ROOT / "דוח כמין" / "שנה 2" / "447 and araE" / "Final 447 and araE.xlsx",
    ROOT / "דוח כמין" / "שנה 2" / "447 and araE" / "Final 447.xlsx",
    ROOT / "דוח כמין" / "שנה 2" / "447 and araE" / "Final araE.xlsx",
]


def worksheet_cells(ws):
    cells = {}
    for row in ws.iter_rows():
        for cell in row:
            value = cell.value
            if value is not None and value != "":
                cells[(cell.row, cell.column)] = (value, cell.coordinate)
    return cells


def focused_values(cells, row, col):
    same_row = []
    same_col_below = []
    for (r, c), (value, ref) in cells.items():
        if not helper.is_measurement_number(value):
            continue
        item = {"cell": ref, "value": float(value), "row_delta": r - row, "col_delta": c - col}
        if r == row and 0 < c - col <= 12:
            same_row.append(item)
        if c == col and 0 < r - row <= 12:
            same_col_below.append(item)
    same_row.sort(key=lambda item: item["col_delta"])
    same_col_below.sort(key=lambda item: item["row_delta"])
    return same_row[:10] + same_col_below[:10]


def main():
    missing_rows = helper.load_missing_rows()
    rows = []
    errors = []
    for path in SOURCE_FILES:
        if not path.exists():
            continue
        print(f"checking {path.relative_to(ROOT)}", flush=True)
        try:
            wb = load_workbook(path, data_only=True, read_only=True)
            for ws in wb.worksheets:
                cells = worksheet_cells(ws)
                for (r, c), (value, ref) in cells.items():
                    if not isinstance(value, str):
                        continue
                    matches = helper.label_matches(value, missing_rows)
                    if not matches:
                        continue
                    nums = focused_values(cells, r, c)
                    if not nums:
                        continue
                    for missing in matches:
                        rows.append(
                            {
                                "final_row": missing["row"],
                                "primary": missing["primary"],
                                "secondary": missing["secondary"],
                                "diagnosis": missing["diagnosis"],
                                "matched_label": helper.clean(value),
                                "detector_guess": helper.detector_guess(path, cells, r, c),
                                "source_file": str(path.relative_to(ROOT)),
                                "sheet": ws.title,
                                "label_cell": ref,
                                "nearby_values": nums[:8],
                            }
                        )
        except Exception as exc:
            errors.append({"file": str(path.relative_to(ROOT)), "error": str(exc)})

    seen = set()
    deduped = []
    for item in rows:
        key = (
            item["final_row"],
            item["matched_label"],
            item["source_file"],
            item["sheet"],
            item["label_cell"],
            tuple((v["cell"], round(v["value"], 12)) for v in item["nearby_values"][:5]),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)

    grouped = {}
    for item in deduped:
        key = (item["final_row"], item["primary"], item["secondary"], item["diagnosis"])
        grouped.setdefault(key, []).append(item)

    report_rows = []
    for (final_row, primary, secondary, diagnosis), hits in sorted(grouped.items()):
        report_rows.append(
            {
                "final_row": final_row,
                "primary": primary,
                "secondary": secondary,
                "diagnosis": diagnosis,
                "hit_count": len(hits),
                "hits": sorted(hits, key=lambda h: (h["source_file"], h["sheet"], h["label_cell"])),
            }
        )

    report = {
        "source_files_checked": [str(p.relative_to(ROOT)) for p in SOURCE_FILES if p.exists()],
        "missing_rows_in_final": len(missing_rows),
        "missing_rows_with_candidate_values": len(report_rows),
        "candidate_hits": len(deduped),
        "rows": report_rows,
        "errors": errors,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in report if k not in {"rows", "errors"}}, ensure_ascii=False, indent=2))
    for row in report_rows:
        print(f"ROW {row['final_row']} | {row['primary']} | {row['secondary']} | {row['diagnosis']} | hits={row['hit_count']}")
        for hit in row["hits"][:10]:
            values = ", ".join(f"{v['cell']}={v['value']:.6g}" for v in hit["nearby_values"][:5])
            print(f"  {hit['detector_guess']} | {hit['matched_label']} | {hit['source_file']} | {hit['sheet']}!{hit['label_cell']} | {values}")
    if errors:
        print(f"ERRORS={len(errors)}")


if __name__ == "__main__":
    main()
