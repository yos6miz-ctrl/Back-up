from __future__ import annotations

from pathlib import Path
import json
import math
import re

from openpyxl import load_workbook


FILES = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260818 UN 447.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260818 UN araE.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260819 UN 447.xlsx"),
]
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\raw_trace_20260818_20260819_extracted.json")


def clean(value):
    return "" if value is None else str(value).strip()


def is_sample_header(value):
    text = clean(value)
    if not text:
        return False
    low = text.lower()
    return not any(token in low for token in ["glutaric", "arabinose", "control"])


def numeric(value):
    try:
        if value in (None, ""):
            return None
        value = float(value)
        if not math.isfinite(value):
            return None
        return value
    except Exception:
        return None


def detector(path: Path):
    return "araE" if "arae" in path.name.lower() else "PA447"


def source_date(path: Path):
    match = re.search(r"(20\d{6})", path.name)
    if not match:
        return None
    text = match.group(1)
    return f"{text[:4]}-{text[4:6]}-{text[6:]}"


def paired_columns(ws):
    pairs = []
    col = 1
    while col + 1 <= ws.max_column:
        label = clean(ws.cell(1, col).value)
        current_header = clean(ws.cell(2, col + 1).value).lower()
        if label and ("µa" in current_header or "ua" in current_header):
            pairs.append({"label": label, "time_col": col, "current_col": col + 1})
        col += 2
    return pairs


def compact_columns(ws):
    pairs = []
    time_col = 1
    for col in range(2, ws.max_column + 1):
        label = clean(ws.cell(1, col).value)
        current_header = clean(ws.cell(2, col).value).lower()
        if label and ("µa" in current_header or "ua" in current_header):
            pairs.append({"label": label, "time_col": time_col, "current_col": col})
    return pairs


def current_at_1500(ws, time_col, current_col):
    best = None
    for row in range(3, ws.max_row + 1):
        t = numeric(ws.cell(row, time_col).value)
        y = numeric(ws.cell(row, current_col).value)
        if t is None or y is None:
            continue
        diff = abs(t - 1500)
        if best is None or diff < best[0]:
            best = (diff, row, y)
            if diff == 0:
                break
    if best is None:
        return None, None
    return best[2], best[1]


def current_at_1500_rows(rows, time_col, current_col):
    best = None
    for row_number, row in enumerate(rows[2:], start=3):
        t = numeric(row[time_col - 1] if time_col - 1 < len(row) else None)
        y = numeric(row[current_col - 1] if current_col - 1 < len(row) else None)
        if t is None or y is None:
            continue
        diff = abs(t - 1500)
        if best is None or diff < best[0]:
            best = (diff, row_number, y)
            if diff == 0:
                break
    if best is None:
        return None, None
    return best[2], best[1]


def paired_columns_from_rows(rows):
    if len(rows) < 2:
        return []
    first = rows[0]
    second = rows[1]
    pairs = []
    col = 1
    while col + 1 <= len(first):
        label = clean(first[col - 1])
        current_header = clean(second[col]).lower() if col < len(second) else ""
        if label and ("µa" in current_header or "ua" in current_header):
            pairs.append({"label": label, "time_col": col, "current_col": col + 1})
        col += 2
    if pairs:
        return pairs
    time_col = 1
    for col in range(2, len(first) + 1):
        label = clean(first[col - 1])
        current_header = clean(second[col - 1]).lower() if col - 1 < len(second) else ""
        if label and ("µa" in current_header or "ua" in current_header):
            pairs.append({"label": label, "time_col": time_col, "current_col": col})
    return pairs


def extract_file(path: Path):
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    pairs = paired_columns_from_rows(rows)
    det = detector(path)
    substrate_token = "arabinose" if det == "araE" else "glutaric"
    substrate = next((p for p in pairs if substrate_token in p["label"].lower()), None)
    control = next((p for p in pairs if "control" in p["label"].lower()), None)
    if not substrate or not control:
        return []
    substrate_current, substrate_row = current_at_1500_rows(rows, substrate["time_col"], substrate["current_col"])
    control_current, control_row = current_at_1500_rows(rows, control["time_col"], control["current_col"])
    if substrate_current is None or control_current is None:
        return []
    control_baseline = round(control_current, 1)
    denominator = substrate_current - control_baseline
    records = []
    for pair in pairs:
        label = pair["label"]
        if not is_sample_header(label):
            continue
        current, row = current_at_1500_rows(rows, pair["time_col"], pair["current_col"])
        if current is None or denominator == 0:
            continue
        value = (current - control_baseline) / denominator
        if value < 0:
            value = 0.0
        records.append(
            {
                "sample_name": label,
                "detector": det,
                "value": value,
                "source_file": path.name,
                "source_date": source_date(path),
                "source_cell": f"{ws.title}!R{row}C{pair['current_col']}",
                "current_at_1500": current,
                "control_current_at_1500": control_current,
                "control_baseline_rounded": control_baseline,
                "substrate_current_at_1500": substrate_current,
                "denominator": denominator,
                "substrate_row": substrate_row,
                "control_row": control_row,
            }
        )
    return records


def main():
    records = []
    for path in FILES:
        records.extend(extract_file(path))
    OUT.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
