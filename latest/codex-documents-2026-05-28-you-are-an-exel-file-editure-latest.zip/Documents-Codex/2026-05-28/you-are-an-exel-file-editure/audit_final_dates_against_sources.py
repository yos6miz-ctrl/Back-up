import json
import re
import zipfile
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

import openpyxl


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS_WORKING = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
REPORT = WORKSPACE / "audit_final_dates_against_sources_report.json"

SOURCE_FILES = [
    ALIQUOTS_WORKING,
    ROOT / "aliqauts 20260801.xlsx",
    ROOT / "Old sampels" / "Stool aliquots updated.xlsx",
    ROOT / "Old sampels" / "All Stool aliquots updated 10.8.23.xlsx",
    ROOT / "Old sampels" / "CD to Bar Ilan Feb 23 clinical data.xlsx",
    ROOT / "Old sampels" / "Stools  to Bar ilan UID 7.2.23.xlsx",
    ROOT / "Old sampels" / "ישן-new stool inventory.xlsx",
    ROOT / "Old sampels" / "samples for weizmann PAO1.xlsx",
]

NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
NS_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def split_names(*values):
    names = []
    for value in values:
        if not value:
            continue
        for part in re.split(r"\s*;\s*", str(value)):
            part = part.strip()
            if part:
                names.append(part)
    return names


def numeric_tail(value):
    text = norm(value)
    match = re.search(r"(\d+)$", text)
    return match.group(1) if match else ""


def strong_keys(names):
    keys = set()
    for name in names:
        text = norm(name)
        if text:
            keys.add(text)
        # Add bare CT/HS numeric only when the prefix is part of the ID.
        match = re.search(r"\b(CT|HS)\s*-?\s*(\d+)\b", name, re.I)
        if match:
            keys.add(match.group(1).upper() + match.group(2))
        # Add "old N" as a linkable alias, but not plain N globally.
        match = re.search(r"\bold\s*(\d+)\b", name, re.I)
        if match:
            keys.add("OLD" + match.group(1))
    return {key for key in keys if key}


def excel_serial_to_date(value):
    try:
        number = float(value)
    except Exception:
        return None
    if not 20000 <= number <= 60000:
        return None
    # Excel incorrectly treats 1900 as leap year; openpyxl's epoch equivalent for Windows workbooks.
    return (datetime(1899, 12, 30) + timedelta(days=number)).strftime("%Y-%m-%d")


def normalize_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d")
    text = str(value).strip()
    if not text:
        return None
    serial = excel_serial_to_date(text)
    if serial:
        return serial
    text = text.split(" ")[0]
    for fmt in ("%Y-%m-%d", "%d.%m.%y", "%d.%m.%Y", "%d/%m/%Y", "%d/%m/%y", "%m/%d/%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except Exception:
            pass
    return text


def col_index(cell_ref):
    letters = "".join(ch for ch in cell_ref if ch.isalpha())
    result = 0
    for char in letters:
        result = result * 26 + ord(char.upper()) - ord("A") + 1
    return result


def read_shared_strings(zf):
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    strings = []
    for si in root.findall(f"{NS_MAIN}si"):
        strings.append("".join(t.text or "" for t in si.iter(f"{NS_MAIN}t")))
    return strings


def sheet_path_for_name(zf, sheet_name):
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_by_id = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels.findall(f"{NS_PKG_REL}Relationship")}
    for sheet in workbook.findall(f".//{NS_MAIN}sheet"):
        if sheet.attrib.get("name") == sheet_name:
            target = rel_by_id[sheet.attrib[f"{NS_REL}id"]].lstrip("/")
            return target if target.startswith("xl/") else "xl/" + target
    raise RuntimeError(sheet_name)


def cell_text(cell, shared_strings):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(t.text or "" for t in cell.iter(f"{NS_MAIN}t"))
    value = cell.find(f"{NS_MAIN}v")
    if value is None:
        return ""
    text = value.text or ""
    if cell_type == "s":
        try:
            return shared_strings[int(text)]
        except Exception:
            return text
    return text


def read_final_rows():
    with zipfile.ZipFile(FINAL) as zf:
        shared_strings = read_shared_strings(zf)
        root = ET.fromstring(zf.read(sheet_path_for_name(zf, "Final")))
        raw_rows = []
        for row in root.findall(f".//{NS_MAIN}row"):
            values = {}
            max_col = 0
            for cell in row.findall(f"{NS_MAIN}c"):
                index = col_index(cell.attrib["r"])
                values[index] = cell_text(cell, shared_strings)
                max_col = max(max_col, index)
            raw_rows.append([values.get(index, "") for index in range(1, max_col + 1)])
    headers = {name: index for index, name in enumerate(raw_rows[0])}
    final_rows = []
    for excel_row, row in enumerate(raw_rows[1:], start=2):
        def get(header):
            index = headers.get(header)
            return row[index] if index is not None and index < len(row) else ""
        names = split_names(get("Primary name"), get("Secondary / other name"))
        final_rows.append(
            {
                "row": excel_row,
                "primary": get("Primary name"),
                "secondary": get("Secondary / other name"),
                "status": get("Measurement status"),
                "diagnosis": get("Diagnosis"),
                "final_date_raw": get("Sample date"),
                "final_date": normalize_date(get("Sample date")),
                "source": get("Measurement/source file"),
                "names": names,
                "keys": sorted(strong_keys(names)),
            }
        )
    return final_rows


def find_col(headers, *needles):
    lowered = [str(header or "").strip().lower() for header in headers]
    for needle in needles:
        for index, header in enumerate(lowered):
            if needle in header:
                return index + 1
    return None


def resolved_merged_value(ws, row, col):
    cell = ws.cell(row, col)
    if cell.value is not None:
        return cell.value
    for merged in ws.merged_cells.ranges:
        if merged.min_row <= row <= merged.max_row and merged.min_col <= col <= merged.max_col:
            return ws.cell(merged.min_row, merged.min_col).value
    return None


def source_records_from_workbook(path):
    records = []
    try:
        wb = openpyxl.load_workbook(path, read_only=False, data_only=True)
    except Exception as exc:
        return records, str(exc)
    for ws in wb.worksheets:
        headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
        patient_col = find_col(headers, "patient number", "מספר מטופל", "patient")
        sample_col = find_col(headers, "sample #", "sample code", "sample name", "קוד דגימה", "samplecode")
        date_col = find_col(headers, "sample date", "תאריך דגימה", "date", "תאריך")
        diagnosis_col = find_col(headers, "diagnosis", "ibd")
        box_col = find_col(headers, "box", "משלוח")
        if not sample_col and not patient_col:
            continue
        for row in range(2, ws.max_row + 1):
            patient = ws.cell(row, patient_col).value if patient_col else None
            sample = ws.cell(row, sample_col).value if sample_col else None
            if not patient and not sample:
                continue
            names = split_names(patient, sample)
            keys = strong_keys(names)
            if not keys:
                continue
            diag = ws.title
            if diagnosis_col:
                diag_value = ws.cell(row, diagnosis_col).value
                if diag_value:
                    diag = str(diag_value)
            records.append(
                {
                    "file": str(path),
                    "sheet": ws.title,
                    "row": row,
                    "box": resolved_merged_value(ws, row, box_col) if box_col else None,
                    "patient": patient,
                    "sample": sample,
                    "diagnosis": diag,
                    "date": normalize_date(ws.cell(row, date_col).value) if date_col else None,
                    "date_raw": str(ws.cell(row, date_col).value) if date_col and ws.cell(row, date_col).value is not None else None,
                    "keys": sorted(keys),
                    "tail": numeric_tail(sample) or numeric_tail(patient),
                }
            )
    wb.close()
    return records, None


def main():
    final_rows = read_final_rows()
    source_records = []
    source_errors = []
    seen = set()
    for path in SOURCE_FILES:
        if not path.exists():
            continue
        records, error = source_records_from_workbook(path)
        if error:
            source_errors.append({"file": str(path), "error": error})
        for record in records:
            marker = (record["file"], record["sheet"], record["row"], tuple(record["keys"]))
            if marker not in seen:
                source_records.append(record)
                seen.add(marker)

    source_by_key = defaultdict(list)
    for record in source_records:
        for key in record["keys"]:
            source_by_key[key].append(record)

    unsupported_dates = []
    suspicious_shared_numeric = []
    for final in final_rows:
        if not final["final_date"]:
            continue
        matched = []
        for key in final["keys"]:
            matched.extend(source_by_key.get(key, []))
        # de-dupe
        unique = []
        seen_match = set()
        for match in matched:
            marker = (match["file"], match["sheet"], match["row"])
            if marker not in seen_match:
                unique.append(match)
                seen_match.add(marker)
        source_dates = sorted({match["date"] for match in unique if match["date"]})
        if unique and final["final_date"] not in source_dates:
            unsupported_dates.append(
                {
                    "final": {key: final[key] for key in ("row", "primary", "secondary", "diagnosis", "status", "final_date")},
                    "matched_source_dates": source_dates,
                    "matched_sources": unique[:8],
                }
            )

    # Potential collisions by exact secondary/name numeric value among different primary names.
    by_numeric_key = defaultdict(list)
    for final in final_rows:
        for name in final["names"]:
            if re.fullmatch(r"\d+", str(name).strip()):
                by_numeric_key[str(name).strip()].append(final)
    for num, rows in by_numeric_key.items():
        primaries = {row["primary"] for row in rows}
        diagnoses = {row["diagnosis"] for row in rows}
        dates = {row["final_date"] for row in rows}
        if len(primaries) > 1 and (len(diagnoses) > 1 or len(dates) > 1):
            suspicious_shared_numeric.append(
                {
                    "numeric_alias": num,
                    "rows": [
                        {key: row[key] for key in ("row", "primary", "secondary", "diagnosis", "status", "final_date", "source")}
                        for row in rows
                    ],
                }
            )

    focus = {}
    for target in ("F-MH-21163", "CT-163", "CT1156", "F-YD-21156"):
        target_key = norm(target)
        focus[target] = {
            "final_rows": [
                {key: row[key] for key in ("row", "primary", "secondary", "diagnosis", "status", "final_date", "source")}
                for row in final_rows
                if target_key in row["keys"] or target_key in norm(" ".join(row["names"]))
            ],
            "source_rows": [
                record
                for record in source_records
                if target_key in record["keys"] or target_key in norm(" ".join(str(x or "") for x in (record["patient"], record["sample"])))
            ],
        }

    report = {
        "source_errors": source_errors,
        "source_record_count": len(source_records),
        "unsupported_date_count": len(unsupported_dates),
        "unsupported_dates": unsupported_dates[:100],
        "suspicious_shared_numeric_count": len(suspicious_shared_numeric),
        "suspicious_shared_numeric": suspicious_shared_numeric[:100],
        "focus": focus,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
