import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const file = "C:/Users/Popovtzer lab/.codex/Excel file editor/Merged Unknowns trial 6.26.xlsx";
const input = await FileBlob.load(file);
const workbook = await SpreadsheetFile.importXlsx(input);

const preview = await workbook.inspect({
  kind: "table",
  range: "Merged!A1:L12",
  include: "values,formulas",
  tableMaxRows: 12,
  tableMaxCols: 12,
});

const eim = await workbook.inspect({
  kind: "table",
  range: "Merged!A140:J140",
  include: "values,formulas",
  tableMaxRows: 1,
  tableMaxCols: 10,
});

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 50 },
  summary: "formula error scan",
});

try {
  await workbook.render({ sheetName: "Merged", range: "A1:J30", scale: 1 });
  console.log("RENDER\tok");
} catch (error) {
  console.log(`RENDER\t${error?.message ?? error}`);
}

console.log("PREVIEW");
console.log(preview.ndjson);
console.log("EIM_ROW");
console.log(eim.ndjson);
console.log("ERRORS");
console.log(errors.ndjson);
