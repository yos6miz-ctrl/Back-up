import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const folder = "C:/Users/Popovtzer lab/.codex/Excel file editor";
const files = {
  names: `${folder}/UN stool names.xlsx`,
  trial: `${folder}/Unknowns trial 6.26.xlsx`,
  merged: `${folder}/Merged Unknowns trial 6.26.xlsx`,
};

async function inspectValues(file, range, maxRows = 500, maxCols = 26) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const table = await workbook.inspect({
    kind: "table",
    range: `${sheet.name}!${range}`,
    include: "values,formulas",
    tableMaxRows: maxRows,
    tableMaxCols: maxCols,
  });
  const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
  return JSON.parse(line).values ?? [];
}

async function chunkedValues(file, columnEnd, maxRow, chunkSize) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const rows = [];
  for (let start = 1; start <= maxRow; start += chunkSize) {
    const end = Math.min(maxRow, start + chunkSize - 1);
    const table = await workbook.inspect({
      kind: "table",
      range: `${sheet.name}!A${start}:${columnEnd}${end}`,
      include: "values,formulas",
      tableMaxRows: chunkSize,
      tableMaxCols: 26,
    });
    const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
    const matrix = JSON.parse(line).values ?? [];
    for (let i = 0; i < matrix.length; i++) {
      rows.push({ sourceRow: start + i, values: matrix[i] });
    }
  }
  return rows;
}

function clean(value) {
  return typeof value === "string" ? value.trim() : value;
}

function key(value) {
  return String(value ?? "")
    .toUpperCase()
    .replace(/\([^)]*\)/g, "")
    .replace(/^UN\s*/, "")
    .replace(/[^A-Z0-9.]/g, "")
    .replace(/\./g, "");
}

function duplicates(rows, nameGetter) {
  const seen = new Map();
  const result = [];
  for (const row of rows) {
    const name = nameGetter(row);
    const k = key(name);
    if (!k) continue;
    if (seen.has(k)) {
      result.push({ duplicate: row, original: seen.get(k), key: k });
    } else {
      seen.set(k, row);
    }
  }
  return result;
}

const nameRows = (await inspectValues(files.names, "A1:B500"))
  .map((row, index) => ({ row: index + 1, realName: clean(row[0]), unknownName: clean(row[1]) }))
  .filter((row) => row.realName || row.unknownName);

const trialRows = (await chunkedValues(files.trial, "I", 220, 30))
  .map(({ sourceRow, values }) => ({ row: sourceRow, unknownName: clean(values[0]) }))
  .filter((row) => row.row > 1 && row.unknownName);

const mergedRows = (await chunkedValues(files.merged, "N", 220, 30))
  .map(({ sourceRow, values }) => ({ row: sourceRow, realName: clean(values[0]), unknownName: clean(values[1]), matchStatus: clean(values[10]) }))
  .filter((row) => row.row > 1 && (row.realName || row.unknownName));

console.log(JSON.stringify({
  counts: {
    names: nameRows.length,
    trial: trialRows.length,
    merged: mergedRows.length,
  },
  nameDuplicatesByUnknown: duplicates(nameRows, (row) => row.unknownName),
  nameDuplicatesByReal: duplicates(nameRows, (row) => row.realName),
  trialDuplicatesByUnknown: duplicates(trialRows, (row) => row.unknownName),
  mergedDuplicatesByUnknown: duplicates(mergedRows, (row) => row.unknownName),
  mergedDuplicatesByReal: duplicates(mergedRows, (row) => row.realName),
}, null, 2));
