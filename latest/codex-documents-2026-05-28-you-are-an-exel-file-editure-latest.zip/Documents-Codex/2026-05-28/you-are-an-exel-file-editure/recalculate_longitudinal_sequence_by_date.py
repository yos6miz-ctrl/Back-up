from __future__ import annotations

from collections import defaultdict, Counter
from datetime import datetime
from pathlib import Path
import json
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "recalculate_longitudinal_sequence_by_date_report.json"


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def date_key(value):
    value = clean(value)
    if not value:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return value[:10]


def sortable_date(value):
    key = date_key(value)
    try:
        return datetime.strptime(key, "%Y-%m-%d")
    except ValueError:
        return datetime.max


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def alias_base(value):
    text = norm(value)
    match = re.match(r"^(\d+[A-Z]+)\d+$", text)
    if match:
        return match.group(1)
    return None


def sample_aliases_from_aliquots():
    aliases = {}
    source_dates = defaultdict(set)
    if not ALIQUOTS.exists():
        return aliases, source_dates
    wb = load_workbook(ALIQUOTS, data_only=True)
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        header = None
        for row_num in range(1, ws.max_row + 1):
            values = [ws.cell(row_num, col).value for col in range(1, ws.max_column + 1)]
            labels = [(clean(value) or "").lower() for value in values]
            if "sample name (f)" in labels or "sample #" in labels or "sample" in labels:
                header = {label: idx for idx, label in enumerate(labels) if label}
                continue
            if not header:
                continue
            sample_idx = header.get("sample name (f)", header.get("sample #", header.get("sample")))
            if sample_idx is None or sample_idx >= len(values):
                continue
            sample = clean(values[sample_idx])
            if not sample:
                continue

            candidate_aliases = []
            for label in ("patient number", "name"):
                idx = header.get(label)
                if idx is not None and idx < len(values):
                    candidate_aliases.append(clean(values[idx]))
            patient_code_idx = header.get("מספר מטופל")
            patient_code = clean(values[patient_code_idx]) if patient_code_idx is not None and patient_code_idx < len(values) else None

            group = None
            for candidate in candidate_aliases:
                base = alias_base(candidate)
                if base:
                    group = f"alias-base:{base}"
                    break
            if not group and patient_code:
                group = f"patient-code:{norm(patient_code)}"
            if not group:
                for candidate in candidate_aliases:
                    if candidate and norm(candidate) != norm(sample):
                        candidate_key = norm(candidate)
                        if candidate_key.isdigit():
                            group = f"sheet:{norm(sheet)}:patient-alias:{candidate_key}"
                        else:
                            group = f"patient-alias:{candidate_key}"
                        break
            if not group:
                continue

            for value in [sample, *candidate_aliases]:
                key = norm(value)
                if key:
                    aliases[key] = group
            date_idx = header.get("תאריך ביקור", header.get("date"))
            if date_idx is not None and date_idx < len(values):
                sample_date = date_key(values[date_idx])
                if sample_date:
                    source_dates[group].add(sample_date)
    return aliases, source_dates


def group_for_row(row_values, headers, alias_groups):
    primary = row_values[headers["Primary name"] - 1]
    secondary = row_values[headers["Secondary / other name"] - 1]
    patient_code = clean(row_values[headers["Patient unique code"] - 1]) if "Patient unique code" in headers else None
    if patient_code:
        return f"patient-code:{norm(patient_code)}"
    for value in (primary, secondary):
        key = norm(value)
        if key in alias_groups:
            return alias_groups[key]
    for value in (primary, secondary):
        base = alias_base(value)
        if base:
            return f"alias-base:{base}"
    return f"single-row:{norm(primary)}:{norm(secondary)}"


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def style_sheet(ws):
    headers = header_map(ws)
    for row in range(2, ws.max_row + 1):
        importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
        importer.style_final(ws.cell(row, headers["Final classification / decision"]), ws.cell(row, headers["Final classification / decision"]).value)
        importer.style_detector(ws.cell(row, headers["PA447 decision"]), ws.cell(row, headers["PA447 decision"]).value)
        importer.style_detector(ws.cell(row, headers["araE decision"]), ws.cell(row, headers["araE decision"]).value)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "Longitudinal sample": 16,
        "Patient unique code": 18,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    measurement_cols = set()
    for name, col in headers.items():
        if name and "measurement" in str(name).lower() and "source" not in str(name).lower():
            measurement_cols.add(col)
            widths[name] = 13.5
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_cols:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col in {headers["Longitudinal sample"], headers["Patient unique code"], headers["Calprotectin level"]}:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.zoomScale = 85


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before longitudinal sequence recalculation {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    alias_groups, source_dates = sample_aliases_from_aliquots()
    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    rows = []
    groups = defaultdict(list)
    for row_num, values in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        group = group_for_row(values, headers, alias_groups)
        record = {
            "row": row_num,
            "group": group,
            "primary": values[headers["Primary name"] - 1],
            "secondary": values[headers["Secondary / other name"] - 1],
            "sample_date": values[headers["Sample date"] - 1],
            "date_key": date_key(values[headers["Sample date"] - 1]),
            "old": values[headers["Longitudinal sample"] - 1],
        }
        rows.append(record)
        groups[group].append(record)

    changes = []
    group_summaries = []
    for group, records in groups.items():
        source_distinct_dates = sorted(source_dates.get(group, []))
        group_is_longitudinal = len(records) > 1 or len(source_distinct_dates) > 1
        if not group_is_longitudinal:
            new_values = {records[0]["row"]: 0}
        else:
            distinct_dates = []
            for key in source_distinct_dates:
                if key not in distinct_dates:
                    distinct_dates.append(key)
            for record in sorted(records, key=lambda item: (sortable_date(item["sample_date"]), item["row"])):
                key = record["date_key"] or f"row-{record['row']}"
                if key not in distinct_dates:
                    distinct_dates.append(key)
            rank_by_date = {key: idx for idx, key in enumerate(distinct_dates, start=1)}
            new_values = {}
            for record in records:
                key = record["date_key"] or f"row-{record['row']}"
                new_values[record["row"]] = rank_by_date[key]
        if len(records) > 1:
            group_summaries.append(
                {
                    "group": group,
                    "count": len(records),
                    "max_sequence": max(new_values.values()),
                    "samples": [
                        {
                            "row": record["row"],
                            "primary": record["primary"],
                            "secondary": record["secondary"],
                            "date": record["date_key"],
                            "old": record["old"],
                            "new": new_values[record["row"]],
                        }
                        for record in sorted(records, key=lambda item: (sortable_date(item["sample_date"]), item["row"]))
                    ],
                }
            )
        for record in records:
            new_value = new_values[record["row"]]
            cell = ws.cell(record["row"], headers["Longitudinal sample"])
            if cell.value != new_value:
                changes.append(
                    {
                        "row": record["row"],
                        "primary": record["primary"],
                        "date": record["date_key"],
                        "old": cell.value,
                        "new": new_value,
                    }
                )
                cell.value = new_value

    style_sheet(ws)
    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    values = [check_ws.cell(row, check_headers["Longitudinal sample"]).value for row in range(2, check_ws.max_row + 1)]
    report = {
        "final": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "rows": check_ws.max_row - 1,
        "columns": check_ws.max_column,
        "changed_rows_count": len(changes),
        "longitudinal_value_counts": dict(Counter(values)),
        "multi_sample_group_count": sum(1 for records in groups.values() if len(records) > 1),
        "groups_with_sequence_above_2_count": sum(1 for summary in group_summaries if summary["max_sequence"] > 2),
        "groups_with_sequence_above_2": [summary for summary in group_summaries if summary["max_sequence"] > 2],
        "sample_changes_preview": changes[:80],
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2, default=str))


if __name__ == "__main__":
    main()
