import json
import shutil
import zipfile
from copy import copy
from pathlib import Path

import openpyxl

ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\fix_ct163_unsupported_metadata_report.json")

CLEAR_COLUMNS = ["Calprotectin level", "Disease location", "Sample date"]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def style_empty_clinical_cell(ws, headers, row, column_name):
    col = headers[column_name]
    cell = ws.cell(row, col)
    # Reuse an existing green "missing clinical metadata" cell style if available.
    for scan_row in range(2, ws.max_row + 1):
        other = ws.cell(scan_row, col)
        if other.value in (None, ""):
            fill = other.fill
            rgb = getattr(fill.fgColor, "rgb", None)
            if fill.fill_type == "solid" and rgb and rgb.upper() in {"FFC6EFCE", "FFCCFFCC", "FF92D050", "FF00B050"}:
                cell.fill = copy(fill)
                return


def validate_xlsx(path):
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        tables = [name for name in zf.namelist() if name.startswith("xl/tables/")]
    return {"zip_bad_member": bad, "table_parts": tables}


def main():
    wb = openpyxl.load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    primary_col = headers["Primary name"]
    target_rows = [row for row in range(2, ws.max_row + 1) if str(ws.cell(row, primary_col).value or "") == "CT-163"]
    if target_rows != [309]:
        raise RuntimeError(f"Expected CT-163 only at row 309, found {target_rows}")

    row = target_rows[0]
    before = {column: ws.cell(row, headers[column]).value for column in CLEAR_COLUMNS}
    for column in CLEAR_COLUMNS:
        ws.cell(row, headers[column]).value = None
    style_empty_clinical_cell(ws, headers, row, "Calprotectin level")
    style_empty_clinical_cell(ws, headers, row, "Disease location")

    wb.save(ONEDRIVE_FINAL)
    wb.close()
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    wb_check = openpyxl.load_workbook(ONEDRIVE_FINAL, data_only=True)
    ws_check = wb_check["Final"]
    headers_check = header_map(ws_check)
    after = {column: ws_check.cell(row, headers_check[column]).value for column in CLEAR_COLUMNS}
    wb_check.close()

    report = {
        "row": row,
        "primary": "CT-163",
        "reason": "Date/calprotectin/location were unsupported for CT-163 and came from the separate F-MH-21163 row through shared numeric alias 163.",
        "before": before,
        "after": after,
        "onedrive_health": validate_xlsx(ONEDRIVE_FINAL),
        "codex_health": validate_xlsx(CODEX_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
