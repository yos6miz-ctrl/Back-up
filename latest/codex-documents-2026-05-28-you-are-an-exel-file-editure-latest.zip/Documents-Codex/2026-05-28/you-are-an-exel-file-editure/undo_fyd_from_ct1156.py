import json
import re
import shutil
import zipfile
from copy import copy
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import expand_measurement_columns_and_show_all as expander
import import_2026_measurements as importer


FINAL_CODEX = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
FINAL_ONEDRIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\undo_fyd_from_ct1156_report.json")

FYD_ROW = {
    "Primary name": "CDf F-YD21156",
    "Secondary / other name": None,
    "Measurement status": "measured",
    "Diagnosis": "CDf",
    "Final classification / decision": "inconclusive",
    "Calprotectin level": 442,
    "Disease location": "Ileal",
    "Longitudinal sample": 1,
    "Patient unique code": 1853925,
    "Sample date": "2021-03-08",
    "Measurement/source file": "PA447: 20230928 447 15 eddited.xlsx, 20231130 447 35 eddited.xlsx",
    "PA447 values": [0.3227896489595112, 0.1467104487948947],
}

CT1156_PA447_KEEP = [0.3283287853563772, 0.06571293379131117, 0.01676493658535725]


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def detector_cols(headers, detector):
    cols = []
    i = 1
    while f"{detector} measurement {i}" in headers:
        cols.append(headers[f"{detector} measurement {i}"])
        i += 1
    return cols


def copy_row_style(ws, src_row, dest_row):
    for col in range(1, ws.max_column + 1):
        src = ws.cell(src_row, col)
        dest = ws.cell(dest_row, col)
        if src.has_style:
            dest._style = copy(src._style)
        dest.number_format = src.number_format
        if src.alignment:
            dest.alignment = copy(src.alignment)
        if src.border:
            dest.border = copy(src.border)


def set_detector_values(ws, headers, row, detector, values):
    cols = detector_cols(headers, detector)
    if len(values) > len(cols):
        raise RuntimeError(f"Need {len(values)} {detector} columns but only found {len(cols)}")
    for idx, col in enumerate(cols):
        cell = ws.cell(row, col)
        cell.value = values[idx] if idx < len(values) else None
        if cell.value is not None:
            cell.number_format = "0.000000000"


def clean_secondary(value):
    parts = []
    for part in re.split(r"\s*;\s*", str(value or "")):
        part = part.strip().replace("CDf 1156 old (old)", "CDf 1156 old")
        if not part or norm(part) in {"CDFFYD21156", "FYD21156"}:
            continue
        if part not in parts:
            parts.append(part)
    if "CDf 1156 old" not in parts:
        parts.append("CDf 1156 old")
    return "; ".join(parts)


def workbook_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "tables": [name for name in zf.namelist() if name.startswith("xl/tables/")],
        }


def row_summary(ws, headers, row):
    data = {}
    for key in (
        "Primary name",
        "Secondary / other name",
        "Measurement status",
        "Diagnosis",
        "Final classification / decision",
        "Calprotectin level",
        "Disease location",
        "Longitudinal sample",
        "Patient unique code",
        "PA447 decision",
        "araE decision",
        "Sample date",
        "Measurement/source file",
    ):
        data[key] = ws.cell(row, headers[key]).value
    for detector in ("PA447", "araE"):
        values = []
        for col in detector_cols(headers, detector):
            value = ws.cell(row, col).value
            if importer.is_numeric(value):
                values.append(float(value))
        data[f"{detector} values"] = values
    return data


def main():
    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_CODEX)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    ct_rows = []
    existing_fyd_rows = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        if norm(primary) == "CT1156":
            ct_rows.append(row)
        if norm(primary) in {"CDFFYD21156", "FYD21156"} or norm(secondary) in {"CDFFYD21156", "FYD21156"}:
            existing_fyd_rows.append(row)
    if len(ct_rows) != 1:
        raise RuntimeError(f"Expected one CT1156 row, found {ct_rows}")
    if existing_fyd_rows:
        raise RuntimeError(f"F-YD row already exists: {existing_fyd_rows}")

    ct_row = ct_rows[0]
    before_ct = row_summary(ws, headers, ct_row)

    ws.cell(ct_row, headers["Secondary / other name"]).value = clean_secondary(
        ws.cell(ct_row, headers["Secondary / other name"]).value
    )
    ws.cell(ct_row, headers["Measurement/source file"]).value = (
        "PA447: 20230928 447 15 eddited.xlsx, 20260826 447 sample repeats.xlsx; "
        "araE: 20240523 araE 11 eddited.xlsx, 20240528 araE 16 eddited.xlsx, 20260826 araE sample repeats.xlsx"
    )
    set_detector_values(ws, headers, ct_row, "PA447", CT1156_PA447_KEEP)
    expander.reclassify_row_majority(ws, headers, ct_row, bars)

    new_row = ws.max_row + 1
    copy_row_style(ws, ct_row, new_row)
    for col in range(1, ws.max_column + 1):
        ws.cell(new_row, col).value = None
    for key, value in FYD_ROW.items():
        if key.endswith(" values"):
            continue
        ws.cell(new_row, headers[key]).value = value
    set_detector_values(ws, headers, new_row, "PA447", FYD_ROW["PA447 values"])
    set_detector_values(ws, headers, new_row, "araE", [])
    expander.reclassify_row_majority(ws, headers, new_row, bars)

    for cell in ws[1]:
        cell.fill = importer.PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
        cell.font = importer.Font(name="Calibri", size=11, bold=True, color="000000")

    importer.sort_records(ws, headers)
    headers = importer.header_map(ws)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL_CODEX)
    importer.remove_comment_and_table_parts(FINAL_CODEX)
    shutil.copy2(FINAL_CODEX, FINAL_ONEDRIVE)

    check = load_workbook(FINAL_CODEX, read_only=True, data_only=True)
    check_ws = check["Final"]
    check_headers = importer.header_map(check_ws)
    after = []
    for row in range(2, check_ws.max_row + 1):
        primary = check_ws.cell(row, check_headers["Primary name"]).value
        secondary = check_ws.cell(row, check_headers["Secondary / other name"]).value
        if norm(primary) == "CT1156" or norm(primary) in {"CDFFYD21156", "FYD21156"}:
            after.append({"row": row, **row_summary(check_ws, check_headers, row)})
    check.close()

    report = {
        "before_ct1156": before_ct,
        "after_rows": after,
        "codex_health": workbook_health(FINAL_CODEX),
        "onedrive_health": workbook_health(FINAL_ONEDRIVE),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
