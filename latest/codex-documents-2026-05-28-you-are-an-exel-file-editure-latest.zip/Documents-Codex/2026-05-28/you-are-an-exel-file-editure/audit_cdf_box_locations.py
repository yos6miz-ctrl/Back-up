import json
from pathlib import Path

import openpyxl

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
CURRENT = ROOT / "aliqauts 20260801.xlsx"
OLD_REFERENCE = ROOT / "Old sampels" / "All Stool aliquots updated 10.8.23.xlsx"
REPORT = WORKSPACE / "audit_cdf_box_locations_report.json"


def resolved_box(ws, row):
    value = ws.cell(row, 2).value
    if value not in (None, ""):
        return value
    for merged in ws.merged_cells.ranges:
        if merged.min_col <= 2 <= merged.max_col and merged.min_row <= row <= merged.max_row:
            return ws.cell(merged.min_row, merged.min_col).value
    return None


def read_cdf(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["CDf"]
    rows = []
    for row in range(1, ws.max_row + 1):
        rows.append(
            {
                "row": row,
                "group": ws.cell(row, 1).value,
                "box_cell": ws.cell(row, 2).value,
                "resolved_box": resolved_box(ws, row),
                "patient": ws.cell(row, 3).value,
                "sample": ws.cell(row, 4).value,
                "date": ws.cell(row, 6).value,
                "aliquots": ws.cell(row, 14).value if ws.max_column >= 14 else None,
            }
        )
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    wb.close()
    return {"rows": rows, "merged_ranges": merged}


def main():
    current = read_cdf(CURRENT)
    old = read_cdf(OLD_REFERENCE)
    missing_current_boxes = [
        row for row in current["rows"][1:] if row["sample"] and not row["resolved_box"]
    ]
    report = {
        "current_file": str(CURRENT),
        "old_reference_file": str(OLD_REFERENCE),
        "current_cdf": current,
        "old_reference_cdf": old,
        "missing_current_boxes_count": len(missing_current_boxes),
        "missing_current_boxes": missing_current_boxes,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
