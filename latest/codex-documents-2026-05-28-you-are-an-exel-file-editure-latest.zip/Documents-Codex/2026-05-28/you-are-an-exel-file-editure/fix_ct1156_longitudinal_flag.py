import json
import shutil
import zipfile
from pathlib import Path

import openpyxl

ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\fix_ct1156_longitudinal_flag_report.json")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def validate_xlsx(path):
    with zipfile.ZipFile(path) as zf:
        return {"zip_bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def main():
    wb = openpyxl.load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    target_rows = [
        row
        for row in range(2, ws.max_row + 1)
        if str(ws.cell(row, headers["Primary name"]).value or "") == "CT1156"
    ]
    if target_rows != [72]:
        raise RuntimeError(f"Expected CT1156 only at row 72, found {target_rows}")

    row = target_rows[0]
    col = headers["Longitudinal sample"]
    before = ws.cell(row, col).value
    ws.cell(row, col).value = 0
    wb.save(ONEDRIVE_FINAL)
    wb.close()
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    wb_check = openpyxl.load_workbook(ONEDRIVE_FINAL, data_only=True)
    ws_check = wb_check["Final"]
    headers_check = header_map(ws_check)
    after = ws_check.cell(row, headers_check["Longitudinal sample"]).value
    wb_check.close()

    report = {
        "row": row,
        "primary": "CT1156",
        "reason": "CT1156/F-YD-21156 appears in the regular CDf aliquots sheet, not in the two longitudinal aliquots tabs.",
        "before_longitudinal_sample": before,
        "after_longitudinal_sample": after,
        "onedrive_health": validate_xlsx(ONEDRIVE_FINAL),
        "codex_health": validate_xlsx(CODEX_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
