from datetime import datetime
from pathlib import Path
from shutil import copy2
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
REPAIRED_COPY = EXCEL_DIR / "Final Known and Unknown merged repaired.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before open-error repair {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    changed = []
    with ZipFile(WORKBOOK, "r") as zin:
        with NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            with ZipFile(tmp_path, "w", ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    data = zin.read(item.filename)
                    if item.filename == "xl/tables/table1.xml":
                        text = data.decode("utf-8")
                        old = '<autoFilter ref="A1:R358"/>'
                        new = '<autoFilter ref="A1:R352"/>'
                        if old in text:
                            text = text.replace(old, new)
                            data = text.encode("utf-8")
                            changed.append((item.filename, old, new))
                    zout.writestr(item, data)

            saved_as = WORKBOOK
            try:
                WORKBOOK.unlink()
                tmp_path.replace(WORKBOOK)
            except PermissionError:
                copy2(tmp_path, REPAIRED_COPY)
                saved_as = REPAIRED_COPY
        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    print({"workbook": str(WORKBOOK), "saved_as": str(saved_as), "backup": str(backup), "changed": changed})


def try_install_repaired_copy():
    if not REPAIRED_COPY.exists():
        print({"installed": False, "reason": "No repaired copy exists"})
        return
    try:
        copy2(REPAIRED_COPY, WORKBOOK)
    except PermissionError as exc:
        print({"installed": False, "reason": str(exc), "repaired_copy": str(REPAIRED_COPY)})
        return
    REPAIRED_COPY.unlink()
    print({"installed": True, "workbook": str(WORKBOOK)})


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--install-repaired-copy":
        try_install_repaired_copy()
    else:
        main()
