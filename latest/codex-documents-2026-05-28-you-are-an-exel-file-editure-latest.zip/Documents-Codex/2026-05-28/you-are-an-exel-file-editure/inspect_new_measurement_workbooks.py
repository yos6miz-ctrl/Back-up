from pathlib import Path
from openpyxl import load_workbook

FILES = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260818 UN 447.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260818 UN araE.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260819 UN 447.xlsx"),
]

for path in FILES:
    print("\nFILE", path.name)
    wbv = load_workbook(path, data_only=True, read_only=False)
    wbf = load_workbook(path, data_only=False, read_only=False)
    for ws in wbv.worksheets:
        wsf = wbf[ws.title]
        print("SHEET", ws.title, ws.max_row, ws.max_column)
        print("top-left")
        for r in range(1, min(ws.max_row, 12) + 1):
            vals = [ws.cell(r, c).value for c in range(1, min(ws.max_column, 18) + 1)]
            print(r, vals)
        print("bottom/right non-empty")
        rows = []
        for r in range(max(1, ws.max_row - 20), ws.max_row + 1):
            vals = []
            has = False
            for c in range(max(1, ws.max_column - 18), ws.max_column + 1):
                v = ws.cell(r, c).value
                f = wsf.cell(r, c).value
                if v is not None or f is not None:
                    has = True
                vals.append(v if v is not None else f)
            if has:
                rows.append((r, vals))
        for r, vals in rows:
            print(r, vals)
        print("formula cells with division, first 30")
        n = 0
        for row in wsf.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and v.startswith("=") and "/" in v:
                    print(cell.coordinate, v, "=>", ws[cell.coordinate].value)
                    n += 1
                    if n >= 30:
                        break
            if n >= 30:
                break
