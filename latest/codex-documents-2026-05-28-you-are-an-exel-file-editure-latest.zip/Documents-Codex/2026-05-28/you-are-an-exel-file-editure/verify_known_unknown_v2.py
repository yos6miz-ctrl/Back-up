from collections import Counter
from pathlib import Path
import importlib.util

from openpyxl import load_workbook


workspace = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
builder_path = workspace / "build_known_unknown_workbook.py"
spec = importlib.util.spec_from_file_location("builder", builder_path)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
NOT_CHECKED = builder.NOT_CHECKED
MISSING = builder.MISSING

preferred_path = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Merged Unknowns trial 6.26 updated.xlsx")
path = preferred_path if preferred_path.exists() else Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Merged Unknowns trial 6.26.xlsx")
wb = load_workbook(path, data_only=True)
unknown = wb["Unknown"]
known = wb["Known"]
notes = wb["Match notes"]

issues = []
if wb.sheetnames != ["Unknown", "Known", "Match notes"]:
    issues.append(f"Unexpected sheets: {wb.sheetnames}")
if unknown.max_row - 1 != 140:
    issues.append(f"Unknown row count is {unknown.max_row - 1}, expected 140")
if known.max_row - 1 != 58:
    issues.append(f"Known row count is {known.max_row - 1}, expected 58")

expected_unknown_headers = [
    "Real name",
    "Unknown name",
    "Diagnosis",
    "PA447 measurement 1",
    "PA447 measurement 2",
    "PA447 measurement 3",
    "PA447 decision",
    "araE measurement 1",
    "araE measurement 2",
    "araE measurement 3",
    "araE decision",
    "Final decision",
]
expected_known_headers = [
    "Sample name",
    "Matched source/sample name",
    "Diagnosis",
    "PA447 measurement",
    "PA447 decision",
    "araE measurement",
    "araE decision",
    "Final classification",
    "Measurement status",
    "Sample date",
    "Date sent",
    "Match basis",
    "Measurement source",
    "Alias source",
]
unknown_headers = [unknown.cell(row=1, column=col).value for col in range(1, len(expected_unknown_headers) + 1)]
known_headers = [known.cell(row=1, column=col).value for col in range(1, len(expected_known_headers) + 1)]
if unknown_headers != expected_unknown_headers:
    issues.append(f"Unknown headers mismatch: {unknown_headers}")
if known_headers != expected_known_headers:
    issues.append(f"Known headers mismatch: {known_headers}")

unknown_names = [unknown.cell(row=row, column=2).value for row in range(2, unknown.max_row + 1) if unknown.cell(row=row, column=2).value]
if len(unknown_names) != len(set(unknown_names)):
    issues.append("Duplicate Unknown sample names found")

known_names = [known.cell(row=row, column=2).value for row in range(2, known.max_row + 1) if known.cell(row=row, column=2).value]
if len(known_names) != len(set(known_names)):
    issues.append("Duplicate Known sample names found")

all_rows, all_by_key = builder.load_all_measurements()
old_rows = builder.load_old()
old_by_name = {row["old_name"]: row for row in old_rows}
all_by_source_diag = {(row["source_name"], row["diagnosis"]): row for row in all_rows}


def same_value(a, b):
    if a in (None, "") and b in (None, ""):
        return True
    if isinstance(a, (int, float)) or isinstance(b, (int, float)):
        return abs(float(a) - float(b)) < 1e-10
    return str(a) == str(b)

for row in range(2, known.max_row + 1):
    sample_name = known.cell(row=row, column=1).value
    source_name = known.cell(row=row, column=2).value
    diagnosis = known.cell(row=row, column=3).value
    pa447 = known.cell(row=row, column=4).value
    pa447_decision = known.cell(row=row, column=5).value
    arae = known.cell(row=row, column=6).value
    arae_decision = known.cell(row=row, column=7).value
    final = known.cell(row=row, column=8).value
    status = known.cell(row=row, column=9).value
    source = known.cell(row=row, column=13).value
    if status == "not measured":
        issues.append(f"Known row {row}: old English not measured label remains")
        continue
    if status == NOT_CHECKED:
        if final != NOT_CHECKED:
            issues.append(f"Known row {row}: לא נבדק final is {final}")
        if any(value not in (None, "") for value in [source_name, diagnosis, pa447, pa447_decision, arae, arae_decision, source]):
            if any(value not in (None, "") for value in [source_name, pa447, pa447_decision, arae, arae_decision, source]):
                issues.append(f"Known row {row}: לא נבדק row contains unexpected matched values")
        continue
    if status == MISSING:
        if final != MISSING:
            issues.append(f"Known row {row}: missing final is {final}")
        if any(value not in (None, "") for value in [source_name, pa447, pa447_decision, arae, arae_decision, source]):
            issues.append(f"Known row {row}: missing row contains unexpected matched values")
        continue
    if status != "measured":
        issues.append(f"Known row {row}: unknown measurement status {status}")
        continue
    if source == "447 and araE ALL":
        record = all_by_source_diag.get((source_name, diagnosis))
        if record is None:
            issues.append(f"Known row {row}: ALL source record not found for {source_name}/{diagnosis}")
            continue
        if not same_value(record["pa447"], pa447):
            issues.append(f"Known row {row}: PA447 mismatch from ALL")
        if not same_value(record["araE"], arae):
            issues.append(f"Known row {row}: araE mismatch from ALL")
    elif source == "IBD IBS OLD":
        record = old_by_name.get(source_name)
        if record is None:
            issues.append(f"Known row {row}: OLD source record not found for {source_name}")
            continue
        if not same_value(record["pa447"], pa447):
            issues.append(f"Known row {row}: PA447 mismatch from OLD")
        if not same_value(record["araE"], arae):
            issues.append(f"Known row {row}: araE mismatch from OLD")
    else:
        issues.append(f"Known row {row}: missing measurement source")
    expected_final = builder.final_decision(pa447_decision, arae_decision)
    if final != expected_final:
        issues.append(f"Known row {row}: final mismatch {final} != {expected_final}")

style_checks = {
    "Unknown header": unknown["A1"].fill.fgColor.rgb,
    "Known header": known["A1"].fill.fgColor.rgb,
    "Known IBD": None,
    "Known IBS": None,
    "Known missing": None,
    "Known לא נבדק": None,
}
for row in range(2, known.max_row + 1):
    final = known.cell(row=row, column=8).value
    if final == "IBD" and style_checks["Known IBD"] is None:
        style_checks["Known IBD"] = known.cell(row=row, column=8).fill.fgColor.rgb
    elif final == "IBS" and style_checks["Known IBS"] is None:
        style_checks["Known IBS"] = known.cell(row=row, column=8).fill.fgColor.rgb
    elif final == MISSING and style_checks["Known missing"] is None:
        style_checks["Known missing"] = known.cell(row=row, column=8).fill.fgColor.rgb
    elif final == NOT_CHECKED and style_checks["Known לא נבדק"] is None:
        style_checks["Known לא נבדק"] = known.cell(row=row, column=8).fill.fgColor.rgb

print({
    "unknown_rows": unknown.max_row - 1,
    "known_rows": known.max_row - 1,
    "unknown_diagnosis_counts": dict(Counter(unknown.cell(row=row, column=3).value for row in range(2, unknown.max_row + 1))),
    "known_status_counts": dict(Counter(known.cell(row=row, column=9).value for row in range(2, known.max_row + 1))),
    "known_final_counts": dict(Counter(known.cell(row=row, column=8).value for row in range(2, known.max_row + 1))),
    "known_source_counts": dict(Counter(known.cell(row=row, column=13).value for row in range(2, known.max_row + 1))),
    "style_checks": style_checks,
    "issues": issues,
})
