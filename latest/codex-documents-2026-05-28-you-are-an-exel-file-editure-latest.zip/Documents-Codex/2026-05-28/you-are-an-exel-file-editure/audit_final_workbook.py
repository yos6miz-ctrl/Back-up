from collections import Counter, defaultdict
from pathlib import Path
import importlib.util
import json
import math
import re

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FOLDER = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = FOLDER / "Merged Unknowns trial 6.26.xlsx"
REPORT_PATH = WORKSPACE / "final_workbook_diagnostics.json"

spec = importlib.util.spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


def as_text(value):
    return "" if value is None else str(value).strip()


def row_values(ws, row):
    return [ws.cell(row=row, column=col).value for col in range(1, ws.max_column + 1)]


def almost_equal(left, right, tolerance=1e-9):
    if left is None or right is None:
        return False
    try:
        return math.isclose(float(left), float(right), rel_tol=tolerance, abs_tol=tolerance)
    except Exception:
        return False


def output_key_values(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def build_output_indexes(wb):
    unknown = wb["Unknown"]
    known = wb["Known"]
    indexes = {
        "unknown_by_key": defaultdict(list),
        "known_by_key": defaultdict(list),
        "known_rows": [],
        "unknown_rows": [],
    }
    for row in range(2, unknown.max_row + 1):
        raw = row_values(unknown, row)
        values = [raw[0], raw[1], raw[11], *raw[2:11]]
        record = {"row": row, "values": values}
        indexes["unknown_rows"].append(record)
        for key in output_key_values(values[0], values[1]):
            indexes["unknown_by_key"][key].append(record)
    for row in range(2, known.max_row + 1):
        raw = row_values(known, row)
        values = [raw[0], raw[1], raw[7], *raw[2:7], *raw[8:13]]
        record = {"row": row, "values": values}
        indexes["known_rows"].append(record)
        for key in output_key_values(values[0], values[1]):
            indexes["known_by_key"][key].append(record)
    return indexes


def final_workbook_basic_checks(wb):
    errors = []
    expected_sheets = ["Unknown", "Known", "Match notes"]
    if wb.sheetnames != expected_sheets:
        errors.append({"check": "sheet_names", "message": f"Expected {expected_sheets}, got {wb.sheetnames}"})
    expected_known = [
        "Sample name",
        "Synonym / other name",
        "PA447 measurement",
        "PA447 decision",
        "araE measurement",
        "araE decision",
        "Final classification",
        "Diagnosis",
        "Measurement status",
        "Sample date",
        "Date sent",
        "Match basis",
        "Measurement/source file",
    ]
    expected_unknown = [
        "Real name",
        "Unknown name",
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "PA447 decision",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
        "araE decision",
        "Final decision",
        "Diagnosis",
    ]
    known = wb["Known"]
    unknown = wb["Unknown"]
    known_headers = [known.cell(1, col).value for col in range(1, len(expected_known) + 1)]
    unknown_headers = [unknown.cell(1, col).value for col in range(1, len(expected_unknown) + 1)]
    if known_headers != expected_known:
        errors.append({"check": "known_headers", "message": f"Known headers mismatch: {known_headers}"})
    if unknown_headers != expected_unknown:
        errors.append({"check": "unknown_headers", "message": f"Unknown headers mismatch: {unknown_headers}"})
    return errors


def check_placement_and_names(indexes, aliquots, old_rows):
    errors = []
    warnings = []
    old_strict = set().union(*(row["strict_identifiers"] for row in old_rows))
    known_by_key = indexes["known_by_key"]
    unknown_by_key = indexes["unknown_by_key"]
    preferred_known_sources = {}

    for source_record in aliquots:
        is_old_unknown_source = source_record["source_sheet"] == "Unknown" and bool(source_record["strict_identifiers"] & old_strict)
        if source_record["source_sheet"] == "Unknown" and not is_old_unknown_source:
            continue
        comparable = source_record
        if is_old_unknown_source:
            comparable = {
                **source_record,
                "sample_name": source_record.get("patient_name") or source_record["sample_name"],
                "other_name": source_record.get("raw_sample_name"),
            }
        key = builder.norm(comparable["sample_name"]) or next(iter(sorted(comparable["identifiers"])), "")
        if builder.prefer_record(comparable, preferred_known_sources.get(key)):
            preferred_known_sources[key] = comparable

    for record in aliquots:
        is_old_unknown = record["source_sheet"] == "Unknown" and bool(record["strict_identifiers"] & old_strict)
        expected_unknown = record["source_sheet"] == "Unknown" and not is_old_unknown
        target = unknown_by_key if expected_unknown else known_by_key
        matches = []
        for key in record["identifiers"] | record["strict_identifiers"]:
            matches.extend(target.get(key, []))
        if not matches:
            errors.append(
                {
                    "check": "aliquots_placement",
                    "source": f"{record['source_sheet']} row {record['source_row']}",
                    "sample": record["sample_name"],
                    "expected": "Unknown" if expected_unknown else "Known",
                    "message": "Aliquots record not found in expected final sheet",
                }
            )
            continue

        # Name display checks for rows whose final sample name is directly known.
        if expected_unknown:
            expected_diag = builder.canonical_group(record.get("diagnosis")) or "Unknown"
            found_diag = {match["values"][2] for match in matches}
            if expected_diag not in found_diag:
                errors.append(
                    {
                        "check": "unknown_diagnosis",
                        "source": f"{record['source_sheet']} row {record['source_row']}",
                        "sample": record["sample_name"],
                        "expected": expected_diag,
                        "found": sorted(str(value) for value in found_diag),
                    }
                )
        else:
            comparable_record = record
            if is_old_unknown:
                comparable_record = {
                    **record,
                    "sample_name": record.get("patient_name") or record["sample_name"],
                    "other_name": record.get("raw_sample_name"),
                }
            expected_diag = builder.canonical_group(comparable_record.get("diagnosis")) or "Unknown"
            found_diag = {builder.canonical_group(match["values"][2]) or "Unknown" for match in matches}
            if expected_diag not in found_diag:
                errors.append(
                    {
                        "check": "known_diagnosis",
                        "source": f"{record['source_sheet']} row {record['source_row']}",
                        "sample": comparable_record["sample_name"],
                        "expected": expected_diag,
                        "found": sorted(str(value) for value in found_diag),
                    }
                )
            sample_key = builder.norm(comparable_record["sample_name"]) or next(iter(sorted(comparable_record["identifiers"])), "")
            preferred = preferred_known_sources.get(sample_key)
            if preferred and preferred.get("source_sheet") != comparable_record.get("source_sheet"):
                continue
            if preferred and preferred.get("source_row") != comparable_record.get("source_row"):
                continue
            expected_synonym = comparable_record.get("other_name")
            for match in matches:
                values = match["values"]
                if builder.norm(values[0]) == builder.norm(comparable_record.get("sample_name")):
                    found_synonym = values[1]
                    if (expected_synonym or None) != (found_synonym or None):
                        warnings.append(
                            {
                                "check": "known_synonym",
                                "row": match["row"],
                                "sample": values[0],
                                "expected_synonym": expected_synonym,
                                "found_synonym": found_synonym,
                                "message": "Known synonym differs from aliquots synonym",
                            }
                        )
                    break

    for old in old_rows:
        matches = []
        for key in old["identifiers"] | old["strict_identifiers"]:
            matches.extend(known_by_key.get(key, []))
        if not matches:
            errors.append({"check": "old_placement", "sample": old["sample_name"], "message": "IBD IBS OLD row is not in Known"})

    unknown_names = [record["values"][1] for record in indexes["unknown_rows"]]
    duplicate_unknowns = [name for name, count in Counter(unknown_names).items() if name and count > 1]
    if duplicate_unknowns:
        errors.append({"check": "duplicate_unknown_names", "duplicates": duplicate_unknowns})
    known_names = [record["values"][0] for record in indexes["known_rows"]]
    duplicate_known = [name for name, count in Counter(known_names).items() if name and count > 1]
    if duplicate_known:
        errors.append({"check": "duplicate_known_names", "duplicates": duplicate_known})

    return errors, warnings


def build_measurement_catalog(all_rows, old_rows):
    catalog = {"PA447": defaultdict(list), "araE": defaultdict(list)}
    for item in all_rows + old_rows:
        for detector, field in [("PA447", "pa447"), ("araE", "araE")]:
            if item.get(field) is None:
                continue
            keys = set(item.get("identifiers", set())) | set(item.get("strict_identifiers", set()))
            for key in keys:
                catalog[detector][key].append(item)
    return catalog


def check_measurements(indexes, catalog):
    errors = []
    warnings = []
    uncertain = []
    used_alias_value = defaultdict(list)

    for record in indexes["known_rows"]:
        row = record["row"]
        values = record["values"]
        sample, synonym, diagnosis = values[0], values[1], values[2]
        pa447, pa447_decision = values[3], values[4]
        arae, arae_decision = values[5], values[6]
        final, status = values[7], values[8]
        source = as_text(values[12])
        basis = as_text(values[11])

        if status == builder.MISSING:
            if final != builder.MISSING:
                errors.append({"check": "missing_final", "row": row, "sample": sample, "final": final})
            continue
        if status == builder.NOT_CHECKED:
            if final != builder.NOT_CHECKED:
                errors.append({"check": "not_checked_final", "row": row, "sample": sample, "final": final})
            continue
        if status == builder.OLD_METERING_SYSTEM:
            if final is not None:
                errors.append({"check": "old_metering_final", "row": row, "sample": sample, "final": final})
            if pa447 is None:
                errors.append({"check": "old_metering_missing_pa447", "row": row, "sample": sample})
            if pa447_decision is not None:
                errors.append({"check": "old_metering_pa447_decision", "row": row, "sample": sample, "decision": pa447_decision})
            if arae is not None or arae_decision is not None:
                errors.append(
                    {
                        "check": "old_metering_values",
                        "row": row,
                        "sample": sample,
                        "arae": arae,
                        "arae_decision": arae_decision,
                    }
                )
            continue

        if status != "measured":
            errors.append({"check": "unknown_status", "row": row, "sample": sample, "status": status})
            continue

        expected_pa447 = builder.detector_decision(pa447, "PA447")
        expected_arae = builder.detector_decision(arae, "araE")
        expected_final = builder.final_decision(expected_pa447, expected_arae)
        if pa447_decision != expected_pa447:
            errors.append({"check": "pa447_decision", "row": row, "sample": sample, "expected": expected_pa447, "found": pa447_decision})
        if arae_decision != expected_arae:
            errors.append({"check": "arae_decision", "row": row, "sample": sample, "expected": expected_arae, "found": arae_decision})
        if final != expected_final:
            errors.append({"check": "final_decision", "row": row, "sample": sample, "expected": expected_final, "found": final})

        keys = output_key_values(sample, synonym)
        for detector, value in [("PA447", pa447), ("araE", arae)]:
            if value is None:
                continue
            source_records = []
            for key in keys:
                source_records.extend(catalog[detector].get(key, []))
            if not any(almost_equal(item.get("pa447" if detector == "PA447" else "araE"), value) for item in source_records):
                warnings.append(
                    {
                        "check": "measurement_value_trace",
                        "row": row,
                        "sample": sample,
                        "detector": detector,
                        "value": value,
                        "message": "Final value not found among catalog records for this row's aliases",
                    }
                )

            if "alias" in basis.lower():
                used_alias_value[(detector, round(float(value), 12), builder.norm(synonym or sample))].append((row, sample))

            if detector == "PA447" and "PA447: 447 and araE ALL" in source:
                # We can verify values exist in the summary, but cannot prove GA provenance from that summary alone.
                exact_edited = [
                    item
                    for item in source_records
                    if item.get("source") == "edited normalized files"
                    and almost_equal(item.get("pa447"), value, tolerance=1e-7)
                    and item.get("source_file")
                ]
                provenance_ok = any(
                    almost_equal(item.get("pa447"), value, tolerance=1e-7)
                    and (
                        item.get("pa447_447_old_status") == "found_ga"
                        or item.get("pa447_447_new_status") == "found_ga_edited"
                    )
                    for item in source_records
                )
                if not exact_edited and not provenance_ok:
                    uncertain.append(
                        {
                            "check": "pa447_summary_ga_provenance",
                            "row": row,
                            "sample": sample,
                            "synonym": synonym,
                            "value": value,
                            "source": source,
                            "message": "PA447 comes from 447 and araE ALL and was not traceable to a same-value GA/glutaric edited workbook.",
                        }
                    )

    repeated_alias = {str(key): rows for key, rows in used_alias_value.items() if len(rows) > 1}
    if repeated_alias:
        errors.append({"check": "repeated_alias_detector_value", "duplicates": repeated_alias})

    return errors, warnings, uncertain


def check_folder_measurement_coverage(indexes, catalog):
    errors = []
    for record in indexes["known_rows"]:
        row = record["row"]
        values = record["values"]
        sample, synonym, diagnosis = values[0], values[1], values[2]
        pa447, pa447_decision = values[3], values[4]
        arae, arae_decision = values[5], values[6]
        final, status = values[7], values[8]
        if status == builder.NOT_CHECKED:
            continue
        keys = output_key_values(sample, synonym)
        for detector, value, decision in [("PA447", pa447, pa447_decision), ("araE", arae, arae_decision)]:
            if value is not None and decision is not None:
                continue
            available = []
            for key in keys:
                for item in catalog[detector].get(key, []):
                    if item.get("source") != "edited normalized files":
                        continue
                    if not builder.compatible(diagnosis, item.get("diagnosis")):
                        continue
                    available.append(item)
            if available:
                errors.append(
                    {
                        "check": "missed_folder_measurement",
                        "row": row,
                        "sample": sample,
                        "synonym": synonym,
                        "detector": detector,
                        "status": status,
                        "final": final,
                        "available_sources": sorted(
                            {
                                f"{item.get('source_file')}:{item.get('source_rows', [''])[0]}"
                                for item in available
                            }
                        )[:8],
                    }
                )
    return errors


def check_sorting(indexes):
    errors = []
    statuses = [record["values"][8] for record in indexes["known_rows"]]
    ordered = sorted(statuses, key=builder.status_sort_value)
    if statuses != ordered:
        errors.append({"check": "known_status_sort", "message": "Known rows are not sorted measured, old metering system, missing, לא נבדק"})
    return errors


def check_pa447_folder_ga(indexes):
    errors = []
    used_files = []
    pattern = re.compile(r"PA447: edited normalized files \((.*?)\)")
    for record in indexes["known_rows"]:
        source = as_text(record["values"][12])
        for match in pattern.finditer(source):
            rel = match.group(1)
            path = FOLDER / rel
            used_files.append(rel)
            try:
                wb = load_workbook(path, data_only=False, read_only=False)
            except Exception as exc:
                errors.append({"check": "pa447_edited_file_open", "row": record["row"], "file": rel, "error": str(exc)})
                continue
            if not builder.has_ga_marker(wb):
                errors.append({"check": "pa447_edited_ga_marker", "row": record["row"], "file": rel, "message": "PA447 edited source file lacks GA/glutaric marker"})
    return errors, {"pa447_edited_files_used": len(used_files), "unique_pa447_edited_files_used": len(set(used_files))}


def main():
    wb = load_workbook(FINAL_PATH, data_only=True)
    indexes = build_output_indexes(wb)
    aliquots, _aliases, _rows = builder.load_aliquots_inventory()
    old_rows = builder.load_old_rows()
    all_rows, _all_by_key = builder.load_all_measurements()
    catalog = build_measurement_catalog(all_rows, old_rows)

    errors = []
    warnings = []
    uncertain = []
    stats = {
        "final_unknown_rows": len(indexes["unknown_rows"]),
        "final_known_rows": len(indexes["known_rows"]),
        "aliquots_records": len(aliquots),
        "old_rows": len(old_rows),
        "edited_normalized_records": sum(1 for row in all_rows if row.get("source") == "edited normalized files"),
        "known_status_counts": dict(Counter(record["values"][8] for record in indexes["known_rows"])),
        "unknown_diagnosis_counts": dict(Counter(record["values"][2] for record in indexes["unknown_rows"])),
    }

    errors.extend(final_workbook_basic_checks(wb))
    placement_errors, placement_warnings = check_placement_and_names(indexes, aliquots, old_rows)
    errors.extend(placement_errors)
    warnings.extend(placement_warnings)
    measurement_errors, measurement_warnings, measurement_uncertain = check_measurements(indexes, catalog)
    errors.extend(measurement_errors)
    warnings.extend(measurement_warnings)
    uncertain.extend(measurement_uncertain)
    errors.extend(check_sorting(indexes))
    errors.extend(check_folder_measurement_coverage(indexes, catalog))
    ga_errors, ga_stats = check_pa447_folder_ga(indexes)
    errors.extend(ga_errors)
    stats.update(ga_stats)

    report = {
        "stats": stats,
        "errors": errors,
        "warnings": warnings,
        "uncertain": uncertain,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in report.items()}, ensure_ascii=False, indent=2))
    if errors:
        print("ERROR_EXAMPLES")
        print(json.dumps(errors[:20], ensure_ascii=False, indent=2))
    if warnings:
        print("WARNING_EXAMPLES")
        print(json.dumps(warnings[:20], ensure_ascii=False, indent=2))
    if uncertain:
        print("UNCERTAIN_EXAMPLES")
        print(json.dumps(uncertain[:20], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
