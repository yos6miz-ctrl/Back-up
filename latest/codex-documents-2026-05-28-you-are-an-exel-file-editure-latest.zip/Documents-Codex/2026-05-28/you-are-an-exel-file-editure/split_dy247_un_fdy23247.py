from copy import copy
from pathlib import Path

from openpyxl import load_workbook


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_row(ws, headers, primary, secondary=None):
    for row in range(2, ws.max_row + 1):
        primary_value = str(ws.cell(row, headers["Primary name"]).value or "").strip()
        secondary_value = str(ws.cell(row, headers["Secondary / other name"]).value or "").strip()
        if primary_value != primary:
            continue
        if secondary is not None and secondary_value != str(secondary or "").strip():
            continue
        return row
    return None


def copy_row_style(ws, source_row, target_row):
    for col in range(1, ws.max_column + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        if source.has_style:
            target._style = copy(source._style)
        if source.number_format:
            target.number_format = source.number_format
        if source.alignment:
            target.alignment = copy(source.alignment)
        if source.border:
            target.border = copy(source.border)
        if source.fill:
            target.fill = copy(source.fill)
        if source.font:
            target.font = copy(source.font)


def clear_measurements(ws, headers, row):
    for detector in ("PA447", "araE"):
        for idx in (1, 2, 3):
            ws.cell(row, headers[f"{detector} measurement {idx}"]).value = None


def set_measurements(ws, headers, row, detector, values):
    for idx in (1, 2, 3):
        cell = ws.cell(row, headers[f"{detector} measurement {idx}"])
        cell.value = None
        if idx <= len(values):
            cell.value = float(values[idx - 1])
            cell.number_format = "0.000000000"


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    dy_row = find_row(ws, headers, "DY-247")
    if dy_row is None:
        raise ValueError("DY-247 row not found")

    un_row = find_row(ws, headers, "UN F-DY-23247", "F-DY-23247")
    if un_row is None:
        ws.insert_rows(2)
        copy_row_style(ws, 3, 2)
        un_row = 2
        headers = header_map(ws)
        dy_row = find_row(ws, headers, "DY-247")

    # User-requested split.
    ws.cell(un_row, headers["Original tab"]).value = "Unknown"
    ws.cell(un_row, headers["Primary name"]).value = "UN F-DY-23247"
    ws.cell(un_row, headers["Secondary / other name"]).value = "F-DY-23247"
    ws.cell(un_row, headers["Measurement status"]).value = "measured"
    ws.cell(un_row, headers["Diagnosis"]).value = "CDr"
    ws.cell(un_row, headers["Calprotectin level"]).value = 165
    ws.cell(un_row, headers["Disease location"]).value = None
    ws.cell(un_row, headers["Sample date"]).value = "3.12.23"
    clear_measurements(ws, headers, un_row)
    set_measurements(ws, headers, un_row, "PA447", [0.193415, 0.591012096])
    set_measurements(ws, headers, un_row, "araE", [0.034902, 0.119836])

    set_measurements(ws, headers, dy_row, "PA447", [0.872768982, 0.306182081])
    set_measurements(ws, headers, dy_row, "araE", [0.046561491, 0.041162673])

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "un_row": un_row, "dy_row": dy_row})


if __name__ == "__main__":
    main()
