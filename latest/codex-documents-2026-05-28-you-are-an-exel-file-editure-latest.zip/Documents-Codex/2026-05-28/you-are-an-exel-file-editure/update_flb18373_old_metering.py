from copy import copy
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")

OLD_SOURCES = [
    "p447 CD 14.03.23.xlsx",
    "p447 CD stool samples 21.03.23.xlsx",
    "p447 CD stool samples 22.03.23.xlsx",
    "p447 stool samples 26.06.23.xlsx",
    "p447 (IBS) stool samples 03.07.23 (2).xlsx",
]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_row(ws, headers, primary):
    for row in range(2, ws.max_row + 1):
        if str(ws.cell(row, headers["Primary name"]).value or "").strip() == primary:
            return row
    return None


def copy_row_style(ws, source_row, target_row):
    for col in range(1, ws.max_column + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        if source.has_style:
            target._style = copy(source._style)
        target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.border = copy(source.border)
        target.fill = copy(source.fill)
        target.font = copy(source.font)


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    row = find_row(ws, headers, "F-LB-18373")
    if row is None:
        row = find_row(ws, headers, "F-ESH-21586") or ws.max_row + 1
        ws.insert_rows(row)
        copy_row_style(ws, min(row + 1, ws.max_row), row)
        headers = header_map(ws)

    for header in [
        "Original tab",
        "Primary name",
        "Secondary / other name",
        "Diagnosis",
        "Final classification / decision",
        "Calprotectin level",
        "Disease location",
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "PA447 decision",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
        "araE decision",
        "Measurement status",
        "Sample date",
        "Measurement/source file",
    ]:
        ws.cell(row, headers[header]).value = None

    values = {
        "Original tab": "Known",
        "Primary name": "F-LB-18373",
        "Secondary / other name": "CDf 373",
        "Diagnosis": "CDf",
        "Final classification / decision": "old metering system*",
        "Calprotectin level": 1128,
        "Disease location": None,
        "Measurement status": "old metering system",
        "Sample date": datetime(2018, 12, 12),
        "Measurement/source file": "PA447: " + ", ".join(OLD_SOURCES),
    }
    for header, value in values.items():
        ws.cell(row, headers[header]).value = value

    fills = {
        "Original tab": ("E7E6E6", "000000"),
        "Diagnosis": ("E06666", "FFFFFF"),
        "Final classification / decision": ("FFE599", "7F6000"),
        "Measurement status": ("FFE599", "7F6000"),
    }
    for header, (fill, font_color) in fills.items():
        cell = ws.cell(row, headers[header])
        cell.fill = PatternFill(fill_type="solid", fgColor=fill)
        cell.font = Font(name="Calibri", size=11, color=font_color, bold=True)

    final_cell = ws.cell(row, headers["Final classification / decision"])
    final_cell.comment = Comment(
        "Old metering system only. Raw 447 files contain CD 373/CDf 373 labels, but no GA/glutaric-normalized scalar was found; do not use as final IBD/IBS classification.",
        "Codex",
    )

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "row": row})


if __name__ == "__main__":
    main()
