import json
import shutil
import zipfile
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import expand_measurement_columns_and_show_all as expander
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPORT = WORKSPACE / "finish_20260826_import_report.json"

CT1156_VALUES = {
    "PA447": (0.016764936585357253, "20260826 447 sample repeats.xlsx"),
    "araE": (0.04110013274867531, "20260826 araE sample repeats.xlsx"),
}

AFFECTED_PRIMARY = {"F-AA-25186", "F-IY-25190", "F-OE-25191", "CT-130", "CT1156"}


def workbook_zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "tables": [name for name in zf.namelist() if name.startswith("xl/tables/")],
        }


def find_row_by_primary(ws, headers, primary):
    matches = []
    for row in range(2, ws.max_row + 1):
        if str(ws.cell(row, headers["Primary name"]).value or "").strip().upper() == primary.upper():
            matches.append(row)
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one row for {primary}; found {matches}")
    return matches[0]


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def value_present(ws, row, cols, value, tol=5e-6):
    for col in cols:
        cell_value = ws.cell(row, col).value
        if importer.is_numeric(cell_value) and abs(float(cell_value) - float(value)) <= tol:
            return True
    return False


def add_measurement(ws, headers, row, detector, value, source_file):
    cols = detector_cols(headers, detector)
    if value_present(ws, row, cols, value):
        return {"detector": detector, "value": value, "source_file": source_file, "status": "already_present"}
    for col in cols:
        if ws.cell(row, col).value in (None, ""):
            ws.cell(row, col).value = value
            ws.cell(row, col).number_format = "0.000000000"
            importer.write_source_cell(ws, row, headers, detector, source_file)
            return {
                "detector": detector,
                "value": value,
                "source_file": source_file,
                "status": "added",
                "cell": ws.cell(row, col).coordinate,
            }
    raise RuntimeError(f"No blank {detector} slot for row {row}")


def main():
    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    ct_row = find_row_by_primary(ws, headers, "CT1156")
    ct_results = []
    for detector, (value, source_file) in CT1156_VALUES.items():
        ct_results.append(add_measurement(ws, headers, ct_row, detector, value, source_file))

    reclassified = []
    for primary in sorted(AFFECTED_PRIMARY):
        row = find_row_by_primary(ws, headers, primary)
        before = ws.cell(row, headers["Final classification / decision"]).value
        after = expander.reclassify_row_majority(ws, headers, row, bars)
        reclassified.append(
            {
                "primary": primary,
                "row_before_sort": row,
                "before_final": before,
                "after_final": after,
                "pa447_decision": ws.cell(row, headers["PA447 decision"]).value,
                "arae_decision": ws.cell(row, headers["araE decision"]).value,
            }
        )

    for cell in ws[1]:
        cell.fill = importer.PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
        cell.font = importer.Font(name="Calibri", size=11, bold=True, color="000000")

    importer.sort_records(ws, headers)
    headers = importer.header_map(ws)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)
    shutil.copy2(FINAL, ONEDRIVE_FINAL)

    report = {
        "ct1156_manual_resolution": ct_results,
        "reclassified": reclassified,
        "final_zip_health": workbook_zip_health(FINAL),
        "onedrive_zip_health": workbook_zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
