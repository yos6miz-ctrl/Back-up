import json
from pathlib import Path

data = json.loads(Path("summary_with_single_and_old.json").read_text(encoding="utf-8"))
rows = data["added_rows"]

for dx in ["CDf", "CDr", "UCf", "IBS"]:
    print(f"\n{dx}")
    for row in rows:
        good = (
            dx in {"CDf", "CDr", "UCf"}
            and row["diagnosis"] == dx
            and row["classifier_final"] == "IBD"
        ) or (
            dx == "IBS"
            and row["diagnosis"] == "IBS"
            and row["classifier_final"] == "IBS"
        )
        if not good:
            continue
        vals = "; ".join(
            f"{detail['detector']}={detail['value']:.9g} {detail['call']}"
            for detail in row["details"]
        )
        print(
            row["excel_row"],
            row["primary"],
            row["secondary"],
            row["kind"],
            "cal=",
            row["calprotectin"],
            "loc=",
            repr(row["location"]),
            "bucket=",
            row["location_bucket"],
            "vals=",
            vals,
        )
