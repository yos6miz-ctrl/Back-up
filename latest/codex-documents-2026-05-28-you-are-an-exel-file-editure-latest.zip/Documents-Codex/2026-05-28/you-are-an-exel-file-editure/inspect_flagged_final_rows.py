import json
from pathlib import Path

import openpyxl

FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
TARGETS = {"CT-163", "F-MH-21163", "F-HG-20673", "CT-673", "F-KH-20674", "CT-674", "CT1156"}
COLUMNS = [
    "Primary name",
    "Secondary / other name",
    "Measurement status",
    "Diagnosis",
    "Final classification / decision",
    "Calprotectin level",
    "Disease location",
    "Sample date",
    "Measurement/source file",
]


def main():
    wb = openpyxl.load_workbook(FINAL, data_only=True)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    rows = []
    for row in range(2, ws.max_row + 1):
        primary = str(ws.cell(row, headers["Primary name"]).value or "")
        if primary in TARGETS:
            rows.append(
                {
                    "row": row,
                    **{
                        column: ws.cell(row, headers[column]).value if column in headers else None
                        for column in COLUMNS
                    },
                }
            )
    wb.close()
    print(json.dumps(rows, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
