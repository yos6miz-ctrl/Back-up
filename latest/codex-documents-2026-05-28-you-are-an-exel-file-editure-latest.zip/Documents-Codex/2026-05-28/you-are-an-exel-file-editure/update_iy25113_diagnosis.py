from datetime import datetime
from pathlib import Path
from shutil import copy2

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

CD_F_FILL = "FFE06666"
CD_F_FONT = "FF000000"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def row_text(ws, row):
    return " | ".join("" if ws.cell(row, col).value is None else str(ws.cell(row, col).value) for col in range(1, ws.max_column + 1))


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before IY25113 diagnosis update {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    wb = load_workbook(WORKBOOK)
    ws = wb["Final"]
    headers = header_map(ws)
    diagnosis_col = headers["Diagnosis"]

    matches = []
    for row in range(2, ws.max_row + 1):
        text = row_text(ws, row).lower()
        if "25113" in text or "iy 25113" in text or "iy25113" in text:
            matches.append(row)

    if len(matches) != 1:
        raise RuntimeError(f"Expected one IY25113 match, found {matches}")

    row = matches[0]
    old_diagnosis = ws.cell(row, diagnosis_col).value
    ws.cell(row, diagnosis_col).value = "CDf"
    ws.cell(row, diagnosis_col).fill = PatternFill(fill_type="solid", fgColor=CD_F_FILL)
    ws.cell(row, diagnosis_col).font = Font(name="Calibri", size=11, color=CD_F_FONT)

    wb.save(WORKBOOK)

    print(
        {
            "workbook": str(WORKBOOK),
            "backup": str(backup),
            "row": row,
            "primary": ws.cell(row, headers["Primary name"]).value,
            "secondary": ws.cell(row, headers["Secondary / other name"]).value,
            "old_diagnosis": old_diagnosis,
            "new_diagnosis": ws.cell(row, diagnosis_col).value,
        }
    )


if __name__ == "__main__":
    main()
