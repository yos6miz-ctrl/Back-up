from collections import Counter
from openpyxl import load_workbook


WORKBOOK = r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx"


def clean(value):
    if value is None:
        return ""
    return str(value).strip()


def norm(value):
    return clean(value).lower().replace(" ", "")


def doctor_class(dx):
    d = norm(dx)
    if not d:
        return None
    if d.startswith(("ucf", "ucr", "uc")):
        return "IBD"
    if d.startswith(("cdf", "cdr", "cd")):
        return "IBD"
    if d.startswith(("ibs", "healthy", "hs")):
        return "IBS"
    return None


def gut_class(decision):
    d = norm(decision).replace("*", "")
    if not d or "missing" in d or "oldmeter" in d or "inconclusive" in d or d in {"int", "לאנבדק"}:
        return None
    if "ibd" in d:
        return "IBD"
    if "ibs" in d:
        return "IBS"
    return None


def is_old(row):
    status = norm(row.get("Measurement status", ""))
    decision = norm(row.get("Final classification / decision", ""))
    return "oldmeter" in status or "oldmeter" in decision or "oldmetering" in status or "oldmetering" in decision


def is_healthy(dx):
    d = norm(dx)
    return d.startswith("healthy") or d == "hs"


def is_uc(dx):
    d = norm(dx)
    return d.startswith(("ucf", "ucr", "uc"))


def calpro_class(value):
    if value in (None, ""):
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return "IBD" if v >= 150 else "IBS"


def location_bucket(location):
    text = norm(location)
    if not text:
        return "Unknown/not recorded"
    has_small = any(token in text for token in ["ileal", "ileum", "smallbowel", "ileocecal", "terminalileum"])
    has_colon = any(token in text for token in ["colon", "colonic", "rect", "pancolitis", "leftsided", "l1", "l2", "l3"])
    # L1 is ileal, L2 colonic, L3 ileocolonic when recorded as Montreal location.
    if "l1" in text and "l2" not in text and "l3" not in text:
        has_small, has_colon = True, False
    if "l2" in text and "l1" not in text and "l3" not in text:
        has_small, has_colon = False, True
    if "l3" in text:
        has_small, has_colon = True, True
    if has_small and has_colon:
        return "Both colon and small bowel"
    if has_small:
        return "Small bowel only"
    if has_colon:
        return "Colon only"
    return "Unknown/not recorded"


wb = load_workbook(WORKBOOK, data_only=True)
ws = wb["Final"]
headers = [clean(ws.cell(1, c).value) for c in range(1, ws.max_column + 1)]
rows = []
for r in range(2, ws.max_row + 1):
    rows.append({headers[c - 1]: ws.cell(r, c).value for c in range(1, ws.max_column + 1)})

def confusion(subset, classifier):
    out = Counter()
    n = 0
    for row in subset:
        doc = doctor_class(row.get("Diagnosis"))
        pred = classifier(row)
        if not doc or not pred:
            continue
        n += 1
        if doc == "IBD" and pred == "IBD":
            out["TP"] += 1
        elif doc == "IBD" and pred == "IBS":
            out["FN"] += 1
        elif doc == "IBS" and pred == "IBD":
            out["FP"] += 1
        elif doc == "IBS" and pred == "IBS":
            out["TN"] += 1
    sens = out["TP"] / (out["TP"] + out["FN"]) if out["TP"] + out["FN"] else None
    spec = out["TN"] / (out["TN"] + out["FP"]) if out["TN"] + out["FP"] else None
    return n, out, sens, spec


current = [row for row in rows if not is_healthy(row.get("Diagnosis")) and not is_old(row)]
old = [row for row in rows if not is_healthy(row.get("Diagnosis")) and is_old(row)]
all_nonhealthy = [row for row in rows if not is_healthy(row.get("Diagnosis"))]
main_eligible = [
    row
    for row in current
    if doctor_class(row.get("Diagnosis")) and gut_class(row.get("Final classification / decision"))
]

main = confusion(current, lambda row: gut_class(row.get("Final classification / decision")))
old_res = confusion(old, lambda row: gut_class(row.get("Final classification / decision")))
combined = confusion(all_nonhealthy, lambda row: gut_class(row.get("Final classification / decision")))
cal = confusion(main_eligible, lambda row: calpro_class(row.get("Calprotectin level")))

low_cal_ibd = []
low_cal_caught = 0
low_cal_both_missed = 0
for row in main_eligible:
    doc = doctor_class(row.get("Diagnosis"))
    cp = calpro_class(row.get("Calprotectin level"))
    gs = gut_class(row.get("Final classification / decision"))
    if doc == "IBD" and cp == "IBS":
        low_cal_ibd.append(row)
        if gs == "IBD":
            low_cal_caught += 1
        elif gs == "IBS":
            low_cal_both_missed += 1

uc_current = [row for row in main_eligible if is_uc(row.get("Diagnosis"))]
uc_all = [row for row in rows if is_uc(row.get("Diagnosis"))]
uc_counts = Counter(gut_class(row.get("Final classification / decision")) or clean(row.get("Final classification / decision")) or "Blank" for row in uc_current)
uc_other = Counter()
for row in uc_all:
    if row in uc_current:
        continue
    key = gut_class(row.get("Final classification / decision")) or clean(row.get("Final classification / decision")) or "Blank"
    if is_old(row):
        key = f"Old-metering {key}*"
    uc_other[key] += 1

positive_nonhealthy = [row for row in current if gut_class(row.get("Final classification / decision")) == "IBD"]
positive_true_ibd = [row for row in positive_nonhealthy if doctor_class(row.get("Diagnosis")) == "IBD"]
loc_all_pos = Counter(location_bucket(row.get("Disease location")) for row in positive_nonhealthy)
loc_true_pos = Counter(location_bucket(row.get("Disease location")) for row in positive_true_ibd)

diagnosis_counts = Counter(clean(row.get("Diagnosis")) for row in rows if clean(row.get("Diagnosis")))
final_counts = Counter(clean(row.get("Final classification / decision")) for row in rows if clean(row.get("Final classification / decision")))

print("TOTAL_ROWS", len(rows))
print("DIAGNOSIS_COUNTS", dict(diagnosis_counts))
print("FINAL_COUNTS", dict(final_counts))
print("MAIN", main[0], dict(main[1]), main[2], main[3])
print("OLD_ONLY", old_res[0], dict(old_res[1]), old_res[2], old_res[3])
print("COMBINED", combined[0], dict(combined[1]), combined[2], combined[3])
print("CALPRO", cal[0], dict(cal[1]), cal[2], cal[3])
print("LOW_CAL_IBD", len(low_cal_ibd), "GS_CAUGHT", low_cal_caught, "BOTH_MISSED", low_cal_both_missed)
print("UC_CURRENT_N", len(uc_current), dict(uc_counts))
print("UC_OTHER", dict(uc_other))
print("LOC_ALL_POS", len(positive_nonhealthy), dict(loc_all_pos))
print("LOC_TRUE_POS", len(positive_true_ibd), dict(loc_true_pos))
