import fs from "node:fs/promises";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const FINAL_PPTX = "C:\\Users\\Popovtzer lab\\OneDrive\\RNA-seq-Biochip\\Gut Sense one-slide summary 2026-08-17.pptx";
const OUT_DIR = "C:\\Users\\Popovtzer lab\\Documents\\Codex\\2026-05-28\\you-are-an-exel-file-editure\\ppt_build\\one_slide_rendered";

const C = {
  ink: "#111827",
  muted: "#5B6472",
  line: "#D9DEE7",
  blue: "#1E5AA7",
  red: "#C82333",
  green: "#186A3B",
  softBlue: "#EAF2FF",
  softRed: "#FCE8E8",
  softGreen: "#EAF6EF",
  white: "#FFFFFF",
};

function addText(slide, text, x, y, w, h, style = {}) {
  const s = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  s.text = text;
  s.text.style = {
    fontSize: style.fontSize ?? 20,
    typeface: "Helvetica Neue",
    color: style.color ?? C.ink,
    bold: style.bold ?? false,
    alignment: style.alignment ?? "left",
    verticalAlignment: style.verticalAlignment ?? "top",
  };
  return s;
}

function addBox(slide, x, y, w, h, fill, line = C.line) {
  return slide.shapes.add({
    geometry: "roundRect",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: 1 },
    borderRadius: "rounded-lg",
  });
}

function addMetric(slide, x, y, w, value, label, color) {
  addText(slide, value, x, y, w, 48, {
    fontSize: 42,
    bold: true,
    color,
    alignment: "center",
  });
  addText(slide, label, x, y + 50, w, 36, {
    fontSize: 17,
    bold: true,
    color: C.ink,
    alignment: "center",
  });
}

function addMiniCell(slide, x, y, w, value, label, color) {
  addBox(slide, x, y, w, 58, C.white, C.line);
  addText(slide, value, x + 8, y + 8, w - 16, 24, {
    fontSize: 22,
    bold: true,
    color,
    alignment: "center",
  });
  addText(slide, label, x + 6, y + 33, w - 12, 18, {
    fontSize: 13,
    color: C.muted,
    alignment: "center",
  });
}

function setNotes(slide) {
  slide.speakerNotes.textFrame.setText([
    "[Sources]",
    "Source workbook: C:\\Users\\Popovtzer lab\\OneDrive\\RNA-seq-Biochip\\Final Known and Unknown merged.xlsx, sheet Final, read on 2026-08-17.",
    "Main Gut Sense analysis: false positive and false negative counts are calculated only for CDf vs IBS rows with conclusive Final classification / decision.",
    "Main CDf vs IBS raw workbook values: n=101, TP=46, FN=23, FP=6, TN=26, sensitivity=66.7%, specificity=81.3%.",
    "User-provided imaging update: one apparent false-positive IBS row was later diagnosed as IBD by imaging. Slide displays adjusted CDf vs IBS values excluding that row from the IBS-negative group: n=100, TP=46, FN=23, FP=5, TN=26, sensitivity=66.7%, specificity=83.9%.",
    "Calprotectin threshold: >=150 is considered positive. The key CDf point: 15 CDf rows were below 150, and Gut Sense caught 10/15 = 66.7% of them.",
    "The broader under-150 IBD/CDr group includes 15 CDf, 23 CDr, and 3 UCf. Gut Sense caught 21 total: 10 CDf, 10 CDr, and 1 UCf. Among CDr under 150, Gut Sense detected 10/23 = 43.5%.",
    "UC subset: 10/15 conclusive non-old UC rows were Gut Sense IBD; other UC rows include 2 inconclusive, 9 missing, and 1 old-metering IBD*.",
    "CDf Gut Sense positive location split: small bowel only=21, both colon and small bowel=12, colon only=3, unknown/not recorded=10.",
  ]);
  slide.speakerNotes.setVisible(true);
}

async function writeBlob(path, blob) {
  await fs.writeFile(path, new Uint8Array(await blob.arrayBuffer()));
}

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true });
  const presentation = Presentation.create({ slideSize: { width: 1280, height: 720 } });
  const slide = presentation.slides.add();
  slide.background.fill = C.white;

  addText(slide, "Gut Sense performance snapshot", 64, 46, 820, 62, {
    fontSize: 50,
    bold: true,
    color: C.ink,
  });
  addText(slide, "Current final workbook", 68, 116, 860, 30, {
    fontSize: 20,
    color: C.muted,
  });
  slide.shapes.add({
    geometry: "rect",
    position: { left: 64, top: 158, width: 1152, height: 2 },
    fill: C.line,
    line: { style: "solid", fill: C.line, width: 0 },
  });

  const colY = 190;
  const colH = 410;
  slide.shapes.add({
    geometry: "rect",
    position: { left: 434, top: colY + 8, width: 2, height: colH - 16 },
    fill: C.line,
    line: { style: "solid", fill: C.line, width: 0 },
  });
  slide.shapes.add({
    geometry: "rect",
    position: { left: 824, top: colY + 8, width: 2, height: colH - 16 },
    fill: C.line,
    line: { style: "solid", fill: C.line, width: 0 },
  });

  addText(slide, "CDf vs IBS performance", 72, 214, 330, 30, { fontSize: 25, bold: true, color: C.blue });
  addText(slide, "Adjusted after imaging update: n=100", 72, 249, 330, 46, { fontSize: 18, color: C.muted });
  addMetric(slide, 74, 314, 138, "66.7%", "Sensitivity", C.red);
  addMetric(slide, 240, 314, 138, "83.9%", "Specificity", C.blue);
  addMiniCell(slide, 74, 430, 72, "46", "TP", C.red);
  addMiniCell(slide, 154, 430, 72, "23", "FN", C.red);
  addMiniCell(slide, 234, 430, 72, "5", "FP", C.blue);
  addMiniCell(slide, 314, 430, 72, "26", "TN", C.blue);
  addText(slide, "One apparent FP was later diagnosed IBD by imaging.", 72, 520, 330, 52, {
    fontSize: 20,
    bold: true,
    color: C.ink,
  });

  addText(slide, "Calprotectin missed", 468, 214, 310, 30, { fontSize: 25, bold: true, color: C.green });
  addText(slide, "Using <150 as negative", 468, 249, 300, 24, { fontSize: 18, color: C.muted });
  addText(slide, "15 CDf samples were under 150.\nGut Sense caught 10/15 of them (66.7%).\n\nBroader missed group: 15 CDf, 23 CDr, 3 UCf.\nCDr: Gut Sense detected 10/23 while calprotectin did not (43.5%).", 468, 300, 320, 270, {
    fontSize: 20,
    bold: true,
    color: C.ink,
  });

  addText(slide, "What to say", 860, 214, 330, 30, { fontSize: 25, bold: true, color: C.red });
  addText(slide, "UC: 10/15 conclusive rows were Gut Sense positive (66.7%).", 860, 258, 330, 58, {
    fontSize: 21,
    bold: true,
    color: C.ink,
  });
  addText(slide, "CDf positives by location: 21 small bowel only, 12 both, 3 colon only, 10 unknown.", 860, 344, 330, 74, {
    fontSize: 19,
    color: C.ink,
  });
  addText(slide, "Best frame: adjunct management signal, especially for low-calprotectin IBD and possible small-bowel activity.", 860, 454, 330, 90, {
    fontSize: 19,
    bold: true,
    color: C.red,
  });

  addText(slide, "Source: Final Known and Unknown merged.xlsx, Final tab", 64, 666, 600, 22, {
    fontSize: 14,
    color: C.muted,
  });
  addText(slide, "2026-08-17", 1080, 666, 136, 22, {
    fontSize: 14,
    color: C.muted,
    alignment: "right",
  });
  setNotes(slide);

  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await writeBlob(`${OUT_DIR}\\gut-sense-one-slide.png`, png);
  const layout = await slide.export({ format: "layout" });
  await fs.writeFile(`${OUT_DIR}\\gut-sense-one-slide.layout.json`, await layout.text(), "utf8");
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(FINAL_PPTX);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
