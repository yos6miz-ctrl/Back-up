import fs from "node:fs/promises";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const FINAL_PPTX = "C:\\Users\\Popovtzer lab\\OneDrive\\RNA-seq-Biochip\\Gut Sense performance summary 2026-08-17.pptx";
const OUT_DIR = "C:\\Users\\Popovtzer lab\\Documents\\Codex\\2026-05-28\\you-are-an-exel-file-editure\\ppt_build\\rendered";
const MONTAGE = "C:\\Users\\Popovtzer lab\\Documents\\Codex\\2026-05-28\\you-are-an-exel-file-editure\\ppt_build\\gut_sense_montage.webp";

const C = {
  ink: "#111827",
  muted: "#5B6472",
  faint: "#F3F6FA",
  line: "#D9DEE7",
  blue: "#1E5AA7",
  lightBlue: "#E9F2FF",
  red: "#C82333",
  lightRed: "#FCE8E8",
  green: "#186A3B",
  amber: "#F7B731",
  white: "#FFFFFF",
};

const page = { left: 64, top: 54, width: 1152, height: 612 };

const sourceNote = [
  "[Sources]",
  "- Source workbook: C:\\Users\\Popovtzer lab\\OneDrive\\RNA-seq-Biochip\\Final Known and Unknown merged.xlsx, sheet Final, read on 2026-08-17.",
  "- Main Gut Sense analysis: Healthy excluded; old-metering rows excluded; only rows with a doctor diagnosis and conclusive Final classification / decision are included.",
  "- Doctor IBD: CDf, CDr, UCf, UCr/UC. Doctor IBS: IBS. Calprotectin positive threshold: >=150.",
  "- Old-metering rows remain separate because they are marked as not final in the workbook.",
].join("\n");

function addText(slide, text, x, y, w, h, style = {}) {
  const s = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  s.text = text;
  s.text.style = {
    fontSize: style.fontSize ?? 20,
    typeface: "Helvetica Neue",
    color: style.color ?? C.ink,
    bold: style.bold ?? false,
    alignment: style.alignment ?? "left",
    verticalAlignment: style.verticalAlignment ?? "top",
  };
  return s;
}

function addRule(slide, x, y, w, color = C.line, height = 2) {
  slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height },
    fill: color,
    line: { style: "solid", fill: color, width: 0 },
  });
}

function addTitle(slide, title, kicker = "Gut Sense performance summary") {
  addText(slide, kicker, page.left, 30, 420, 24, {
    fontSize: 16,
    bold: true,
    color: C.blue,
  });
  addText(slide, title, page.left, 64, 1000, 54, {
    fontSize: 37,
    bold: true,
    color: C.ink,
  });
  addRule(slide, page.left, 134, page.width, C.line, 1.5);
}

function addFooter(slide, slideNo) {
  addText(slide, "Final workbook, 2026-08-17", page.left, 670, 330, 22, {
    fontSize: 14,
    color: C.muted,
  });
  addText(slide, String(slideNo), 1170, 670, 42, 22, {
    fontSize: 14,
    color: C.muted,
    alignment: "right",
  });
}

function addMetric(slide, x, y, w, label, value, sub, color) {
  addText(slide, value, x, y, w, 62, {
    fontSize: 46,
    bold: true,
    color,
    alignment: "center",
  });
  addText(slide, label, x, y + 72, w, 34, {
    fontSize: 22,
    bold: true,
    color: C.ink,
    alignment: "center",
  });
  addText(slide, sub, x, y + 110, w, 50, {
    fontSize: 17,
    color: C.muted,
    alignment: "center",
  });
}

function addTable(slide, x, y, w, h, values, headerFill = C.ink) {
  const table = slide.tables.add({
    rows: values.length,
    columns: values[0].length,
    left: x,
    top: y,
    width: w,
    height: h,
    values,
  });
  table.styleOptions = { headerRow: true, bandedRows: true };
  table.borders.assign({ style: "solid", fill: C.line, width: 1 });
  for (let c = 0; c < values[0].length; c += 1) {
    const cell = table.getCell(0, c);
    cell.fill = headerFill;
    cell.textStyle.color = C.white;
    cell.textStyle.bold = true;
    cell.textStyle.fontSize = 16;
  }
  for (let r = 1; r < values.length; r += 1) {
    for (let c = 0; c < values[0].length; c += 1) {
      const cell = table.getCell(r, c);
      cell.textStyle.fontSize = 16;
      cell.textStyle.color = C.ink;
    }
  }
  return table;
}

function setNotes(slide, text) {
  slide.speakerNotes.textFrame.setText(text);
  slide.speakerNotes.setVisible(true);
}

async function writeBlob(path, blob) {
  await fs.writeFile(path, new Uint8Array(await blob.arrayBuffer()));
}

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true });

  const presentation = Presentation.create({
    slideSize: { width: 1280, height: 720 },
  });

  // Slide 1
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addText(slide, "Gut Sense performance to date", 64, 86, 960, 82, {
      fontSize: 56,
      bold: true,
    });
    addText(slide, "Current final workbook; Healthy excluded from the main clinical performance analysis", 66, 178, 900, 42, {
      fontSize: 24,
      color: C.muted,
    });
    addRule(slide, 66, 244, 630, C.blue, 5);
    addMetric(slide, 78, 310, 250, "Eligible tests", "140", "Conclusive Gut Sense decision plus doctor diagnosis", C.ink);
    addMetric(slide, 386, 310, 250, "Sensitivity", "62.0%", "67 true positives / 108 doctor-IBD", C.red);
    addMetric(slide, 694, 310, 250, "Specificity", "81.3%", "26 true negatives / 32 doctor-IBS", C.blue);
    addText(slide, "Old-metering rows are shown separately because they are marked as non-final.", 78, 590, 870, 38, {
      fontSize: 21,
      color: C.muted,
    });
    addFooter(slide, 1);
    setNotes(slide, `${sourceNote}\n\nSlide values: main n=140, TP=67, FN=41, FP=6, TN=26.`);
  }

  // Slide 2
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addTitle(slide, "False negatives drive the main error profile");
    addTable(slide, 76, 178, 520, 245, [
      ["Gut Sense vs doctor diagnosis", "Doctor IBD", "Doctor IBS"],
      ["Gut Sense IBD", "67 TP", "6 FP"],
      ["Gut Sense IBS", "41 FN", "26 TN"],
    ], C.ink);
    addText(slide, "False negatives", 666, 174, 280, 30, { fontSize: 26, bold: true, color: C.red });
    addText(slide, "41", 666, 212, 170, 70, { fontSize: 58, bold: true, color: C.red });
    addText(slide, "23 CDf, 13 CDr, 5 UCf", 666, 290, 420, 32, { fontSize: 22, color: C.ink });
    addText(slide, "False positives", 666, 378, 280, 30, { fontSize: 26, bold: true, color: C.blue });
    addText(slide, "6", 666, 416, 170, 70, { fontSize: 58, bold: true, color: C.blue });
    addText(slide, "All were doctor-diagnosed IBS", 666, 494, 420, 32, { fontSize: 22, color: C.ink });
    addRule(slide, 666, 552, 474, C.line, 1.5);
    addText(slide, "Adding old-metering rows changes sensitivity to 57.0% and does not improve specificity, so they stay outside the main analysis.", 666, 574, 486, 62, {
      fontSize: 18,
      color: C.muted,
    });
    addFooter(slide, 2);
    setNotes(slide, `${sourceNote}\n\nOld-metering rows: n=34, TP=14, FN=20. Combined with old-metering: TP=81, FN=61, FP=6, TN=26, sensitivity=57.0%, specificity=81.3%.`);
  }

  // Slide 3
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addTitle(slide, "Gut Sense catches some low-calprotectin IBD");
    slide.charts.add("bar", {
      position: { left: 72, top: 178, width: 610, height: 346 },
      categories: ["Sensitivity", "Specificity"],
      series: [
        { name: "Gut Sense", values: [0.620, 0.813], fill: C.blue },
        { name: "Calprotectin >=150", values: [0.602, 0.962], fill: C.green },
      ],
      hasLegend: true,
      legend: { position: "bottom", overlay: false, textStyle: { fontSize: 15, fill: C.muted } },
      barOptions: { direction: "column", grouping: "clustered", gapWidth: 70 },
      yAxis: {
        min: 0,
        max: 1,
        numberFormatCode: "0%",
        majorGridlines: { style: "solid", fill: C.line, width: 1 },
        textStyle: { fontSize: 13, fill: C.muted },
      },
      xAxis: { textStyle: { fontSize: 15, fill: C.ink } },
      dataLabels: { showValue: false },
    });
    addText(slide, "Doctor IBD with calprotectin <150", 742, 180, 430, 35, {
      fontSize: 26,
      bold: true,
      color: C.ink,
    });
    addText(slide, "41", 746, 238, 150, 76, { fontSize: 64, bold: true, color: C.red });
    addText(slide, "samples were missed by calprotectin", 895, 258, 296, 46, {
      fontSize: 22,
      color: C.muted,
    });
    addRule(slide, 746, 342, 402, C.line, 1.5);
    addText(slide, "Gut Sense called 21 of those samples IBD.", 746, 374, 390, 40, {
      fontSize: 24,
      bold: true,
      color: C.blue,
    });
    addText(slide, "Both Gut Sense and calprotectin missed 20 doctor-IBD samples in this subset.", 746, 436, 390, 74, {
      fontSize: 20,
      color: C.muted,
    });
    addText(slide, "Calprotectin comparison uses the same main eligible Gut Sense rows with numeric calprotectin available: n=129.", 72, 592, 930, 42, {
      fontSize: 18,
      color: C.muted,
    });
    addFooter(slide, 3);
    setNotes(slide, `${sourceNote}\n\nCalprotectin comparison subset: n=129; TP=62, FN=41, FP=1, TN=25. Low-calprotectin doctor-IBD rows: 41; Gut Sense caught 21 and missed 20.`);
  }

  // Slide 4
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addTitle(slide, "UC is mostly positive, but data gaps remain");
    addTable(slide, 72, 182, 515, 240, [
      ["UC subset", "Count"],
      ["Conclusive UC rows", "15"],
      ["Gut Sense IBD", "10"],
      ["Gut Sense IBS", "5"],
      ["Other UC: inconclusive / missing / old*", "2 / 9 / 1"],
    ], C.red);
    addText(slide, "UC positivity", 682, 186, 380, 34, { fontSize: 26, bold: true });
    addText(slide, "66.7%", 682, 232, 250, 76, { fontSize: 62, bold: true, color: C.red });
    addText(slide, "10 of 15 conclusive, non-old UC rows were classified as IBD by Gut Sense.", 682, 322, 420, 80, {
      fontSize: 22,
      color: C.ink,
    });
    addRule(slide, 72, 474, 1080, C.line, 1.5);
    addText(slide, "Interpretation: this supports a signal in UC, but the missing UC rows should be completed before making a UC-specific claim.", 72, 506, 1060, 58, {
      fontSize: 23,
      color: C.muted,
    });
    addFooter(slide, 4);
    setNotes(slide, `${sourceNote}\n\nUC rows in source: UCf=22 and UCr=5. Current conclusive non-old UC rows: 15, with 10 IBD and 5 IBS by Gut Sense; other UC rows include 2 inconclusive, 9 missing, and 1 old-metering IBD*.`);
  }

  // Slide 5
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addTitle(slide, "Gut Sense positives include many small-bowel-only cases");
    slide.charts.add("bar", {
      position: { left: 78, top: 178, width: 670, height: 372 },
      categories: ["Small bowel only", "Both", "Colon only", "Unknown"],
      series: [{ name: "Gut Sense positive rows", values: [28, 14, 3, 28], fill: C.red }],
      hasLegend: false,
      barOptions: { direction: "bar", grouping: "clustered", gapWidth: 44 },
      xAxis: {
        min: 0,
        max: 32,
        majorGridlines: { style: "solid", fill: C.line, width: 1 },
        textStyle: { fontSize: 13, fill: C.muted },
      },
      yAxis: { textStyle: { fontSize: 15, fill: C.ink } },
      dataLabels: { showValue: true, position: "outEnd", textStyle: { fontSize: 15, fill: C.ink, bold: true } },
    });
    addText(slide, "Among 73 Gut Sense positive, Healthy-excluded rows:", 804, 190, 350, 64, {
      fontSize: 26,
      bold: true,
    });
    addText(slide, "28 small bowel only\n14 colon + small bowel\n3 colon only\n28 location not recorded", 804, 286, 380, 176, {
      fontSize: 24,
      color: C.ink,
    });
    addText(slide, "Among doctor-IBD true positives only, the location split is 28 / 14 / 3 / 22.", 804, 500, 360, 74, {
      fontSize: 20,
      color: C.muted,
    });
    addFooter(slide, 5);
    setNotes(slide, `${sourceNote}\n\nLocation split for all Gut Sense positive, Healthy-excluded rows: n=73, small bowel only=28, both colon and small bowel=14, colon only=3, unknown/not recorded=28. For true positives only: n=67, 28/14/3/22.`);
  }

  // Slide 6
  {
    const slide = presentation.slides.add();
    slide.background.fill = C.white;
    addTitle(slide, "Gut Sense is best framed as an adjunct signal");
    addText(slide, "What the data supports now", 82, 178, 455, 36, {
      fontSize: 28,
      bold: true,
      color: C.blue,
    });
    addText(slide, "Gut Sense is not yet a standalone diagnostic test. The present profile is more useful for adding context when symptoms, calprotectin, imaging, and clinician diagnosis do not agree.", 82, 232, 480, 116, {
      fontSize: 23,
      color: C.ink,
    });
    addText(slide, "Where it may help", 668, 178, 420, 36, {
      fontSize: 28,
      bold: true,
      color: C.red,
    });
    addText(slide, "Flag IBD cases with low calprotectin\nSupport small-bowel activity discussions\nTrack within-patient changes over time\nPrioritize repeat testing for inconclusive rows", 668, 232, 500, 186, {
      fontSize: 24,
      color: C.ink,
    });
    addRule(slide, 82, 468, 1040, C.line, 1.5);
    addText(slide, "Next analysis step: complete missing UC/location data and keep old-metering results clearly marked as preliminary.", 82, 504, 930, 58, {
      fontSize: 25,
      bold: true,
      color: C.muted,
    });
    addFooter(slide, 6);
    setNotes(slide, `${sourceNote}\n\nManagement-use hypothesis is an interpretation based on the observed pattern: Gut Sense caught 21 doctor-IBD rows where calprotectin was <150, and Gut Sense positive rows include a substantial small-bowel-only subgroup. This should be presented as hypothesis-generating, not clinical validation.`);
  }

  for (const [index, slide] of presentation.slides.items.entries()) {
    const stem = `slide-${String(index + 1).padStart(2, "0")}`;
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await writeBlob(`${OUT_DIR}\\${stem}.png`, png);
    const layout = await slide.export({ format: "layout" });
    await fs.writeFile(`${OUT_DIR}\\${stem}.layout.json`, await layout.text(), "utf8");
  }
  const montage = await presentation.export({ format: "webp", montage: true, scale: 1 });
  await writeBlob(MONTAGE, montage);
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(FINAL_PPTX);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
