import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

import fs from "node:fs";
import fsp from "node:fs/promises";

const original = "C:/Users/Popovtzer lab/.codex/Excel file editor/Merged Unknowns trial 6.26.xlsx";
const file = original;
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/you-are-an-exel-file-editure/previews";
await fsp.mkdir(previewDir, { recursive: true });

for (const [sheetName, range] of [["Unknown", "A1:L24"], ["Known", "A1:M24"], ["Match notes", "A1:B10"]]) {
  try {
    const blob = await workbook.render({ sheetName, range, scale: 1, format: "png" });
    const bytes = new Uint8Array(await blob.arrayBuffer());
    await fsp.writeFile(`${previewDir}/${sheetName.replaceAll(" ", "_")}.png`, bytes);
    console.log(`${sheetName}\trender ok`);
  } catch (error) {
    console.log(`${sheetName}\trender failed\t${error?.message ?? error}`);
  }
}
