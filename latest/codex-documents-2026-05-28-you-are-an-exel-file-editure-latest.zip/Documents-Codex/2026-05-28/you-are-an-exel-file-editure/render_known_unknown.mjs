import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const file = "C:/Users/Popovtzer lab/.codex/Excel file editor/Merged Unknowns trial 6.26.xlsx";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));

for (const sheetName of ["Unknown", "Known"]) {
  const preview = await workbook.inspect({
    kind: "table",
    range: `${sheetName}!A1:P12`,
    include: "values,formulas",
    tableMaxRows: 12,
    tableMaxCols: 15,
  });
  await workbook.render({ sheetName, range: sheetName === "Unknown" ? "A1:L24" : "A1:P24", scale: 1 });
  console.log(sheetName);
  console.log(preview.ndjson);
}
