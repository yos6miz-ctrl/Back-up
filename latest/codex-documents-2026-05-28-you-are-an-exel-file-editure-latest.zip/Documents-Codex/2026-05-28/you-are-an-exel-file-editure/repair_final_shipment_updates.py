from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import zipfile

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
RESTORE_BACKUP = WORKSPACE / "backups" / "Final Known and Unknown merged before shipment dates 20260806-141435.xlsx"
REPORT_PATH = WORKSPACE / "repair_final_shipment_updates_report.json"


TARGETS = {
    "UN FSL 666": {
        "secondary": "F-SL-2666",
        "date": datetime(2026, 2, 24),
        "source": "PA447: 20260803 UN 447 new.xlsx; araE: 20260803 UN araE new.xlsx, 20260804 UN araE new.xlsx",
    },
    "LRS-26188": {
        "secondary": "F-LRS-26188",
        "date": datetime(2026, 7, 8),
        "source": "PA447: 20260803 UN 447 new.xlsx; araE: 20260803 UN araE new.xlsx, 20260728 araE laura new.xlsx",
    },
    "UN FDN 119": {
        "secondary": "F-DN-26119",
        "date": datetime(2026, 4, 16),
        "source": "PA447: 20260803 UN 447 new.xlsx; araE: 20260803 UN araE new.xlsx",
    },
    "UN FHF 510": {
        "secondary": "F-HF-2510",
        "date": datetime(2025, 1, 8),
        "source": "PA447: 20260803 UN 447 new.xlsx; araE: 20260803 UN araE new.xlsx",
    },
    "UN FMM 157": {
        "secondary": "F-MN-24157",
        "date": datetime(2024, 9, 29),
        "source": "PA447: 20260803 UN 447 new.xlsx; araE: 20260803 UN araE new.xlsx, 20260804 UN araE new.xlsx",
    },
    "UN FOB 182": {
        "secondary": "F-OB-25182",
        "date": datetime(2025, 12, 16),
        "source": "araE: 20260804 UN araE new.xlsx",
    },
}


def remove_comment_and_table_parts(path):
    with zipfile.ZipFile(path, "r") as source:
        payload = [
            (item, source.read(item.filename))
            for item in source.infolist()
            if not item.filename.startswith("xl/tables/")
            and "comments" not in item.filename.lower()
            and "vmlDrawing" not in item.filename
        ]
    temp_path = path.with_suffix(".tmp.xlsx")
    with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as target:
        for item, data in payload:
            target.writestr(item, data)
    temp_path.replace(path)


def main():
    if not RESTORE_BACKUP.exists():
        raise FileNotFoundError(RESTORE_BACKUP)
    FINAL_PATH.write_bytes(RESTORE_BACKUP.read_bytes())

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    updates = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        if primary not in TARGETS:
            continue
        target = TARGETS[primary]
        before = {
            "secondary": ws.cell(row, headers["Secondary / other name"]).value,
            "date": str(ws.cell(row, headers["Sample date"]).value),
            "source": ws.cell(row, headers["Measurement/source file"]).value,
        }
        ws.cell(row, headers["Secondary / other name"]).value = target["secondary"]
        ws.cell(row, headers["Sample date"]).value = target["date"]
        ws.cell(row, headers["Sample date"]).number_format = "dd/mm/yyyy"
        ws.cell(row, headers["Measurement/source file"]).value = target["source"]
        updates.append({"row": row, "primary": primary, "before": before, "after": target})
    wb.save(FINAL_PATH)
    remove_comment_and_table_parts(FINAL_PATH)
    REPORT_PATH.write_text(json.dumps({"restored_from": str(RESTORE_BACKUP), "updates": updates}, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"restored_from": str(RESTORE_BACKUP), "updates": updates}, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
