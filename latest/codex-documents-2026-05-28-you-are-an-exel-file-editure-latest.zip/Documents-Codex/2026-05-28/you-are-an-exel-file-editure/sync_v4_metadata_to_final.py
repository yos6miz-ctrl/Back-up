from __future__ import annotations

from collections import Counter
from copy import copy
from datetime import datetime
from pathlib import Path
import json
import re
import shutil

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

import build_accounted_known_unknown as builder
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
V4 = WORKSPACE / "Final Known and Unknown merged - Ichilov v4 stripped temp.xlsx"
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "sync_v4_metadata_to_final_report.json"


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def canon_header(value):
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def canonical_date(value):
    if value in (None, ""):
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return str(value)[:10]


def nameset(*values):
    return {builder.norm(value) for value in values if builder.norm(value)}


def map_v4_headers(headers):
    mapped = {}
    for idx, header in enumerate(headers, start=1):
        h = canon_header(header)
        if h == "primary name":
            mapped["primary"] = idx
        elif h.startswith("secondary"):
            mapped["secondary"] = idx
        elif "measurement status" in h:
            mapped["status"] = idx
        elif "ichilov" in h and "diagnosis" in h:
            mapped["diagnosis"] = idx
        elif "final classification" in h:
            mapped["final"] = idx
        elif "calprotectin" in h:
            mapped["calprotectin"] = idx
        elif h == "disease location":
            mapped["disease_location"] = idx
        elif h == "sample date":
            mapped["sample_date"] = idx
    return mapped


def load_v4_records():
    wb = load_workbook(V4, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = map_v4_headers([cell.value for cell in ws[1]])
    records = []
    for row_number, row in enumerate(ws.iter_rows(min_row=2, max_col=ws.max_column, values_only=True), start=2):
        primary = clean(row[headers["primary"] - 1])
        secondary = clean(row[headers["secondary"] - 1]) if headers.get("secondary") else None
        keys = nameset(primary, secondary)
        if not keys:
            continue
        records.append(
            {
                "row": row_number,
                "primary": primary,
                "secondary": secondary,
                "keys": keys,
                "date": canonical_date(row[headers["sample_date"] - 1]) if headers.get("sample_date") else "",
                "diagnosis": builder.canonical_group(row[headers["diagnosis"] - 1]) if headers.get("diagnosis") else None,
                "calprotectin": row[headers["calprotectin"] - 1] if headers.get("calprotectin") else None,
                "disease_location": clean(row[headers["disease_location"] - 1]) if headers.get("disease_location") else None,
                "final_from_source": clean(row[headers["final"] - 1]) if headers.get("final") else None,
            }
        )
    return records


def choose_v4_record(target_keys, target_date, records):
    same_date = [record for record in records if target_keys & record["keys"] and record["date"] == target_date]
    if len(same_date) == 1:
        return same_date[0], "name+date"
    if len(same_date) > 1:
        return None, "multiple name+date matches"

    by_name = [record for record in records if target_keys & record["keys"]]
    if len(by_name) == 1:
        return by_name[0], "unique name"
    if len(by_name) > 1:
        return None, "multiple name matches"
    return None, "no match"


def value_present(value):
    return value not in (None, "")


def main():
    v4_records = load_v4_records()
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before v4 metadata sync {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(FINAL, backup)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = importer.header_map(ws)
    stats = Counter()
    updated_rows = []
    unmatched_rows = []

    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        target_keys = nameset(primary, secondary)
        if not target_keys:
            continue
        target_date = canonical_date(ws.cell(row, headers["Sample date"]).value)
        source, basis = choose_v4_record(target_keys, target_date, v4_records)
        if not source:
            if basis != "no match":
                unmatched_rows.append({"row": row, "primary": primary, "secondary": secondary, "date": target_date, "reason": basis})
            continue

        changes = {}
        for field, header in [
            ("diagnosis", "Diagnosis"),
            ("calprotectin", "Calprotectin level"),
            ("disease_location", "Disease location"),
        ]:
            value = source.get(field)
            if value_present(value) and ws.cell(row, headers[header]).value != value:
                ws.cell(row, headers[header]).value = value
                changes[header] = value

        if source.get("date") and not target_date:
            ws.cell(row, headers["Sample date"]).value = source["date"]
            ws.cell(row, headers["Sample date"]).number_format = "dd/mm/yyyy"
            changes["Sample date"] = source["date"]

        if changes:
            importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
            updated_rows.append(
                {
                    "row_before_sort": row,
                    "primary": primary,
                    "secondary": secondary,
                    "source_v4_row": source["row"],
                    "basis": basis,
                    "changes": changes,
                }
            )
            stats["rows_updated"] += 1

    for cell in ws[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
        cell.font = Font(name="Calibri", size=11, bold=True, color="000000")

    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{ws.cell(1, ws.max_column).coordinate[0]}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)
    shutil.copy2(FINAL, ONEDRIVE_FINAL)

    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "v4_source": str(V4),
        "backup": str(backup),
        "stats": dict(stats),
        "updated_rows": updated_rows,
        "ambiguous_final_rows": unmatched_rows,
        "note": "Only metadata was synced from v4; Gut Sense measurements and final classifications were not overwritten by v4.",
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
