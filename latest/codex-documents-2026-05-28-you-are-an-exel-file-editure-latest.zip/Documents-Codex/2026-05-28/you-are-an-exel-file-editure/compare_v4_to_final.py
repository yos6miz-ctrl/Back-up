from __future__ import annotations

from pathlib import Path
import json
import re

from openpyxl import load_workbook

import build_accounted_known_unknown as builder


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
V4 = WORKSPACE / "Final Known and Unknown merged - Ichilov v4 stripped temp.xlsx"
OUT = WORKSPACE / "v4_to_final_comparison.json"


def clean_header(value):
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def date_key(value):
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return str(value)[:10]


def sample_key(primary, secondary, sample_date):
    names = [builder.norm(primary), builder.norm(secondary)]
    names = sorted(name for name in names if name)
    return ("|".join(names), date_key(sample_date))


def map_final_headers(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def map_v4_headers(headers):
    result = {}
    for idx, header in enumerate(headers, start=1):
        h = clean_header(header)
        if h == "primary name":
            result["primary"] = idx
        elif h.startswith("secondary"):
            result["secondary"] = idx
        elif "measurement status" in h:
            result["status"] = idx
        elif "ichilov" in h and "diagnosis" in h:
            result["diagnosis"] = idx
        elif "final classification" in h:
            result["final"] = idx
        elif "calprotectin" in h:
            result["calprotectin"] = idx
        elif h == "disease location":
            result["disease_location"] = idx
        elif h == "pa447 measurement 1":
            result["pa447_1"] = idx
        elif h == "pa447 measurement 2":
            result["pa447_2"] = idx
        elif h == "pa447 measurement 3":
            result["pa447_3"] = idx
        elif "pa447" in h and "decision" in h:
            result["pa447_decision"] = idx
        elif h == "arae measurement 1":
            result["arae_1"] = idx
        elif h == "arae measurement 2":
            result["arae_2"] = idx
        elif h == "arae measurement 3":
            result["arae_3"] = idx
        elif "arae" in h and "decision" in h:
            result["arae_decision"] = idx
        elif h == "sample date":
            result["sample_date"] = idx
        elif h == "measurement/source file":
            result["source"] = idx
    return result


def final_keys():
    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = map_final_headers(ws)
    keys = {}
    for row_number, row in enumerate(ws.iter_rows(min_row=2, max_col=ws.max_column, values_only=True), start=2):
        key = sample_key(row[headers["Primary name"] - 1], row[headers["Secondary / other name"] - 1], row[headers["Sample date"] - 1])
        keys.setdefault(key, []).append(row_number)
    return keys


def v4_records():
    wb = load_workbook(V4, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = map_v4_headers([cell.value for cell in ws[1]])
    records = []
    for row_number, row in enumerate(ws.iter_rows(min_row=2, max_col=ws.max_column, values_only=True), start=2):
        primary = row[headers["primary"] - 1]
        secondary = row[headers["secondary"] - 1] if headers.get("secondary") else None
        sample_date = row[headers["sample_date"] - 1]
        if not primary and not secondary:
            continue
        records.append(
            {
                "row": row_number,
                "primary": primary,
                "secondary": secondary,
                "date": date_key(sample_date),
                "diagnosis": row[headers["diagnosis"] - 1] if headers.get("diagnosis") else None,
                "final": row[headers["final"] - 1] if headers.get("final") else None,
                "calprotectin": row[headers["calprotectin"] - 1] if headers.get("calprotectin") else None,
                "disease_location": row[headers["disease_location"] - 1] if headers.get("disease_location") else None,
                "key": sample_key(primary, secondary, sample_date),
            }
        )
    return records


def is_pnumber(record):
    names = [str(record.get("primary") or ""), str(record.get("secondary") or "")]
    return any(re.fullmatch(r"P\d+", name.strip(), flags=re.I) for name in names)


def main():
    fkeys = final_keys()
    missing = [record for record in v4_records() if record["key"] not in fkeys and not is_pnumber(record)]
    report = {
        "final": str(FINAL),
        "v4": str(V4),
        "missing_count": len(missing),
        "missing": missing,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
