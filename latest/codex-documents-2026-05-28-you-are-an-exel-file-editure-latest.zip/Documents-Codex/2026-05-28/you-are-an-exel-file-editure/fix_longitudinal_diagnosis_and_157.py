from __future__ import annotations

from copy import copy
from datetime import datetime
from pathlib import Path
import json
import math
import re
import shutil
import zipfile

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import expand_measurement_columns_and_show_all as repeat_logic
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ALIQUOTS = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "fix_longitudinal_diagnosis_and_157_report.json"

IBD_OLD_SOURCE = "IBD IBS OLD.xlsx"


def clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def norm(value):
    return re.sub(r"[^A-Z0-9]+", "", clean(value).upper())


def parse_date(value):
    if hasattr(value, "date"):
        return value.date()
    text = clean(value)
    for fmt in ("%d.%m.%y", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def trailing_sequence(value):
    match = re.search(r"(\d+)\s*$", clean(value))
    return int(match.group(1)) if match else None


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def almost_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def parse_sources(text):
    parts = {"PA447": [], "araE": []}
    text = clean(text)
    if not text:
        return parts
    if "PA447:" not in text and "araE:" not in text:
        if text.lower().endswith(".xlsx"):
            return {"PA447": [text], "araE": [text]}
        return parts
    for detector in parts:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if not match:
            continue
        for item in match.group(1).split(","):
            label = clean(item.replace("/", "\\").split("\\")[-1])
            if label:
                parts[detector].append(label)
    return parts


def format_sources(parts):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for label in parts[detector]:
            if label and label not in labels:
                labels.append(label)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    return "; ".join(segments) if segments else None


def detector_entries(ws, headers, row, detector):
    sources = parse_sources(ws.cell(row, headers["Measurement/source file"]).value)[detector]
    entries = []
    for idx, col in enumerate(detector_cols(headers, detector)):
        cell = ws.cell(row, col)
        if is_numeric(cell.value):
            entries.append(
                {
                    "value": float(cell.value),
                    "source": sources[idx] if idx < len(sources) else None,
                    "font": copy(cell.font),
                    "fill": copy(cell.fill),
                    "alignment": copy(cell.alignment),
                    "number_format": cell.number_format,
                }
            )
    return entries


def clear_measurement_cell(cell):
    cell.value = None
    cell.fill = PatternFill(fill_type=None)
    cell.font = Font(name="Calibri", size=11, color="000000", bold=False)
    cell.number_format = "0.000000000"
    cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)


def write_detector_entries(ws, headers, row, detector, entries):
    cols = detector_cols(headers, detector)
    for col in cols:
        clear_measurement_cell(ws.cell(row, col))
    for entry, col in zip(entries, cols):
        cell = ws.cell(row, col)
        cell.value = entry["value"]
        cell.number_format = entry.get("number_format") or "0.000000000"
        cell.font = copy(entry["font"]) if entry.get("font") else Font(name="Calibri", size=11, color="000000")
        cell.fill = copy(entry["fill"]) if entry.get("fill") else PatternFill(fill_type=None)
        cell.alignment = copy(entry["alignment"]) if entry.get("alignment") else Alignment(horizontal="right", vertical="center")


def source_records():
    wb = openpyxl.load_workbook(ALIQUOTS, data_only=True, read_only=True)
    records = []

    ws = wb["מתלקחים CD (blind)"]
    groups = {}
    for row in range(2, ws.max_row + 1):
        patient = clean(ws.cell(row, 6).value)
        sample = clean(ws.cell(row, 8).value)
        synonym = clean(ws.cell(row, 12).value)
        date = parse_date(ws.cell(row, 7).value)
        if not patient or not sample or sample.lower() in {"sample name (f)", "sample"}:
            continue
        groups.setdefault(patient, []).append(
            {"sheet": ws.title, "aliquot_row": row, "patient": patient, "sample": sample, "synonym": synonym, "date": date}
        )
    for patient, items in groups.items():
        items.sort(key=lambda item: (item["date"] or datetime.max.date(), item["aliquot_row"]))
        for index, item in enumerate(items, start=1):
            records.append(
                {
                    **item,
                    "expected_diagnosis": "CDf" if index == len(items) else "CDr",
                    "expected_longitudinal": index,
                    "set_count": len(items),
                }
            )

    ws = wb["CD רמיסיה (blind)"]
    remission_groups = {}
    for row in range(2, ws.max_row + 1):
        sample = clean(ws.cell(row, 6).value)
        synonym = clean(ws.cell(row, 10).value)
        date = parse_date(ws.cell(row, 5).value)
        if not sample or sample.lower() == "sample" or not norm(sample):
            continue
        prefix = re.sub(r"\d+$", "", norm(synonym)) or norm(sample)
        remission_groups.setdefault(prefix, []).append(
            {"sheet": ws.title, "aliquot_row": row, "patient": prefix, "sample": sample, "synonym": synonym, "date": date}
        )
    for _prefix, items in remission_groups.items():
        items.sort(key=lambda item: (item["date"] or datetime.max.date(), item["aliquot_row"]))
        for index, item in enumerate(items, start=1):
            records.append(
                {
                    **item,
                    "expected_diagnosis": "CDr",
                    "expected_longitudinal": trailing_sequence(item["synonym"]) or index,
                    "set_count": len(items),
                }
            )
    return records


def build_row_index(ws, headers):
    by_key = {}
    for row in range(2, ws.max_row + 1):
        keys = {
            norm(ws.cell(row, headers["Primary name"]).value),
            norm(ws.cell(row, headers["Secondary / other name"]).value),
        } - {""}
        for key in keys:
            by_key.setdefault(key, []).append(row)
    return by_key


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before longitudinal diagnosis fix {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(CODEX_FINAL, backup)

    wb = openpyxl.load_workbook(CODEX_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    by_key = build_row_index(ws, headers)

    diagnosis_changes = []
    longitudinal_changes = []
    missing_source_records = []

    for record in source_records():
        keys = {norm(record["sample"]), norm(record["synonym"])} - {""}
        rows = sorted({row for key in keys for row in by_key.get(key, [])})
        if not rows:
            missing_source_records.append(record)
            continue
        for row in rows:
            diag_cell = ws.cell(row, headers["Diagnosis"])
            if diag_cell.value != record["expected_diagnosis"]:
                diagnosis_changes.append(
                    {
                        "row_before_sort": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                        "old": diag_cell.value,
                        "new": record["expected_diagnosis"],
                        "source_sheet": record["sheet"],
                        "aliquot_row": record["aliquot_row"],
                    }
                )
                diag_cell.value = record["expected_diagnosis"]
                importer.style_diagnosis(diag_cell, record["expected_diagnosis"])

            long_cell = ws.cell(row, headers["Longitudinal sample"])
            if long_cell.value != record["expected_longitudinal"]:
                longitudinal_changes.append(
                    {
                        "row_before_sort": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                        "old": long_cell.value,
                        "new": record["expected_longitudinal"],
                        "source_sheet": record["sheet"],
                        "aliquot_row": record["aliquot_row"],
                    }
                )
                long_cell.value = record["expected_longitudinal"]

    migration_157 = {"status": "not-found"}
    rows_cdf157 = [row for row in range(2, ws.max_row + 1) if norm(ws.cell(row, headers["Primary name"]).value) == "CDF157"]
    target_rows = sorted(set(by_key.get("SHR22194", []) + by_key.get("157SHR3", [])))
    if rows_cdf157 and target_rows:
        source_row = rows_cdf157[0]
        target_row = target_rows[0]
        source_pa447 = [entry for entry in detector_entries(ws, headers, source_row, "PA447") if entry["source"] != IBD_OLD_SOURCE]
        target_pa447 = [entry for entry in detector_entries(ws, headers, target_row, "PA447") if entry["source"] != IBD_OLD_SOURCE]
        added = []
        for entry in source_pa447:
            if not any(almost_equal(entry["value"], existing["value"]) for existing in target_pa447):
                target_pa447.append(entry)
                added.append({"value": entry["value"], "source": entry["source"]})
        target_arae = detector_entries(ws, headers, target_row, "araE")
        write_detector_entries(ws, headers, target_row, "PA447", target_pa447)
        write_detector_entries(ws, headers, target_row, "araE", target_arae)
        source_parts = {
            "PA447": [entry["source"] for entry in target_pa447 if entry.get("source")],
            "araE": [entry["source"] for entry in target_arae if entry.get("source")],
        }
        ws.cell(target_row, headers["Measurement/source file"]).value = format_sources(source_parts)
        ws.cell(target_row, headers["Measurement status"]).value = "measured"
        repeat_logic.reclassify_row_majority(
            ws,
            headers,
            target_row,
            importer.classifier.learn_detector_bars(importer.classifier.load_training()[0], importer.classifier.load_training()[1]),
        )
        ws.delete_rows(source_row, 1)
        migration_157 = {
            "status": "migrated",
            "deleted_orphan_row_before_sort": source_row,
            "target_row_before_sort": target_row,
            "target": "SHR-22194 / 157SHR3",
            "added_to_target": added,
            "skipped_orphan_araE_reason": "orphan araE was from IBD IBS OLD.xlsx, not a raw measurement file",
        }

    headers = header_map(ws)
    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(CODEX_FINAL)
    importer.remove_comment_and_table_parts(CODEX_FINAL)

    copy_error = None
    try:
        shutil.copy2(CODEX_FINAL, ONEDRIVE_FINAL)
    except PermissionError as exc:
        copy_error = str(exc)

    check_wb = openpyxl.load_workbook(CODEX_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    watched = {"F-SHR-21479", "F-SHR-21576", "SHR-22194", "CDf 157"}
    watched_rows = []
    remaining_cdf157 = []
    for row in range(2, check_ws.max_row + 1):
        primary = check_ws.cell(row, check_headers["Primary name"]).value
        secondary = check_ws.cell(row, check_headers["Secondary / other name"]).value
        if primary in watched or secondary in watched or norm(primary) == "CDF157":
            if norm(primary) == "CDF157":
                remaining_cdf157.append(row)
            watched_rows.append(
                {
                    "row": row,
                    "primary": primary,
                    "secondary": secondary,
                    "diagnosis": check_ws.cell(row, check_headers["Diagnosis"]).value,
                    "longitudinal": check_ws.cell(row, check_headers["Longitudinal sample"]).value,
                    "final": check_ws.cell(row, check_headers["Final classification / decision"]).value,
                    "PA447": [
                        check_ws.cell(row, col).value
                        for col in detector_cols(check_headers, "PA447")
                        if is_numeric(check_ws.cell(row, col).value)
                    ],
                    "araE": [
                        check_ws.cell(row, col).value
                        for col in detector_cols(check_headers, "araE")
                        if is_numeric(check_ws.cell(row, col).value)
                    ],
                    "source": check_ws.cell(row, check_headers["Measurement/source file"]).value,
                }
            )

    report = {
        "workbook": str(CODEX_FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "onedrive_copy_error": copy_error,
        "backup": str(backup),
        "diagnosis_changes_count": len(diagnosis_changes),
        "diagnosis_changes": diagnosis_changes,
        "longitudinal_changes_count": len(longitudinal_changes),
        "longitudinal_changes": longitudinal_changes,
        "missing_source_records": missing_source_records,
        "migration_157": migration_157,
        "watched_rows_after": watched_rows,
        "remaining_cdf157_rows": remaining_cdf157,
        "dimensions": {"rows": check_ws.max_row, "columns": check_ws.max_column},
        "zip_health": zip_health(CODEX_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, default=str, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
