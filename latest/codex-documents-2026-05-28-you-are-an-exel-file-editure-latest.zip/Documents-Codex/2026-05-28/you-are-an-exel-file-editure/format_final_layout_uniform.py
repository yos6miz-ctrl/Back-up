from __future__ import annotations

from pathlib import Path
import json
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_ORIGINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
ONEDRIVE_COPY = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged - expanded repeats.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "format_final_layout_uniform_report.json"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def detector_headers(headers, detector):
    names = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        names.append(f"{detector} measurement {idx}")
        idx += 1
    return names


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / "Final Known and Unknown merged before uniform layout.xlsx"
    shutil.copy2(FINAL, backup)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = header_map(ws)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.showGridLines = True
    ws.sheet_view.zoomScale = 85

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    for name in detector_headers(headers, "PA447"):
        widths[name] = 13.5
    for name in detector_headers(headers, "araE"):
        widths[name] = 13.5

    for name, col in headers.items():
        width = widths.get(name, 14)
        ws.column_dimensions[get_column_letter(col)].width = width

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border

    text_columns = {
        headers["Primary name"],
        headers["Secondary / other name"],
        headers["Measurement status"],
        headers["Diagnosis"],
        headers["Final classification / decision"],
        headers["Disease location"],
        headers["Measurement/source file"],
    }
    center_columns = {
        headers["Calprotectin level"],
        headers["Sample date"],
        headers["PA447 decision"],
        headers["araE decision"],
    }
    measurement_columns = {
        headers[name]
        for detector in ("PA447", "araE")
        for name in detector_headers(headers, detector)
    }

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_columns:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col == headers["Calprotectin level"]:
                cell.number_format = "0"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col in center_columns:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col in text_columns:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(vertical="center", wrap_text=False)

    ws.row_dimensions[1].height = 42
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)

    copied_original = False
    original_copy_error = None
    try:
        shutil.copy2(FINAL, ONEDRIVE_ORIGINAL)
        copied_original = True
    except PermissionError as exc:
        original_copy_error = str(exc)

    shutil.copy2(FINAL, ONEDRIVE_COPY)

    report = {
        "final": str(FINAL),
        "onedrive_original": str(ONEDRIVE_ORIGINAL),
        "onedrive_copy": str(ONEDRIVE_COPY),
        "copied_original": copied_original,
        "original_copy_error": original_copy_error,
        "backup": str(backup),
        "dimensions": {"rows": ws.max_row, "columns": ws.max_column},
        "widths": {name: ws.column_dimensions[get_column_letter(col)].width for name, col in headers.items()},
        "zip_health_final": zip_health(FINAL),
        "zip_health_copy": zip_health(ONEDRIVE_COPY),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
