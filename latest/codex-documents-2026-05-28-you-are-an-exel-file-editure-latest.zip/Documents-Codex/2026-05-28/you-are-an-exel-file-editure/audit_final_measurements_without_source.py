from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import json
import math
import os
import posixpath
import re
import xml.etree.ElementTree as ET
import zipfile

from openpyxl import load_workbook
from openpyxl.formula.translate import Translator
import build_accounted_known_unknown as builder


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_SOURCE_ROOT = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
ONEDRIVE_ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
ACTIVE_ROOTS = [
    ONEDRIVE_ROOT / "447 and araE 2026",
    ONEDRIVE_ROOT / "sample repeats",
]
OUTPUT_PATH = Path(os.environ["AUDIT_OUTPUT_PATH"]) if os.environ.get("AUDIT_OUTPUT_PATH") else None
EXCLUDED_SOURCE_TOKENS = (
    "final known and unknown",
    "merged",
    "trial 6.26",
    "447 and arae all",
    "ibd ibs old",
)
NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def clean(value):
    if value is None:
        return None
    text = str(value).strip()
    return re.sub(r"\s+", " ", text) or None


def norm(value):
    text = clean(value)
    if not text:
        return ""
    return re.sub(r"[^A-Z0-9א-ת]+", "", text.upper())


def variants(*names):
    out = set()
    for name in names:
        for part in re.split(r"[;,\n]+", str(name or "")):
            part = part.strip()
            if not part:
                continue
            base = norm(part)
            if base:
                out.add(base)
            stripped = re.sub(r"^(?:UN|CDR|CDF|IBS|HS|UCF|UCR|CT|F)+", "", base)
            if stripped:
                out.add(stripped)
            digits = "".join(re.findall(r"\d+", base))
            letters = "".join(re.findall(r"[A-Z]+", base))
            if digits:
                out.add(digits)
            if letters and digits:
                out.add(f"{letters}{digits}")
                out.add(f"{letters[-2:]}{digits}")
            out.update(builder.identifier_variants(part))
            out.update(builder.strict_identifier_variants(part))
    return {item for item in out if item}


def expand_manual_aliases(keys):
    expanded = set(keys)
    for names in builder.MANUAL_SAMPLE_ALIASES:
        alias_keys = set()
        for name in names:
            alias_keys.update(builder.identifier_variants(name))
            alias_keys.update(builder.strict_identifier_variants(name))
        if expanded & alias_keys:
            expanded.update(alias_keys)
    return expanded


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def detector_from_path(path: Path) -> str:
    name = path.name.lower()
    if "arae" in name:
        return "araE"
    if "447" in name:
        return "PA447"
    return "araE" if any(part.lower() == "arae" for part in path.parts) else "PA447"


def col_to_index(col_letters: str) -> int:
    result = 0
    for char in col_letters:
        result = result * 26 + (ord(char.upper()) - 64)
    return result


def split_coord(coord: str) -> tuple[int, int]:
    match = re.fullmatch(r"([A-Z]+)(\d+)", coord)
    return int(match.group(2)), col_to_index(match.group(1))


def resolve_shared_formulas(grid):
    bases = {}
    for item in grid.values():
        shared_id = item.get("formula_shared_id")
        formula = item.get("formula")
        if shared_id is not None and formula:
            bases[shared_id] = (item["coord"], formula)
    for item in grid.values():
        shared_id = item.get("formula_shared_id")
        if not item.get("formula_exists") or item.get("formula") or shared_id not in bases:
            continue
        origin, base_formula = bases[shared_id]
        try:
            translated = Translator(f"={base_formula}", origin=origin).translate_formula(item["coord"])
            item["formula"] = translated.lstrip("=")
        except Exception:
            pass


def evaluated_numeric(grid, row, col, stack=None):
    item = grid.get((row, col))
    if not item:
        return None
    stack = set(stack or ())
    if (row, col) in stack:
        return None
    stack.add((row, col))
    formula = item.get("formula")
    if item.get("formula_exists") and formula:
        expression = formula.lstrip("=")

        def replace_reference(match):
            ref_row, ref_col = split_coord(f"{match.group(1).upper()}{match.group(2)}")
            value = evaluated_numeric(grid, ref_row, ref_col, stack)
            if value is None:
                raise ValueError("unresolved reference")
            return repr(float(value))

        try:
            expression = re.sub(r"\$?([A-Z]{1,3})\$?(\d+)", replace_reference, expression)
            if not re.fullmatch(r"[0-9eE.()+\-*/\s]+", expression):
                raise ValueError("unsupported formula")
            return float(eval(expression, {"__builtins__": {}}, {}))
        except Exception:
            pass
    try:
        return float(item.get("value"))
    except Exception:
        return None


def shared_strings(zip_handle):
    if "xl/sharedStrings.xml" not in zip_handle.namelist():
        return []
    root = ET.fromstring(zip_handle.read("xl/sharedStrings.xml"))
    strings = []
    for si in root.findall(f"{{{NS_MAIN}}}si"):
        parts = [node.text or "" for node in si.findall(f".//{{{NS_MAIN}}}t")]
        strings.append("".join(parts))
    return strings


def cell_display_value(cell, strings):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        parts = [node.text or "" for node in cell.findall(f".//{{{NS_MAIN}}}t")]
        return "".join(parts)
    value_node = cell.find(f"{{{NS_MAIN}}}v")
    if value_node is None:
        return None
    text = value_node.text
    if cell_type == "s":
        try:
            return strings[int(text)]
        except Exception:
            return None
    return text


def sheet_paths(zip_handle) -> dict[str, str]:
    workbook = ET.fromstring(zip_handle.read("xl/workbook.xml"))
    rels = ET.fromstring(zip_handle.read("xl/_rels/workbook.xml.rels"))
    rel_by_id = {
        rel.attrib["Id"]: rel.attrib["Target"]
        for rel in rels.findall(f"{{{NS_PKG_REL}}}Relationship")
    }
    paths = {}
    for sheet in workbook.findall(f".//{{{NS_MAIN}}}sheet"):
        name = sheet.attrib.get("name")
        rel_id = sheet.attrib.get(f"{{{NS_REL}}}id")
        target = rel_by_id.get(rel_id)
        if not name or not target:
            continue
        if target.startswith("/"):
            path = target.lstrip("/")
        else:
            path = posixpath.normpath(posixpath.join("xl", target))
        paths[name] = path
    return paths


def is_sample_label(value) -> bool:
    text = clean(value)
    if not text or text.startswith("="):
        return False
    low = text.lower()
    if low in {"control", "cont", "glutaric acid", "glutaric", "arabinose", "ara", "s"}:
        return False
    if "control" in low or "glutaric" in low or "arabinose" in low:
        return False
    if re.fullmatch(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", text):
        return False
    return bool(norm(text))


def header_for(grid, row: int, col: int):
    for header_row in range(row - 1, 0, -1):
        item = grid.get((header_row, col), {})
        value = item.get("value")
        if item.get("formula_exists"):
            continue
        if is_sample_label(value):
            text = clean(value)
            text = re.sub(r"^(?:P?A?0?447|P447|447|ARAE)\s*[-:]?\s*", "", text, flags=re.I)
            return clean(text)
    return None


def has_marker(grids, detector):
    markers = []
    for grid in grids:
        for (row, _col), item in grid.items():
            if row <= 5:
                text = (clean(item.get("value")) or "").lower()
                if text:
                    markers.append(text)
    joined = " ".join(markers)
    if detector == "PA447":
        return "glutaric" in joined or re.search(r"\bga\b", joined) is not None
    return "arabinose" in joined or re.search(r"\bara\b", joined) is not None


def extract_formula_records(path: Path):
    detector = detector_from_path(path)
    records = []
    try:
        with zipfile.ZipFile(path) as z:
            strings = shared_strings(z)
            paths = sheet_paths(z)
            grids_by_sheet = []
            for sheet_name, sheet_path in paths.items():
                root = ET.fromstring(z.read(sheet_path))
                grid = {}
                for cell in root.findall(f".//{{{NS_MAIN}}}c"):
                    coord = cell.attrib.get("r")
                    if not coord:
                        continue
                    row, col = split_coord(coord)
                    formula_node = cell.find(f"{{{NS_MAIN}}}f")
                    value = cell_display_value(cell, strings)
                    grid[(row, col)] = {
                        "value": value,
                        "formula": formula_node.text if formula_node is not None else None,
                        "formula_exists": formula_node is not None,
                        "formula_shared_id": formula_node.attrib.get("si") if formula_node is not None else None,
                        "coord": coord,
                    }
                grids_by_sheet.append((sheet_name, grid))
            if not has_marker([grid for _sheet, grid in grids_by_sheet], detector):
                return []
            for sheet_name, grid in grids_by_sheet:
                resolve_shared_formulas(grid)
                normalized_shared_ids = {
                    item.get("formula_shared_id")
                    for item in grid.values()
                    if item.get("formula_shared_id") is not None and "/" in (item.get("formula") or "")
                }
                normalized_formula_cells = {
                    (cell_row, cell_col)
                    for (cell_row, cell_col), cell_item in grid.items()
                    if "/" in (cell_item.get("formula") or "")
                    or (
                        cell_item.get("formula_exists")
                        and cell_item.get("formula_shared_id") in normalized_shared_ids
                    )
                }
                normalized_min_col_by_row = {}
                for cell_row, cell_col in normalized_formula_cells:
                    normalized_min_col_by_row[cell_row] = min(
                        cell_col,
                        normalized_min_col_by_row.get(cell_row, cell_col),
                    )
                for (row, col), item in grid.items():
                    formula = item.get("formula")
                    is_normalized_formula = (row, col) in normalized_formula_cells
                    is_literal_normalized_value = (
                        not item.get("formula_exists")
                        and row in normalized_min_col_by_row
                        and col >= normalized_min_col_by_row[row]
                    )
                    if row > 12 or col < 2 or not (is_normalized_formula or is_literal_normalized_value):
                        continue
                    value = evaluated_numeric(grid, row, col)
                    if value is None or not math.isfinite(value):
                        continue
                    sample = header_for(grid, row, col)
                    if not sample:
                        continue
                    records.append(
                        {
                            "detector": detector,
                            "value": value,
                            "sample": sample,
                            "keys": expand_manual_aliases(variants(sample)),
                            "source_file": path.name,
                            "source_cell": f"{sheet_name}!{item['coord']}",
                            "path": str(path),
                        }
                    )
    except Exception:
        return []
    return records


def detector_columns(headers, detector):
    cols = []
    i = 1
    while f"{detector} measurement {i}" in headers:
        cols.append(headers[f"{detector} measurement {i}"])
        i += 1
    return cols


def source_file_parts(value) -> dict[str, list[str]]:
    text = str(value or "")
    result = {"PA447": [], "araE": []}
    for detector in result:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if match:
            result[detector] = [part.strip() for part in match.group(1).split(",") if part.strip()]
    return result


def read_final():
    wb = load_workbook(FINAL_PATH, data_only=True, read_only=False)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    measurements = []
    needed_files = set()
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        status = ws.cell(row, headers["Measurement status"]).value
        source_text = ws.cell(row, headers["Measurement/source file"]).value
        sources = source_file_parts(source_text)
        for names in sources.values():
            needed_files.update(names)
        for detector in ("PA447", "araE"):
            for col in detector_columns(headers, detector):
                cell = ws.cell(row, col)
                if is_numeric(cell.value):
                    measurements.append(
                        {
                            "row": row,
                            "cell": cell.coordinate,
                            "primary": primary,
                            "secondary": secondary,
                            "status": status,
                            "detector": detector,
                            "value": float(cell.value),
                            "keys": expand_manual_aliases(variants(primary, secondary)),
                            "listed_files": sources[detector],
                        }
                    )
    return measurements, needed_files


def is_raw_source_candidate(path: Path) -> bool:
    name = path.name.lower()
    if name.startswith("~$") or path.name == FINAL_PATH.name:
        return False
    return not any(token in name for token in EXCLUDED_SOURCE_TOKENS)


def locate_sources(needed_files):
    located = defaultdict(list)
    for path in CODEX_SOURCE_ROOT.rglob("*.xlsx"):
        if is_raw_source_candidate(path):
            located[path.name].append(path)
    for root in ACTIVE_ROOTS:
        if root.exists():
            for path in root.glob("*.xlsx"):
                if is_raw_source_candidate(path):
                    located[path.name].append(path)
    if ONEDRIVE_ROOT.exists():
        for path in ONEDRIVE_ROOT.rglob("*.xlsx"):
            if path.name not in located and is_raw_source_candidate(path):
                located[path.name].append(path)
    return {name: sorted(set(paths), key=lambda p: str(p).lower()) for name, paths in located.items()}


def main():
    measurements, needed_files = read_final()
    sources_by_name = locate_sources(needed_files)
    source_records = []
    for _name, paths in sorted(sources_by_name.items()):
        for path in paths:
            source_records.extend(extract_formula_records(path))

    by_file_detector_value = defaultdict(list)
    by_detector_value = defaultdict(list)
    for record in source_records:
        key_value = round(record["value"], 6)
        by_file_detector_value[(record["source_file"], record["detector"], key_value)].append(record)
        by_detector_value[(record["detector"], key_value)].append(record)

    unsourced = []
    found_elsewhere = []
    sourced = 0
    for measurement in measurements:
        value_key = round(measurement["value"], 6)
        listed_matches = []
        for file_name in measurement["listed_files"]:
            for candidate in by_file_detector_value.get((file_name, measurement["detector"], value_key), []):
                if measurement["keys"] & candidate["keys"]:
                    listed_matches.append(candidate)
        if listed_matches:
            sourced += 1
            continue
        same_sample_matches = [
            candidate
            for candidate in by_detector_value.get((measurement["detector"], value_key), [])
            if measurement["keys"] & candidate["keys"]
        ]
        record = {
            "row": measurement["row"],
            "cell": measurement["cell"],
            "primary": measurement["primary"],
            "secondary": measurement["secondary"],
            "status": measurement["status"],
            "detector": measurement["detector"],
            "value": measurement["value"],
            "listed_files": measurement["listed_files"],
        }
        if same_sample_matches:
            record["found_for_same_sample_elsewhere"] = [
                {
                    "source_file": candidate["source_file"],
                    "sample": candidate["sample"],
                    "source_cell": candidate["source_cell"],
                    "path": candidate["path"],
                }
                for candidate in same_sample_matches[:5]
            ]
            found_elsewhere.append(record)
        else:
            same_value_other_sample = by_detector_value.get((measurement["detector"], value_key), [])
            record["same_value_seen_for_other_sample"] = [
                {
                    "source_file": candidate["source_file"],
                    "sample": candidate["sample"],
                    "source_cell": candidate["source_cell"],
                }
                for candidate in same_value_other_sample[:5]
            ]
            unsourced.append(record)

    result = {
                "measurements_checked": len(measurements),
                "sourced_from_listed_file": sourced,
                "unsourced_count": len(unsourced),
                "unsourced": unsourced,
                "found_for_same_sample_but_unlisted_count": len(found_elsewhere),
                "found_for_same_sample_but_unlisted": found_elsewhere,
                "source_records_extracted": len(source_records),
                "source_files_located": len(sources_by_name),
                "missing_listed_xlsx_files": sorted(
                    name for name in needed_files if str(name).endswith(".xlsx") and name not in sources_by_name
                ),
            }
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if OUTPUT_PATH:
        OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        OUTPUT_PATH.write_text(payload, encoding="utf-8")
        print(
            json.dumps(
                {
                    "measurements_checked": result["measurements_checked"],
                    "sourced_from_listed_file": result["sourced_from_listed_file"],
                    "unsourced_count": result["unsourced_count"],
                    "found_for_same_sample_but_unlisted_count": result["found_for_same_sample_but_unlisted_count"],
                    "source_records_extracted": result["source_records_extracted"],
                    "source_files_located": result["source_files_located"],
                    "output_path": str(OUTPUT_PATH),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print(payload)


if __name__ == "__main__":
    main()
