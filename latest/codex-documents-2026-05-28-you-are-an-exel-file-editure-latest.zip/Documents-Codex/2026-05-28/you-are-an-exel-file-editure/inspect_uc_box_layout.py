import json
from pathlib import Path

import openpyxl

ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")


def main():
    wb = openpyxl.load_workbook(ALIQUOTS, data_only=True)
    ws = wb["UC"]
    rows = []
    for row in range(1, ws.max_row + 1):
        rows.append(
            {
                "row": row,
                "values": [ws.cell(row, col).value for col in range(1, ws.max_column + 1)],
            }
        )
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    wb.close()
    print(json.dumps({"rows": rows, "merged_ranges": merged}, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
