from datetime import datetime
from pathlib import Path
from shutil import copy2

from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

YELLOW_RGB = "FFF2CC"


def is_yellow_fill(cell):
    if cell.fill.fill_type != "solid":
        return False
    rgb = cell.fill.fgColor.rgb
    return bool(rgb and str(rgb).upper().endswith(YELLOW_RGB))


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before original-yellow cleanup {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    wb = load_workbook(WORKBOOK)
    ws = wb["Final"]

    old_widths = {
        col: ws.column_dimensions[get_column_letter(col)].width
        for col in range(1, ws.max_column + 1)
    }

    removed_original = False
    if ws.cell(1, 1).value == "Original tab":
        ws.delete_cols(1)
        removed_original = True

        for old_col in range(2, len(old_widths) + 1):
            new_letter = get_column_letter(old_col - 1)
            width = old_widths.get(old_col)
            if width is not None:
                ws.column_dimensions[new_letter].width = width

    yellow_removed = 0
    comments_removed = 0
    leftover_comments_removed = 0
    for row in ws.iter_rows():
        for cell in row:
            if is_yellow_fill(cell):
                cell.fill = PatternFill(fill_type=None)
                yellow_removed += 1
                if cell.comment is not None:
                    cell.comment = None
                    comments_removed += 1
            elif cell.comment is not None:
                cell.comment = None
                leftover_comments_removed += 1

    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    wb.save(WORKBOOK)

    print(
        {
            "workbook": str(WORKBOOK),
            "backup": str(backup),
            "removed_original_tab_column": removed_original,
            "yellow_fills_removed": yellow_removed,
            "comments_removed": comments_removed,
            "leftover_comments_removed": leftover_comments_removed,
            "auto_filter": ws.auto_filter.ref,
            "rows": ws.max_row - 1,
            "cols": ws.max_column,
        }
    )


if __name__ == "__main__":
    main()
