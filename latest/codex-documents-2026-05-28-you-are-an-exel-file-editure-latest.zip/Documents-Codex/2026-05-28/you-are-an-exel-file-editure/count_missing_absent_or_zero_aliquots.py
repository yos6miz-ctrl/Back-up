from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import json

from openpyxl import load_workbook

import build_accounted_known_unknown as builder


FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
REPORT = Path("missing_absent_or_zero_aliquots_20260801_report.json")


def clean(value):
    return builder.clean(value)


def norm(value):
    return builder.norm(value)


def header_indices(ws):
    headers = [str(ws.cell(1, col).value or "").strip().lower() for col in range(1, ws.max_column + 1)]

    def find(*needles):
        for index, header in enumerate(headers, start=1):
            if any(needle in header for needle in needles):
                return index
        return None

    return {
        "sample": find("sample #", "sample name", "sample"),
        "patient": find("patient number", "מספר מטופל"),
        "aliquots": find("aliquots"),
    }


def numeric_zero(value):
    if value is None:
        return False
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return False
    try:
        return float(value) == 0
    except Exception:
        return False


def numeric_positive(value):
    if value is None:
        return False
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return False
    try:
        return float(value) > 0
    except Exception:
        return False


def keys_for(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
        if norm(value):
            keys.add(norm(value))
    return {key for key in keys if key}


def load_aliquot_index():
    wb = load_workbook(ALIQUOTS, read_only=True, data_only=True)
    index = defaultdict(list)
    rows = []
    for ws in wb.worksheets:
        cols = header_indices(ws)
        if not cols["aliquots"]:
            continue
        for row in range(2, ws.max_row + 1):
            sample = clean(ws.cell(row, cols["sample"]).value) if cols["sample"] else None
            patient = clean(ws.cell(row, cols["patient"]).value) if cols["patient"] else None
            if patient == "1":
                patient = None
            if not sample and not patient:
                continue
            record = {
                "sheet": ws.title,
                "row": row,
                "sample": sample,
                "patient": patient,
                "aliquots": ws.cell(row, cols["aliquots"]).value,
                "keys": sorted(keys_for(sample, patient)),
            }
            rows.append(record)
            for key in record["keys"]:
                index[key].append(record)
    return index, rows


def load_missing_rows():
    wb = load_workbook(FINAL, read_only=True, data_only=True)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    out = []
    for row in range(2, ws.max_row + 1):
        status = clean(ws.cell(row, headers["Measurement status"]).value)
        final = clean(ws.cell(row, headers["Final classification / decision"]).value)
        if status != "missing" and final != "missing":
            continue
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        out.append(
            {
                "row": row,
                "primary": primary,
                "secondary": secondary,
                "status": status,
                "final": final,
                "keys": sorted(keys_for(primary, secondary)),
            }
        )
    return out


def main():
    aliquot_index, aliquot_rows = load_aliquot_index()
    missing_rows = load_missing_rows()

    absent = []
    zero = []
    present_positive = []
    present_nonzero_unknown = []

    for item in missing_rows:
        matches = []
        seen = set()
        for key in item["keys"]:
            for record in aliquot_index.get(key, []):
                unique = (record["sheet"], record["row"])
                if unique not in seen:
                    seen.add(unique)
                    matches.append(record)
        if not matches:
            absent.append(item)
            continue
        if any(numeric_positive(record["aliquots"]) for record in matches):
            present_positive.append({**item, "matches": matches})
        elif any(numeric_zero(record["aliquots"]) for record in matches):
            zero.append({**item, "matches": matches})
        else:
            present_nonzero_unknown.append({**item, "matches": matches})

    report = {
        "final_file": str(FINAL),
        "aliquots_file": str(ALIQUOTS),
        "aliquot_rows_indexed": len(aliquot_rows),
        "missing_rows_total": len(missing_rows),
        "absent_from_aliquots_20260801": len(absent),
        "present_but_zero_aliquots": len(zero),
        "present_with_positive_aliquots": len(present_positive),
        "present_with_blank_or_non_numeric_aliquots": len(present_nonzero_unknown),
        "absent": absent,
        "zero": zero,
        "present_positive": present_positive,
        "present_nonzero_unknown": present_nonzero_unknown,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
