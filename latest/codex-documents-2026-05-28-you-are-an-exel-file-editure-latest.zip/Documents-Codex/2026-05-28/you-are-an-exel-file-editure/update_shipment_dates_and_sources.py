from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import re
import zipfile

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS_PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
SHIPMENT_PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Shipment Bar Ilan 7.26 Blinded.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT_PATH = WORKSPACE / "shipment_dates_update_report.json"


SOURCE_RENAMES = {
    "20260728 447 laura.xlsx": "20260728 447 laura new.xlsx",
    "20260728 araE laura.xlsx": "20260728 araE laura new.xlsx",
    "20260803 UN 447.xlsx": "20260803 UN 447 new.xlsx",
    "20260803 UN araE.xlsx": "20260803 UN araE new.xlsx",
    "20260804 UN araE.xlsx": "20260804 UN araE new.xlsx",
}


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def norm(value):
    text = (clean(value) or "").upper()
    text = re.sub(r"^UN[\s\-_]*", "", text)
    return re.sub(r"[^A-Z0-9]", "", text)


def date_to_cell(value):
    if value is None:
        return None
    if hasattr(value, "date"):
        return value
    text = clean(value)
    if not text:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%y", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return text


def load_shipment_dates():
    wb = load_workbook(SHIPMENT_PATH, data_only=True, read_only=True)
    ws = wb.active
    headers = [clean(ws.cell(1, col).value) for col in range(1, ws.max_column + 1)]
    header_map = {str(header).strip().lower(): index + 1 for index, header in enumerate(headers) if header}
    date_col = header_map["date of sample"]
    sample_col = header_map["sample code"]
    dates = {}
    rows = {}
    for row in range(2, ws.max_row + 1):
        sample = clean(ws.cell(row, sample_col).value)
        sample_date = date_to_cell(ws.cell(row, date_col).value)
        if not sample or not sample_date:
            continue
        key = norm(sample)
        dates[key] = sample_date
        rows[key] = row
    return dates, rows


def find_date_column(ws):
    for col in range(1, ws.max_column + 1):
        header = str(ws.cell(1, col).value or "").strip().lower()
        if header in {"date", "תאריך ביקור"} or "date" in header:
            return col
    return None


def find_name_columns(ws):
    headers = [str(ws.cell(1, col).value or "").strip().lower() for col in range(1, ws.max_column + 1)]
    cols = []
    for index, header in enumerate(headers, start=1):
        if any(token in header for token in ["sample", "patient number", "sample name", "sample #", "sample code"]):
            cols.append(index)
    if ws.title == "Unknown":
        cols.extend([2, 3])
    return sorted(set(col for col in cols if 1 <= col <= ws.max_column))


def update_aliquots(shipment_dates, shipment_rows):
    wb = load_workbook(ALIQUOTS_PATH)
    updates = []
    for ws in wb.worksheets:
        date_col = find_date_column(ws)
        name_cols = find_name_columns(ws)
        if not date_col or not name_cols:
            continue
        for row in range(2, ws.max_row + 1):
            hit_key = None
            hit_value = None
            for col in name_cols:
                value = clean(ws.cell(row, col).value)
                key = norm(value)
                if key in shipment_dates:
                    hit_key = key
                    hit_value = value
                    break
            if not hit_key:
                continue
            old = ws.cell(row, date_col).value
            new = shipment_dates[hit_key]
            if old == new:
                continue
            ws.cell(row, date_col).value = new
            ws.cell(row, date_col).number_format = "dd/mm/yyyy"
            updates.append(
                {
                    "sheet": ws.title,
                    "row": row,
                    "matched_name": hit_value,
                    "shipment_row": shipment_rows[hit_key],
                    "old_date": str(old) if old is not None else None,
                    "new_date": str(new),
                }
            )
    wb.save(ALIQUOTS_PATH)
    return updates


def load_aliquots_lookup():
    wb = load_workbook(ALIQUOTS_PATH, data_only=True, read_only=True)
    lookup = {}
    for ws in wb.worksheets:
        date_col = find_date_column(ws)
        name_cols = find_name_columns(ws)
        if not name_cols:
            continue
        for row in range(2, ws.max_row + 1):
            names = [clean(ws.cell(row, col).value) for col in name_cols]
            names = [name for name in names if name and name != "1"]
            if not names:
                continue
            primary = names[-1] if ws.title == "Unknown" and len(names) >= 2 else names[0]
            secondary = names[0] if ws.title == "Unknown" and len(names) >= 2 and norm(names[0]) != norm(primary) else None
            sample_date = ws.cell(row, date_col).value if date_col else None
            record = {
                "primary": primary,
                "secondary": secondary,
                "sample_date": sample_date,
                "sheet": ws.title,
                "row": row,
            }
            for name in names:
                lookup[norm(name)] = record
    return lookup


def update_final(shipment_dates):
    aliquots_lookup = load_aliquots_lookup()
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    updates = []
    source_updates = []
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        keys = [norm(secondary), norm(primary)]
        aliquot_record = next((aliquots_lookup[key] for key in keys if key in aliquots_lookup), None)
        if aliquot_record and not secondary and aliquot_record.get("secondary"):
            ws.cell(row, headers["Secondary / other name"]).value = aliquot_record["secondary"]
            secondary = aliquot_record["secondary"]
        matched_key = next((key for key in [norm(secondary), norm(primary)] if key in shipment_dates), None)
        if matched_key or (aliquot_record and aliquot_record.get("sample_date")):
            old_date = ws.cell(row, headers["Sample date"]).value
            new_date = shipment_dates[matched_key] if matched_key else aliquot_record.get("sample_date")
            if old_date != new_date:
                ws.cell(row, headers["Sample date"]).value = new_date
                ws.cell(row, headers["Sample date"]).number_format = "dd/mm/yyyy"
                updates.append(
                    {
                        "row": row,
                        "primary": primary,
                        "secondary": secondary,
                        "old_date": str(old_date) if old_date is not None else None,
                        "new_date": str(new_date),
                    }
                )

        source_cell = ws.cell(row, headers["Measurement/source file"])
        source = source_cell.value
        if source:
            new_source = str(source)
            for old_name, new_name in SOURCE_RENAMES.items():
                new_source = new_source.replace(old_name, new_name)
            if new_source != source:
                source_cell.value = new_source
                source_updates.append({"row": row, "primary": primary, "old_source": source, "new_source": new_source})
    wb.save(FINAL_PATH)
    remove_comment_and_table_parts(FINAL_PATH)
    return updates, source_updates


def remove_comment_and_table_parts(path):
    with zipfile.ZipFile(path, "r") as source:
        payload = [
            (item, source.read(item.filename))
            for item in source.infolist()
            if not item.filename.startswith("xl/tables/")
            and "comments" not in item.filename.lower()
            and "vmlDrawing" not in item.filename
        ]
    temp_path = path.with_suffix(".tmp.xlsx")
    with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as target:
        for item, data in payload:
            target.writestr(item, data)
    temp_path.replace(path)


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    aliquots_backup = BACKUP_DIR / f"aliqauts 20260801 before shipment dates {stamp}.xlsx"
    final_backup = BACKUP_DIR / f"Final Known and Unknown merged before shipment dates {stamp}.xlsx"
    aliquots_backup.write_bytes(ALIQUOTS_PATH.read_bytes())
    final_backup.write_bytes(FINAL_PATH.read_bytes())

    shipment_dates, shipment_rows = load_shipment_dates()
    aliquots_updates = update_aliquots(shipment_dates, shipment_rows)
    final_date_updates, final_source_updates = update_final(shipment_dates)
    report = {
        "aliquots_file": str(ALIQUOTS_PATH),
        "final_workbook": str(FINAL_PATH),
        "shipment_file": str(SHIPMENT_PATH),
        "aliquots_backup": str(aliquots_backup),
        "final_backup": str(final_backup),
        "shipment_date_count": len(shipment_dates),
        "aliquots_updates": aliquots_updates,
        "final_date_updates": final_date_updates,
        "final_source_updates": final_source_updates,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
