import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const folder = "C:/Users/Popovtzer lab/.codex/Excel file editor";
const mapPath = `${folder}/UN stool names.xlsx`;
const trialPath = `${folder}/Unknowns trial 6.26.xlsx`;
const outputPath = `${folder}/Merged Unknowns trial 6.26.xlsx`;
const fallbackOutputPath = `${folder}/Merged Unknowns trial 6.26 cleaned.xlsx`;

const confirmedMatches = new Map([
  ["UN FSL 672", "UN FLS 672"],
  ["UN EIM19262", "UN FIM19262"],
]);

async function inspectValues(file, range, maxRows = 500, maxCols = 26) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const table = await workbook.inspect({
    kind: "table",
    range: `${sheet.name}!${range}`,
    include: "values,formulas",
    tableMaxRows: maxRows,
    tableMaxCols: maxCols,
  });
  const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
  return JSON.parse(line).values ?? [];
}

async function chunkedValues(file, columnEnd, maxRow, chunkSize) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const rows = [];
  for (let start = 1; start <= maxRow; start += chunkSize) {
    const end = Math.min(maxRow, start + chunkSize - 1);
    const table = await workbook.inspect({
      kind: "table",
      range: `${sheet.name}!A${start}:${columnEnd}${end}`,
      include: "values,formulas",
      tableMaxRows: chunkSize,
      tableMaxCols: 26,
    });
    const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
    const matrix = JSON.parse(line).values ?? [];
    for (let i = 0; i < matrix.length; i++) {
      rows.push({ sourceRow: start + i, values: matrix[i] });
    }
  }
  return rows;
}

function clean(value) {
  return typeof value === "string" ? value.trim() : value;
}

function norm(value) {
  return String(value ?? "")
    .toUpperCase()
    .replace(/\([^)]*\)/g, "")
    .replace(/^UN\s*/, "")
    .replace(/[^A-Z0-9.]/g, "");
}

function compact(value) {
  return norm(value).replace(/\./g, "");
}

function editDistance(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[a.length][b.length];
}

function score(a, b) {
  const x = compact(a);
  const y = compact(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.includes(y) || y.includes(x)) return Math.min(x.length, y.length) / Math.max(x.length, y.length);
  return 1 - editDistance(x, y) / Math.max(x.length, y.length);
}

function finalDecision(first, second) {
  const values = [first, second]
    .filter((value) => value !== null && value !== undefined && String(value).trim() !== "")
    .map((value) => String(value).trim().toLowerCase());
  if (values.length === 0) return null;
  if (values.includes("pos")) return "IBD";
  if (values.length === 2 && values.every((value) => value === "neg")) return "IBS";
  if (values.includes("int")) return "Int";
  return null;
}

const mapRows = (await inspectValues(mapPath, "A1:B500"))
  .map((row, index) => ({
    sourceRow: index + 1,
    realName: clean(row[0]),
    unknownName: clean(row[1]),
  }))
  .filter((row) => row.realName || row.unknownName);

const trialRows = (await chunkedValues(trialPath, "I", 200, 30))
  .map(({ sourceRow, values }) => ({
    sourceRow,
    unknownName: clean(values[0]),
    pa447_1: values[1] ?? null,
    pa447_2: values[2] ?? null,
    pa447_3: values[3] ?? null,
    pa447Decision: values[4] ?? null,
    araE_1: values[5] ?? null,
    araE_2: values[6] ?? null,
    araE_3: values[7] ?? null,
    araEDecision: values[8] ?? null,
  }))
  .filter((row) => row.sourceRow > 1 && row.unknownName);

function bestMapMatch(trialUnknown) {
  const confirmedUnknown = confirmedMatches.get(trialUnknown);
  if (confirmedUnknown) {
    const index = mapRows.findIndex((row) => compact(row.unknownName) === compact(confirmedUnknown));
    if (index >= 0) return { index, mapped: mapRows[index], matchType: "confirmed similar", matchScore: 1 };
  }
  const candidates = mapRows
    .map((mapped, index) => ({
      index,
      mapped,
      matchScore: Math.max(score(trialUnknown, mapped.unknownName), score(trialUnknown, mapped.realName)),
    }))
    .sort((a, b) => b.matchScore - a.matchScore);
  const best = candidates[0];
  if (!best || best.matchScore < 1) return null;
  return { ...best, matchType: "exact normalized" };
}

const usedMapIndexes = new Set();
const merged = [];
for (const trial of trialRows) {
  const match = bestMapMatch(trial.unknownName);
  if (match) usedMapIndexes.add(match.index);
  merged.push([
    match?.mapped.realName ?? null,
    trial.unknownName,
    trial.pa447_1,
    trial.pa447_2,
    trial.pa447_3,
    trial.pa447Decision,
    trial.araE_1,
    trial.araE_2,
    trial.araE_3,
    trial.araEDecision,
    finalDecision(trial.pa447Decision, trial.araEDecision),
  ]);
}

for (let index = 0; index < mapRows.length; index++) {
  if (usedMapIndexes.has(index)) continue;
  const row = mapRows[index];
  merged.push([
    row.realName ?? null,
    row.unknownName ?? null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
  ]);
}

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Merged");
const headers = [
  "Real name",
  "Unknown name",
  "PA447 measurement 1",
  "PA447 measurement 2",
  "PA447 measurement 3",
  "PA447 decision",
  "araE measurement 1",
  "araE measurement 2",
  "araE measurement 3",
  "araE decision",
  "Final decision",
];
sheet.getRange(`A1:K${merged.length + 1}`).values = [headers, ...merged];

sheet.getRange("A1:K1").format = {
  font: { bold: true, color: "#111111" },
  fill: { color: "#D9EAF7" },
  alignment: { horizontal: "center", vertical: "middle", wrapText: true },
};
sheet.getRange("A1:B1").format = {
  font: { bold: true, color: "#111111" },
  fill: { color: "#D9EAF7" },
  alignment: { horizontal: "center", vertical: "middle", wrapText: true },
};
sheet.getRange("C1:F1").format = {
  font: { bold: true, color: "#111111" },
  fill: { color: "#E3EBC8" },
  alignment: { horizontal: "center", vertical: "middle", wrapText: true },
};
sheet.getRange("G1:J1").format = {
  font: { bold: true, color: "#111111" },
  fill: { color: "#F3DEC9" },
  alignment: { horizontal: "center", vertical: "middle", wrapText: true },
};
sheet.getRange("1:1").rowHeightPx = 42;
sheet.getRange(`A2:K${merged.length + 1}`).format = {
  font: { color: "#111111" },
  fill: { color: "#FFFFFF" },
  alignment: { vertical: "middle", wrapText: false },
};
sheet.getRange(`A2:B${merged.length + 1}`).format = {
  font: { color: "#111111" },
  fill: { color: "#FFFFFF" },
  alignment: { vertical: "middle", wrapText: false },
};
sheet.getRange(`C2:E${merged.length + 1}`).numberFormat = "0.000";
sheet.getRange(`G2:I${merged.length + 1}`).numberFormat = "0.000";
for (let row = 2; row <= merged.length + 1; row++) {
  for (const [col, index, color] of [["F", 5, "IBD"], ["J", 9, "IBS"]]) {
    const value = merged[row - 2]?.[index];
    if (!value) continue;
    if (color === "IBD") {
      sheet.getRange(`${col}${row}`).format = {
        font: { bold: true, color: "#5A1212" },
        fill: { color: "#F4C7C3" },
        alignment: { horizontal: "center", vertical: "middle" },
      };
    } else {
      sheet.getRange(`${col}${row}`).format = {
        font: { bold: true, color: "#17365D" },
        fill: { color: "#CFE2F3" },
        alignment: { horizontal: "center", vertical: "middle" },
      };
    }
  }
}
for (const [col, width] of [
  ["A", 160],
  ["B", 180],
  ["C", 110],
  ["D", 110],
  ["E", 110],
  ["F", 95],
  ["G", 110],
  ["H", 110],
  ["I", 110],
  ["J", 95],
  ["K", 110],
]) {
  sheet.getRange(`${col}:${col}`).columnWidthPx = width;
}

const notes = workbook.worksheets.add("Match notes");
notes.getRange("A1:B6").values = [
  ["Item", "Value"],
  ["Trial rows", trialRows.length],
  ["Name rows", mapRows.length],
  ["Rows in merged sheet", merged.length],
  ["Confirmed similar matches", "UN FSL 672 = UN FLS 672 / F-SL-19672; UN EIM19262 = UN FIM19262 / F-IM19262"],
  ["Blank measurements", "Rows marked no trial measurements came from the name list only."],
];
notes.getRange("A1:B1").format = {
  font: { bold: true, color: "#FFFFFF" },
  fill: { color: "#315A7D" },
};
notes.getRange("A:A").columnWidthPx = 170;
notes.getRange("B:B").columnWidthPx = 420;

await fs.mkdir(folder, { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
let savedPath = outputPath;
try {
  await output.save(outputPath);
} catch (error) {
  if (error?.code !== "EBUSY") throw error;
  savedPath = fallbackOutputPath;
  await output.save(fallbackOutputPath);
}

console.log(JSON.stringify({ outputPath: savedPath, mergedRows: merged.length, trialRows: trialRows.length, mapRows: mapRows.length }, null, 2));
