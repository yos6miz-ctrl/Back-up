from pathlib import Path

from openpyxl import load_workbook


PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged - Ichilov v4.xlsx")
SAMPLES = [
    "F-DO-2665",
    "F-US-26120",
    "F-NSE-26138",
    "F-GS-26166",
    "F-NW-26181",
    "F-SG-2533",
    "F-ZS-2688",
    "F-BZ-2698",
    "F-ED-24107",
    "F-OK-25179",
]


def main():
    wb = load_workbook(PATH, data_only=True, read_only=True)
    ws = wb["Final"]
    print("rows", ws.max_row, "cols", ws.max_column)
    print([ws.cell(1, col).value for col in range(1, ws.max_column + 1)])
    for sample in SAMPLES:
        found = []
        for row in range(2, ws.max_row + 1):
            values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
            if sample in values:
                found.append((row, values))
        if found:
            print("\n" + sample)
            for item in found[:10]:
                print(item)


if __name__ == "__main__":
    main()
