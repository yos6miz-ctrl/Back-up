from copy import copy
from pathlib import Path
import json
import re
import shutil

from openpyxl import load_workbook


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
SOURCE_PATH = EXCEL_DIR / "Final Known and Unknown merged - Ichilov.xlsx"
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
REPORT_PATH = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\finalize_ichilov_workbook_report.json")
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

NOT_CHECKED = "לא נבדק"
OLD_METERING_SYSTEM = "old metering system"
MISSING = "missing"


def clean(value):
    if value is None:
        return ""
    return str(value).strip()


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def status_sort_value(status):
    status = clean(status)
    if status == "measured":
        return 0
    if status == OLD_METERING_SYSTEM:
        return 1
    if status == MISSING:
        return 2
    if status == NOT_CHECKED:
        return 3
    return 4


def diagnosis_sort_value(diagnosis, final_value):
    value = clean(diagnosis) or clean(final_value)
    order = {
        "CDf": 0,
        "CDr": 1,
        "UCf": 2,
        "UCr": 3,
        "UC": 4,
        "IBD": 5,
        "IBS": 6,
        "Healthy": 7,
        "HS": 7,
        "Unknown": 8,
        "(IBS controls)": 9,
    }
    return (order.get(value, 99), value)


def p_control_name(value):
    text = clean(value).upper()
    return bool(re.fullmatch(r"(IBS\s*)?P[1-6]", text))


def row_values(ws, row):
    return [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]


def row_styles(ws, row):
    styles = []
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(row, col)
        styles.append(
            {
                "style": copy(cell._style),
                "number_format": cell.number_format,
                "alignment": copy(cell.alignment),
                "border": copy(cell.border),
                "fill": copy(cell.fill),
                "font": copy(cell.font),
                "comment": copy(cell.comment),
            }
        )
    return styles


def write_row(ws, row, values, styles):
    for col, value in enumerate(values, start=1):
        cell = ws.cell(row, col)
        cell.value = value
        style = styles[col - 1]
        cell._style = copy(style["style"])
        cell.number_format = style["number_format"]
        cell.alignment = copy(style["alignment"])
        cell.border = copy(style["border"])
        cell.fill = copy(style["fill"])
        cell.font = copy(style["font"])
        cell.comment = copy(style["comment"])


def table_sort_key(record, headers):
    values = record["values"]
    def val(header):
        col = headers[header] - 1
        return values[col] if col < len(values) else None

    return (
        status_sort_value(val("Measurement status")),
        diagnosis_sort_value(val("Diagnosis"), val("Final classification / decision")),
        clean(val("Original tab")),
        clean(val("Primary name")),
        clean(val("Secondary / other name")),
    )


def main():
    if not SOURCE_PATH.exists():
        raise FileNotFoundError(SOURCE_PATH)

    wb = load_workbook(SOURCE_PATH)
    if "Final" not in wb.sheetnames:
        raise ValueError(f"Expected a Final sheet in {SOURCE_PATH}")

    removed_sheets = []
    for sheet_name in list(wb.sheetnames):
        if sheet_name != "Final":
            del wb[sheet_name]
            removed_sheets.append(sheet_name)

    ws = wb["Final"]
    headers = header_map(ws)
    required = [
        "Primary name",
        "Secondary / other name",
        "Measurement status",
        "Diagnosis",
        "Final classification / decision",
    ]
    missing_headers = [header for header in required if header not in headers]
    if missing_headers:
        raise ValueError(f"Missing headers: {missing_headers}")

    records = []
    removed_rows = []
    for row in range(2, ws.max_row + 1):
        values = row_values(ws, row)
        primary = values[headers["Primary name"] - 1]
        secondary = values[headers["Secondary / other name"] - 1]
        if p_control_name(primary) or p_control_name(secondary):
            removed_rows.append({"row": row, "primary": primary, "secondary": secondary})
            continue
        records.append({"values": values, "styles": row_styles(ws, row), "original_row": row})

    records.sort(key=lambda record: table_sort_key(record, headers))

    for row in range(2, ws.max_row + 1):
        for col in range(1, ws.max_column + 1):
            ws.cell(row, col).value = None
            ws.cell(row, col).comment = None

    for offset, record in enumerate(records, start=2):
        write_row(ws, offset, record["values"], record["styles"])

    if ws.max_row > len(records) + 1:
        ws.delete_rows(len(records) + 2, ws.max_row - len(records) - 1)

    if ws.tables:
        for table in ws.tables.values():
            table.ref = f"A1:{ws.cell(row=1, column=ws.max_column).column_letter}{ws.max_row}"

    ws.auto_filter.ref = f"A1:{ws.cell(row=1, column=ws.max_column).column_letter}{ws.max_row}"

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    backup_path = BACKUP_DIR / "Final Known and Unknown merged before Ichilov.xlsx"
    if FINAL_PATH.exists():
        shutil.copy2(FINAL_PATH, backup_path)
    wb.save(FINAL_PATH)

    if SOURCE_PATH != FINAL_PATH and SOURCE_PATH.exists():
        SOURCE_PATH.unlink()

    report = {
        "saved": str(FINAL_PATH),
        "backup": str(backup_path) if backup_path.exists() else None,
        "removed_source_file": str(SOURCE_PATH),
        "removed_sheets": removed_sheets,
        "removed_rows": removed_rows,
        "final_rows": ws.max_row - 1,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2, default=str))


if __name__ == "__main__":
    main()
