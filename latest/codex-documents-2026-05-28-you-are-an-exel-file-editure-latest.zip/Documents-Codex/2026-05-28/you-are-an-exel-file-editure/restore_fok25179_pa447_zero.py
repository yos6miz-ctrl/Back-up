from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import shutil

from openpyxl import load_workbook

import build_accounted_known_unknown as builder
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "restore_fok25179_pa447_zero_report.json"


def row_names(ws, headers, row):
    return {
        builder.norm(ws.cell(row, headers["Primary name"]).value),
        builder.norm(ws.cell(row, headers["Secondary / other name"]).value),
    }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before F-OK-25179 PA447 zero restore {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(FINAL, backup)

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    matches = [row for row in range(2, ws.max_row + 1) if "FOK25179" in row_names(ws, headers, row)]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one F-OK-25179 row, found {matches}")
    row = matches[0]

    pa_cols = importer.detector_columns(headers, "PA447")
    ws.cell(row, pa_cols[0]).value = 0.0
    ws.cell(row, pa_cols[0]).number_format = "0.000000000"
    importer.write_source_cell(ws, row, headers, "PA447", "20260818 UN 447.xlsx")
    ws.cell(row, headers["Measurement status"]).value = "measured"
    importer.reclassify_row(ws, headers, row, bars)

    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{ws.cell(1, ws.max_column).coordinate[0]}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)
    shutil.copy2(FINAL, ONEDRIVE_FINAL)

    wb_check = load_workbook(FINAL, data_only=True, read_only=True)
    ws_check = wb_check["Final"]
    headers_check = importer.header_map(ws_check)
    check_row = [r for r in range(2, ws_check.max_row + 1) if "FOK25179" in row_names(ws_check, headers_check, r)][0]
    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "backup": str(backup),
        "row_after_sort": check_row,
        "primary": ws_check.cell(check_row, headers_check["Primary name"]).value,
        "secondary": ws_check.cell(check_row, headers_check["Secondary / other name"]).value,
        "pa447": [ws_check.cell(check_row, col).value for col in importer.detector_columns(headers_check, "PA447")],
        "pa447_decision": ws_check.cell(check_row, headers_check["PA447 decision"]).value,
        "arae": [ws_check.cell(check_row, col).value for col in importer.detector_columns(headers_check, "araE")],
        "arae_decision": ws_check.cell(check_row, headers_check["araE decision"]).value,
        "final_classification": ws_check.cell(check_row, headers_check["Final classification / decision"]).value,
        "source": ws_check.cell(check_row, headers_check["Measurement/source file"]).value,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
