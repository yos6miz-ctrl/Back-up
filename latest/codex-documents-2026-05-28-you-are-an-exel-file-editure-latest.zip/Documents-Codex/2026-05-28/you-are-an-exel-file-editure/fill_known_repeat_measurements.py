from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import os

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = Path(os.environ.get("FINAL_WORKBOOK_PATH", EXCEL_DIR / "Final Known and Unknown merged.xlsx"))

spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def expand_with_aliases(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def row_keys(primary, secondary):
    keys = set()
    keys.update(builder.identifier_variants(primary, secondary))
    keys.update(builder.strict_identifier_variants(primary, secondary))
    return {key for key in keys if key}


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def is_valid_candidate(row_diagnosis, item):
    if not (builder.compatible(row_diagnosis, item.get("diagnosis")) or item.get("diagnosis") is None):
        return False
    return True


def source_priority(item):
    source = item.get("source")
    if source == "edited normalized files":
        return 0
    if source == "IBD IBS OLD":
        return 1
    if source == "447 and araE ALL":
        return 2
    return 3


def value_key(value):
    try:
        return f"{float(value):.12g}"
    except Exception:
        return str(value)


def unique_candidates(items, detector, row_diagnosis):
    filtered = []
    for item in items:
        value = detector_value(item, detector)
        if value is None:
            continue
        if not is_valid_candidate(row_diagnosis, item):
            continue
        if detector == "PA447" and item.get("pa447_removed_reason"):
            continue
        filtered.append(item)

    if any(item.get("source") == "edited normalized files" for item in filtered):
        filtered = [item for item in filtered if item.get("source") == "edited normalized files"]

    unique = {}
    for item in sorted(filtered, key=source_sort_key_for_dedup):
        value = detector_value(item, detector)
        key = (
            item.get("source_name"),
            f"{float(value):.6f}" if isinstance(value, (int, float)) else value_key(value),
        )
        if key not in unique:
            unique[key] = item
    return sorted(
        unique.values(),
        key=lambda item: (
            source_priority(item),
            str(item.get("source_date") or ""),
            str(item.get("source_file") or ""),
            str(item.get("source_name") or ""),
            value_key(detector_value(item, detector)),
        ),
    )


def source_sort_key_for_dedup(item):
    return (
        source_priority(item),
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item.get("source_name") or ""),
        value_key(detector_value(item, "PA447") if item.get("pa447") is not None else item.get("araE")),
    )


def source_label(detector, items):
    if not items:
        return None
    grouped = defaultdict(list)
    for item in items:
        source = item.get("source")
        detail = item.get("source_file")
        label = source + (f" ({detail})" if detail else "")
        grouped[label].append(item.get("source_name"))
    parts = []
    for label, names in grouped.items():
        clean_names = sorted({str(name) for name in names if name})
        parts.append(label + (f" [{', '.join(clean_names)}]" if clean_names else ""))
    return f"{detector}: " + " | ".join(parts)


def main():
    aliases_records, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    del aliases_records
    all_rows, all_by_key = builder.load_all_measurements()
    old_rows = builder.load_old_rows()

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    primary_col = headers["Primary name"]
    secondary_col = headers["Secondary / other name"]
    diagnosis_col = headers["Diagnosis"]
    original_tab_col = headers["Original tab"]
    source_col = headers["Measurement/source file"]

    detector_cols = {
        "PA447": [headers[f"PA447 measurement {idx}"] for idx in (1, 2, 3)],
        "araE": [headers[f"araE measurement {idx}"] for idx in (1, 2, 3)],
    }

    changed_rows = []
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, original_tab_col).value != "Known":
            continue
        primary = ws.cell(row, primary_col).value
        secondary = ws.cell(row, secondary_col).value
        diagnosis = ws.cell(row, diagnosis_col).value
        keys = expand_with_aliases(row_keys(primary, secondary), aliases_by_key)

        row_sources = []
        row_changed = False
        for detector in ("PA447", "araE"):
            candidates = []
            for key in keys:
                candidates.extend(all_by_key.get(key, []))
            for old in old_rows:
                old_keys = old.get("identifiers", set()) | old.get("strict_identifiers", set())
                if keys & old_keys:
                    candidates.append(old)

            selected = unique_candidates(candidates, detector, diagnosis)[:3]
            values = [detector_value(item, detector) for item in selected]
            for idx, col in enumerate(detector_cols[detector]):
                old_value = ws.cell(row, col).value
                new_value = values[idx] if idx < len(values) else None
                if old_value != new_value:
                    ws.cell(row, col).value = new_value
                    row_changed = True
            label = source_label(detector, selected)
            if label:
                row_sources.append(label)

        if row_sources:
            old_source = ws.cell(row, source_col).value
            metadata_part = None
            if isinstance(old_source, str) and "; Metadata:" in old_source:
                metadata_part = "Metadata:" + old_source.split("; Metadata:", 1)[1].strip()
            new_source = "; ".join(row_sources)
            if metadata_part:
                new_source = f"{new_source}; {metadata_part}"
            ws.cell(row, source_col).value = new_source
        if row_changed:
            changed_rows.append((row, primary))

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "known_rows_with_repeat_changes": len(changed_rows), "examples": changed_rows[:20]})


if __name__ == "__main__":
    main()
