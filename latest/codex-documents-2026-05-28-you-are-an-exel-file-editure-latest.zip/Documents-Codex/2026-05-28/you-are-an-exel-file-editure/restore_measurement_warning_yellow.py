from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from shutil import copy2

from openpyxl import load_workbook
from openpyxl.styles import PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")
CLASSIFIER_HELPER = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\run_consensus_repeat_classifier.py"
)

BRIGHT_YELLOW = "FFFF00"
WARNING_YELLOW = "FFF2CC"


def load_helper():
    spec = spec_from_file_location("consensus_helper", CLASSIFIER_HELPER)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def is_fill(cell, rgb_suffix):
    if cell.fill.fill_type != "solid":
        return False
    rgb = cell.fill.fgColor.rgb
    return bool(rgb and str(rgb).upper().endswith(rgb_suffix))


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before measurement-yellow restore {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    helper = load_helper()
    classifier = helper.load_classifier()
    training, feature_cols, _fill_values, _sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(WORKBOOK)
    ws = wb["Final"]
    headers = header_map(ws)

    cleared_dfg = 0
    for header in ["Diagnosis", "Calprotectin level", "Disease location"]:
        col = headers[header]
        for row in range(2, ws.max_row + 1):
            cell = ws.cell(row, col)
            if is_fill(cell, BRIGHT_YELLOW):
                cell.fill = PatternFill(fill_type=None)
                cleared_dfg += 1

    measurement_cols = {
        "PA447": [headers[f"PA447 measurement {idx}"] for idx in (1, 2, 3)],
        "araE": [headers[f"araE measurement {idx}"] for idx in (1, 2, 3)],
    }

    cleared_old_warning = 0
    marked_warning = 0
    marked_by_reason = {}
    warning_fill = PatternFill(fill_type="solid", fgColor=WARNING_YELLOW)

    for row in range(2, ws.max_row + 1):
        for detector, cols in measurement_cols.items():
            for col in cols:
                cell = ws.cell(row, col)
                if is_fill(cell, WARNING_YELLOW):
                    cell.fill = PatternFill(fill_type=None)
                    cleared_old_warning += 1
                cell.comment = None

            values = [helper.numeric(ws.cell(row, col).value) for col in cols]
            result = helper.consensus_detector(detector, values, bars[detector]["bar"], classifier)
            if not result["problem_indices"]:
                continue

            marked_by_reason[result["reason"]] = marked_by_reason.get(result["reason"], 0) + len(result["problem_indices"])
            for idx in result["problem_indices"]:
                cell = ws.cell(row, cols[idx])
                if cell.value not in (None, ""):
                    cell.fill = warning_fill
                    marked_warning += 1

    wb.save(WORKBOOK)

    print(
        {
            "workbook": str(WORKBOOK),
            "backup": str(backup),
            "cleared_bright_yellow_in_DFG": cleared_dfg,
            "cleared_old_measurement_warning_yellow": cleared_old_warning,
            "marked_measurement_warning_yellow": marked_warning,
            "marked_by_reason": marked_by_reason,
            "rows": ws.max_row - 1,
            "cols": ws.max_column,
        }
    )


if __name__ == "__main__":
    main()
