from __future__ import annotations

import json
import re
import zipfile
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import openpyxl
import audit_final_dates_against_sources as fast_xlsx

WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
BACKUP_BEFORE_RESTORE = WORKSPACE / "backups" / "Final Known and Unknown merged before removing v4 and 0-2 score 20260825-144453.xlsx"
REPORT = WORKSPACE / "audit_longitudinal_flags_against_aliquots_report.json"

LONGITUDINAL_TABS = ["מתלקחים CD (blind)", "CD רמיסיה (blind)"]


def clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", clean(value)).upper()


def parse_date(value):
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    text = clean(value)
    if not text:
        return ""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return text[:10]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def split_names(*values):
    names = []
    for value in values:
        for part in re.split(r"\s*;\s*", clean(value)):
            if part:
                names.append(part)
    return names


def final_key_set(primary, secondary):
    keys = set()
    for name in split_names(primary, secondary):
        key = norm(name)
        if key:
            keys.add(key)
    return keys


def source_keys(record):
    keys = set()
    for name in (record.get("sample"), record.get("synonym"), record.get("patient")):
        key = norm(name)
        if key:
            keys.add(key)
    return keys


def read_longitudinal_source_records():
    wb = openpyxl.load_workbook(ALIQUOTS, data_only=True, read_only=True)
    records = []

    # מתלקחים CD (blind): columns used by the earlier dedicated audit.
    if "מתלקחים CD (blind)" in wb.sheetnames:
        ws = wb["מתלקחים CD (blind)"]
        grouped = defaultdict(list)
        for row in range(2, ws.max_row + 1):
            patient = clean(ws.cell(row, 6).value)
            date = parse_date(ws.cell(row, 7).value)
            sample = clean(ws.cell(row, 8).value)
            synonym = clean(ws.cell(row, 12).value)
            if not sample or sample.lower() in {"sample", "sample name (f)"}:
                continue
            grouped[patient or synonym or sample].append(
                {
                    "sheet": ws.title,
                    "row": row,
                    "patient": patient,
                    "sample": sample,
                    "synonym": synonym,
                    "date": date,
                }
            )
        for _, items in grouped.items():
            items.sort(key=lambda item: (item["date"] or "9999-12-31", item["row"]))
            for index, item in enumerate(items, start=1):
                records.append({**item, "expected_longitudinal": index, "expected_diagnosis": "CDf" if index == len(items) else "CDr"})

    # CD רמיסיה (blind): each row is longitudinal/remission, sequence is by matching patient/synonym/date.
    if "CD רמיסיה (blind)" in wb.sheetnames:
        ws = wb["CD רמיסיה (blind)"]
        grouped = defaultdict(list)
        for row in range(2, ws.max_row + 1):
            date = parse_date(ws.cell(row, 5).value)
            sample = clean(ws.cell(row, 6).value)
            synonym = clean(ws.cell(row, 10).value)
            if not sample or sample.lower() in {"sample", "sample name (f)"}:
                continue
            patient = re.sub(r"\D", "", synonym) or synonym or sample
            grouped[patient].append(
                {
                    "sheet": ws.title,
                    "row": row,
                    "patient": patient,
                    "sample": sample,
                    "synonym": synonym,
                    "date": date,
                }
            )
        for _, items in grouped.items():
            items.sort(key=lambda item: (item["date"] or "9999-12-31", item["row"]))
            for index, item in enumerate(items, start=1):
                records.append({**item, "expected_longitudinal": index, "expected_diagnosis": "CDr"})

    wb.close()
    return records


def read_final_rows(path):
    with zipfile.ZipFile(path) as zf:
        shared_strings = fast_xlsx.read_shared_strings(zf)
        root = fast_xlsx.ET.fromstring(zf.read(fast_xlsx.sheet_path_for_name(zf, "Final")))
        raw_rows = []
        for row_node in root.findall(f".//{fast_xlsx.NS_MAIN}row"):
            values = {}
            max_col = 0
            for cell in row_node.findall(f"{fast_xlsx.NS_MAIN}c"):
                index = fast_xlsx.col_index(cell.attrib["r"])
                values[index] = fast_xlsx.cell_text(cell, shared_strings)
                max_col = max(max_col, index)
            raw_rows.append([values.get(index, "") for index in range(1, max_col + 1)])
    headers = {name: index for index, name in enumerate(raw_rows[0])}
    rows = []
    for row_number, row_values in enumerate(raw_rows[1:], start=2):
        def get(column):
            index = headers.get(column)
            return row_values[index] if index is not None and index < len(row_values) else ""

        primary = get("Primary name")
        secondary = get("Secondary / other name")
        rows.append(
            {
                "row": row_number,
                "primary": clean(primary),
                "secondary": clean(secondary),
                "keys": sorted(final_key_set(primary, secondary)),
                "diagnosis": get("Diagnosis"),
                "sample_date": parse_date(get("Sample date")),
                "longitudinal": get("Longitudinal sample"),
            }
        )
    return rows


def build_source_index(records):
    by_key = defaultdict(list)
    for record in records:
        for key in source_keys(record):
            by_key[key].append(record)
    return by_key


def find_backup_value(backup_rows, primary, secondary):
    target_keys = final_key_set(primary, secondary)
    return [
        {
            "row": row["row"],
            "primary": row["primary"],
            "secondary": row["secondary"],
            "longitudinal": row["longitudinal"],
            "sample_date": row["sample_date"],
        }
        for row in backup_rows
        if target_keys & set(row["keys"])
    ]


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {"bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def main():
    source_records = read_longitudinal_source_records()
    source_by_key = build_source_index(source_records)
    final_rows = read_final_rows(FINAL)
    backup_rows = read_final_rows(BACKUP_BEFORE_RESTORE) if BACKUP_BEFORE_RESTORE.exists() else []

    nonzero_final = [row for row in final_rows if row["longitudinal"] not in (None, "", 0, "0")]
    unsupported_nonzero = []
    matched_nonzero = []
    missing_source_records = []

    final_by_key = defaultdict(list)
    for row in final_rows:
        for key in row["keys"]:
            final_by_key[key].append(row)

    for row in nonzero_final:
        matches = []
        for key in row["keys"]:
            matches.extend(source_by_key.get(key, []))
        unique = {}
        for match in matches:
            unique[(match["sheet"], match["row"])] = match
        matches = list(unique.values())
        if matches:
            matched_nonzero.append({**row, "source_matches": matches})
        else:
            unsupported_nonzero.append({**row, "backup_matches": find_backup_value(backup_rows, row["primary"], row["secondary"])})

    for record in source_records:
        matches = []
        for key in source_keys(record):
            matches.extend(final_by_key.get(key, []))
        unique = {}
        for match in matches:
            unique[match["row"]] = match
        if not unique:
            missing_source_records.append(record)

    ct1156_trace = {
        "current": [row for row in final_rows if "CT1156" in row["keys"] or "FYD21156" in row["keys"]],
        "backup_before_restore": find_backup_value(backup_rows, "CT1156", "1156; CDf 1156 old; F-YD-21156"),
        "longitudinal_source_matches": [
            record
            for record in source_records
            if source_keys(record) & {"CT1156", "FYD21156", "1156"}
        ],
    }

    report = {
        "source_workbook": str(ALIQUOTS),
        "final_workbook": str(FINAL),
        "longitudinal_source_records": len(source_records),
        "final_nonzero_longitudinal_count": len(nonzero_final),
        "unsupported_nonzero_count": len(unsupported_nonzero),
        "unsupported_nonzero": unsupported_nonzero,
        "missing_source_records_count": len(missing_source_records),
        "missing_source_records": missing_source_records,
        "ct1156_trace": ct1156_trace,
        "zip_health": {"onedrive_final": zip_health(FINAL), "codex_final": zip_health(CODEX_FINAL)},
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
