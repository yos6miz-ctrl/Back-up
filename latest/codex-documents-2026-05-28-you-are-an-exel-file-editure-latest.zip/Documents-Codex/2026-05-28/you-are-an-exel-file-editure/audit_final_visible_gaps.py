from __future__ import annotations

import json
from pathlib import Path

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
REPORT = WORKSPACE / "final_visible_gaps_audit.json"


def main():
    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    header_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    headers = {value: idx for idx, value in enumerate(header_row)}
    rows = []
    max_visible_counts = {"PA447": 0, "araE": 0}
    for row_number, row in enumerate(ws.iter_rows(min_row=2, max_col=ws.max_column, values_only=True), start=2):
        for detector in ("PA447", "araE"):
            slots = [row[headers[f"{detector} measurement {i}"]] for i in (1, 2, 3)]
            numeric_count = sum(isinstance(value, (int, float)) for value in slots)
            max_visible_counts[detector] = max(max_visible_counts[detector], numeric_count)
            seen_blank = False
            gaps = []
            for idx, value in enumerate(slots, start=1):
                if value in (None, ""):
                    seen_blank = True
                elif seen_blank:
                    gaps.append(idx)
            if gaps:
                rows.append(
                    {
                        "row": row_number,
                        "primary": row[headers["Primary name"]],
                        "secondary": row[headers["Secondary / other name"]],
                        "detector": detector,
                        "slots": slots,
                        "gap_slots": gaps,
                    }
                )
    report = {"gap_rows": rows, "max_visible_counts": max_visible_counts}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
