from __future__ import annotations

import json
import shutil
import zipfile
from copy import copy
from pathlib import Path

import openpyxl

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ALIQUOTS_ONEDRIVE = ROOT / "aliqauts 20260801.xlsx"
ALIQUOTS_WORKING = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
REPORT = WORKSPACE / "repair_uc_box_layout_report.json"

UC_ROWS = [
    ["UCf", "1,4,2", 527, "F-DS-20527", "2020-08-25 00:00:00", 12],
    ["UCf", "2,1,2", 113, "CT113", "2017-05-23 00:00:00", 22],
    ["UCf", "3,1,2", 163, "CT-163", None, 5],
    ["UCf", "3,1,2", 167, "CT-167", None, 14],
    ["UCf", "3,1,2", 187, "CT-187", None, 14],
    ["UCf", "3,1,2", 229, "CT-229", None, 9],
    ["UCf", "3,1,2", 270, "CT-270", None, 10],
    ["UCr", "3,1,3", 222, "CT-222", None, 10],
    ["UCr", "3,1,3", 241, "CT-241", None, 5],
    ["UCr", "3,1,3", 245, "CT-245", None, 6],
    ["UCr", "3,1,3", 247, "CT-247", None, 6],
    ["UCr", "3,1,3", 258, "CT-258", None, 5],
]


def health(path):
    with zipfile.ZipFile(path) as zf:
        return {"bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def merged_ranges_for_groups(start_row=2):
    ranges = []
    group_start = start_row
    prev = None
    for offset, row in enumerate(UC_ROWS):
        key = (row[0], row[1])
        excel_row = start_row + offset
        if prev is None:
            prev = key
            group_start = excel_row
            continue
        if key != prev:
            if excel_row - group_start > 1:
                ranges.append((group_start, excel_row - 1))
            group_start = excel_row
            prev = key
    last_row = start_row + len(UC_ROWS) - 1
    if last_row - group_start >= 1:
        ranges.append((group_start, last_row))
    return ranges


def repair(path):
    wb = openpyxl.load_workbook(path)
    ws = wb["UC"]

    before = [[row] + [ws.cell(row, col).value for col in range(1, 7)] for row in range(1, ws.max_row + 1)]

    style_templates = {}
    for row in range(1, ws.max_row + 1):
        sample = ws.cell(row, 4).value
        if sample:
            style_templates[str(sample)] = [copy(ws.cell(row, col)._style) for col in range(1, 7)]
    default_styles = [copy(ws.cell(2, col)._style) for col in range(1, 7)]
    header_values = [ws.cell(1, col).value for col in range(1, 7)]
    header_styles = [copy(ws.cell(1, col)._style) for col in range(1, 7)]
    column_widths = {col: ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width for col in range(1, 7)}

    for merged in list(ws.merged_cells.ranges):
        if merged.min_col <= 2 and merged.max_col >= 1:
            ws.unmerge_cells(str(merged))

    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)

    for col, value in enumerate(header_values, start=1):
        cell = ws.cell(1, col)
        cell.value = value
        cell._style = copy(header_styles[col - 1])
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = column_widths[col]

    for index, values in enumerate(UC_ROWS, start=2):
        sample = str(values[3])
        styles = style_templates.get(sample, default_styles)
        for col, value in enumerate(values, start=1):
            cell = ws.cell(index, col)
            cell.value = value
            cell._style = copy(styles[col - 1])
            if col == 5 and value:
                cell.number_format = "yyyy-mm-dd"

    for start, end in merged_ranges_for_groups():
        ws.merge_cells(start_row=start, start_column=1, end_row=end, end_column=1)
        ws.merge_cells(start_row=start, start_column=2, end_row=end, end_column=2)

    wb.save(path)
    wb.close()

    check = openpyxl.load_workbook(path, data_only=True)
    ws_check = check["UC"]
    after = [[row] + [ws_check.cell(row, col).value for col in range(1, 7)] for row in range(1, ws_check.max_row + 1)]
    merged = [str(rng) for rng in ws_check.merged_cells.ranges]
    check.close()
    return {"before": before, "after": after, "merged_ranges": merged}


def main():
    result = repair(ALIQUOTS_ONEDRIVE)
    shutil.copy2(ALIQUOTS_ONEDRIVE, ALIQUOTS_WORKING)
    report = {
        "onedrive": str(ALIQUOTS_ONEDRIVE),
        "working_copy": str(ALIQUOTS_WORKING),
        "layout": result,
        "health": {
            "onedrive": health(ALIQUOTS_ONEDRIVE),
            "working_copy": health(ALIQUOTS_WORKING),
        },
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
