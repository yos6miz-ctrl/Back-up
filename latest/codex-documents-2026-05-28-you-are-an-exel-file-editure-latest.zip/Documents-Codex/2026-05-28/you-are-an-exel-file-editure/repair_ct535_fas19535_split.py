from pathlib import Path

from openpyxl import load_workbook


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_row(ws, headers, primary):
    for row in range(2, ws.max_row + 1):
        if str(ws.cell(row, headers["Primary name"]).value or "").strip() == primary:
            return row
    raise ValueError(f"Could not find {primary}")


def set_detector_values(ws, headers, row, detector, values):
    for idx, value in enumerate(values, start=1):
        cell = ws.cell(row, headers[f"{detector} measurement {idx}"])
        cell.value = value
        cell.number_format = "0.000000000"
    for idx in range(len(values) + 1, 4):
        ws.cell(row, headers[f"{detector} measurement {idx}"]).value = None


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    ct535_row = find_row(ws, headers, "CT535")
    fas_row = find_row(ws, headers, "F-AS19535")

    set_detector_values(
        ws,
        headers,
        ct535_row,
        "PA447",
        [0.3880724683403969, 0.14048531228435526, 0.15539153416951496],
    )
    set_detector_values(ws, headers, ct535_row, "araE", [0.09805624303683429])

    set_detector_values(
        ws,
        headers,
        fas_row,
        "PA447",
        [0.3067726641893387, 0.3846322912918894, 0.252961688571506],
    )
    set_detector_values(ws, headers, fas_row, "araE", [0.016451011513764005])

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "CT535_row": ct535_row,
            "F-AS19535_row": fas_row,
        }
    )


if __name__ == "__main__":
    main()
