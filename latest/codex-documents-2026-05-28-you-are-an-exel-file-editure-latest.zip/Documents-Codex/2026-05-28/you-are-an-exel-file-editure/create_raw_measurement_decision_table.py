from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
OUTPUT_PATH = EXCEL_DIR / "Raw normalized measurements needing decisions.xlsx"


spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def keys_for_values(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def filename(value):
    if not value:
        return None
    return str(value).replace("/", "\\").split("\\")[-1]


def detector_value(record, detector):
    return record.get("pa447") if detector == "PA447" else record.get("araE")


def almost_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def source_files_for_detector(source_text, detector):
    if not source_text:
        return set()
    text = str(source_text)
    match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE|Metadata):|$)", text, flags=re.I)
    if not match:
        return set()
    names = set()
    for part in match.group(1).split(","):
        name = filename(part.strip())
        if name and name.lower().endswith(".xlsx"):
            names.add(name)
    return names


def load_final_rows(aliases_by_key):
    wb = load_workbook(FINAL_PATH, data_only=True)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    rows = []
    key_to_rows = defaultdict(list)
    for row_index in range(2, ws.max_row + 1):
        row = {
            "row": row_index,
            "primary": ws.cell(row_index, headers["Primary name"]).value,
            "secondary": ws.cell(row_index, headers["Secondary / other name"]).value,
            "status": ws.cell(row_index, headers["Measurement status"]).value,
            "diagnosis": ws.cell(row_index, headers["Diagnosis"]).value,
            "final": ws.cell(row_index, headers["Final classification / decision"]).value,
            "source": ws.cell(row_index, headers["Measurement/source file"]).value,
            "values": {},
            "source_files": {},
        }
        row["keys"] = expand_keys(keys_for_values(row["primary"], row["secondary"]), aliases_by_key)
        for detector in ("PA447", "araE"):
            values = []
            for idx in (1, 2, 3):
                value = ws.cell(row_index, headers[f"{detector} measurement {idx}"]).value
                if isinstance(value, (int, float)):
                    values.append(value)
            row["values"][detector] = values
            row["source_files"][detector] = source_files_for_detector(row["source"], detector)
        rows.append(row)
        for key in row["keys"]:
            key_to_rows[key].append(row)
    return rows, key_to_rows


def final_row_candidates(record, detector, aliases_by_key, key_to_rows):
    record_keys = expand_keys(record.get("identifiers", set()) | record.get("strict_identifiers", set()), aliases_by_key)
    candidates = []
    seen = set()
    for key in record_keys:
        for row in key_to_rows.get(key, []):
            if row["row"] in seen:
                continue
            seen.add(row["row"])
            row_diagnosis = str(row.get("diagnosis") or "").strip().lower()
            if (
                row_diagnosis in {"", "unknown"}
                or builder.compatible(row.get("diagnosis"), record.get("diagnosis"))
                or record.get("diagnosis") is None
            ):
                candidates.append(row)
    return sorted(candidates, key=lambda item: item["row"])


def classify_gap(record, detector, candidates):
    if not candidates:
        return "No matching final row"
    if len(candidates) > 1:
        return "Multiple possible final rows"
    row = candidates[0]
    if row["status"] == builder.MISSING:
        return "Final row marked missing but raw value exists"
    if not row["values"][detector]:
        return "No displayed values for this detector"
    if len(row["values"][detector]) >= 3:
        return "Final already has 3 displayed values"
    return "Extra edited normalized value not displayed"


def clean_display(values):
    if not values:
        return ""
    return ", ".join(f"{value:.9g}" for value in values)


def ignored_raw_source_name(name):
    text = str(name or "").strip()
    return bool(re.fullmatch(r"IBS\s+[Pp]\d+(?:\s+\w+\d+)?", text, flags=re.I))


def main():
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    final_rows, key_to_rows = load_final_rows(aliases_by_key)
    records = builder.load_edited_normalized_measurements()

    decision_rows = []
    accounted = 0
    ignored_name_count = 0
    for record in records:
        if ignored_raw_source_name(record.get("source_name")):
            ignored_name_count += 1
            continue
        detector = "PA447" if record.get("pa447") is not None else "araE"
        value = detector_value(record, detector)
        candidates = final_row_candidates(record, detector, aliases_by_key, key_to_rows)
        displayed_hits = [
            row for row in candidates if any(almost_equal(displayed, value) for displayed in row["values"][detector])
        ]
        if displayed_hits:
            accounted += 1
            continue

        source_name = filename(record.get("source_file"))
        source_listed = any(source_name in row["source_files"][detector] for row in candidates)
        reason = classify_gap(record, detector, candidates)
        decision_rows.append(
            {
                "Your decision": "",
                "Review reason": reason,
                "Detector": detector,
                "Raw source name": record.get("source_name"),
                "Raw normalized value": value,
                "Raw source file": source_name,
                "Raw source cell": ", ".join(record.get("source_rows") or []),
                "Raw diagnosis": record.get("diagnosis"),
                "Final row(s)": "; ".join(
                    f"{row['row']}: {row['primary']} / {row['secondary']}" for row in candidates
                ),
                "Final status": "; ".join(str(row.get("status") or "") for row in candidates),
                "Final diagnosis": "; ".join(str(row.get("diagnosis") or "") for row in candidates),
                "Final decision": "; ".join(str(row.get("final") or "") for row in candidates),
                "Displayed values in final": "; ".join(clean_display(row["values"][detector]) for row in candidates),
                "Source file already listed": "yes" if source_listed else "no",
            }
        )

    decision_rows.sort(
        key=lambda item: (
            item["Review reason"],
            item["Detector"],
            str(item["Final row(s)"]),
            str(item["Raw source name"]),
            str(item["Raw source file"]),
        )
    )

    wb = Workbook()
    ws = wb.active
    ws.title = "Need decision"
    headers = [
        "Your decision",
        "Review reason",
        "Detector",
        "Raw source name",
        "Raw normalized value",
        "Raw source file",
        "Raw source cell",
        "Raw diagnosis",
        "Final row(s)",
        "Final status",
        "Final diagnosis",
        "Final decision",
        "Displayed values in final",
        "Source file already listed",
    ]
    ws.append(headers)
    for row in decision_rows:
        ws.append([row[header] for header in headers])

    summary = wb.create_sheet("Summary")
    summary.append(["Metric", "Count"])
    summary_rows = [
        ("Edited normalized raw records extracted", len(records)),
        ("Ignored IBS Pnumber raw records", ignored_name_count),
        ("Already shown in final workbook", accounted),
        ("Need your decision", len(decision_rows)),
    ]
    summary_rows.extend(sorted(Counter(row["Review reason"] for row in decision_rows).items()))
    for item in summary_rows:
        summary.append(list(item))

    fallback = wb.create_sheet("Fallback locations")
    fallback.append(["Sample", "Detector fallback", "Where fallback value currently comes from"])
    fallback_rows = [
        ("UN F-SL19237", "araE", "Unknowns trial 6.26.xlsx row 134"),
        ("UN F-LB19251", "araE", "Unknowns trial 6.26.xlsx row 135"),
        ("UN F-MB19279", "araE", "Unknowns trial 6.26.xlsx row 138"),
        ("UN FSD 139", "PA447 and araE", "Unknowns trial 6.26.xlsx row 71"),
        ("UN FSB 549", "PA447", "Unknowns trial 6.26.xlsx row 73"),
    ]
    for item in fallback_rows:
        fallback.append(list(item))

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    warning_fill = PatternFill("solid", fgColor="FFF2CC")
    border = Border(bottom=Side(style="thin", color="B7B7B7"))
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = Font(bold=True)
            cell.border = border
            cell.alignment = Alignment(horizontal="center")
        for row in sheet.iter_rows(min_row=2):
            if sheet.title == "Need decision":
                row[0].fill = warning_fill
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        widths = {
            "A": 16,
            "B": 34,
            "C": 10,
            "D": 22,
            "E": 16,
            "F": 38,
            "G": 14,
            "H": 14,
            "I": 38,
            "J": 18,
            "K": 18,
            "L": 16,
            "M": 28,
            "N": 20,
        }
        for column, width in widths.items():
            sheet.column_dimensions[column].width = width
        if sheet.title != "Need decision":
            for col in range(1, sheet.max_column + 1):
                sheet.column_dimensions[get_column_letter(col)].width = max(sheet.column_dimensions[get_column_letter(col)].width or 0, 24)

    wb.save(OUTPUT_PATH)
    print(
        {
            "saved": str(OUTPUT_PATH),
            "edited_normalized_records": len(records),
            "already_accounted": accounted,
            "needs_decision": len(decision_rows),
            "reasons": dict(Counter(row["Review reason"] for row in decision_rows)),
        }
    )


if __name__ == "__main__":
    main()
