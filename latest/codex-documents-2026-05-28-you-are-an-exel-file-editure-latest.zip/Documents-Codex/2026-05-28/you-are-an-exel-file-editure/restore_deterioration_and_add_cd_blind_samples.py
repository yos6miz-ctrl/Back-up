from __future__ import annotations

from collections import defaultdict
from copy import copy
from datetime import datetime
from pathlib import Path
import json
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS_COPY = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
RESTORE_BACKUP = WORKSPACE / "backups" / "Final Known and Unknown merged before removing v4 and 0-2 score 20260825-144453.xlsx"
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "restore_deterioration_and_add_cd_blind_samples_report.json"

CD_TABS = [
    ("מתלקחים CD (blind)", "CDf"),
    ("CD רמיסיה (blind)", "CDr"),
]


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def date_key(value):
    value = clean(value)
    if not value:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return value[:10]


def date_cell(value):
    key = date_key(value)
    if not key:
        return None
    try:
        return datetime.strptime(key, "%Y-%m-%d")
    except ValueError:
        return clean(value)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def keys_for(primary, secondary=None):
    keys = {norm(primary), norm(secondary)}
    return {key for key in keys if key}


def build_final_index(ws, headers):
    by_key = defaultdict(list)
    by_key_date = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        sample_date = date_key(ws.cell(row, headers["Sample date"]).value)
        item = {"row": row, "primary": clean(primary), "secondary": clean(secondary), "date": sample_date}
        for key in keys_for(primary, secondary):
            by_key[key].append(item)
            if sample_date:
                by_key_date[(key, sample_date)].append(item)
    return by_key, by_key_date


def unique_rows(items):
    found = {}
    for item in items:
        found[item["row"]] = item
    return list(found.values())


def find_row(record, by_key, by_key_date):
    matches = []
    if record["date"]:
        for key in keys_for(record["sample"], record["alias"]):
            matches.extend(by_key_date.get((key, record["date"]), []))
        matches = unique_rows(matches)
        if len(matches) == 1:
            return matches[0]["row"]
        exact = [item for item in matches if norm(item["primary"]) == norm(record["sample"])]
        if len(exact) == 1:
            return exact[0]["row"]
    matches = []
    for key in keys_for(record["sample"], record["alias"]):
        matches.extend(by_key.get(key, []))
    matches = unique_rows(matches)
    blank_or_same = [item for item in matches if not record["date"] or not item["date"] or item["date"] == record["date"]]
    if len(blank_or_same) == 1:
        return blank_or_same[0]["row"]
    return None


def parse_floatish(value):
    value = clean(value)
    if value is None:
        return None
    try:
        return float(value)
    except ValueError:
        return value


def patient_group_from_alias(alias):
    text = clean(alias) or ""
    match = re.match(r"(\d+)", text)
    return match.group(1) if match else text


def read_cd_tab_records():
    wb = load_workbook(ALIQUOTS_COPY, data_only=True)
    records = []
    for sheet_name, diagnosis in CD_TABS:
        ws = wb[sheet_name]
        header = None
        sheet_records = []
        for row_num in range(1, ws.max_row + 1):
            values = [ws.cell(row_num, col).value for col in range(1, ws.max_column + 1)]
            labels = [(clean(value) or "").lower() for value in values]
            if "sample name (f)" in labels or "sample" in labels:
                header = {label: idx for idx, label in enumerate(labels) if label}
                continue
            if not header:
                continue
            sample_idx = header.get("sample name (f)", header.get("sample"))
            if sample_idx is None:
                continue
            sample = clean(values[sample_idx] if sample_idx < len(values) else None)
            if not sample:
                continue
            alias_idx = header.get("patient number", header.get("name"))
            date_idx = header.get("תאריך ביקור", header.get("date"))
            calpro_idx = header.get("calpro")
            location_idx = header.get("disease placement")
            aliquots_idx = header.get("aliquots")
            patient_code_idx = header.get("מספר מטופל")
            alias = clean(values[alias_idx] if alias_idx is not None and alias_idx < len(values) else None)
            patient_code = clean(values[patient_code_idx] if patient_code_idx is not None and patient_code_idx < len(values) else None)
            if not patient_code:
                patient_code = patient_group_from_alias(alias)
            sheet_records.append(
                {
                    "sheet": sheet_name,
                    "source_row": row_num,
                    "sample": sample,
                    "alias": alias,
                    "diagnosis": diagnosis,
                    "sample_date": date_cell(values[date_idx] if date_idx is not None and date_idx < len(values) else None),
                    "date": date_key(values[date_idx] if date_idx is not None and date_idx < len(values) else None),
                    "calprotectin": parse_floatish(values[calpro_idx] if calpro_idx is not None and calpro_idx < len(values) else None),
                    "location": clean(values[location_idx] if location_idx is not None and location_idx < len(values) else None),
                    "aliquots": parse_floatish(values[aliquots_idx] if aliquots_idx is not None and aliquots_idx < len(values) else None),
                    "patient_code": patient_code,
                }
            )
        grouped = defaultdict(list)
        for record in sheet_records:
            grouped[record["patient_code"]].append(record)
        for patient_code, patient_records in grouped.items():
            patient_records.sort(key=lambda item: (item["date"], item["source_row"]))
            for idx, record in enumerate(patient_records):
                record["longitudinal"] = 1 if idx == 0 and len(patient_records) > 1 else 2 if len(patient_records) > 1 else 0
                records.append(record)
    return records


def backup_longitudinal_values():
    if not RESTORE_BACKUP.exists():
        return {}
    wb = load_workbook(RESTORE_BACKUP, data_only=True)
    ws = wb["Final"]
    headers = header_map(ws)
    if "Longitudinal sample" not in headers:
        return {}
    lookup = {}
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        sample_date = date_key(ws.cell(row, headers["Sample date"]).value)
        value = ws.cell(row, headers["Longitudinal sample"]).value
        if value in (None, ""):
            continue
        for key in keys_for(primary, secondary):
            lookup[(key, sample_date)] = value
            lookup[(key, "")] = value
    return lookup


def add_longitudinal_column(ws):
    headers = header_map(ws)
    if "Longitudinal sample" in headers:
        return header_map(ws)
    insert_at = headers["Patient unique code"] if "Patient unique code" in headers else headers["PA447 measurement 1"]
    ws.insert_cols(insert_at)
    ws.cell(1, insert_at).value = "Longitudinal sample"
    return header_map(ws)


def fill_if_blank(cell, value):
    if value in (None, ""):
        return False
    if cell.value in (None, ""):
        cell.value = value
        return True
    return False


def set_if_different(cell, value):
    if value in (None, ""):
        return False
    if cell.value != value:
        cell.value = value
        return True
    return False


def append_row(ws, headers, record):
    row = ws.max_row + 1
    if row > 2:
        for col in range(1, ws.max_column + 1):
            src = ws.cell(row - 1, col)
            dst = ws.cell(row, col)
            if src.has_style:
                dst._style = copy(src._style)
            dst.number_format = src.number_format
            dst.alignment = copy(src.alignment)
            dst.border = copy(src.border)
    ws.cell(row, headers["Primary name"]).value = record["sample"]
    ws.cell(row, headers["Secondary / other name"]).value = record["alias"]
    ws.cell(row, headers["Measurement status"]).value = "0 aliquots" if record.get("aliquots") == 0 else "missing"
    ws.cell(row, headers["Diagnosis"]).value = record["diagnosis"]
    ws.cell(row, headers["Final classification / decision"]).value = "missing"
    ws.cell(row, headers["Calprotectin level"]).value = record["calprotectin"]
    ws.cell(row, headers["Disease location"]).value = record["location"]
    ws.cell(row, headers["Longitudinal sample"]).value = record["longitudinal"]
    ws.cell(row, headers["Patient unique code"]).value = record["patient_code"]
    ws.cell(row, headers["Sample date"]).value = record["sample_date"]
    ws.cell(row, headers["Measurement/source file"]).value = f"aliqauts 20260801.xlsx - {record['sheet']}"
    return row


def style_sheet(ws):
    headers = header_map(ws)
    importer.sort_records(ws, headers)
    headers = header_map(ws)
    for row in range(2, ws.max_row + 1):
        importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
        importer.style_final(ws.cell(row, headers["Final classification / decision"]), ws.cell(row, headers["Final classification / decision"]).value)
        importer.style_detector(ws.cell(row, headers["PA447 decision"]), ws.cell(row, headers["PA447 decision"]).value)
        importer.style_detector(ws.cell(row, headers["araE decision"]), ws.cell(row, headers["araE decision"]).value)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "Longitudinal sample": 16,
        "Patient unique code": 18,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    measurement_cols = set()
    for name, col in headers.items():
        if name and "measurement" in str(name).lower() and "source" not in str(name).lower():
            measurement_cols.add(col)
            widths[name] = 13.5
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_cols:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col in {headers["Longitudinal sample"], headers["Patient unique code"], headers["Calprotectin level"]}:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.zoomScale = 85


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before restoring deterioration samples {stamp}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    records = read_cd_tab_records()
    backup_values = backup_longitudinal_values()
    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = add_longitudinal_column(ws)

    restored = 0
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, headers["Longitudinal sample"]).value not in (None, ""):
            continue
        row_date = date_key(ws.cell(row, headers["Sample date"]).value)
        for key in keys_for(ws.cell(row, headers["Primary name"]).value, ws.cell(row, headers["Secondary / other name"]).value):
            value = backup_values.get((key, row_date), backup_values.get((key, "")))
            if value not in (None, ""):
                ws.cell(row, headers["Longitudinal sample"]).value = value
                restored += 1
                break

    by_key, by_key_date = build_final_index(ws, headers)
    updated = []
    appended = []
    for record in records:
        row = find_row(record, by_key, by_key_date)
        if row:
            changes = []
            if set_if_different(ws.cell(row, headers["Diagnosis"]), record["diagnosis"]):
                changes.append("Diagnosis")
            if fill_if_blank(ws.cell(row, headers["Secondary / other name"]), record["alias"]):
                changes.append("Secondary / other name")
            if fill_if_blank(ws.cell(row, headers["Calprotectin level"]), record["calprotectin"]):
                changes.append("Calprotectin level")
            if fill_if_blank(ws.cell(row, headers["Disease location"]), record["location"]):
                changes.append("Disease location")
            if fill_if_blank(ws.cell(row, headers["Longitudinal sample"]), record["longitudinal"]):
                changes.append("Longitudinal sample")
            if fill_if_blank(ws.cell(row, headers["Patient unique code"]), record["patient_code"]):
                changes.append("Patient unique code")
            if fill_if_blank(ws.cell(row, headers["Sample date"]), record["sample_date"]):
                changes.append("Sample date")
            if changes:
                updated.append({"row": row, "sample": record["sample"], "changes": changes})
        else:
            new_row = append_row(ws, headers, record)
            appended.append(
                {
                    "row": new_row,
                    "sample": record["sample"],
                    "alias": record["alias"],
                    "diagnosis": record["diagnosis"],
                    "date": record["date"],
                    "aliquots": record["aliquots"],
                    "sheet": record["sheet"],
                }
            )
            by_key, by_key_date = build_final_index(ws, headers)

    style_sheet(ws)
    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    wb_check = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    ws_check = wb_check["Final"]
    headers_check = [ws_check.cell(1, col).value for col in range(1, ws_check.max_column + 1)]
    report = {
        "final": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "cd_tab_records": len(records),
        "restored_longitudinal_existing_rows": restored,
        "updated_existing_cd_tab_rows": updated,
        "appended_cd_tab_rows": appended,
        "rows": ws_check.max_row - 1,
        "columns": ws_check.max_column,
        "headers": headers_check,
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2, default=str))


if __name__ == "__main__":
    main()
