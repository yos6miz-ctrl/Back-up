import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const folder = "C:/Users/Popovtzer lab/.codex/Excel file editor";
const files = {
  names: `${folder}/UN stool names.xlsx`,
  trial: `${folder}/Unknowns trial 6.26.xlsx`,
  merged: `${folder}/Merged Unknowns trial 6.26.xlsx`,
};

const confirmedMatches = new Map([
  ["UN FSL 672", "UN FLS 672"],
  ["UN EIM19262", "UN FIM19262"],
]);

async function chunkedValues(file, columnEnd, maxRow, chunkSize) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const rows = [];
  for (let start = 1; start <= maxRow; start += chunkSize) {
    const end = Math.min(maxRow, start + chunkSize - 1);
    const table = await workbook.inspect({
      kind: "table",
      range: `${sheet.name}!A${start}:${columnEnd}${end}`,
      include: "values,formulas",
      tableMaxRows: chunkSize,
      tableMaxCols: 26,
    });
    const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
    const matrix = JSON.parse(line).values ?? [];
    for (let i = 0; i < matrix.length; i++) {
      rows.push({ row: start + i, values: matrix[i] });
    }
  }
  return rows;
}

function clean(value) {
  return typeof value === "string" ? value.trim() : value;
}

function norm(value) {
  return String(value ?? "")
    .toUpperCase()
    .replace(/\([^)]*\)/g, "")
    .replace(/^UN\s*/, "")
    .replace(/[^A-Z0-9.]/g, "")
    .replace(/\./g, "");
}

function sameValue(a, b) {
  if ((a === null || a === undefined || a === "") && (b === null || b === undefined || b === "")) return true;
  if (typeof a === "number" || typeof b === "number") {
    return Math.abs(Number(a) - Number(b)) < 1e-10;
  }
  return String(a) === String(b);
}

function editDistance(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[a.length][b.length];
}

function score(a, b) {
  const x = norm(a);
  const y = norm(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.includes(y) || y.includes(x)) return Math.min(x.length, y.length) / Math.max(x.length, y.length);
  return 1 - editDistance(x, y) / Math.max(x.length, y.length);
}

const nameRows = (await chunkedValues(files.names, "B", 180, 30))
  .map(({ row, values }) => ({ row, realName: clean(values[0]), unknownName: clean(values[1]) }))
  .filter((entry) => entry.realName || entry.unknownName);

const trialRows = (await chunkedValues(files.trial, "I", 220, 30))
  .map(({ row, values }) => ({
    row,
    unknownName: clean(values[0]),
    values: [
      values[1] ?? null,
      values[2] ?? null,
      values[3] ?? null,
      values[4] ?? null,
      values[5] ?? null,
      values[6] ?? null,
      values[7] ?? null,
      values[8] ?? null,
    ],
  }))
  .filter((entry) => entry.row > 1 && entry.unknownName);

const mergedRows = (await chunkedValues(files.merged, "L", 180, 30))
  .map(({ row, values }) => ({
    row,
    realName: clean(values[0]),
    unknownName: clean(values[1]),
    values: [
      values[2] ?? null,
      values[3] ?? null,
      values[4] ?? null,
      values[5] ?? null,
      values[6] ?? null,
      values[7] ?? null,
      values[8] ?? null,
      values[9] ?? null,
    ],
    extraK: values[10] ?? null,
    extraL: values[11] ?? null,
  }))
  .filter((entry) => entry.row > 1 && (entry.realName || entry.unknownName));

const namesByUnknown = new Map(nameRows.map((entry) => [norm(entry.unknownName), entry]));
function bestNameMatch(trialUnknown) {
  const confirmedUnknown = confirmedMatches.get(trialUnknown);
  if (confirmedUnknown) return namesByUnknown.get(norm(confirmedUnknown)) ?? null;
  const candidates = nameRows
    .map((entry) => ({
      entry,
      matchScore: Math.max(score(trialUnknown, entry.unknownName), score(trialUnknown, entry.realName)),
    }))
    .sort((a, b) => b.matchScore - a.matchScore);
  return candidates[0]?.matchScore === 1 ? candidates[0].entry : null;
}
const mergedByUnknown = new Map();
const duplicateMergedUnknowns = [];
for (const entry of mergedRows) {
  const key = norm(entry.unknownName);
  if (mergedByUnknown.has(key)) duplicateMergedUnknowns.push({ unknownName: entry.unknownName, rows: [mergedByUnknown.get(key).row, entry.row] });
  else mergedByUnknown.set(key, entry);
}

const issues = [];
const usedNameKeys = new Set();
for (const trial of trialRows) {
  const merged = mergedByUnknown.get(norm(trial.unknownName));
  if (!merged) {
    issues.push({ type: "missing trial in merged", trialRow: trial.row, unknownName: trial.unknownName });
    continue;
  }
  for (let index = 0; index < trial.values.length; index++) {
    if (!sameValue(trial.values[index], merged.values[index])) {
      issues.push({
        type: "measurement mismatch",
        trialRow: trial.row,
        mergedRow: merged.row,
        unknownName: trial.unknownName,
        columnOffset: index,
        trialValue: trial.values[index],
        mergedValue: merged.values[index],
      });
    }
  }
  const nameEntry = bestNameMatch(trial.unknownName);
  if (nameEntry) usedNameKeys.add(norm(nameEntry.unknownName));
  if ((nameEntry?.realName ?? null) !== (merged.realName ?? null)) {
    issues.push({
      type: "real name mismatch",
      trialRow: trial.row,
      mergedRow: merged.row,
      unknownName: trial.unknownName,
      expectedRealName: nameEntry?.realName ?? null,
      mergedRealName: merged.realName ?? null,
    });
  }
}

function expectedFinal(first, second) {
  const values = [first, second]
    .filter((value) => value !== null && value !== undefined && String(value).trim() !== "")
    .map((value) => String(value).trim().toLowerCase());
  if (values.length === 0) return null;
  if (values.includes("pos")) return "IBD";
  if (values.length === 2 && values.every((value) => value === "neg")) return "IBS";
  if (values.includes("int")) return "Int";
  return null;
}

for (const merged of mergedRows) {
  const expected = expectedFinal(merged.values[3], merged.values[7]);
  if ((merged.extraK ?? null) !== expected) {
    issues.push({
      type: "final decision mismatch",
      mergedRow: merged.row,
      unknownName: merged.unknownName,
      pa447Decision: merged.values[3],
      araEDecision: merged.values[7],
      expectedFinal: expected,
      mergedFinal: merged.extraK ?? null,
    });
  }
}

const extraColumnValues = mergedRows
  .filter((entry) => entry.extraL !== null)
  .map((entry) => ({ row: entry.row, unknownName: entry.unknownName, L: entry.extraL }));

const nameOnlyRows = mergedRows.filter((entry) => entry.values.every((value) => value === null || value === ""));

console.log(JSON.stringify({
  counts: {
    names: nameRows.length,
    trial: trialRows.length,
    merged: mergedRows.length,
    nameOnlyRows: nameOnlyRows.length,
  },
  issues,
  duplicateMergedUnknowns,
  extraColumnValues,
  nameOnlyRows: nameOnlyRows.map((entry) => ({ row: entry.row, realName: entry.realName, unknownName: entry.unknownName })),
}, null, 2));
