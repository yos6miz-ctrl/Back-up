from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
REPORT_PATH = WORKSPACE / "old_vs_normalized_overlap_report.json"

spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def item_keys(item):
    return set(item.get("identifiers", set())) | set(item.get("strict_identifiers", set()))


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    queue = list(keys)
    while queue:
        key = queue.pop()
        for alias in aliases_by_key.get(key, set()):
            if alias not in expanded:
                expanded.add(alias)
                queue.append(alias)
    return expanded


def compatible_name(left, right, aliases_by_key):
    left_keys = expand_keys(item_keys(left), aliases_by_key)
    right_keys = expand_keys(item_keys(right), aliases_by_key)
    return bool(left_keys & right_keys)


def compatible_diagnosis(left, right):
    return builder.compatible(left.get("diagnosis"), right.get("diagnosis")) or left.get("diagnosis") is None or right.get("diagnosis") is None


def close_to_existing(value, normalized_values, tolerance=1e-5):
    for normalized_value in normalized_values:
        try:
            if math.isclose(float(value), float(normalized_value), rel_tol=tolerance, abs_tol=tolerance):
                return True
        except Exception:
            pass
    return False


def between_existing(value, normalized_values):
    numeric = []
    try:
        value = float(value)
    except Exception:
        return False
    for normalized_value in normalized_values:
        try:
            numeric.append(float(normalized_value))
        except Exception:
            pass
    if len(numeric) < 2:
        return False
    return min(numeric) <= value <= max(numeric)


def summarize(item, detector):
    return {
        "name": item.get("source_name") or item.get("sample_name"),
        "value": detector_value(item, detector),
        "diagnosis": item.get("diagnosis"),
        "source": item.get("source"),
        "source_file": item.get("source_file"),
        "source_rows": item.get("source_rows"),
        "source_date": item.get("source_date"),
        "removed_reason": item.get("pa447_removed_reason"),
        "old_metering_pa447": item.get("old_metering_pa447"),
    }


def main():
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    all_rows, _all_by_key = builder.load_all_measurements()
    old_rows = builder.load_old_rows()

    edited = [row for row in all_rows if row.get("source") == "edited normalized files"]
    summary = [row for row in all_rows if row.get("source") == "447 and araE ALL"]

    overlaps = []
    for old in old_rows:
        old_keys = expand_keys(item_keys(old), aliases_by_key)
        for detector in ("PA447", "araE"):
            old_value = detector_value(old, detector)
            if old_value is None:
                continue
            normalized_matches = [
                item
                for item in edited
                if detector_value(item, detector) is not None
                and compatible_diagnosis(old, item)
                and old_keys & expand_keys(item_keys(item), aliases_by_key)
            ]
            summary_matches = [
                item
                for item in summary
                if detector_value(item, detector) is not None
                and compatible_diagnosis(old, item)
                and old_keys & expand_keys(item_keys(item), aliases_by_key)
            ]
            if not normalized_matches and not summary_matches:
                continue
            normalized_values = [detector_value(item, detector) for item in normalized_matches]
            same_label_normalized = [
                item
                for item in normalized_matches
                if builder.norm(item.get("source_name")) == builder.norm(old.get("sample_name") or old.get("source_name"))
            ]
            status = "same_or_rounding_duplicate" if close_to_existing(old_value, normalized_values) else "between_normalized_values" if between_existing(old_value, normalized_values) else "conflict_or_summary_only"
            if normalized_matches and not same_label_normalized:
                status = "alias_overlap_not_same_visible_label"
            if not normalized_matches and summary_matches:
                status = "summary_only_no_good_file"
            overlaps.append(
                {
                    "old": summarize(old, detector),
                    "detector": detector,
                    "status": status,
                    "same_visible_label": bool(same_label_normalized),
                    "good_normalized_matches": [summarize(item, detector) for item in normalized_matches],
                    "summary_matches": [summarize(item, detector) for item in summary_matches[:5]],
                }
            )

    report = {
        "stats": {
            "old_rows": len(old_rows),
            "edited_normalized_records": len(edited),
            "summary_records": len(summary),
            "overlaps": len(overlaps),
            "overlap_status_counts": dict(defaultdict(int)),
        },
        "overlaps": overlaps,
    }
    counts = defaultdict(int)
    for item in overlaps:
        counts[item["status"]] += 1
    report["stats"]["overlap_status_counts"] = dict(counts)
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report["stats"], ensure_ascii=True, indent=2))
    print("REPORT", REPORT_PATH)


if __name__ == "__main__":
    main()
