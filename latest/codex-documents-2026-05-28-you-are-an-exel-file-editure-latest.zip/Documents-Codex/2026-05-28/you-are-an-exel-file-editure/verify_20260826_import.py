import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

import openpyxl

sys.path.insert(0, r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
import import_2026_measurements as imp


FINAL_CODEX = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
FINAL_ONEDRIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
FILES = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260826 UN 447.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026\20260826 UN araE.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats\20260826 447 sample repeats.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats\20260826 araE sample repeats.xlsx"),
]
WATCH = ["F-AA-25186", "F-IY-25190", "F-OE-25191", "CT-130", "CT1156"]


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def main():
    wb = openpyxl.load_workbook(FINAL_ONEDRIVE, read_only=True, data_only=True)
    ws = wb["Final"]
    headers = {cell.value: idx + 1 for idx, cell in enumerate(ws[1])}

    name_index = {}
    for row in range(2, ws.max_row + 1):
        for header in ("Primary name", "Secondary / other name"):
            value = ws.cell(row, headers[header]).value
            if value:
                name_index.setdefault(norm(value), set()).add(row)

    extracted = []
    for path in FILES:
        extracted.extend(imp.extract_normalized_records(path))

    watch_rows = {}
    for primary in WATCH:
        rows = sorted(name_index.get(norm(primary), []))
        watch_rows[primary] = []
        for row in rows:
            record = {}
            for header in (
                "Primary name",
                "Secondary / other name",
                "Measurement status",
                "Diagnosis",
                "Final classification / decision",
                "PA447 measurement 1",
                "PA447 measurement 2",
                "PA447 measurement 3",
                "PA447 decision",
                "araE measurement 1",
                "araE measurement 2",
                "araE measurement 3",
                "araE decision",
                "Sample date",
                "Measurement/source file",
            ):
                if header in headers:
                    record[header] = ws.cell(row, headers[header]).value
            watch_rows[primary].append({"row": row, "record": record})

    missing = []
    for rec in extracted:
        rows = set(name_index.get(norm(rec["sample_name"]), set()))
        if norm(rec["sample_name"].replace("-", "")) == "CT1156":
            rows |= name_index.get("CT1156", set())

        found = False
        for row in rows:
            cols = detector_cols(headers, rec["detector"])
            values = [ws.cell(row, col).value for col in cols]
            if any(isinstance(value, (int, float)) and abs(float(value) - float(rec["value"])) <= 5e-6 for value in values):
                found = True
                break
        if not found:
            missing.append({key: rec[key] for key in ("source_file", "sample_name", "detector", "value")})

    wb.close()

    health = {}
    for path in (FINAL_CODEX, FINAL_ONEDRIVE):
        with zipfile.ZipFile(path) as zf:
            health[str(path)] = {
                "bad_file": zf.testzip(),
                "tables": [name for name in zf.namelist() if name.startswith("xl/tables/")],
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest().upper(),
            }

    report = {
        "extracted_count": len(extracted),
        "missing_extracted_count": len(missing),
        "missing_extracted": missing,
        "watch_rows": watch_rows,
        "health": health,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
