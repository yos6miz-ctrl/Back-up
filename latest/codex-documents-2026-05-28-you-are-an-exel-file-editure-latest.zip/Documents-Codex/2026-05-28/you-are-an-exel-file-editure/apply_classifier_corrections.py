from pathlib import Path
import json
import os

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = Path(os.environ.get("FINAL_WORKBOOK_PATH", EXCEL_DIR / "Final Known and Unknown merged.xlsx"))
AUDIT_PATH = EXCEL_DIR / "classifier full file audit.json"


FINAL_STYLES = {
    "IBD": ("C00000", "FFFFFF"),
    "IBS": ("003399", "FFFFFF"),
    "inconclusive": ("D9D2E9", "4C3868"),
    "missing": ("E7E6E6", "666666"),
    "לא נבדק": ("D9D2E9", "4C3868"),
}


def base_final(value):
    if value is None:
        return ""
    return str(value).strip().rstrip("*").strip()


def style_final(cell, value):
    base = base_final(value)
    fill, font = FINAL_STYLES.get(base, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def main():
    audit = json.loads(AUDIT_PATH.read_text(encoding="utf-8"))
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)
    final_col = headers["Final classification / decision"]
    status_col = headers["Measurement status"]

    corrected = []
    old_marked = []
    for issue in audit["issues"]:
        row = int(issue["row"])
        status = str(ws.cell(row, status_col).value or "").strip()
        final_cell = ws.cell(row, final_col)

        if issue["comparison_type"] == "classifier":
            expected = issue["expected_final"]
            final_cell.value = expected
            final_cell.comment = None
            style_final(final_cell, expected)
            corrected.append((row, issue["sample"], issue["current_final"], expected))
            continue

        if issue["comparison_type"] == "status-exempt" and status in {"missing", "לא נבדק"}:
            expected = issue["expected_final"]
            final_cell.value = expected
            final_cell.comment = None
            style_final(final_cell, expected)
            corrected.append((row, issue["sample"], issue["current_final"], expected))
            continue

        if status == "old metering system":
            base = base_final(final_cell.value)
            if base:
                final_cell.value = f"{base}*"
                style_final(final_cell, base)
                final_cell.comment = Comment(
                    "Old metering system: keep the value, but interpret lightly; this is not a clean final decision.",
                    "Codex",
                )
                old_marked.append((row, issue["sample"], final_cell.value))

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "classifier_corrections": len(corrected),
            "old_metering_marked": len(old_marked),
            "classifier_examples": corrected[:20],
            "old_metering_examples": old_marked[:10],
        }
    )


if __name__ == "__main__":
    main()
