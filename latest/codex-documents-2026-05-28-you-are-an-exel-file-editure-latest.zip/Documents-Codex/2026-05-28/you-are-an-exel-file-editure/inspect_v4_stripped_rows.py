from pathlib import Path

from openpyxl import load_workbook


PATH = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\Final Known and Unknown merged - Ichilov v4 stripped temp.xlsx")
SAMPLES = [
    "F-DO-2665",
    "F-US-26120",
    "F-NSE-26138",
    "F-GS-26166",
    "F-NW-26181",
    "F-SG-2533",
    "F-ZS-2688",
    "F-BZ-2698",
    "F-ED-24107",
    "F-OK-25179",
]


def main():
    wb = load_workbook(PATH, data_only=True, read_only=True)
    ws = wb["Final"]
    header_count = ws.max_column
    for sample in SAMPLES:
        found = []
        for row_number, row_values in enumerate(ws.iter_rows(min_row=2, max_col=header_count, values_only=True), start=2):
            values = list(row_values)
            if sample in values:
                found.append((row_number, values))
        if found:
            print("\n" + sample)
            for row, values in found[:10]:
                print(row, values)


if __name__ == "__main__":
    main()
