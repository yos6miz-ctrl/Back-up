from __future__ import annotations

from collections import defaultdict
from copy import copy
from datetime import datetime
from pathlib import Path
import json
import math
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import build_accounted_known_unknown as builder
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
SOURCE_ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
OLD_SAMPLES = SOURCE_ROOT / "Old sampels"
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "merge_ichilov_v4_shipments_to_final_and_archive_report.json"

SOURCE_FILES = [
    SOURCE_ROOT / "merged - Ichilov v4.xlsx",
    SOURCE_ROOT / "Shipment Bar Ilan 7.26 - Blinded.xlsx",
    SOURCE_ROOT / "Shipment Bar Ilan 7.26 Blinded.xlsx",
]
LOCAL_V4 = WORKSPACE / "merged - Ichilov v4 source copy.xlsx"
LOCAL_SHIP_DIAG = WORKSPACE / "Shipment Bar Ilan 7.26 - Blinded source copy.xlsx"
LOCAL_SHIP_FULL = WORKSPACE / "Shipment Bar Ilan 7.26 Blinded source copy.xlsx"

NEW_COLUMNS = [
    "Longitudinal sample",
    "Patient unique code",
    "Diagnosis match",
    "Bar Ilan v4 final classification",
    "Shipment patient number (Study)",
    "Shipment patient number (Project)",
    "Study number",
    "Shipment box",
    "Shipment aliquots",
]


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def canon_header(value):
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def norm(value):
    return builder.norm(value)


def conservative_keys(*values):
    keys = set()
    for value in values:
        text = clean(value)
        key = norm(text)
        if not key:
            continue
        # Avoid matching samples just by patient number. It caused false joins
        # between F-coded samples and CT-coded UC/Healthy rows in earlier audits.
        if not re.search(r"[A-Z]", key):
            continue
        keys.add(key)
        for strict in builder.strict_identifier_variants(text):
            if re.search(r"[A-Z]", strict):
                keys.add(strict)
    return keys


def is_pnumber_name(value):
    text = clean(value) or ""
    return bool(re.fullmatch(r"(IBS\s*)?P\d+", text, flags=re.I))


def date_key(value):
    if value in (None, ""):
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    text = clean(value) or ""
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%d.%m.%y", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return text[:10]


def date_cell(value):
    if value in (None, ""):
        return None
    if hasattr(value, "date"):
        return value
    key = date_key(value)
    try:
        return datetime.strptime(key, "%Y-%m-%d")
    except ValueError:
        return value


def numeric_or_blank(value):
    if value in (None, ""):
        return None
    if isinstance(value, str) and value.strip().upper() in {"N/A", "NA"}:
        return value.strip()
    return value


def canon_diag(value):
    diag = builder.canonical_group(value)
    return diag or clean(value)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_detector_headers(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def v4_headers(ws):
    mapped = {}
    for col in range(1, ws.max_column + 1):
        h = canon_header(ws.cell(1, col).value)
        if h == "primary name":
            mapped["primary"] = col
        elif h.startswith("secondary"):
            mapped["secondary"] = col
        elif "patient unique code" in h:
            mapped["patient_unique_code"] = col
        elif h.startswith("longitudinal sample"):
            mapped["longitudinal"] = col
        elif "measurement status" in h:
            mapped["status"] = col
        elif "ichilov" in h and "diagnosis" in h:
            mapped["diagnosis"] = col
        elif "final classification" in h:
            mapped["v4_final"] = col
        elif "calprotectin" in h:
            mapped["calprotectin"] = col
        elif h == "disease location":
            mapped["location"] = col
        elif "diagnosis match" in h:
            mapped["diagnosis_match"] = col
        elif h == "sample date":
            mapped["date"] = col
        elif "pa447 measurement" in h:
            match = re.search(r"(\d+)$", h)
            if match:
                mapped[f"pa447_{match.group(1)}"] = col
        elif "pa447" in h and "decision" in h:
            mapped["pa447_decision"] = col
        elif "arae measurement" in h:
            match = re.search(r"(\d+)$", h)
            if match:
                mapped[f"arae_{match.group(1)}"] = col
        elif "arae" in h and "decision" in h:
            mapped["arae_decision"] = col
        elif h == "measurement/source file":
            mapped["source_file"] = col
    return mapped


def make_record(source, primary, secondary=None, sample_date=None, **fields):
    primary = clean(primary)
    secondary = clean(secondary)
    if not primary and not secondary:
        return None
    if is_pnumber_name(primary) or is_pnumber_name(secondary):
        return None
    keys = conservative_keys(primary, secondary)
    if not keys:
        return None
    return {
        "source": source,
        "primary": primary or secondary,
        "secondary": secondary if primary and secondary and norm(primary) != norm(secondary) else None,
        "date": date_key(sample_date),
        "sample_date": date_cell(sample_date),
        "keys": keys,
        **fields,
    }


def load_v4_records():
    wb = load_workbook(LOCAL_V4, data_only=True, keep_links=False)
    ws = wb["Final"]
    headers = v4_headers(ws)
    records = []
    for row, values in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        def val(field):
            col = headers.get(field)
            return values[col - 1] if col else None

        pa = [val(f"pa447_{idx}") for idx in range(1, 4) if f"pa447_{idx}" in headers]
        ara = [val(f"arae_{idx}") for idx in range(1, 4) if f"arae_{idx}" in headers]
        record = make_record(
            "merged - Ichilov v4.xlsx",
            val("primary"),
            val("secondary"),
            val("date"),
            v4_row=row,
            status=clean(val("status")),
            diagnosis=canon_diag(val("diagnosis")),
            v4_final=clean(val("v4_final")),
            calprotectin=numeric_or_blank(val("calprotectin")),
            location=clean(val("location")),
            diagnosis_match=val("diagnosis_match"),
            longitudinal=val("longitudinal"),
            patient_unique_code=val("patient_unique_code"),
            pa447_values=pa,
            pa447_decision=clean(val("pa447_decision")),
            arae_values=ara,
            arae_decision=clean(val("arae_decision")),
            measurement_source=clean(val("source_file")),
        )
        if record:
            records.append(record)
    return records


def load_shipment_diag_records():
    wb = load_workbook(LOCAL_SHIP_DIAG, data_only=True, keep_links=False)
    ws = wb.active
    records = []
    for row, values in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        record = make_record(
            "Shipment Bar Ilan 7.26 - Blinded.xlsx",
            values[1] if len(values) > 1 else None,
            sample_date=values[0] if len(values) > 0 else None,
            shipment_diag_row=row,
            diagnosis=canon_diag(values[2] if len(values) > 2 else None),
        )
        if record:
            records.append(record)
    return records


def load_shipment_full_records():
    wb = load_workbook(LOCAL_SHIP_FULL, data_only=True, keep_links=False)
    ws = wb.active
    records = []
    for row, values in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        record = make_record(
            "Shipment Bar Ilan 7.26 Blinded.xlsx",
            values[4] if len(values) > 4 else None,
            sample_date=values[3] if len(values) > 3 else None,
            shipment_full_row=row,
            patient_number_study=values[0] if len(values) > 0 else None,
            patient_number_project=values[1] if len(values) > 1 else None,
            study_number=values[2] if len(values) > 2 else None,
            shipment_box=values[5] if len(values) > 5 else None,
            shipment_aliquots=values[6] if len(values) > 6 else None,
        )
        if record:
            records.append(record)
    return records


def merge_source_records(records):
    by_key = {}
    for record in records:
        key = (record["primary"], record.get("secondary"), record["date"])
        target = by_key.setdefault(key, {**record, "sources": []})
        target["sources"].append(record["source"])
        target["keys"].update(record["keys"])
        for field, value in record.items():
            if field in {"keys", "sources"} or value in (None, ""):
                continue
            if field not in target or target.get(field) in (None, ""):
                target[field] = value
            elif field == "diagnosis":
                target[field] = value
    return list(by_key.values())


def build_final_indexes(ws, headers):
    by_key_date = defaultdict(list)
    by_key = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        row_date = date_key(ws.cell(row, headers["Sample date"]).value)
        keys = conservative_keys(primary, secondary)
        item = {"row": row, "primary": primary, "secondary": secondary, "date": row_date, "keys": keys}
        for key in keys:
            by_key[key].append(item)
            if row_date:
                by_key_date[(key, row_date)].append(item)
    return by_key, by_key_date


def unique_matches(matches):
    out = {}
    for item in matches:
        out[item["row"]] = item
    return list(out.values())


def find_final_match(record, by_key, by_key_date):
    if record["date"]:
        matches = []
        for key in record["keys"]:
            matches.extend(by_key_date.get((key, record["date"]), []))
        matches = unique_matches(matches)
        if len(matches) == 1:
            return matches[0]["row"], "name+date"
        if len(matches) > 1:
            exact_primary = [item for item in matches if norm(item["primary"]) == norm(record["primary"])]
            if len(exact_primary) == 1:
                return exact_primary[0]["row"], "exact primary+date"
            return None, "multiple name+date matches", matches

    matches = []
    for key in record["keys"]:
        matches.extend(by_key.get(key, []))
    matches = unique_matches(matches)
    if record["date"]:
        blank_or_same = [item for item in matches if not item["date"] or item["date"] == record["date"]]
        if len(blank_or_same) == 1:
            return blank_or_same[0]["row"], "name+blank date"
        if len(blank_or_same) > 1:
            return None, "multiple name matches with blank/same date", blank_or_same
        return None, "append different date", []
    if len(matches) == 1:
        return matches[0]["row"], "unique name"
    if len(matches) > 1:
        return None, "multiple name matches", matches
    return None, "no match", []


def has_measurement(record):
    for value in record.get("pa447_values", []) + record.get("arae_values", []):
        if isinstance(value, (int, float)) and math.isfinite(float(value)):
            return True
    return False


def append_allowed(record):
    if str(record.get("status") or "").strip().lower() == "missing":
        return False
    if str(record.get("v4_final") or "").strip().lower() == "missing":
        return False
    return has_measurement(record) or clean(record.get("v4_final")) not in (None, "missing")


def ensure_columns(ws):
    headers = header_map(ws)
    insert_at = headers["PA447 measurement 1"]
    for name in NEW_COLUMNS:
        if name not in headers:
            ws.insert_cols(insert_at)
            ws.cell(1, insert_at).value = name
            insert_at += 1
            headers = header_map(ws)
    return header_map(ws)


def fill_if_present(ws, row, headers, header, value, changes, overwrite=True):
    if value in (None, ""):
        return
    cell = ws.cell(row, headers[header])
    if not overwrite and cell.value not in (None, ""):
        return
    if cell.value != value:
        old = cell.value
        cell.value = value
        changes[header] = {"old": old, "new": value}


def apply_record_to_row(ws, row, headers, record, append_mode=False):
    changes = {}
    fill_if_present(ws, row, headers, "Secondary / other name", record.get("secondary"), changes, overwrite=False)
    fill_if_present(ws, row, headers, "Diagnosis", record.get("diagnosis"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Calprotectin level", record.get("calprotectin"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Disease location", record.get("location"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Sample date", record.get("sample_date"), changes, overwrite=False)
    fill_if_present(ws, row, headers, "Longitudinal sample", record.get("longitudinal"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Patient unique code", record.get("patient_unique_code"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Diagnosis match", record.get("diagnosis_match"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Bar Ilan v4 final classification", record.get("v4_final"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Shipment patient number (Study)", record.get("patient_number_study"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Shipment patient number (Project)", record.get("patient_number_project"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Study number", record.get("study_number"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Shipment box", record.get("shipment_box"), changes, overwrite=True)
    fill_if_present(ws, row, headers, "Shipment aliquots", record.get("shipment_aliquots"), changes, overwrite=True)

    if append_mode:
        ws.cell(row, headers["Primary name"]).value = record["primary"]
        if record.get("secondary"):
            ws.cell(row, headers["Secondary / other name"]).value = record["secondary"]
        status = record.get("status") or ("measured" if has_measurement(record) else "missing")
        ws.cell(row, headers["Measurement status"]).value = status
        if record.get("v4_final"):
            ws.cell(row, headers["Final classification / decision"]).value = record["v4_final"]
        for detector, field_prefix, decision_field in [
            ("PA447", "pa447_values", "pa447_decision"),
            ("araE", "arae_values", "arae_decision"),
        ]:
            cols = find_detector_headers(headers, detector)
            for idx, value in enumerate(record.get(field_prefix, [])):
                if idx < len(cols) and isinstance(value, (int, float)) and math.isfinite(float(value)):
                    ws.cell(row, cols[idx]).value = float(value)
            if record.get(decision_field):
                ws.cell(row, headers[f"{detector} decision"]).value = record[decision_field]
        ws.cell(row, headers["Measurement/source file"]).value = record.get("measurement_source") or "merged - Ichilov v4.xlsx"
    return changes


def style_workbook(ws, headers):
    for row in range(2, ws.max_row + 1):
        importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
        importer.style_final(ws.cell(row, headers["Final classification / decision"]), ws.cell(row, headers["Final classification / decision"]).value)
        importer.style_detector(ws.cell(row, headers["PA447 decision"]), ws.cell(row, headers["PA447 decision"]).value)
        importer.style_detector(ws.cell(row, headers["araE decision"]), ws.cell(row, headers["araE decision"]).value)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "Longitudinal sample": 16,
        "Patient unique code": 18,
        "Diagnosis match": 14,
        "Bar Ilan v4 final classification": 18,
        "Shipment patient number (Study)": 18,
        "Shipment patient number (Project)": 18,
        "Study number": 14,
        "Shipment box": 12,
        "Shipment aliquots": 14,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    for name in find_detector_headers(headers, "PA447") + find_detector_headers(headers, "araE"):
        widths[name] = 13.5
    for name, col in headers.items():
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    measurement_cols = set(find_detector_headers(headers, "PA447") + find_detector_headers(headers, "araE"))
    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_cols:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col in {headers["Calprotectin level"], headers["Shipment aliquots"], headers["Longitudinal sample"], headers["Patient unique code"], headers["Diagnosis match"]}:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.zoomScale = 85


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def safe_remove_parts(path):
    try:
        importer.remove_comment_and_table_parts(path)
        return None
    except PermissionError as exc:
        return str(exc)


def archive_sources():
    OLD_SAMPLES.mkdir(parents=True, exist_ok=True)
    moved = []
    for source in SOURCE_FILES:
        if not source.exists():
            moved.append({"source": str(source), "status": "not found"})
            continue
        if source.parent.resolve() != SOURCE_ROOT.resolve():
            moved.append({"source": str(source), "status": "skipped: outside expected source root"})
            continue
        dest = OLD_SAMPLES / source.name
        if dest.exists():
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            dest = OLD_SAMPLES / f"{source.stem} moved {stamp}{source.suffix}"
        shutil.move(str(source), str(dest))
        moved.append({"source": str(source), "destination": str(dest), "status": "moved"})
    return moved


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before Ichilov v4 shipment merge {stamp}.xlsx"
    shutil.copy2(FINAL, backup)

    source_records = merge_source_records(load_v4_records() + load_shipment_diag_records() + load_shipment_full_records())

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = ensure_columns(ws)
    by_key, by_key_date = build_final_indexes(ws, headers)

    updated = []
    appended = []
    skipped_append = []
    ambiguous = []
    for record in source_records:
        match = find_final_match(record, by_key, by_key_date)
        if len(match) == 2:
            row, basis = match
            matches = []
        else:
            row, basis, matches = match
        if row:
            changes = apply_record_to_row(ws, row, headers, record, append_mode=False)
            if changes:
                updated.append({"row": row, "primary": record["primary"], "date": record["date"], "basis": basis, "changes": changes})
            continue
        if basis.startswith("multiple"):
            ambiguous.append({"primary": record["primary"], "secondary": record.get("secondary"), "date": record["date"], "reason": basis, "matches": matches})
            continue
        if not append_allowed(record):
            skipped_append.append({"primary": record["primary"], "secondary": record.get("secondary"), "date": record["date"], "reason": "missing/P-number/no usable measurement row"})
            continue

        new_row = ws.max_row + 1
        if new_row > 2:
            for col in range(1, ws.max_column + 1):
                src = ws.cell(new_row - 1, col)
                dst = ws.cell(new_row, col)
                if src.has_style:
                    dst._style = copy(src._style)
                dst.number_format = src.number_format
                dst.alignment = copy(src.alignment)
                dst.border = copy(src.border)
        apply_record_to_row(ws, new_row, headers, record, append_mode=True)
        appended.append({"row": new_row, "primary": record["primary"], "secondary": record.get("secondary"), "date": record["date"], "sources": sorted(set(record.get("sources", [])))})
        by_key, by_key_date = build_final_indexes(ws, headers)

    importer.sort_records(ws, headers)
    headers = header_map(ws)
    style_workbook(ws, headers)
    wb.save(FINAL)
    cleanup_error = safe_remove_parts(FINAL)

    copy_error = None
    try:
        ONEDRIVE_FINAL.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(FINAL, ONEDRIVE_FINAL)
    except PermissionError as exc:
        copy_error = str(exc)

    moved_sources = []
    if copy_error is None:
        moved_sources = archive_sources()

    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "backup": str(backup),
        "source_records": len(source_records),
        "updated_rows_count": len(updated),
        "appended_rows_count": len(appended),
        "skipped_append_count": len(skipped_append),
        "ambiguous_count": len(ambiguous),
        "updated_rows": updated,
        "appended_rows": appended,
        "skipped_append": skipped_append,
        "ambiguous": ambiguous,
        "cleanup_error": cleanup_error,
        "copy_error": copy_error,
        "moved_sources": moved_sources,
        "zip_health": zip_health(FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2, default=str))


if __name__ == "__main__":
    main()
