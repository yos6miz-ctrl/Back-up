from __future__ import annotations

from collections import Counter, defaultdict
from copy import copy
from datetime import datetime
from pathlib import Path
import json
import math
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

import build_accounted_known_unknown as builder
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
HISTORIC_REPORT = WORKSPACE / "known_measurement_coverage_full.json"
REPORT = WORKSPACE / "expand_measurement_columns_and_show_all_report.json"

SOFT_YELLOW = importer.SOFT_YELLOW
NEEDS_REPEAT_ORANGE = "FCE4D6"
HEADER_FILL = importer.HEADER_FILL


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def numeric_equal(left, right, tolerance=1e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def detector_measurement_headers(headers, detector):
    result = []
    index = 1
    while f"{detector} measurement {index}" in headers:
        result.append(f"{detector} measurement {index}")
        index += 1
    return result


def detector_cols(headers, detector):
    return [headers[name] for name in detector_measurement_headers(headers, detector)]


def copy_column_style(ws, source_col, target_col):
    source_letter = get_column_letter(source_col)
    target_letter = get_column_letter(target_col)
    ws.column_dimensions[target_letter].width = ws.column_dimensions[source_letter].width or 12
    source_header = ws.cell(1, source_col)
    target_header = ws.cell(1, target_col)
    if source_header.has_style:
        target_header._style = copy(source_header._style)
    target_header.number_format = source_header.number_format
    target_header.alignment = copy(source_header.alignment)
    target_header.border = copy(source_header.border)


def ensure_detector_columns(ws, detector, target_count):
    headers = header_map(ws)
    current = len(detector_measurement_headers(headers, detector))
    while current < target_count:
        headers = header_map(ws)
        insert_at = headers[f"{detector} decision"]
        source_col = headers[f"{detector} measurement {current}"]
        ws.insert_cols(insert_at)
        copy_column_style(ws, source_col, insert_at)
        ws.cell(1, insert_at).value = f"{detector} measurement {current + 1}"
        ws.cell(1, insert_at).fill = PatternFill(fill_type="solid", fgColor=HEADER_FILL)
        ws.cell(1, insert_at).font = Font(name="Calibri", size=11, bold=True, color="000000")
        current += 1


def safe_norms(*values):
    return {builder.norm(value) for value in values if builder.norm(value)}


def report_row_key(row):
    return safe_norms(row.get("primary"), row.get("secondary"))


def workbook_row_key(ws, headers, row):
    return safe_norms(
        ws.cell(row, headers["Primary name"]).value,
        ws.cell(row, headers["Secondary / other name"]).value,
    )


def item_value(item, detector):
    return item.get("value") if "value" in item else item.get("pa447" if detector == "PA447" else "araE")


def item_source_name(item):
    return clean(item.get("source_name") or item.get("sample_name"))


def dy_guard_allows(row_names, item):
    item_name = builder.norm(item_source_name(item))
    row_has_fdy23247 = any(name in {"FDY23247", "DY23247"} for name in row_names)
    row_has_dy247 = "DY247" in row_names
    item_is_fdy23247 = item_name in {"FDY23247", "DY23247"} or "FDY23247" in item_name
    item_is_dy247 = item_name == "DY247"
    if row_has_dy247 and item_is_fdy23247:
        return False
    if row_has_fdy23247 and item_is_dy247:
        return False
    return True


def source_sort_key(item):
    source = item.get("source") or ""
    rank = {
        "edited normalized files": 0,
        "447 and araE 2026": 1,
        "447 and araE ALL": 2,
        "IBD IBS OLD": 3,
    }.get(source, 4)
    return (
        rank,
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item_source_name(item) or ""),
        str(item.get("source_rows") or ""),
    )


def load_historic_available_indexes():
    if not HISTORIC_REPORT.exists():
        return {"by_key": {}, "by_name": {}}
    data = json.loads(HISTORIC_REPORT.read_text(encoding="utf-8"))
    by_key = defaultdict(lambda: {"PA447": [], "araE": []})
    by_name = defaultdict(lambda: {"PA447": [], "araE": []})
    for row in data.get("rows", []):
        key = tuple(sorted(report_row_key(row)))
        if not key:
            continue
        for detector in ("PA447", "araE"):
            for item in row.get("available", {}).get(detector, []):
                value = item_value(item, detector)
                if is_numeric(value):
                    by_key[key][detector].append(item)
                    for name in key:
                        by_name[name][detector].append(item)
    return {"by_key": by_key, "by_name": by_name}


def match_historic_items(row_names, historic_indexes, detector):
    direct = historic_indexes["by_key"].get(tuple(sorted(row_names)), {}).get(detector, [])
    if direct:
        return direct
    matches = []
    for name in row_names:
        matches.extend(historic_indexes["by_name"].get(name, {}).get(detector, []))
    return matches


def existing_entries(ws, headers, row, detector):
    entries = []
    for col in detector_cols(headers, detector):
        value = ws.cell(row, col).value
        if is_numeric(value):
            entries.append(
                {
                    "value": float(value),
                    "source": "currently displayed",
                    "source_file": None,
                    "source_name": ws.cell(row, headers["Primary name"]).value,
                    "source_date": None,
                    "source_rows": None,
                }
            )
    return entries


def dedupe_entries(entries):
    unique = []
    seen = set()
    seen_summary_values = set()
    for item in entries:
        value = item_value(item, "PA447") if "value" not in item else item["value"]
        value_key = round(float(value), 10)
        source_name = builder.norm(item_source_name(item))
        source_file = clean(item.get("source_file"))
        source_rows = tuple(item.get("source_rows") or [])
        if not source_file:
            summary_key = (source_name, value_key)
            if summary_key in seen_summary_values:
                continue
            seen_summary_values.add(summary_key)
        if source_file or source_rows:
            key = (source_file, source_rows, source_name, value_key)
        else:
            key = (source_name, value_key)
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


def call_family(call):
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    return "inconclusive"


def detector_decision_text(call):
    if call == "IBD-like":
        return "Pos"
    if call == "IBS-like":
        return "Neg"
    if call == "inconclusive":
        return "Int"
    return None


def detector_consensus_with_used(values, bar):
    entries = []
    for idx, value in enumerate(values):
        if not is_numeric(value):
            continue
        call, margin = importer.classifier.detector_call(float(value), bar)
        entries.append({"idx": idx, "value": float(value), "call": call, "family": call_family(call), "margin": margin})

    if not entries:
        return {"call": None, "decision": None, "used_indices": [], "problem_indices": []}
    if len(entries) == 1:
        return {
            "call": "inconclusive",
            "decision": "Int",
            "used_indices": [],
            "problem_indices": [],
            "needs_repeat_indices": [entries[0]["idx"]],
        }

    conclusive_counts = Counter(entry["family"] for entry in entries if entry["family"] in {"IBD", "IBS"})
    ibd_count = conclusive_counts.get("IBD", 0)
    ibs_count = conclusive_counts.get("IBS", 0)

    if ibd_count == ibs_count and ibd_count > 0:
        closest_pair = None
        if len(entries) >= 3:
            for left_pos, left in enumerate(entries):
                for right in entries[left_pos + 1 :]:
                    conclusive_families = {
                        entry["family"]
                        for entry in (left, right)
                        if entry["family"] in {"IBD", "IBS"}
                    }
                    if len(conclusive_families) > 1:
                        continue
                    pair_average = (left["value"] + right["value"]) / 2
                    pair_call, _pair_margin = importer.classifier.detector_call(pair_average, bar)
                    distance = abs(left["value"] - right["value"])
                    if closest_pair is None or distance < closest_pair["distance"]:
                        closest_pair = {
                            "distance": distance,
                            "call": pair_call,
                            "used": [left["idx"], right["idx"]],
                        }
        if closest_pair is not None:
            used = set(closest_pair["used"])
            return {
                "call": closest_pair["call"],
                "decision": detector_decision_text(closest_pair["call"]),
                "used_indices": closest_pair["used"],
                "problem_indices": [entry["idx"] for entry in entries if entry["idx"] not in used],
            }
        problem = [entry["idx"] for entry in entries if entry["family"] in {"IBD", "IBS"}]
        return {"call": "inconclusive", "decision": "Int", "used_indices": [], "problem_indices": problem}

    if ibd_count or ibs_count:
        majority_family = "IBD" if ibd_count > ibs_count else "IBS"
        used_entries = [entry for entry in entries if entry["family"] == majority_family]
        problem_entries = [entry for entry in entries if entry["family"] in {"IBD", "IBS"} and entry["family"] != majority_family]
    else:
        used_entries = entries
        problem_entries = entries

    used_value = sum(entry["value"] for entry in used_entries) / len(used_entries)
    call, _margin = importer.classifier.detector_call(used_value, bar)
    return {
        "call": call,
        "decision": detector_decision_text(call),
        "used_indices": [entry["idx"] for entry in used_entries],
        "problem_indices": [entry["idx"] for entry in problem_entries],
        "needs_repeat_indices": [],
    }


def style_measurement_cells(ws, headers, row, detector, result):
    cols = detector_cols(headers, detector)
    used = set(result.get("used_indices", []))
    problems = set(result.get("problem_indices", []))
    needs_repeat = set(result.get("needs_repeat_indices", []))
    for idx, col in enumerate(cols):
        cell = ws.cell(row, col)
        if not is_numeric(cell.value):
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.font = Font(name="Calibri", size=11, color="000000", bold=False)
            continue
        cell.number_format = "0.000000000"
        cell.font = Font(name="Calibri", size=11, color="000000", bold=idx in used)
        if idx in needs_repeat:
            cell.fill = PatternFill(fill_type="solid", fgColor=NEEDS_REPEAT_ORANGE)
        elif idx in problems:
            cell.fill = PatternFill(fill_type="solid", fgColor=SOFT_YELLOW)
        else:
            cell.fill = PatternFill(fill_type=None)


def reclassify_row_majority(ws, headers, row, bars):
    status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
    final_col = headers["Final classification / decision"]
    if status in {"missing", "לא נבדק"}:
        ws.cell(row, final_col).value = status
        importer.style_final(ws.cell(row, final_col), status)
        return status
    if status == "old metering system":
        return ws.cell(row, final_col).value

    calls = []
    for detector in ("PA447", "araE"):
        cols = detector_cols(headers, detector)
        values = [ws.cell(row, col).value if is_numeric(ws.cell(row, col).value) else None for col in cols]
        result = detector_consensus_with_used(values, bars[detector]["bar"])
        ws.cell(row, headers[f"{detector} decision"]).value = result["decision"]
        importer.style_detector(ws.cell(row, headers[f"{detector} decision"]), result["decision"])
        style_measurement_cells(ws, headers, row, detector, result)
        if result["call"]:
            calls.append(result["call"])

    final_value = importer.classifier.final_classification(calls) if calls else "missing"
    ws.cell(row, final_col).value = final_value
    importer.style_final(ws.cell(row, final_col), final_value)
    return final_value


def source_label(item):
    if item.get("source_file"):
        return str(item["source_file"]).replace("/", "\\").split("\\")[-1]
    return clean(item.get("source")) or None


def write_sources(ws, headers, row, entries_by_detector):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for item in entries_by_detector[detector]:
            label = source_label(item)
            if label and label not in labels and label != "currently displayed":
                labels.append(label)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    if segments:
        ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments)


def workbook_zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    print("loading historic repeat report", flush=True)
    historic_by_key = load_historic_available_indexes()

    target_counts = {"PA447": 8, "araE": 6}
    rows_with_more_than_three = []

    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before expanded repeat columns {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(FINAL, backup)

    print("loading classifier", flush=True)
    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    print("opening writable workbook", flush=True)
    wb = load_workbook(FINAL)
    ws = wb["Final"]
    print(f"ensuring columns PA447={target_counts['PA447']} araE={target_counts['araE']}", flush=True)
    ensure_detector_columns(ws, "PA447", target_counts["PA447"])
    ensure_detector_columns(ws, "araE", target_counts["araE"])
    headers = header_map(ws)

    added_values = []
    compacted_gaps = []
    overflow = []
    reclassified = []

    print("updating rows", flush=True)
    for row in range(2, ws.max_row + 1):
        if row % 50 == 0:
            print(f"  row {row}/{ws.max_row}", flush=True)
        row_names = workbook_row_key(ws, headers, row)
        if not row_names:
            continue
        entries_by_detector = {"PA447": [], "araE": []}
        for detector in ("PA447", "araE"):
            current_entries = existing_entries(ws, headers, row, detector)
            source_entries = []
            for item in match_historic_items(row_names, historic_by_key, detector):
                if not dy_guard_allows(row_names, item):
                    continue
                value = item_value(item, detector)
                if not is_numeric(value):
                    continue
                if any(numeric_equal(value, existing["value"]) for existing in current_entries):
                    continue
                normalized_item = dict(item)
                normalized_item["value"] = float(value)
                source_entries.append(normalized_item)
            combined = dedupe_entries(current_entries + sorted(source_entries, key=source_sort_key))
            entries_by_detector[detector] = combined

            cols = detector_cols(headers, detector)
            old_values = [ws.cell(row, col).value for col in cols]
            new_values = [entry["value"] for entry in combined]
            if len(new_values) > len(cols):
                overflow.append(
                    {
                        "row": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "detector": detector,
                        "needed": len(new_values),
                        "available_columns": len(cols),
                    }
                )
                new_values = new_values[: len(cols)]

            if [value for value in old_values if is_numeric(value)] != new_values[: len([value for value in old_values if is_numeric(value)])]:
                pass

            seen_blank = False
            had_gap = False
            for value in old_values:
                if value in (None, ""):
                    seen_blank = True
                elif seen_blank:
                    had_gap = True
            if had_gap:
                compacted_gaps.append(
                    {
                        "row": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "detector": detector,
                        "old_slots": old_values,
                    }
                )

            old_numeric_count = sum(is_numeric(value) for value in old_values)
            if len(new_values) > old_numeric_count:
                added_values.append(
                    {
                        "row": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                        "detector": detector,
                        "old_numeric_count": old_numeric_count,
                        "new_numeric_count": len(new_values),
                    }
                )
            if len(new_values) > 3:
                rows_with_more_than_three.append(
                    {
                        "row_before_sort": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                        "detector": detector,
                        "displayed_count_after_edit": len(new_values),
                    }
                )

            for idx, col in enumerate(cols):
                ws.cell(row, col).value = new_values[idx] if idx < len(new_values) else None

        before_final = ws.cell(row, headers["Final classification / decision"]).value
        after_final = reclassify_row_majority(ws, headers, row, bars)
        if before_final != after_final:
            reclassified.append(
                {
                    "row": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                    "old_final": before_final,
                    "new_final": after_final,
                }
            )
        write_sources(ws, headers, row, entries_by_detector)

    for cell in ws[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor=HEADER_FILL)
        cell.font = Font(name="Calibri", size=11, bold=True, color="000000")

    print("sorting records", flush=True)
    importer.sort_records(ws, headers)
    headers = header_map(ws)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    print("saving workbook", flush=True)
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)

    print("copying to OneDrive", flush=True)
    copied_to_onedrive = False
    copy_error = None
    try:
        shutil.copy2(FINAL, ONEDRIVE_FINAL)
        copied_to_onedrive = True
    except PermissionError as exc:
        copy_error = str(exc)

    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "copied_to_onedrive": copied_to_onedrive,
        "copy_error": copy_error,
        "backup": str(backup),
        "target_counts": target_counts,
        "rows_with_more_than_three_before_edit": rows_with_more_than_three,
        "rows_with_more_than_three_count": len(rows_with_more_than_three),
        "added_values": added_values,
        "added_values_count": len(added_values),
        "compacted_gaps": compacted_gaps,
        "compacted_gaps_count": len(compacted_gaps),
        "overflow": overflow,
        "reclassified": reclassified,
        "zip_health": workbook_zip_health(FINAL),
    }
    print("writing report", flush=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
