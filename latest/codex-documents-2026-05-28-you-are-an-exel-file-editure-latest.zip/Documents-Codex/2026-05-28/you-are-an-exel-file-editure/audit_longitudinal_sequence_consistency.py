import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import audit_singleton_longitudinal_flags as singleton_audit

REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\audit_longitudinal_sequence_consistency_report.json")


def date_key(value):
    text = str(value or "").strip()
    if not text:
        return ""
    if text.isdigit():
        number = int(text)
        if 20000 <= number <= 60000:
            return (datetime(1899, 12, 30) + timedelta(days=number)).strftime("%Y-%m-%d")
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return text


def sortable(value):
    key = date_key(value)
    try:
        return datetime.strptime(key, "%Y-%m-%d")
    except ValueError:
        return datetime.max


def main():
    rows = singleton_audit.read_final_rows()
    groups = defaultdict(list)
    for row in rows:
        if row["primary"]:
            groups[row["group"]].append(row)

    mismatches = []
    single_nonzero = []
    for group, items in groups.items():
        if len(items) == 1:
            item = items[0]
            expected = 0
            if item["longitudinal"] != expected:
                single_nonzero.append({**item, "expected": expected})
            continue

        distinct_dates = []
        for item in sorted(items, key=lambda row: (sortable(row["sample_date"]), row["row"])):
            key = date_key(item["sample_date"]) or f"row-{item['row']}"
            if key not in distinct_dates:
                distinct_dates.append(key)
        expected_by_date = {date: idx for idx, date in enumerate(distinct_dates, start=1)}
        for item in items:
            key = date_key(item["sample_date"]) or f"row-{item['row']}"
            expected = expected_by_date[key]
            if item["longitudinal"] != expected:
                mismatches.append({**item, "normalized_date": key, "expected": expected, "group_size": len(items)})

    report = {
        "single_nonzero_count": len(single_nonzero),
        "single_nonzero": single_nonzero,
        "sequence_mismatch_count": len(mismatches),
        "sequence_mismatches": mismatches,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
