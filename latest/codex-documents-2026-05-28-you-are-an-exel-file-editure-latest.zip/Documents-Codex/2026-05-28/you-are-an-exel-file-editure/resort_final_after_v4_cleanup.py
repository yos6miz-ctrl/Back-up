from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "resort_final_after_v4_cleanup_report.json"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before post-v4 cleanup sort {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    before = {
        ws.cell(row, headers["Primary name"]).value: row
        for row in range(2, ws.max_row + 1)
        if ws.cell(row, headers["Primary name"]).value
    }

    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    watched = ["F-AA-25186", "F-AA-26113", "F-AT-2661", "F-GM-2614", "F-IY-25190", "F-NW-26115", "F-OE-25191", "F-SS-2613"]
    rows = []
    for row in range(2, check_ws.max_row + 1):
        primary = check_ws.cell(row, check_headers["Primary name"]).value
        if primary in watched:
            rows.append(
                {
                    "primary": primary,
                    "row": row,
                    "old_row": before.get(primary),
                    "status": check_ws.cell(row, check_headers["Measurement status"]).value,
                    "diagnosis": check_ws.cell(row, check_headers["Diagnosis"]).value,
                    "final": check_ws.cell(row, check_headers["Final classification / decision"]).value,
                    "source": check_ws.cell(row, check_headers["Measurement/source file"]).value,
                }
            )

    report = {
        "workbook": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "rows": check_ws.max_row,
        "columns": check_ws.max_column,
        "watched_rows_after_sort": rows,
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
