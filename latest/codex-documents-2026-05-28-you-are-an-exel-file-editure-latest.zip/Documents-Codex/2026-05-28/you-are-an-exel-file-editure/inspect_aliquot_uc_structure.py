import json
from pathlib import Path

import openpyxl

ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")


def main():
    wb = openpyxl.load_workbook(ALIQUOTS, data_only=True)
    out = {}
    for sheet in ["CDf", "UC"]:
        ws = wb[sheet]
        out[sheet] = {
            "max_row": ws.max_row,
            "max_column": ws.max_column,
            "rows": [
                [ws.cell(row, col).value for col in range(1, min(ws.max_column, 22) + 1)]
                for row in range(1, min(ws.max_row, 8) + 1)
            ],
        }
    wb.close()
    print(json.dumps(out, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
