import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const file = "C:/Users/Popovtzer lab/.codex/Excel file editor/UN stool names.xlsx";

const input = await FileBlob.load(file);
const source = await SpreadsheetFile.importXlsx(input);
const sourceSheet = source.worksheets.items[0];
const table = await source.inspect({
  kind: "table",
  range: `${sourceSheet.name}!A1:B500`,
  include: "values,formulas",
  tableMaxRows: 500,
  tableMaxCols: 2,
});
const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
const rows = (JSON.parse(line).values ?? [])
  .map((row) => [
    typeof row[0] === "string" ? row[0].trim() : row[0] ?? null,
    typeof row[1] === "string" ? row[1].trim() : row[1] ?? null,
  ])
  .filter((row) => row[0] || row[1]);

function key(value) {
  return String(value ?? "")
    .toUpperCase()
    .replace(/\([^)]*\)/g, "")
    .replace(/^UN\s*/, "")
    .replace(/[^A-Z0-9.]/g, "")
    .replace(/\./g, "");
}

const seenUnknown = new Set();
const seenReal = new Set();
const deduped = [];
const removed = [];
for (let index = 0; index < rows.length; index++) {
  const row = rows[index];
  const unknownKey = key(row[1]);
  const realKey = key(row[0]);
  if ((unknownKey && seenUnknown.has(unknownKey)) || (realKey && seenReal.has(realKey))) {
    removed.push({ sourceRow: index + 1, realName: row[0], unknownName: row[1] });
    continue;
  }
  if (unknownKey) seenUnknown.add(unknownKey);
  if (realKey) seenReal.add(realKey);
  deduped.push(row);
}

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Sheet1");
sheet.getRange(`A1:B${deduped.length}`).values = deduped;
sheet.getRange("A:A").columnWidthPx = 140;
sheet.getRange("B:B").columnWidthPx = 160;

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(file);

console.log(JSON.stringify({ originalRows: rows.length, keptRows: deduped.length, removedRows: removed.length, removed }, null, 2));
