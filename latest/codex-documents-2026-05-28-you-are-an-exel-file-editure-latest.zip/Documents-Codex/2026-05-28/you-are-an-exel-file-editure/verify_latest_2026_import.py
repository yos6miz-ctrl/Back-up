from __future__ import annotations

from pathlib import Path
import hashlib
import json
import zipfile

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
V4_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged - Ichilov v4.xlsx")
REPORT_PATH = WORKSPACE / "latest_2026_import_verification.json"

SAMPLES = [
    "F-DO-2665",
    "F-US-26120",
    "F-NSE-26138",
    "F-GS-26166",
    "F-NW-26181",
    "F-SG-2533",
    "F-ZS-2688",
    "F-BZ-2698",
    "F-ED-24107",
    "F-OK-25179",
]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def zip_health(path: Path) -> dict:
    with zipfile.ZipFile(path) as zf:
        bad_file = zf.testzip()
        names = zf.namelist()
    return {
        "bad_file": bad_file,
        "table_parts": [name for name in names if name.startswith("xl/tables/")],
        "comment_parts": [name for name in names if "comments" in name.lower()],
    }


def header_map(ws) -> dict:
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def sample_rows(path: Path) -> dict:
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb["Final"] if "Final" in wb.sheetnames else wb[wb.sheetnames[0]]
    headers = header_map(ws)
    required = [
        "Measurement status",
        "Diagnosis",
        "Final classification / decision",
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
        "PA447 decision",
        "araE decision",
        "Sample date",
        "Measurement/source file",
    ]
    missing_headers = [header for header in required if header not in headers]
    if missing_headers:
        return {
            "sheet": ws.title,
            "rows": ws.max_row,
            "cols": ws.max_column,
            "headers": [ws.cell(1, col).value for col in range(1, ws.max_column + 1)],
            "missing_expected_headers": missing_headers,
            "samples": {},
        }
    found = {}
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers.get("Primary name", 1)).value
        secondary = ws.cell(row, headers.get("Secondary / other name", 2)).value
        names = {primary, secondary}
        for sample in SAMPLES:
            if sample in names:
                found.setdefault(sample, []).append(
                    {
                        "row": row,
                        "primary": primary,
                        "secondary": secondary,
                        "status": ws.cell(row, headers["Measurement status"]).value,
                        "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                        "final": ws.cell(row, headers["Final classification / decision"]).value,
                        "pa447": [
                            ws.cell(row, headers[f"PA447 measurement {i}"]).value for i in (1, 2, 3)
                        ],
                        "arae": [
                            ws.cell(row, headers[f"araE measurement {i}"]).value for i in (1, 2, 3)
                        ],
                        "pa447_decision": ws.cell(row, headers["PA447 decision"]).value,
                        "arae_decision": ws.cell(row, headers["araE decision"]).value,
                        "sample_date": ws.cell(row, headers["Sample date"]).value,
                        "source": ws.cell(row, headers["Measurement/source file"]).value,
                    }
                )
    return {
        "sheet": ws.title,
        "rows": ws.max_row,
        "cols": ws.max_column,
        "headers": [ws.cell(1, col).value for col in range(1, ws.max_column + 1)],
        "samples": found,
    }


def main():
    report = {
        "onedrive_final": str(ONEDRIVE_FINAL),
        "codex_final": str(CODEX_FINAL),
        "same_hash": digest(ONEDRIVE_FINAL) == digest(CODEX_FINAL),
        "onedrive_hash": digest(ONEDRIVE_FINAL),
        "codex_hash": digest(CODEX_FINAL),
        "onedrive_zip_health": zip_health(ONEDRIVE_FINAL),
        "codex_zip_health": zip_health(CODEX_FINAL),
        "onedrive_rows": sample_rows(ONEDRIVE_FINAL),
    }
    if V4_FINAL.exists():
        report["v4_exists"] = True
        report["v4_size"] = V4_FINAL.stat().st_size
        report["v4_hash"] = digest(V4_FINAL)
        report["v4_zip_health"] = zip_health(V4_FINAL)
        report["v4_rows"] = sample_rows(V4_FINAL)
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
