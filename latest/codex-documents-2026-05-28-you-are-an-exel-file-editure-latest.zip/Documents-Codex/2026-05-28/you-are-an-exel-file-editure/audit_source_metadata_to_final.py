from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
import json
import re

from openpyxl import load_workbook

import build_accounted_known_unknown as builder


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
V4 = WORKSPACE / "merged - Ichilov v4 source copy.xlsx"
SHIP_DIAG = WORKSPACE / "Shipment Bar Ilan 7.26 - Blinded source copy.xlsx"
SHIP_FULL = WORKSPACE / "Shipment Bar Ilan 7.26 Blinded source copy.xlsx"
REPORT = WORKSPACE / "audit_source_metadata_to_final_report.json"


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def canon_header(value):
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def norm(value):
    return builder.norm(value)


def date_key(value):
    if value in (None, ""):
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    text = clean(value) or ""
    for fmt in ("%Y-%m-%d", "%d.%m.%y", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return text[:10]


def nameset(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
        if norm(value):
            keys.add(norm(value))
    return {key for key in keys if key}


def final_rows():
    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    rows = []
    by_name = defaultdict(list)
    by_name_date = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        sample_date = date_key(ws.cell(row, headers["Sample date"]).value)
        keys = nameset(primary, secondary)
        item = {"row": row, "primary": primary, "secondary": secondary, "date": sample_date, "keys": keys}
        rows.append(item)
        for key in keys:
            by_name[key].append(item)
            by_name_date[(key, sample_date)].append(item)
    return rows, by_name, by_name_date


def add_record(records, source, sample, secondary=None, date=None, **fields):
    sample = clean(sample)
    secondary = clean(secondary)
    if not sample and not secondary:
        return
    if re.fullmatch(r"P\d+", sample or "", flags=re.I) or re.fullmatch(r"P\d+", secondary or "", flags=re.I):
        return
    records.append(
        {
            "source": source,
            "primary": sample or secondary,
            "secondary": secondary if sample and secondary and norm(sample) != norm(secondary) else None,
            "date": date_key(date),
            "keys": nameset(sample, secondary),
            **fields,
        }
    )


def load_v4():
    wb = load_workbook(V4, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = {}
    for col in range(1, ws.max_column + 1):
        h = canon_header(ws.cell(1, col).value)
        if h == "primary name":
            headers["primary"] = col
        elif h.startswith("secondary"):
            headers["secondary"] = col
        elif "longitudinal sample" in h:
            headers["longitudinal"] = col
        elif "patient unique code" in h:
            headers["patient_unique_code"] = col
        elif "measurement status" in h:
            headers["status"] = col
        elif "ichilov" in h and "diagnosis" in h:
            headers["diagnosis"] = col
        elif "final classification" in h:
            headers["final"] = col
        elif "calprotectin" in h:
            headers["calprotectin"] = col
        elif h == "disease location":
            headers["location"] = col
        elif "diagnosis match" in h:
            headers["diagnosis_match"] = col
        elif h == "sample date":
            headers["date"] = col
    records = []
    for row in range(2, ws.max_row + 1):
        add_record(
            records,
            "merged - Ichilov v4.xlsx",
            ws.cell(row, headers["primary"]).value,
            ws.cell(row, headers.get("secondary", 0)).value if headers.get("secondary") else None,
            ws.cell(row, headers.get("date", 0)).value if headers.get("date") else None,
            source_row=row,
            diagnosis=ws.cell(row, headers.get("diagnosis", 0)).value if headers.get("diagnosis") else None,
            calprotectin=ws.cell(row, headers.get("calprotectin", 0)).value if headers.get("calprotectin") else None,
            location=ws.cell(row, headers.get("location", 0)).value if headers.get("location") else None,
            status=ws.cell(row, headers.get("status", 0)).value if headers.get("status") else None,
            final=ws.cell(row, headers.get("final", 0)).value if headers.get("final") else None,
            longitudinal=ws.cell(row, headers.get("longitudinal", 0)).value if headers.get("longitudinal") else None,
            patient_unique_code=ws.cell(row, headers.get("patient_unique_code", 0)).value if headers.get("patient_unique_code") else None,
            diagnosis_match=ws.cell(row, headers.get("diagnosis_match", 0)).value if headers.get("diagnosis_match") else None,
        )
    return records


def load_ship_diag():
    wb = load_workbook(SHIP_DIAG, data_only=True, read_only=True)
    ws = wb.active
    records = []
    for row in range(2, ws.max_row + 1):
        add_record(records, "Shipment Bar Ilan 7.26 - Blinded.xlsx", ws.cell(row, 2).value, date=ws.cell(row, 1).value, source_row=row, diagnosis=ws.cell(row, 3).value)
    return records


def load_ship_full():
    wb = load_workbook(SHIP_FULL, data_only=True, read_only=True)
    ws = wb.active
    records = []
    for row in range(2, ws.max_row + 1):
        add_record(
            records,
            "Shipment Bar Ilan 7.26 Blinded.xlsx",
            ws.cell(row, 5).value,
            date=ws.cell(row, 4).value,
            source_row=row,
            patient_number_study=ws.cell(row, 1).value,
            patient_number_project=ws.cell(row, 2).value,
            study_number=ws.cell(row, 3).value,
            shipment_box=ws.cell(row, 6).value,
            shipment_aliquots=ws.cell(row, 7).value,
        )
    return records


def main():
    _rows, by_name, by_name_date = final_rows()
    sources = load_v4() + load_ship_diag() + load_ship_full()
    stats = Counter()
    details = []
    for record in sources:
        matches = []
        if record["date"]:
            for key in record["keys"]:
                matches.extend(by_name_date.get((key, record["date"]), []))
        if not matches:
            for key in record["keys"]:
                matches.extend(by_name.get(key, []))
        unique = {(item["row"], item["primary"], item["date"]) for item in matches}
        if not unique:
            stats[(record["source"], "append")] += 1
            outcome = "append"
        elif len(unique) == 1:
            stats[(record["source"], "update")] += 1
            outcome = "update"
        else:
            stats[(record["source"], "multiple")] += 1
            outcome = "multiple"
        details.append({k: v for k, v in record.items() if k != "keys"} | {"outcome": outcome, "matches": sorted(unique)})
    report = {
        "source_rows": len(sources),
        "stats": {f"{k[0]} | {k[1]}": v for k, v in stats.items()},
        "append_or_multiple": [item for item in details if item["outcome"] != "update"],
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
