from __future__ import annotations

from copy import copy
from pathlib import Path
import json
import math
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "separate_yellow_excluded_from_repeat_needed_report.json"

EXCLUDED_YELLOW = "FFF2CC"
NEEDS_REPEAT_ORANGE = "FCE4D6"


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def set_bold(cell, bold):
    font = copy(cell.font)
    font.bold = bold
    cell.font = font


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / "Final Known and Unknown merged before separating yellow repeat needed.xlsx"
    shutil.copy2(FINAL, backup)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = header_map(ws)

    changed_to_orange = []
    yellow_excluded_cells = []
    numeric_single_detectors = 0

    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        for detector in ("PA447", "araE"):
            cols = detector_cols(headers, detector)
            numeric_cols = [col for col in cols if is_numeric(ws.cell(row, col).value)]
            if len(numeric_cols) == 1:
                numeric_single_detectors += 1
                cell = ws.cell(row, numeric_cols[0])
                cell.fill = PatternFill(fill_type="solid", fgColor=NEEDS_REPEAT_ORANGE)
                set_bold(cell, False)
                changed_to_orange.append(
                    {
                        "row": row,
                        "sample": primary,
                        "detector": detector,
                        "value": cell.value,
                    }
                )
            else:
                for col in numeric_cols:
                    cell = ws.cell(row, col)
                    fill = cell.fill.fgColor.rgb
                    if fill in {"00" + EXCLUDED_YELLOW, "FF" + EXCLUDED_YELLOW, EXCLUDED_YELLOW}:
                        yellow_excluded_cells.append(
                            {
                                "row": row,
                                "sample": primary,
                                "detector": detector,
                                "column": ws.cell(1, col).value,
                                "value": cell.value,
                            }
                        )

    wb.save(FINAL)

    copy_error = None
    try:
        shutil.copy2(FINAL, ONEDRIVE_FINAL)
    except PermissionError as exc:
        copy_error = str(exc)

    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "backup": str(backup),
        "copy_error": copy_error,
        "needs_repeat_color": NEEDS_REPEAT_ORANGE,
        "excluded_color": EXCLUDED_YELLOW,
        "single_detector_cells_changed_to_orange": len(changed_to_orange),
        "yellow_excluded_measurement_cells_remaining": len(yellow_excluded_cells),
        "changed_to_orange": changed_to_orange,
        "yellow_excluded_cells": yellow_excluded_cells,
        "zip_health": zip_health(FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
