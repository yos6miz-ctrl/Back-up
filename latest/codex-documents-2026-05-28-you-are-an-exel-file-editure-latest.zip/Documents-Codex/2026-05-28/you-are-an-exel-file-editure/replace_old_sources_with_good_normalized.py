from collections import defaultdict
from copy import copy
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import os

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = Path(os.environ.get("FINAL_WORKBOOK_PATH", EXCEL_DIR / "Final Known and Unknown merged.xlsx"))
REPORT_PATH = WORKSPACE / "replace_old_sources_with_good_normalized_report.json"

spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    queue = list(keys)
    while queue:
        key = queue.pop()
        for alias in aliases_by_key.get(key, set()):
            if alias not in expanded:
                expanded.add(alias)
                queue.append(alias)
    return expanded


def row_keys(builder, primary, secondary):
    keys = set()
    keys.update(builder.identifier_variants(primary, secondary))
    keys.update(builder.strict_identifier_variants(primary, secondary))
    return {key for key in keys if key}


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def detector_cols(headers, detector):
    return [headers[f"{detector} measurement {idx}"] for idx in (1, 2, 3)]


def decision_col(headers, detector):
    return headers[f"{detector} decision"]


def displayed_values(ws, row, headers, detector):
    return [ws.cell(row, col).value for col in detector_cols(headers, detector) if ws.cell(row, col).value not in (None, "")]


def source_sort_key(item):
    return (
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item.get("source_name") or ""),
        str(item.get("source_rows") or ""),
    )


def same_visible_label(primary, secondary, item):
    item_name = item.get("source_name")
    item_norm = builder.norm(item_name)
    return item_norm and item_norm in {
        builder.norm(primary),
        builder.norm(secondary),
    }


def compatible_row_item(primary, secondary, diagnosis, item):
    record = {
        "sample_name": primary,
        "other_name": secondary,
        "diagnosis": diagnosis,
        "identifiers": row_keys(builder, primary, secondary),
        "strict_identifiers": row_keys(builder, primary, secondary),
    }
    return builder.compatible(diagnosis, item.get("diagnosis")) or builder.manual_alias_match(record, item)


def value_key(value):
    try:
        return f"{float(value):.12g}"
    except Exception:
        return str(value)


def close_any(value, values, tolerance=1e-5):
    for other in values:
        try:
            if math.isclose(float(value), float(other), rel_tol=tolerance, abs_tol=tolerance):
                return True
        except Exception:
            pass
    return False


def unique_good_items(items, detector):
    unique = {}
    for item in sorted(items, key=source_sort_key):
        value = detector_value(item, detector)
        key = (
            item.get("source_file"),
            tuple(item.get("source_rows") or []),
            item.get("source_name"),
            value_key(value),
        )
        unique[key] = item
    return list(unique.values())


def style_detector(cell, value):
    styles = {
        "Pos": ("F4C7C3", "5A1212"),
        "Neg": ("CFE2F3", "17365D"),
        "Int": ("FFE599", "7F6000"),
    }
    fill, font_color = styles.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font_color, bold=True)


def style_final(cell, value):
    styles = {
        "IBD": ("C00000", "FFFFFF"),
        "IBS": ("003399", "FFFFFF"),
        "inconclusive": ("D9D2E9", "4C3868"),
        "missing": ("E7E6E6", "666666"),
        "old metering system*": ("FFE599", "7F6000"),
    }
    fill, font_color = styles.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font_color, bold=True)


def parse_source_parts(source_text):
    parts = {"PA447": [], "araE": [], "other": []}
    for part in str(source_text or "").split(";"):
        text = part.strip()
        if text.startswith("PA447:"):
            parts["PA447"].append(text)
        elif text.startswith("araE:"):
            parts["araE"].append(text)
        elif text:
            parts["other"].append(text)
    return parts


def source_label(detector, items):
    names = []
    for item in items:
        name = Path(item.get("source_file") or "").name
        if name and name not in names:
            names.append(name)
    return f"{detector}: {', '.join(names)}" if names else None


def set_detector_values(ws, row, headers, detector, items):
    values = [detector_value(item, detector) for item in items[:3]]
    cols = detector_cols(headers, detector)
    for idx, col in enumerate(cols):
        ws.cell(row, col).value = values[idx] if idx < len(values) else None
    decision = builder.detector_decision(values[0] if values else None, detector)
    # This workbook's repeat-decision logic is conservative; if repeats cross the threshold, mark Int.
    if len(values) >= 2:
        calls = {builder.detector_decision(value, detector) for value in values if value is not None}
        if len(calls - {None}) > 1:
            decision = "Int"
    ws.cell(row, decision_col(headers, detector)).value = decision
    style_detector(ws.cell(row, decision_col(headers, detector)), decision)
    return values, decision


def final_from_detector_decisions(pa447_decision, arae_decision):
    if pa447_decision == "Pos" or arae_decision == "Pos":
        return "IBD"
    if pa447_decision == "Neg" and arae_decision == "Neg":
        return "IBS"
    return "inconclusive"


def main():
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    all_rows, all_by_key = builder.load_all_measurements()

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    changed = []
    kept_old = []
    removed_old_detector_value = []
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, headers["Original tab"]).value != "Known":
            continue
        source_text = ws.cell(row, headers["Measurement/source file"]).value
        if "IBD IBS OLD" not in str(source_text or ""):
            continue
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        diagnosis = ws.cell(row, headers["Diagnosis"]).value
        keys = expand_keys(row_keys(builder, primary, secondary), aliases_by_key)
        parts = parse_source_parts(source_text)

        row_changed = False
        new_detector_labels = {}
        for detector in ("PA447", "araE"):
            detector_source_text = " ".join(parts[detector])
            if "IBD IBS OLD" not in detector_source_text:
                if parts[detector]:
                    new_detector_labels[detector] = parts[detector][0]
                continue
            good_candidates = []
            for key in keys:
                for item in all_by_key.get(key, []):
                    if item.get("source") != "edited normalized files":
                        continue
                    if detector_value(item, detector) is None:
                        continue
                    if not compatible_row_item(primary, secondary, diagnosis, item):
                        continue
                    good_candidates.append(item)
            good_candidates = unique_good_items(good_candidates, detector)
            same_label = [item for item in good_candidates if same_visible_label(primary, secondary, item)]
            selected = same_label or good_candidates
            if selected:
                before = displayed_values(ws, row, headers, detector)
                values, decision = set_detector_values(ws, row, headers, detector, selected)
                label = source_label(detector, selected)
                if label:
                    new_detector_labels[detector] = label
                row_changed = True
                changed.append(
                    {
                        "row": row,
                        "primary": primary,
                        "secondary": secondary,
                        "detector": detector,
                        "before": before,
                        "after": values,
                        "decision": decision,
                        "same_visible_label": bool(same_label),
                        "source_files": [item.get("source_file") for item in selected[:3]],
                    }
                )
            else:
                kept_old.append({"row": row, "primary": primary, "secondary": secondary, "detector": detector, "reason": "no good edited normalized replacement"})
                if parts[detector]:
                    new_detector_labels[detector] = parts[detector][0]

        if row_changed:
            # Keep any non-IBD-old detector source labels, replace changed detector labels with clean file names.
            for detector in ("PA447", "araE"):
                if detector not in new_detector_labels and parts[detector]:
                    new_detector_labels[detector] = parts[detector][0]
            source_parts = []
            for detector in ("PA447", "araE"):
                label = new_detector_labels.get(detector)
                if label:
                    source_parts.append(label)
            source_parts.extend(parts["other"])
            ws.cell(row, headers["Measurement/source file"]).value = "; ".join(source_parts) if source_parts else None

            pa447_decision = ws.cell(row, headers["PA447 decision"]).value
            arae_decision = ws.cell(row, headers["araE decision"]).value
            final = final_from_detector_decisions(pa447_decision, arae_decision)
            final_cell = ws.cell(row, headers["Final classification / decision"])
            final_cell.value = final
            style_final(final_cell, final)
            ws.cell(row, headers["Measurement status"]).value = "measured"

    wb.save(FINAL_PATH)
    report = {
        "saved": str(FINAL_PATH),
        "changed_detector_sources": changed,
        "kept_old_detector_sources": kept_old,
        "removed_old_detector_value": removed_old_detector_value,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({k: len(v) if isinstance(v, list) else v for k, v in report.items()}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
