import json
import re
import zipfile
from pathlib import Path

import audit_final_dates_against_sources as fast_xlsx

WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
REPORT = WORKSPACE / "trace_ct1156_longitudinal_history_report.json"
WORKBOOKS = sorted((WORKSPACE / "backups").glob("Final Known and Unknown merged before *20260825-*.xlsx")) + [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx"),
]


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def read_rows(path):
    if not path.exists():
        return []
    with zipfile.ZipFile(path) as zf:
        shared_strings = fast_xlsx.read_shared_strings(zf)
        root = fast_xlsx.ET.fromstring(zf.read(fast_xlsx.sheet_path_for_name(zf, "Final")))
        raw_rows = []
        for row_node in root.findall(f".//{fast_xlsx.NS_MAIN}row"):
            values = {}
            max_col = 0
            for cell in row_node.findall(f"{fast_xlsx.NS_MAIN}c"):
                index = fast_xlsx.col_index(cell.attrib["r"])
                values[index] = fast_xlsx.cell_text(cell, shared_strings)
                max_col = max(max_col, index)
            raw_rows.append([values.get(index, "") for index in range(1, max_col + 1)])
    headers = {name: index for index, name in enumerate(raw_rows[0])}
    found = []
    for row_number, row in enumerate(raw_rows[1:], start=2):
        def get(name):
            index = headers.get(name)
            return row[index] if index is not None and index < len(row) else ""

        primary = get("Primary name")
        secondary = get("Secondary / other name")
        combined = f"{primary} {secondary}"
        if any(key in norm(combined) for key in ("CT1156", "CDF1156OLD", "FYD21156")):
            found.append(
                {
                    "row": row_number,
                    "primary": primary,
                    "secondary": secondary,
                    "longitudinal": get("Longitudinal sample"),
                    "patient_unique_code": get("Patient unique code"),
                    "sample_date": get("Sample date"),
                }
            )
    return found


def main():
    report = {str(path): read_rows(path) for path in WORKBOOKS}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
