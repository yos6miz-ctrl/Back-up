from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import os

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
AGENT_DIR = Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
CLASSIFIER_SCRIPT = AGENT_DIR / "skills" / "classifier" / "scripts" / "run_threshold_bar_classifier.py"
FINAL_PATH = Path(os.environ.get("FINAL_WORKBOOK_PATH", EXCEL_DIR / "Final Known and Unknown merged.xlsx"))
REPORT_PATH = EXCEL_DIR / "classifier full file audit.json"
REPORT_XLSX_PATH = EXCEL_DIR / "classifier full file audit.xlsx"


STATUS_EXEMPT = {"missing", "לא נבדק", "old metering system"}


def load_classifier():
    spec = spec_from_file_location("ibd_ibs_classifier", CLASSIFIER_SCRIPT)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def norm_text(value):
    if value is None:
        return ""
    return str(value).strip()


def canonical_final(value):
    text = norm_text(value)
    text = text.rstrip("*").strip()
    lower = text.lower()
    if lower in {"ibd", "pos", "positive"}:
        return "IBD"
    if lower in {"ibs", "neg", "negative", "ibs control"}:
        return "IBS"
    if lower in {"int", "inconclusive"}:
        return "inconclusive"
    if lower == "missing":
        return "missing"
    if text == "לא נבדק":
        return "לא נבדק"
    return text


def numeric(value):
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def average(values):
    nums = [numeric(value) for value in values]
    nums = [value for value in nums if value is not None]
    if not nums:
        return None
    return sum(nums) / len(nums)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def row_identifier(ws, row, headers):
    parts = []
    for header in ("Primary name", "Synonym / other name"):
        col = headers.get(header)
        if col:
            value = norm_text(ws.cell(row, col).value)
            if value and value not in parts:
                parts.append(value)
    return " / ".join(parts)


def main():
    classifier = load_classifier()
    training, feature_cols, _fill_values, sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_PATH, data_only=True)
    ws = wb["Final"]
    headers = header_map(ws)

    detector_measurement_cols = {
        "PA447": [
            headers.get("PA447 measurement 1"),
            headers.get("PA447 measurement 2"),
            headers.get("PA447 measurement 3"),
        ],
        "araE": [
            headers.get("araE measurement 1"),
            headers.get("araE measurement 2"),
            headers.get("araE measurement 3"),
        ],
    }
    detector_measurement_cols = {
        key: [col for col in cols if col]
        for key, cols in detector_measurement_cols.items()
    }

    final_col = headers["Final classification / decision"]
    status_col = headers.get("Measurement status")
    source_col = headers.get("Measurement/source file")
    diagnosis_col = headers.get("Diagnosis")
    table_col = headers.get("Table")

    rows = []
    issues = []
    counts = Counter()
    for row in range(2, ws.max_row + 1):
        status = norm_text(ws.cell(row, status_col).value) if status_col else ""
        existing = canonical_final(ws.cell(row, final_col).value)
        sample = row_identifier(ws, row, headers)

        detector_results = []
        detector_values = {}
        for detector in feature_cols:
            detector_name = str(detector)
            cols = detector_measurement_cols.get(detector_name, [])
            if not cols:
                continue
            value = average(ws.cell(row, col).value for col in cols)
            detector_values[detector_name] = value
            if value is None:
                continue
            bar = bars[detector_name]["bar"]
            call, margin = classifier.detector_call(value, bar)
            detector_results.append(
                {
                    "detector": detector_name,
                    "value": value,
                    "bar": bar,
                    "call": call,
                    "margin": margin,
                }
            )

        if detector_results:
            classifier_final = classifier.final_classification([item["call"] for item in detector_results])
            confidence = classifier.confidence_level(classifier_final, detector_results)
        else:
            classifier_final = "missing"
            confidence = ""

        if status in STATUS_EXEMPT:
            expected = status
            if status == "old metering system":
                expected = f"{existing}*" if existing else ""
            comparison = "status-exempt"
            if status == "old metering system":
                raw_final = norm_text(ws.cell(row, final_col).value)
                needs_fix = bool(existing) and not raw_final.endswith("*")
            else:
                needs_fix = existing != expected
            reason = (
                f"Status is {status}; old metering final can remain but should be marked with *"
                if status == "old metering system"
                else f"Status is {status}; final should stay {status}"
            )
        elif not detector_results:
            expected = "missing"
            comparison = "no-measurements"
            needs_fix = existing != expected
            reason = "No usable PA447 or araE measurements found; final should be missing"
        else:
            expected = classifier_final
            comparison = "classifier"
            needs_fix = existing != expected
            crossed = [item for item in detector_results if item["call"] == "IBD-like"]
            inconclusive = [item for item in detector_results if item["call"] == "inconclusive"]
            if classifier_final == "IBD":
                reason = "At least one detector is above 105% of its learned bar: " + ", ".join(
                    f"{item['detector']}={item['value']:.6g} vs bar {item['bar']:.6g}"
                    for item in crossed
                )
            elif classifier_final == "inconclusive":
                reason = "No detector is IBD-like, but at least one detector is within 95%-105% of its bar: " + ", ".join(
                    f"{item['detector']}={item['value']:.6g} vs bar {item['bar']:.6g}"
                    for item in inconclusive
                )
            else:
                reason = "All available detectors are below 95% of their learned bars"

        counts[(comparison, "needs_fix" if needs_fix else "ok")] += 1
        record = {
            "row": row,
            "sample": sample,
            "table": norm_text(ws.cell(row, table_col).value) if table_col else "",
            "diagnosis": norm_text(ws.cell(row, diagnosis_col).value) if diagnosis_col else "",
            "measurement_status": status,
            "measurement_source_file": norm_text(ws.cell(row, source_col).value) if source_col else "",
            "current_final": existing,
            "classifier_final": classifier_final,
            "expected_final": expected,
            "comparison_type": comparison,
            "needs_fix": needs_fix,
            "reason": reason,
            "confidence": confidence,
            "detectors": detector_results,
            "detector_averages": detector_values,
        }
        rows.append(record)
        if needs_fix:
            issues.append(record)

    report = {
        "workbook": str(FINAL_PATH),
        "rows_checked": len(rows),
        "bars": {str(key): value["bar"] for key, value in bars.items()},
        "training_sources": sources,
        "counts": {f"{key[0]}:{key[1]}": value for key, value in sorted(counts.items())},
        "issues": issues,
        "issue_count": len(issues),
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    out = Workbook()
    summary_ws = out.active
    summary_ws.title = "Summary"
    summary_ws.append(["Check", "Value"])
    summary_rows = [
        ("Workbook", str(FINAL_PATH)),
        ("Rows checked", len(rows)),
        ("PA447 bar", bars["PA447"]["bar"]),
        ("araE bar", bars["araE"]["bar"]),
        ("Measured rows matching classifier", counts[("classifier", "ok")]),
        ("Measured rows needing classifier fix", counts[("classifier", "needs_fix")]),
        ("Status rows OK", counts[("status-exempt", "ok")]),
        ("Status rows needing fix", counts[("status-exempt", "needs_fix")]),
    ]
    for item in summary_rows:
        summary_ws.append(item)

    issues_ws = out.create_sheet("Needs attention")
    issue_headers = [
        "Row",
        "Sample",
        "Diagnosis",
        "Measurement status",
        "Current final",
        "Expected final",
        "Classifier final",
        "Confidence",
        "PA447 average",
        "PA447 call",
        "araE average",
        "araE call",
        "Reason",
        "Measurement/source file",
    ]
    issues_ws.append(issue_headers)
    for issue in issues:
        det_by_name = {item["detector"]: item for item in issue["detectors"]}
        issues_ws.append(
            [
                issue["row"],
                issue["sample"],
                issue["diagnosis"],
                issue["measurement_status"],
                issue["current_final"],
                issue["expected_final"],
                issue["classifier_final"],
                issue["confidence"],
                issue["detector_averages"].get("PA447"),
                det_by_name.get("PA447", {}).get("call"),
                issue["detector_averages"].get("araE"),
                det_by_name.get("araE", {}).get("call"),
                issue["reason"],
                issue["measurement_source_file"],
            ]
        )

    all_ws = out.create_sheet("All rows")
    all_headers = [
        "Row",
        "Sample",
        "Table",
        "Diagnosis",
        "Measurement status",
        "Current final",
        "Expected final",
        "Classifier final",
        "Needs fix",
        "Confidence",
        "PA447 average",
        "PA447 call",
        "araE average",
        "araE call",
        "Reason",
        "Measurement/source file",
    ]
    all_ws.append(all_headers)
    for record in rows:
        det_by_name = {item["detector"]: item for item in record["detectors"]}
        all_ws.append(
            [
                record["row"],
                record["sample"],
                record["table"],
                record["diagnosis"],
                record["measurement_status"],
                record["current_final"],
                record["expected_final"],
                record["classifier_final"],
                record["needs_fix"],
                record["confidence"],
                record["detector_averages"].get("PA447"),
                det_by_name.get("PA447", {}).get("call"),
                record["detector_averages"].get("araE"),
                det_by_name.get("araE", {}).get("call"),
                record["reason"],
                record["measurement_source_file"],
            ]
        )

    header_fill = PatternFill(fill_type="solid", fgColor="D9D9D9")
    issue_fill = PatternFill(fill_type="solid", fgColor="F4CCCC")
    ok_fill = PatternFill(fill_type="solid", fgColor="D9EAD3")
    inconclusive_fill = PatternFill(fill_type="solid", fgColor="D9D2E9")
    old_fill = PatternFill(fill_type="solid", fgColor="FFF2CC")
    for ws_out in out.worksheets:
        for cell in ws_out[1]:
            cell.fill = header_fill
            cell.font = Font(bold=True)
        ws_out.freeze_panes = "A2"
        for col in range(1, ws_out.max_column + 1):
            ws_out.column_dimensions[ws_out.cell(1, col).column_letter].width = 18
    for ws_out in (issues_ws, all_ws):
        for row_cells in ws_out.iter_rows(min_row=2):
            values = [cell.value for cell in row_cells]
            if ws_out.title == "Needs attention":
                status = values[3]
                expected = values[5]
            else:
                status = values[4]
                expected = values[6]
            fill = old_fill if status == "old metering system" else issue_fill
            if expected == "inconclusive":
                fill = inconclusive_fill
            for cell in row_cells:
                cell.fill = fill
    for row_cells in all_ws.iter_rows(min_row=2):
        if row_cells[8].value is False:
            for cell in row_cells:
                cell.fill = ok_fill
    issues_ws.column_dimensions["M"].width = 72
    issues_ws.column_dimensions["N"].width = 64
    all_ws.column_dimensions["O"].width = 72
    all_ws.column_dimensions["P"].width = 64
    out.save(REPORT_XLSX_PATH)

    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
