import json
import re
from pathlib import Path

import audit_final_dates_against_sources as audit

REPORT = Path("audit_final_dates_against_sources_report.json")


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def main():
    report = json.loads(REPORT.read_text(encoding="utf-8"))
    targets = [
        "F-HG-20673",
        "CT-673",
        "F-KH-20674",
        "CT-674",
        "F-MH-21163",
        "CT-163",
        "CT1156",
        "F-YD-21156",
    ]
    source_records = []
    for path in audit.SOURCE_FILES:
        if path.exists():
            records, error = audit.source_records_from_workbook(path)
            if error:
                raise RuntimeError(f"{path}: {error}")
            source_records.extend(records)

    output = {"suspicious_shared_numeric": report["suspicious_shared_numeric"], "targets": {}}
    for target in targets:
        key = norm(target)
        final_rows = []
        source_rows = []
        for collision in report["suspicious_shared_numeric"]:
            for row in collision["rows"]:
                if key in norm(row["primary"]) or key in norm(row["secondary"]):
                    final_rows.append(row)
        for record in source_records:
            combined = " ".join(str(record.get(field) or "") for field in ("patient", "sample"))
            if key in norm(combined):
                source_rows.append(
                    {
                        "file": record["file"].split("RNA-seq-Biochip\\")[-1],
                        "sheet": record["sheet"],
                        "row": record["row"],
                        "box": record.get("box"),
                        "patient": record.get("patient"),
                        "sample": record.get("sample"),
                        "diagnosis": record.get("diagnosis"),
                        "date": record.get("date"),
                        "date_raw": record.get("date_raw"),
                    }
                )
        if target in report["focus"]:
            for row in report["focus"][target]["final_rows"]:
                if row not in final_rows:
                    final_rows.append(row)
            for record in report["focus"][target]["source_rows"]:
                compact = {
                    "file": record["file"].split("RNA-seq-Biochip\\")[-1],
                    "sheet": record["sheet"],
                    "row": record["row"],
                    "box": record.get("box"),
                    "patient": record.get("patient"),
                    "sample": record.get("sample"),
                    "diagnosis": record.get("diagnosis"),
                    "date": record.get("date"),
                    "date_raw": record.get("date_raw"),
                }
                if compact not in source_rows:
                    source_rows.append(compact)
        output["targets"][target] = {"final_rows": final_rows, "source_rows": source_rows}

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
