from __future__ import annotations

import json
import shutil
import zipfile
from pathlib import Path

import openpyxl

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ALIQUOTS_ONEDRIVE = ROOT / "aliqauts 20260801.xlsx"
ALIQUOTS_WORKING = WORKSPACE / "aliqauts 20260801 working copy.xlsx"
REPORT = WORKSPACE / "repair_cdf_box_layout_report.json"

# Box layout from the original CDf aliquots sheet, after moving F-DS-20527 and
# CT113 to UCf. Rows not listed here intentionally stay without a box value.
BOX_BY_SAMPLE = {
    "F-SB-2067": "1,4,2",
    "F-IP-20191": "1,4,2",
    "F-PM-20543": "1,4,2",
    "CT-132": "1,4,3",
    "CT-238": "1,4,3",
    "CT-344": "1,4,3",
    "CT-130": "1,4,4",
    "CT-412": "1,4,4",
    "CT-203": "2,1,1",
    "CT-233": "2,1,1",
    "DY-247": "2,1,1",
    "CT-235": "2,1,1",
    "CT-156": "2,1,2",
    "CT1156; F-YD-21156": "2,1,2",
    "CT-463": "2,1,3",
    "CT535": "2,1,3",
    "F-DBH-164": "2,1,3",
    "F-AM-170": "2,1,3",
    "CT-433": "2,1,3",
    "CT-459": "2,1,3",
}


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def key(value):
    return clean(value).upper()


def resolved_box(ws, row):
    value = ws.cell(row, 2).value
    if value not in (None, ""):
        return value
    for merged in ws.merged_cells.ranges:
        if merged.min_col <= 2 <= merged.max_col and merged.min_row <= row <= merged.max_row:
            return ws.cell(merged.min_row, merged.min_col).value
    return None


def health(path):
    with zipfile.ZipFile(path) as zf:
        return {"bad_member": zf.testzip(), "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")]}


def main():
    wb = openpyxl.load_workbook(ALIQUOTS_ONEDRIVE)
    ws = wb["CDf"]
    before = [
        {
            "row": row,
            "box_cell": ws.cell(row, 2).value,
            "resolved_box": resolved_box(ws, row),
            "sample": ws.cell(row, 4).value,
        }
        for row in range(2, ws.max_row + 1)
    ]

    for merged in list(ws.merged_cells.ranges):
        if merged.min_col <= 2 <= merged.max_col:
            ws.unmerge_cells(str(merged))

    for row in range(2, ws.max_row + 1):
        ws.cell(row, 2).value = None

    current_group = None
    group_start = None
    for row in range(2, ws.max_row + 1):
        sample = key(ws.cell(row, 4).value)
        box = None
        for sample_name, sample_box in BOX_BY_SAMPLE.items():
            if key(sample_name) == sample:
                box = sample_box
                break
        if box != current_group:
            if current_group and group_start is not None:
                if row - 1 > group_start:
                    ws.merge_cells(start_row=group_start, start_column=2, end_row=row - 1, end_column=2)
            current_group = box
            group_start = row if box else None
            if box:
                ws.cell(row, 2).value = box
        elif box:
            ws.cell(row, 2).value = None

    if current_group and group_start is not None and ws.max_row > group_start:
        ws.merge_cells(start_row=group_start, start_column=2, end_row=ws.max_row, end_column=2)

    wb.save(ALIQUOTS_ONEDRIVE)
    wb.close()
    shutil.copy2(ALIQUOTS_ONEDRIVE, ALIQUOTS_WORKING)

    check_wb = openpyxl.load_workbook(ALIQUOTS_ONEDRIVE, data_only=True)
    check_ws = check_wb["CDf"]
    after = [
        {
            "row": row,
            "box_cell": check_ws.cell(row, 2).value,
            "resolved_box": resolved_box(check_ws, row),
            "sample": check_ws.cell(row, 4).value,
        }
        for row in range(2, check_ws.max_row + 1)
    ]
    missing = [item for item in after if key(item["sample"]) in {key(k) for k in BOX_BY_SAMPLE} and not item["resolved_box"]]
    wrong = []
    for item in after:
        sample = key(item["sample"])
        expected = next((box for sample_name, box in BOX_BY_SAMPLE.items() if key(sample_name) == sample), None)
        if expected and item["resolved_box"] != expected:
            wrong.append({**item, "expected": expected})
    merged = [str(rng) for rng in check_ws.merged_cells.ranges if rng.min_col <= 2 <= rng.max_col]
    check_wb.close()

    report = {
        "before": before,
        "after": after,
        "missing_box_count": len(missing),
        "missing_boxes": missing,
        "wrong_box_count": len(wrong),
        "wrong_boxes": wrong,
        "merged_box_ranges": merged,
        "health": {
            "onedrive": health(ALIQUOTS_ONEDRIVE),
            "working_copy": health(ALIQUOTS_WORKING),
        },
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
