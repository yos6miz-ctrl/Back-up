from collections import Counter
from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
AGENT_DIR = Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
CLASSIFIER_SCRIPT = AGENT_DIR / "skills" / "classifier" / "scripts" / "run_threshold_bar_classifier.py"
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
OUTPUT_PATH = EXCEL_DIR / "Final Known and Unknown merged classifier-agent.xlsx"
AGENT_RESULTS_PATH = AGENT_DIR / "results 2026-07-22.xlsx"


def load_classifier():
    spec = spec_from_file_location("ibd_ibs_classifier", CLASSIFIER_SCRIPT)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def numeric(value):
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def average(values):
    nums = [numeric(value) for value in values]
    nums = [value for value in nums if value is not None]
    if not nums:
        return None
    return sum(nums) / len(nums)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def color_final(cell, value):
    styles = {
        "IBD": ("C00000", "FFFFFF"),
        "IBS": ("003399", "FFFFFF"),
        "inconclusive": ("D9D2E9", "4C3868"),
        "missing": ("E7E6E6", "666666"),
    }
    fill, font = styles.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def color_agent_cell(cell, value):
    fills = {
        "IBD-like": "F4C7C3",
        "IBS-like": "FFE599",
        "inconclusive": "D9D2E9",
        "IBD": "C00000",
        "IBS": "FFE599",
        "missing": "E7E6E6",
        "high": "D9EAD3",
        "mid": "FFE599",
        "low": "F4C7C3",
    }
    fill = fills.get(value)
    if fill:
        cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    if value == "IBD":
        cell.font = Font(name="Calibri", size=11, color="FFFFFF", bold=True)


def main():
    classifier = load_classifier()
    training, feature_cols, _fill_values, sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)
    final_col = headers["Final classification / decision"]
    primary_col = headers["Primary name"]
    status_col = headers["Measurement status"]

    detector_measurement_cols = {
        "PA447": [
            headers["PA447 measurement 1"],
            headers["PA447 measurement 2"],
            headers["PA447 measurement 3"],
        ],
        "araE": [
            headers["araE measurement 1"],
            headers["araE measurement 2"],
            headers["araE measurement 3"],
        ],
    }

    records = []
    filled = []
    for row in range(2, ws.max_row + 1):
        existing = ws.cell(row, final_col).value
        if existing not in (None, ""):
            continue

        sample = ws.cell(row, primary_col).value
        detector_results = []
        record = {"Sample name": sample, "Final workbook row": row}

        for detector in feature_cols:
            detector_name = str(detector)
            if detector_name not in detector_measurement_cols:
                continue
            value = average(ws.cell(row, col).value for col in detector_measurement_cols[detector_name])
            bar = bars[detector_name]["bar"]
            record[f"{detector_name} bar"] = bar
            record[f"{detector_name} measurement"] = value
            if value is None:
                record[f"{detector_name} assumption"] = "missing"
                record[f"{detector_name} margin vs bar %"] = None
                continue
            call, margin = classifier.detector_call(value, bar)
            record[f"{detector_name} assumption"] = call
            record[f"{detector_name} margin vs bar %"] = margin
            detector_results.append({"detector": detector_name, "call": call, "margin": margin})

        if detector_results:
            verdict = classifier.final_classification([item["call"] for item in detector_results])
            confidence = classifier.confidence_level(verdict, detector_results)
            crossed = [
                item["detector"]
                for item in detector_results
                if item["call"] == "IBD-like"
            ]
            crossed_text = ", ".join(crossed) if crossed else "No detector crossed above bar"
        else:
            verdict = "missing"
            confidence = ""
            crossed_text = "No detector measurement available"

        record["Final classification"] = verdict
        record["Confidence level"] = confidence
        record["Detector(s) crossed above bar"] = crossed_text
        record["Measurement status"] = ws.cell(row, status_col).value
        records.append(record)

        ws.cell(row, final_col).value = verdict
        color_final(ws.cell(row, final_col), verdict)
        filled.append((row, sample, verdict))

    try:
        wb.save(FINAL_PATH)
        saved_final = FINAL_PATH
    except PermissionError:
        wb.save(OUTPUT_PATH)
        saved_final = OUTPUT_PATH

    out = Workbook()
    out_ws = out.active
    out_ws.title = "Classifier results"
    result_headers = [
        "Sample name",
        "Final workbook row",
        "PA447 bar",
        "PA447 measurement",
        "PA447 assumption",
        "PA447 margin vs bar %",
        "araE bar",
        "araE measurement",
        "araE assumption",
        "araE margin vs bar %",
        "Final classification",
        "Detector(s) crossed above bar",
        "Measurement status",
        "Confidence level",
    ]
    out_ws.append(result_headers)
    for record in records:
        out_ws.append([record.get(header) for header in result_headers])
    for cell in out_ws[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor="D9D9D9")
        cell.font = Font(name="Calibri", size=11, bold=True)
    for row in out_ws.iter_rows(min_row=2):
        for cell in row:
            color_agent_cell(cell, cell.value)
    for col in range(1, out_ws.max_column + 1):
        out_ws.column_dimensions[out_ws.cell(1, col).column_letter].width = 22
    out.save(AGENT_RESULTS_PATH)

    print(
        {
            "bars": {key: value["bar"] for key, value in bars.items()},
            "training_sources": sources,
            "filled_count": len(filled),
            "filled_counts": dict(Counter(item[2] for item in filled)),
            "saved_final": str(saved_final),
            "agent_results": str(AGENT_RESULTS_PATH),
            "filled_examples": filled[:20],
        }
    )


if __name__ == "__main__":
    main()
