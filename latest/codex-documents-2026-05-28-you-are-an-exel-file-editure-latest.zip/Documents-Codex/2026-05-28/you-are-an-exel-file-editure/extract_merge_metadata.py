from collections import defaultdict
from pathlib import Path
import json
import re

from openpyxl import load_workbook

import build_accounted_known_unknown as builder


FOLDER = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
SOURCE_FINAL = FOLDER / "Merged Unknowns trial 6.26.xlsx"
OLD_SAMPLES = FOLDER / "Old sampels"
OUTPUT = WORKSPACE / "merged_metadata_overrides.json"


def clean(value):
    return builder.clean(value)


def header_text(value):
    return (clean(value) or "").lower().strip()


def is_sample_header(text):
    text = text.lower().strip()
    if not text:
        return False
    return (
        "sample code" in text
        or "sample name" in text
        or text in {"sample", "sample #", "samplecode"}
        or "קוד דגימה" in text
    )


def is_alias_header(text):
    text = text.lower().strip()
    return text in {"patient number", "patient number ", "name"} or "מספר מטופל" in text


def is_sample_date_header(text):
    text = text.lower().strip()
    if not text:
        return False
    if "birth" in text or text == "dob" or "calprotectin" in text:
        return False
    return (
        text == "date"
        or "sample date" in text
        or "תאריך ביקור" in text
        or "תאריך דגימה" in text
    )


def is_date_sent_header(text):
    text = text.lower().strip()
    return "date sent" in text or "sent date" in text


def is_calprotectin_header(text):
    text = text.lower().strip()
    return (
        text == "calpro"
        or "calprotectin" in text
        or "fecal calprotectin" in text
        or text == "fc baseline"
    )


def is_disease_location_header(text):
    text = text.lower().strip()
    return (
        text == "ibd"
        or text == "details"
        or "disease location" in text
        or "disease placement" in text
    )


def header_map(ws, row_index):
    values = [ws.cell(row_index, col).value for col in range(1, ws.max_column + 1)]
    headers = [header_text(value) for value in values]
    sample_cols = [i + 1 for i, text in enumerate(headers) if is_sample_header(text)]
    alias_cols = [i + 1 for i, text in enumerate(headers) if is_alias_header(text)]
    sample_date_cols = [i + 1 for i, text in enumerate(headers) if is_sample_date_header(text)]
    date_sent_cols = [i + 1 for i, text in enumerate(headers) if is_date_sent_header(text)]
    calprotectin_cols = [i + 1 for i, text in enumerate(headers) if is_calprotectin_header(text)]
    disease_location_cols = [i + 1 for i, text in enumerate(headers) if is_disease_location_header(text)]
    if sample_cols and (sample_date_cols or date_sent_cols or calprotectin_cols or disease_location_cols):
        return {
            "sample_cols": sample_cols,
            "alias_cols": alias_cols,
            "sample_date_cols": sample_date_cols,
            "date_sent_cols": date_sent_cols,
            "calprotectin_cols": calprotectin_cols,
            "disease_location_cols": disease_location_cols,
        }
    return None


def source_rank(file_name):
    name = file_name.lower()
    if name == "aliqauts 20250112.xlsx":
        return 0
    if "all stool aliquots updated 10.8.23" in name:
        return 1
    if "stool aliquots updated.xlsx" in name:
        return 2
    if "stools  to bar ilan uid" in name:
        return 3
    return 4


def metadata_diagnosis_from_sheet(sheet_name):
    text = (clean(sheet_name) or "").lower()
    if not text or "unknown" in text:
        return None
    if "healthy" in text or text in {"hs", "h"}:
        return "Healthy"
    if text == "ibs" or "ibs" in text:
        return "IBS"
    if text == "cdr" or "remission" in text or "רמיס" in text:
        return "CDr"
    if text == "cdf" or "מתלקח" in text:
        return "CDf"
    if text == "uc" or text.startswith("uc"):
        return "UC"
    group = builder.canonical_group(sheet_name)
    if builder.diagnosis_family(group) in {"IBD", "IBS", "Healthy"}:
        return group
    return None


def collect_metadata_sources():
    source_folder = FOLDER / "deta" if (FOLDER / "deta").exists() else FOLDER
    files = [source_folder / "aliqauts 20250112.xlsx"]
    if OLD_SAMPLES.exists():
        files.extend(sorted(OLD_SAMPLES.rglob("*.xlsx")))

    by_key = defaultdict(list)
    for path in files:
        try:
            wb = load_workbook(path, data_only=True, read_only=True)
        except Exception:
            continue
        for ws in wb.worksheets:
            sheet_diagnosis = metadata_diagnosis_from_sheet(ws.title)
            active_headers = None
            for row_index in range(1, ws.max_row + 1):
                detected = header_map(ws, row_index)
                if detected:
                    active_headers = detected
                    continue
                if not active_headers:
                    continue

                sample_values = []
                for col in active_headers["sample_cols"] + active_headers["alias_cols"]:
                    value = clean(ws.cell(row_index, col).value)
                    if value and value.lower() not in {"sample", "sample #", "sample code", "samplecode", "patient number", "name"}:
                        sample_values.append(value)
                if not sample_values:
                    continue

                sample_date = None
                for col in active_headers["sample_date_cols"]:
                    sample_date = builder.date_text(ws.cell(row_index, col).value)
                    if sample_date:
                        break

                date_sent = None
                for col in active_headers["date_sent_cols"]:
                    date_sent = builder.date_text(ws.cell(row_index, col).value)
                    if date_sent:
                        break

                calprotectin = None
                for col in active_headers["calprotectin_cols"]:
                    raw_calprotectin = ws.cell(row_index, col).value
                    calprotectin_text = clean(raw_calprotectin)
                    if calprotectin_text and calprotectin_text.upper() not in {"N/A", "NA"}:
                        calprotectin = raw_calprotectin if isinstance(raw_calprotectin, (int, float)) else calprotectin_text
                        break
                    calprotectin = None

                disease_location = None
                for col in active_headers["disease_location_cols"]:
                    disease_location = clean(ws.cell(row_index, col).value)
                    if disease_location and disease_location.upper() not in {"N/A", "NA"}:
                        break
                    disease_location = None

                if not sample_date and not date_sent and not calprotectin and not disease_location:
                    continue

                entry = {
                    "sample_date": sample_date,
                    "date_sent": date_sent,
                    "calprotectin_level": calprotectin,
                    "disease_location": disease_location,
                    "diagnosis": sheet_diagnosis,
                    "source": f"{path.name} | {ws.title} row {row_index}",
                    "rank": source_rank(path.name),
                }
                for key in builder.identifier_variants(*sample_values):
                    by_key[key].append(entry)
    return by_key


def best_metadata(keys, by_key, diagnosis=None):
    candidates = []
    seen = set()
    for key in keys:
        for entry in by_key.get(key, []):
            if diagnosis and entry.get("diagnosis") and not builder.compatible(diagnosis, entry.get("diagnosis")):
                continue
            marker = (entry.get("sample_date"), entry.get("date_sent"), entry.get("source"))
            if marker in seen:
                continue
            seen.add(marker)
            candidates.append(entry)
    if not candidates:
        return None
    candidates.sort(key=lambda item: (item["rank"], item.get("source") or ""))
    merged = {
        "sample_date": None,
        "date_sent": None,
        "calprotectin_level": None,
        "disease_location": None,
        "metadata_sources": [],
    }
    for entry in candidates:
        if not merged["sample_date"] and entry.get("sample_date"):
            merged["sample_date"] = entry["sample_date"]
            merged["metadata_sources"].append(entry["source"])
        if not merged["date_sent"] and entry.get("date_sent"):
            merged["date_sent"] = entry["date_sent"]
            merged["metadata_sources"].append(entry["source"])
        if not merged["calprotectin_level"] and entry.get("calprotectin_level"):
            merged["calprotectin_level"] = entry["calprotectin_level"]
            merged["metadata_sources"].append(entry["source"])
        if not merged["disease_location"] and entry.get("disease_location"):
            merged["disease_location"] = entry["disease_location"]
            merged["metadata_sources"].append(entry["source"])
    merged["metadata_sources"] = sorted(set(merged["metadata_sources"]))
    return merged if any(merged.get(field) for field in ["sample_date", "date_sent", "calprotectin_level", "disease_location"]) else None


def unknown_measurement_status(row, headers):
    idx = {header: i for i, header in enumerate(headers)}
    measurement_headers = [
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
    ]
    return "measured" if any(row[idx[header]] not in (None, "") for header in measurement_headers) else builder.MISSING


def main():
    by_key = collect_metadata_sources()
    wb = load_workbook(SOURCE_FINAL, data_only=True)
    overrides = {}
    stats = {
        "metadata_keys": len(by_key),
        "unknown_rows": wb["Unknown"].max_row - 1,
        "known_rows": wb["Known"].max_row - 1,
        "sample_date_filled": 0,
        "date_sent_filled": 0,
        "calprotectin_level_filled": 0,
        "disease_location_filled": 0,
    }

    unknown = wb["Unknown"]
    unknown_headers = [cell.value for cell in unknown[1]]
    unknown_idx = {header: i for i, header in enumerate(unknown_headers)}
    for row_index in range(2, unknown.max_row + 1):
        row = [unknown.cell(row_index, col).value for col in range(1, unknown.max_column + 1)]
        primary = row[unknown_idx["Unknown name"]]
        secondary = row[unknown_idx["Real name"]]
        keys = builder.identifier_variants(primary, secondary)
        row_diagnosis = row[unknown_idx.get("Diagnosis")] if "Diagnosis" in unknown_idx else None
        meta = best_metadata(keys, by_key, row_diagnosis) or {"sample_date": None, "date_sent": None, "metadata_sources": []}
        overrides[f"Unknown:{row_index}"] = {
            "measurement_status": unknown_measurement_status(row, unknown_headers),
            "match_basis": "Unknown trial row; names matched from UN stool names and aliquots aliases",
            "measurement_source_file": "Unknowns trial 6.26.xlsx; UN stool names.xlsx; aliqauts 20250112.xlsx",
            "sample_date": meta.get("sample_date"),
            "date_sent": meta.get("date_sent"),
            "calprotectin_level": meta.get("calprotectin_level"),
            "disease_location": meta.get("disease_location"),
            "metadata_sources": meta.get("metadata_sources", []),
        }
        if meta.get("sample_date"):
            stats["sample_date_filled"] += 1
        if meta.get("date_sent"):
            stats["date_sent_filled"] += 1
        if meta.get("calprotectin_level"):
            stats["calprotectin_level_filled"] += 1
        if meta.get("disease_location"):
            stats["disease_location_filled"] += 1

    known = wb["Known"]
    known_headers = [cell.value for cell in known[1]]
    known_idx = {header: i for i, header in enumerate(known_headers)}
    for row_index in range(2, known.max_row + 1):
        row = [known.cell(row_index, col).value for col in range(1, known.max_column + 1)]
        primary = row[known_idx["Sample name"]]
        secondary = row[known_idx["Synonym / other name"]]
        keys = builder.identifier_variants(primary, secondary)
        row_diagnosis = row[known_idx.get("Diagnosis")] if "Diagnosis" in known_idx else None
        meta = best_metadata(keys, by_key, row_diagnosis)
        if not meta:
            continue
        item = {}
        if not row[known_idx["Sample date"]] and meta.get("sample_date"):
            item["sample_date"] = meta["sample_date"]
            stats["sample_date_filled"] += 1
        if not row[known_idx["Date sent"]] and meta.get("date_sent"):
            item["date_sent"] = meta["date_sent"]
            stats["date_sent_filled"] += 1
        if meta.get("calprotectin_level"):
            item["calprotectin_level"] = meta["calprotectin_level"]
            stats["calprotectin_level_filled"] += 1
        if meta.get("disease_location"):
            item["disease_location"] = meta["disease_location"]
            stats["disease_location_filled"] += 1
        if item:
            item["metadata_sources"] = meta.get("metadata_sources", [])
            overrides[f"Known:{row_index}"] = item

    report = {"stats": stats, "overrides": overrides}
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
