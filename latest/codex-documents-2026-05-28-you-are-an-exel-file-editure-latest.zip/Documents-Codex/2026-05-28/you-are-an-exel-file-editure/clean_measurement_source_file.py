from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import re

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BUILDER_PATH = WORKSPACE / "build_accounted_known_unknown.py"


def load_builder():
    spec = spec_from_file_location("builder", BUILDER_PATH)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def expand_with_aliases(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def row_keys(builder, primary, secondary):
    keys = set()
    keys.update(builder.identifier_variants(primary, secondary))
    keys.update(builder.strict_identifier_variants(primary, secondary))
    return {key for key in keys if key}


def filename(path_text):
    if not path_text:
        return None
    text = str(path_text).strip().replace("/", "\\")
    return text.split("\\")[-1]


def source_filename(item):
    name = filename(item.get("source_file"))
    if name:
        return name
    source = item.get("source")
    if source == "IBD IBS OLD":
        return "IBD IBS OLD.xlsx"
    if source == "447 and araE ALL":
        return "447 and araE ALL.xlsx"
    return None


def filenames_from_source_cell(text):
    if not text:
        return {"PA447": [], "araE": []}
    result = {"PA447": [], "araE": []}
    for detector in result:
        pattern = rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE|Metadata):|$)"
        match = re.search(pattern, text, flags=re.I)
        if not match:
            continue
        segment = match.group(1)
        files = re.findall(r"\(([^)]*\.xlsx)\)", segment, flags=re.I)
        for item in files:
            name = filename(item)
            if name and name not in result[detector]:
                result[detector].append(name)
    return result


def item_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def source_priority(item):
    source = item.get("source")
    if source == "edited normalized files":
        return 0
    if source == "IBD IBS OLD":
        return 1
    if source == "447 and araE ALL":
        return 2
    return 3


def source_sort_key(item):
    return (
        source_priority(item),
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item.get("source_name") or ""),
        str(item_value(item, "PA447") if item.get("pa447") is not None else item.get("araE")),
    )


def compatible_source_items(builder, all_by_key, old_rows, aliases_by_key, primary, secondary, diagnosis, detector):
    keys = expand_with_aliases(row_keys(builder, primary, secondary), aliases_by_key)
    candidates = []
    for key in keys:
        candidates.extend(all_by_key.get(key, []))
    candidates.extend(
        old for old in old_rows if keys & (old.get("identifiers", set()) | old.get("strict_identifiers", set()))
    )
    filtered = []
    for item in candidates:
        value = item_value(item, detector)
        if value is None:
            continue
        if detector == "PA447" and item.get("pa447_removed_reason"):
            continue
        if not (builder.compatible(diagnosis, item.get("diagnosis")) or item.get("diagnosis") is None):
            continue
        filtered.append(item)
    if any(item.get("source") == "edited normalized files" for item in filtered):
        filtered = [item for item in filtered if item.get("source") == "edited normalized files"]
    unique = {}
    for item in sorted(filtered, key=source_sort_key):
        name = source_filename(item)
        if name:
            unique[name] = item
    return list(unique)


def displayed_values(ws, row, headers, detector):
    return [
        ws.cell(row, headers[f"{detector} measurement {idx}"]).value
        for idx in (1, 2, 3)
        if ws.cell(row, headers[f"{detector} measurement {idx}"]).value not in (None, "")
    ]


def almost_equal(left, right, tolerance=1e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def diagnosis_allows(builder, row_diagnosis, item_diagnosis):
    if not row_diagnosis or str(row_diagnosis).strip().lower() == "unknown":
        return True
    return builder.compatible(row_diagnosis, item_diagnosis) or item_diagnosis is None


def source_files_for_displayed_values(
    builder,
    all_by_key,
    old_rows,
    aliases_by_key,
    primary,
    secondary,
    diagnosis,
    detector,
    values,
):
    if not values:
        return []
    keys = expand_with_aliases(row_keys(builder, primary, secondary), aliases_by_key)
    candidates = []
    for key in keys:
        candidates.extend(all_by_key.get(key, []))
    candidates.extend(
        old for old in old_rows if keys & (old.get("identifiers", set()) | old.get("strict_identifiers", set()))
    )

    matched = []
    for value in values:
        value_matches = []
        for item in candidates:
            item_val = item_value(item, detector)
            if item_val is None or not almost_equal(item_val, value):
                continue
            if detector == "PA447" and item.get("pa447_removed_reason"):
                continue
            if not diagnosis_allows(builder, diagnosis, item.get("diagnosis")):
                continue
            name = source_filename(item)
            if name:
                value_matches.append((source_priority(item), str(item.get("source_date") or ""), name))
        if value_matches:
            value_matches.sort()
            best_name = value_matches[0][2]
            if best_name not in matched:
                matched.append(best_name)
    return matched


def source_files_and_unmatched_values(
    builder,
    all_by_key,
    old_rows,
    aliases_by_key,
    primary,
    secondary,
    diagnosis,
    detector,
    values,
):
    matched = []
    unmatched = []
    for value in values:
        names = source_files_for_displayed_values(
            builder,
            all_by_key,
            old_rows,
            aliases_by_key,
            primary,
            secondary,
            diagnosis,
            detector,
            [value],
        )
        if names:
            for name in names:
                if name not in matched:
                    matched.append(name)
        else:
            unmatched.append(value)
    return matched, unmatched


def old_metering_files(builder, all_by_key, aliases_by_key, primary, secondary):
    keys = expand_with_aliases(row_keys(builder, primary, secondary), aliases_by_key)
    names = []
    for key in keys:
        for item in all_by_key.get(key, []):
            if item.get("pa447_removed_reason") != "Found in 447-old without GA/glutaric marker":
                continue
            for hit in item.get("pa447_447_old_hits", []):
                name = filename(hit.get("file"))
                if name and name not in names:
                    names.append(name)
    return names


def detector_has_value(ws, row, headers, detector):
    return any(
        ws.cell(row, headers[f"{detector} measurement {idx}"]).value not in (None, "")
        for idx in (1, 2, 3)
    )


def clean_source_for_row(builder, all_by_key, old_rows, aliases_by_key, ws, row, headers):
    primary = ws.cell(row, headers["Primary name"]).value
    secondary = ws.cell(row, headers["Secondary / other name"]).value
    diagnosis = ws.cell(row, headers["Diagnosis"]).value
    status = ws.cell(row, headers["Measurement status"]).value
    source_text = ws.cell(row, headers["Measurement/source file"]).value

    parts = []
    if status == "old metering system":
        names = old_metering_files(builder, all_by_key, aliases_by_key, primary, secondary)
        return f"PA447: {', '.join(names)}" if names else None

    parsed = filenames_from_source_cell(source_text)
    for detector in ("PA447", "araE"):
        if not detector_has_value(ws, row, headers, detector):
            continue
        values = displayed_values(ws, row, headers, detector)
        names, unmatched_values = source_files_and_unmatched_values(
            builder,
            all_by_key,
            old_rows,
            aliases_by_key,
            primary,
            secondary,
            diagnosis,
            detector,
            values,
        )
        if unmatched_values and ws.cell(row, headers["Original tab"]).value == "Unknown":
            if "Unknowns trial 6.26.xlsx" not in names:
                names.append("Unknowns trial 6.26.xlsx")
        names = names or parsed.get(detector) or compatible_source_items(
            builder,
            all_by_key,
            old_rows,
            aliases_by_key,
            primary,
            secondary,
            diagnosis,
            detector,
        )
        if not names and ws.cell(row, headers["Original tab"]).value == "Unknown":
            names = ["Unknowns trial 6.26.xlsx"]
        if names:
            parts.append(f"{detector}: {', '.join(names[:3])}")
    return "; ".join(parts) if parts else None


def main():
    builder = load_builder()
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    all_rows, all_by_key = builder.load_all_measurements()
    old_rows = builder.load_old_rows()

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)
    source_col = headers["Measurement/source file"]

    changed = []
    missing_sources = []
    for row in range(2, ws.max_row + 1):
        clean_source = clean_source_for_row(builder, all_by_key, old_rows, aliases_by_key, ws, row, headers)
        old_source = ws.cell(row, source_col).value
        ws.cell(row, source_col).value = clean_source
        if old_source != clean_source:
            changed.append((row, ws.cell(row, headers["Primary name"]).value, clean_source))
        if clean_source is None and (
            detector_has_value(ws, row, headers, "PA447") or detector_has_value(ws, row, headers, "araE")
        ):
            missing_sources.append((row, ws.cell(row, headers["Primary name"]).value))

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "changed_rows": len(changed),
            "missing_sources_for_measured_rows": missing_sources[:50],
            "changed_examples": changed[:20],
        }
    )


if __name__ == "__main__":
    main()
