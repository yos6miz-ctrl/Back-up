from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import importlib.util
import json


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
IMPORTER_PATH = WORKSPACE / "import_2026_measurements.py"
OUT = WORKSPACE / "dry_run_20260819_import_report.json"


spec = importlib.util.spec_from_file_location("importer", IMPORTER_PATH)
importer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(importer)


def main():
    state = importer.load_state()
    current_files = [p for p in sorted(importer.MEASUREMENT_DIR.glob("*.xlsx")) if not p.name.startswith("~$")]
    current_records = {p.name: importer.file_record(p) for p in current_files}
    files_to_process = []
    for path in current_files:
        previous = state.get("files", {}).get(path.name)
        current = current_records[path.name]
        if previous is None or previous.get("sha256") != current["sha256"]:
            files_to_process.append(path)
        elif str(previous.get("status") or "").startswith("baseline_seen_not_imported"):
            files_to_process.append(path)

    extracted = []
    for path in files_to_process:
        records = importer.extract_normalized_records(path)
        extracted.extend(records)

    aliquots = importer.load_sample_records()
    aliases = importer.build_aliases_from_aliquots(aliquots)
    by_sample = defaultdict(list)
    no_aliquot = []
    for record in extracted:
        aliquot = importer.aliquot_for_record(record, aliquots, aliases)
        item = {
            "raw_sample_name": record["sample_name"],
            "detector": record["detector"],
            "value": record["value"],
            "source_file": record["source_file"],
            "source_cell": record["source_cell"],
            "aliquot_primary": aliquot.get("primary") if aliquot else None,
            "aliquot_secondary": aliquot.get("secondary") if aliquot else None,
            "diagnosis": aliquot.get("diagnosis") if aliquot else None,
            "sample_date": aliquot.get("sample_date") if aliquot else None,
            "aliquots_source": f"{aliquot.get('source_sheet')} row {aliquot.get('source_row')}" if aliquot else None,
        }
        if aliquot:
            by_sample[(item["aliquot_primary"], item["aliquot_secondary"], item["sample_date"])].append(item)
        else:
            no_aliquot.append(item)

    report = {
        "files_to_process": [p.name for p in files_to_process],
        "extracted_count": len(extracted),
        "grouped_samples": [
            {
                "primary": key[0],
                "secondary": key[1],
                "sample_date": key[2],
                "measurements": values,
            }
            for key, values in sorted(by_sample.items(), key=lambda kv: str(kv[0]))
        ],
        "no_aliquot_match": no_aliquot,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
