from __future__ import annotations

from collections import Counter, defaultdict
from copy import copy
from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import hashlib
import json
import math
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
ONEDRIVE_FINAL_PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip") / FINAL_PATH.name
MEASUREMENT_DIR = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026")
ALIQUOTS_PATH = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
STATE_PATH = WORKSPACE / "measurement_import_state_447_arae_2026.json"
REPORT_PATH = WORKSPACE / "measurement_import_2026_report.json"
BACKUP_DIR = WORKSPACE / "backups"
BUILDER_PATH = WORKSPACE / "build_accounted_known_unknown.py"
CLASSIFIER_PATH = (
    Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
    / "skills"
    / "classifier"
    / "scripts"
    / "run_threshold_bar_classifier.py"
)

SOFT_YELLOW = "FFF2CC"
HEADER_FILL = "D9D9D9"
DIAG_FILLS = {
    "CDf": "FFE06666",
    "CDr": "FFF4CCCC",
    "UCf": "FFF6B26B",
    "UCr": "FFFCE5CD",
    "IBS": "FF3C78D8",
    "Healthy": "FFCFE2F3",
}
FINAL_STYLES = {
    "IBD": ("C00000", "FFFFFF"),
    "IBS": ("003399", "FFFFFF"),
    "inconclusive": ("D9D2E9", "4C3868"),
    "missing": ("E7E6E6", "666666"),
    "לא נבדק": ("D9D2E9", "4C3868"),
}
DETECTOR_STYLES = {
    "Pos": ("F4C7C3", "5A1212"),
    "Neg": ("CFE2F3", "17365D"),
    "Int": ("FFF2CC", "7F6000"),
}


def load_module(name: str, path: Path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load_module("builder", BUILDER_PATH)
classifier = load_module("ibd_ibs_classifier", CLASSIFIER_PATH)


def clean(value):
    return builder.clean(value)


def norm(value):
    return builder.norm(value)


def canonical_group(value):
    return builder.canonical_group(value)


def date_text(value):
    return builder.date_text(value)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def file_record(path: Path) -> dict:
    stat = path.stat()
    return {
        "name": path.name,
        "path": str(path),
        "size": stat.st_size,
        "mtime": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
        "sha256": file_hash(path),
    }


def load_state() -> dict:
    if not STATE_PATH.exists():
        return {"files": {}}
    return json.loads(STATE_PATH.read_text(encoding="utf-8"))


def filename_date(path: Path):
    match = re.search(r"(20\d{6})", path.name)
    if not match:
        return None
    text = match.group(1)
    return f"{text[:4]}-{text[4:6]}-{text[6:]}"


def is_2026_new_sample_source(path_or_name) -> bool:
    path = Path(str(path_or_name))
    try:
        return path.resolve().parent == MEASUREMENT_DIR.resolve()
    except OSError:
        return True


def detector_from_path(path: Path) -> str:
    return "araE" if "arae" in path.name.lower() else "PA447"


def is_numeric(value) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def is_sample_label(value) -> bool:
    text = clean(value)
    if not text:
        return False
    if text.startswith("="):
        return False
    low = text.lower()
    if low in {"control", "cont", "glutaric acid", "glutaric", "arabinose", "ara", "s"}:
        return False
    if "control" in low or "glutaric" in low or "arabinose" in low:
        return False
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?", text):
        return False
    return bool(norm(text))


def has_required_marker(workbook, detector: str) -> bool:
    markers = []
    for ws in workbook.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 5), values_only=True):
            for value in row:
                text = (clean(value) or "").lower()
                if text:
                    markers.append(text)
    joined = " ".join(markers)
    if detector == "PA447":
        return "glutaric" in joined or re.search(r"\bga\b", joined) is not None
    return "arabinose" in joined or re.search(r"\bara\b", joined) is not None


def header_for_normalized_cell(ws, row: int, col: int):
    for header_row in range(row - 1, 0, -1):
        value = ws.cell(header_row, col).value
        if isinstance(value, str) and value.startswith("="):
            continue
        if is_sample_label(value):
            text = clean(value)
            text = re.sub(r"^(?:P?A?0?447|P447|447|ARAE)\s*[-:]?\s*", "", text, flags=re.I)
            return clean(text)
    return None


def extract_normalized_records(path: Path) -> list[dict]:
    detector = detector_from_path(path)
    formula_wb = load_workbook(path, data_only=False, read_only=False)
    values_wb = load_workbook(path, data_only=True, read_only=False)
    if not has_required_marker(formula_wb, detector):
        return []

    records = []
    for ws in formula_wb.worksheets:
        values_ws = values_wb[ws.title]
        for row in range(1, min(ws.max_row, 12) + 1):
            for col in range(2, ws.max_column + 1):
                formula = ws.cell(row, col).value
                value = values_ws.cell(row, col).value
                if not (isinstance(formula, str) and formula.startswith("=") and "/" in formula):
                    continue
                if not is_numeric(value):
                    continue
                sample_name = header_for_normalized_cell(ws, row, col)
                if not sample_name:
                    continue
                keys = builder.identifier_variants(sample_name)
                if not keys:
                    continue
                records.append(
                    {
                        "sample_name": sample_name,
                        "detector": detector,
                        "value": float(value),
                        "source_file": path.name,
                        "source_date": filename_date(path),
                        "is_new_shipment": is_2026_new_sample_source(path),
                        "source_cell": f"{ws.title}!{ws.cell(row=row, column=col).coordinate}",
                        "identifiers": keys,
                        "strict_identifiers": builder.strict_identifier_variants(sample_name),
                    }
                )
    return records


def aliquots_header_indices(ws):
    headers = [str(ws.cell(1, col).value or "").strip().lower() for col in range(1, ws.max_column + 1)]

    def find(*needles):
        for index, header in enumerate(headers, start=1):
            if any(needle in header for needle in needles):
                return index
        return None

    return {
        "patient": find("patient number", "מספר מטופל"),
        "sample": find("sample #", "sample name", "sample"),
        "date": find("date", "תאריך"),
        "calprotectin": find("calpro"),
        "disease_location": find("disease location", "disease placement"),
        "diagnosis": find("disease "),
        "pa447_expected": find("447"),
        "arae_expected": find("arae"),
    }


def load_aliquot_records() -> list[dict]:
    wb = load_workbook(ALIQUOTS_PATH, data_only=True, read_only=False)
    records = []
    for ws in wb.worksheets:
        cols = aliquots_header_indices(ws)
        for row in range(2, ws.max_row + 1):
            sample = clean(ws.cell(row, cols["sample"]).value) if cols["sample"] else None
            patient = clean(ws.cell(row, cols["patient"]).value) if cols["patient"] else None
            if patient == "1":
                patient = None
            if not sample and not patient:
                continue
            diagnosis = canonical_group(ws.cell(row, cols["diagnosis"]).value) if cols["diagnosis"] else None
            if not diagnosis and ws.title in {"CDf", "CDr", "IBS", "Healthy", "UC"}:
                diagnosis = canonical_group(ws.title)
            identifiers = builder.identifier_variants(sample, patient)
            strict_identifiers = builder.strict_identifier_variants(sample, patient)
            if not identifiers:
                continue
            records.append(
                {
                    "primary": sample or patient,
                    "secondary": patient if sample and patient and norm(sample) != norm(patient) else None,
                    "sample_date": date_text(ws.cell(row, cols["date"]).value) if cols["date"] else None,
                    "diagnosis": diagnosis,
                    "calprotectin": ws.cell(row, cols["calprotectin"]).value if cols["calprotectin"] else None,
                    "disease_location": ws.cell(row, cols["disease_location"]).value if cols["disease_location"] else None,
                    "pa447_expected": ws.cell(row, cols["pa447_expected"]).value if cols["pa447_expected"] else None,
                    "arae_expected": ws.cell(row, cols["arae_expected"]).value if cols["arae_expected"] else None,
                    "source_sheet": ws.title,
                    "source_row": row,
                    "identifiers": identifiers,
                    "strict_identifiers": strict_identifiers,
                }
            )
    return records


def build_aliases_from_aliquots(records: list[dict]) -> dict:
    aliases = defaultdict(set)
    for record in records:
        keys = set(record["identifiers"]) | set(record["strict_identifiers"])
        for key in keys:
            aliases[key].update(keys)
    builder.apply_manual_aliases(aliases)
    return aliases


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def keys_for_values(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def aliquot_for_record(record, aliquots, aliases_by_key):
    record_keys = expand_keys(set(record["identifiers"]) | set(record["strict_identifiers"]), aliases_by_key)
    hits = []
    for aliquot in aliquots:
        aliquot_keys = expand_keys(set(aliquot["identifiers"]) | set(aliquot["strict_identifiers"]), aliases_by_key)
        if record_keys & aliquot_keys:
            hits.append(aliquot)
    if not hits:
        return None
    hits.sort(key=lambda item: (item["source_sheet"] != "Unknown", item["source_row"]))
    return hits[0]


def row_keyset(ws, headers, row, aliases_by_key):
    keys = keys_for_values(
        ws.cell(row, headers["Primary name"]).value,
        ws.cell(row, headers["Secondary / other name"]).value,
    )
    return expand_keys(keys, aliases_by_key)


def rebuild_key_to_rows(ws, headers, aliases_by_key):
    key_to_rows = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        for key in row_keyset(ws, headers, row, aliases_by_key):
            key_to_rows[key].append(row)
    return key_to_rows


def final_row_candidates(record, key_to_rows, aliases_by_key):
    record_keys = expand_keys(set(record["identifiers"]) | set(record["strict_identifiers"]), aliases_by_key)
    rows = []
    seen = set()
    for key in record_keys:
        for row in key_to_rows.get(key, []):
            if row not in seen:
                rows.append(row)
                seen.add(row)
    return sorted(rows)


def same_excel_date(left, right) -> bool:
    if left in (None, "") or right in (None, ""):
        return False
    left_text = left.strftime("%Y-%m-%d") if hasattr(left, "strftime") else str(left)[:10]
    right_text = right.strftime("%Y-%m-%d") if hasattr(right, "strftime") else str(right)[:10]
    return left_text == right_text


def shipment_row_candidates_by_date(record, candidates, ws, headers):
    sample_date = record.get("sample_date")
    matches = []
    for row in candidates:
        row_date = ws.cell(row, headers["Sample date"]).value
        if same_excel_date(row_date, sample_date):
            matches.append(row)
    return sorted(set(matches))


def detector_columns(headers, detector):
    return [headers[f"{detector} measurement {index}"] for index in (1, 2, 3)]


def numeric_values(ws, row, cols):
    values = []
    for col in cols:
        value = ws.cell(row, col).value
        if is_numeric(value):
            values.append(float(value))
    return values


def blank_measurement_col(ws, row, cols):
    for col in cols:
        if ws.cell(row, col).value in (None, ""):
            return col
    return None


def almost_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def detector_family(value, bar):
    call, _margin = classifier.detector_call(value, bar)
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    return "inconclusive"


def resembles_existing(existing_values, candidate_value, bar):
    candidate = detector_family(candidate_value, bar)
    existing = [detector_family(value, bar) for value in existing_values]
    conclusive_counts = Counter(family for family in existing if family in {"IBD", "IBS"})
    if candidate in {"IBD", "IBS"}:
        opposing_count = sum(count for family, count in conclusive_counts.items() if family != candidate)
        if opposing_count >= 2:
            return False, "candidate is the odd value against two existing agreeing detector calls"
    if candidate == "inconclusive":
        return True, "candidate is inconclusive and does not contradict existing values"
    return True, "candidate matches existing detector diagnosis"


def parse_source_cell(text):
    parts = {"PA447": [], "araE": []}
    if not text:
        return parts
    for detector in parts:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", str(text), flags=re.I)
        if not match:
            continue
        for item in match.group(1).split(","):
            name = item.strip().replace("/", "\\").split("\\")[-1]
            if name and name.lower().endswith(".xlsx") and name not in parts[detector]:
                parts[detector].append(name)
    return parts


def write_source_cell(ws, row, headers, detector, source_file):
    parts = parse_source_cell(ws.cell(row, headers["Measurement/source file"]).value)
    if source_file not in parts[detector]:
        parts[detector].append(source_file)
    segments = []
    for key in ("PA447", "araE"):
        if parts[key]:
            segments.append(f"{key}: {', '.join(parts[key][:3])}")
    ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments) if segments else None


def clone_row_style(ws, src_row: int, dest_row: int):
    for col in range(1, ws.max_column + 1):
        src = ws.cell(src_row, col)
        dest = ws.cell(dest_row, col)
        if src.has_style:
            dest._style = copy(src._style)
        if src.number_format:
            dest.number_format = src.number_format
        if src.alignment:
            dest.alignment = copy(src.alignment)
        if src.border:
            dest.border = copy(src.border)


def style_diagnosis(cell, value):
    fill = DIAG_FILLS.get(value)
    if fill:
        cell.fill = PatternFill(fill_type="solid", fgColor=fill)
        cell.font = Font(name="Calibri", size=11, color="000000", bold=False)
    else:
        cell.fill = PatternFill(fill_type=None)
        cell.font = Font(name="Calibri", size=11, color="000000", bold=False)


def style_final(cell, value):
    fill, font = FINAL_STYLES.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def style_detector(cell, value):
    fill, font = DETECTOR_STYLES.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def detector_decision_text(call):
    if call == "IBD-like":
        return "Pos"
    if call == "IBS-like":
        return "Neg"
    if call == "inconclusive":
        return "Int"
    return None


def call_family(call):
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    if call == "inconclusive":
        return "inconclusive"
    return None


def average(values):
    nums = [float(value) for value in values if value is not None]
    return sum(nums) / len(nums) if nums else None


def closest_pair(entries):
    pairs = []
    for left_index, left in enumerate(entries):
        for right in entries[left_index + 1 :]:
            pairs.append((abs(left["value"] - right["value"]), left, right))
    _distance, left, right = sorted(pairs, key=lambda item: item[0])[0]
    return [left, right]


def consensus_detector(values, bar):
    entries = []
    for index, value in enumerate(values):
        if value is None:
            continue
        call, margin = classifier.detector_call(value, bar)
        entries.append(
            {
                "idx": index,
                "value": float(value),
                "call": call,
                "family": call_family(call),
                "margin": margin,
            }
        )

    if not entries:
        return {"call": None, "decision": None, "problem_indices": []}
    if len(entries) == 1:
        return {
            "call": "inconclusive",
            "decision": "Int",
            "problem_indices": [entries[0]["idx"]],
        }

    groups = defaultdict(list)
    for entry in entries:
        groups[entry["family"]].append(entry)
    conclusive = {key: value for key, value in groups.items() if key in {"IBD", "IBS"}}
    has_ibd = bool(conclusive.get("IBD"))
    has_ibs = bool(conclusive.get("IBS"))
    problem_entries = []

    if len(entries) == 2:
        if has_ibd and has_ibs:
            return {
                "call": "inconclusive",
                "decision": "Int",
                "problem_indices": [entry["idx"] for entry in entries],
            }
        used_entries = entries
    else:
        sorted_groups = sorted(groups.items(), key=lambda item: len(item[1]), reverse=True)
        majority_family, majority_entries = sorted_groups[0]
        if len(majority_entries) >= 2:
            used_entries = majority_entries
            problem_entries = [entry for entry in entries if entry["family"] != majority_family]
        elif has_ibd and has_ibs:
            used_entries = closest_pair(entries)
            problem_entries = [entry for entry in entries if entry not in used_entries]
        else:
            used_entries = entries

    used_value = average([entry["value"] for entry in used_entries])
    call, _margin = classifier.detector_call(used_value, bar)
    return {
        "call": call,
        "decision": detector_decision_text(call),
        "problem_indices": [entry["idx"] for entry in problem_entries],
    }


def reclassify_row(ws, headers, row, bars):
    status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
    final_col = headers["Final classification / decision"]
    if status in {"missing", "לא נבדק"}:
        ws.cell(row, final_col).value = status
        style_final(ws.cell(row, final_col), status)
        return status
    if status == "old metering system":
        return ws.cell(row, final_col).value

    calls = []
    for detector in ("PA447", "araE"):
        cols = detector_columns(headers, detector)
        for col in cols:
            cell = ws.cell(row, col)
            fill_rgb = cell.fill.fgColor.rgb if cell.fill and cell.fill.fill_type == "solid" else None
            if fill_rgb and str(fill_rgb).endswith(SOFT_YELLOW):
                cell.fill = PatternFill(fill_type=None)
        values = [ws.cell(row, col).value if is_numeric(ws.cell(row, col).value) else None for col in cols]
        result = consensus_detector(values, bars[detector]["bar"])
        ws.cell(row, headers[f"{detector} decision"]).value = result["decision"]
        style_detector(ws.cell(row, headers[f"{detector} decision"]), result["decision"])
        for idx in result["problem_indices"]:
            ws.cell(row, cols[idx]).fill = PatternFill(fill_type="solid", fgColor=SOFT_YELLOW)
        if result["call"]:
            calls.append(result["call"])

    final_value = classifier.final_classification(calls) if calls else "missing"
    ws.cell(row, final_col).value = final_value
    style_final(ws.cell(row, final_col), final_value)
    return final_value


def compact_parts(value):
    text = norm(value)
    letters = "".join(re.findall(r"[A-Z]+", text))
    digits = "".join(re.findall(r"\d+", text))
    return letters, digits, digits[-3:] if digits else ""


def similar_names_for_new(ws, headers, primary, secondary, exclude_row=None):
    names = [value for value in (primary, secondary) if value]
    results = []
    for row in range(2, ws.max_row + 1):
        if exclude_row is not None and row == exclude_row:
            continue
        existing_values = [
            ws.cell(row, headers["Primary name"]).value,
            ws.cell(row, headers["Secondary / other name"]).value,
        ]
        for new_name in names:
            new_letters, new_digits, new_last3 = compact_parts(new_name)
            new_norm = norm(new_name)
            for existing in existing_values:
                if not existing:
                    continue
                old_letters, old_digits, old_last3 = compact_parts(existing)
                old_norm = norm(existing)
                if new_norm == old_norm:
                    continue
                reasons = []
                if new_last3 and old_last3 == new_last3:
                    reasons.append("same last 3 digits")
                score = 0.0
                if new_norm and old_norm:
                    from difflib import SequenceMatcher

                    score = SequenceMatcher(None, new_norm, old_norm).ratio()
                    if score >= 0.82:
                        reasons.append(f"fuzzy {score:.2f}")
                if reasons:
                    results.append(
                        {
                            "row": row,
                            "name": existing,
                            "primary": existing_values[0],
                            "secondary": existing_values[1],
                            "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                            "reason": ", ".join(reasons),
                            "score": round(score, 3),
                        }
                    )
    seen = set()
    unique = []
    for item in sorted(results, key=lambda x: (0 if "fuzzy" in x["reason"] else 1, -x["score"], x["row"])):
        key = (item["row"], item["name"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique[:8]


def sort_records(ws, headers):
    status_order = {"measured": 0, "old metering system": 1, "missing": 2, "לא נבדק": 3}
    diagnosis_order = {
        "CDf": 0,
        "CDr": 1,
        "UCf": 2,
        "UCr": 3,
        "UC": 4,
        "IBD": 5,
        "IBS": 6,
        "Healthy": 7,
        "HS": 7,
        "Unknown": 8,
        None: 9,
        "": 9,
    }
    final_order = {"IBD": 0, "inconclusive": 1, "IBS": 2, "missing": 3, "לא נבדק": 4}

    rows = []
    for row in range(2, ws.max_row + 1):
        values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
        styles = []
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            styles.append(
                {
                    "_style": copy(cell._style),
                    "number_format": cell.number_format,
                    "alignment": copy(cell.alignment),
                    "border": copy(cell.border),
                    "fill": copy(cell.fill),
                    "font": copy(cell.font),
                }
            )
        rows.append({"values": values, "styles": styles})

    def key(record):
        vals = {header: record["values"][col - 1] for header, col in headers.items()}
        sample_date = vals.get("Sample date")
        sample_date_key = sample_date.strftime("%Y-%m-%d") if hasattr(sample_date, "strftime") else str(sample_date or "")
        return (
            status_order.get(vals.get("Measurement status"), 99),
            diagnosis_order.get(vals.get("Diagnosis"), 50),
            final_order.get(vals.get("Final classification / decision"), 50),
            str(vals.get("Primary name") or "").upper(),
            str(vals.get("Secondary / other name") or "").upper(),
            sample_date_key,
        )

    rows.sort(key=key)
    for out_index, record in enumerate(rows, start=2):
        for col, value in enumerate(record["values"], start=1):
            cell = ws.cell(out_index, col)
            cell.value = value
            style = record["styles"][col - 1]
            cell._style = copy(style["_style"])
            cell.number_format = style["number_format"]
            cell.alignment = copy(style["alignment"])
            cell.border = copy(style["border"])
            cell.fill = copy(style["fill"])
            cell.font = copy(style["font"])


def remove_comment_and_table_parts(path: Path):
    with zipfile.ZipFile(path, "r") as source:
        keep = [
            item
            for item in source.infolist()
            if not item.filename.startswith("xl/tables/")
            and "comments" not in item.filename.lower()
            and "vmlDrawing" not in item.filename
        ]
        payload = [(item, source.read(item.filename)) for item in keep]
    temp_path = path.with_suffix(".tmp.xlsx")
    with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as target:
        for item, data in payload:
            target.writestr(item, data)
    temp_path.replace(path)


def sync_final_to_onedrive() -> Path:
    ONEDRIVE_FINAL_PATH.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(FINAL_PATH, ONEDRIVE_FINAL_PATH)
    return ONEDRIVE_FINAL_PATH


def main():
    state = load_state()
    current_files = [path for path in sorted(MEASUREMENT_DIR.glob("*.xlsx")) if not path.name.startswith("~$")]
    current_records = {path.name: file_record(path) for path in current_files}

    files_to_process = []
    if not state.get("files"):
        for path in current_files:
            if (filename_date(path) or "") > "2026-07-28":
                files_to_process.append(path)
    else:
        for path in current_files:
            previous = state["files"].get(path.name)
            current = current_records[path.name]
            if previous is None or previous.get("sha256") != current["sha256"]:
                files_to_process.append(path)
            elif str(previous.get("status") or "").startswith("baseline_seen_not_imported"):
                files_to_process.append(path)

    if not files_to_process:
        report = {
            "final_workbook": str(FINAL_PATH),
            "state_file": str(STATE_PATH),
            "files_to_process": [],
            "extracted_count": 0,
            "stats": {},
            "message": "No new or changed measurement files found.",
            "shipment_folder_rule": "Files in the 447 and araE 2026 folder are treated as new shipment samples and matched by sample date instead of collapsed into older rows.",
        }
        REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    extracted = []
    for path in files_to_process:
        extracted.extend(extract_normalized_records(path))

    aliquots = load_aliquot_records()
    aliases_by_key = build_aliases_from_aliquots(aliquots)
    training, feature_cols, _fill_values, _sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before 2026 import {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    backup.write_bytes(FINAL_PATH.read_bytes())

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)
    key_to_rows = rebuild_key_to_rows(ws, headers, aliases_by_key)

    grouped = defaultdict(list)
    for record in extracted:
        aliquot = aliquot_for_record(record, aliquots, aliases_by_key)
        if not aliquot:
            grouped[(record["sample_name"], None)].append({**record, "aliquot": None})
            continue
        if record.get("is_new_shipment"):
            key = ("new-shipment", aliquot["primary"], aliquot.get("secondary"), aliquot.get("sample_date"))
        else:
            key = ("regular", aliquot["primary"], aliquot.get("secondary"))
        grouped[key].append({**record, "aliquot": aliquot})

    stats = Counter()
    added_rows = []
    added_measurements = []
    ignored = []
    similar = {}
    affected_rows = set()

    for _group_key, records in sorted(grouped.items()):
        aliquot = next((record["aliquot"] for record in records if record.get("aliquot")), None)
        if not aliquot:
            stats["no_aliquot_match"] += len(records)
            ignored.append({"records": records, "reason": "no aliquots match"})
            continue

        row_probe = {
            "identifiers": aliquot["identifiers"],
            "strict_identifiers": aliquot["strict_identifiers"],
            "sample_date": aliquot.get("sample_date"),
        }
        candidates = final_row_candidates(row_probe, key_to_rows, aliases_by_key)
        if any(record.get("is_new_shipment") for record in records):
            candidates = shipment_row_candidates_by_date(row_probe, candidates, ws, headers)
        if len(candidates) > 1:
            stats["multiple_final_rows"] += len(records)
            ignored.append({"sample": aliquot["primary"], "rows": candidates, "reason": "multiple final rows"})
            continue
        if not candidates:
            new_row = ws.max_row + 1
            clone_row_style(ws, max(2, ws.max_row), new_row)
            for col in range(1, ws.max_column + 1):
                ws.cell(new_row, col).value = None
            ws.cell(new_row, headers["Primary name"]).value = aliquot["primary"]
            ws.cell(new_row, headers["Secondary / other name"]).value = aliquot.get("secondary")
            ws.cell(new_row, headers["Measurement status"]).value = "measured"
            ws.cell(new_row, headers["Diagnosis"]).value = aliquot.get("diagnosis")
            style_diagnosis(ws.cell(new_row, headers["Diagnosis"]), aliquot.get("diagnosis"))
            ws.cell(new_row, headers["Calprotectin level"]).value = aliquot.get("calprotectin")
            ws.cell(new_row, headers["Disease location"]).value = aliquot.get("disease_location")
            ws.cell(new_row, headers["Sample date"]).value = aliquot.get("sample_date")
            if aliquot.get("sample_date"):
                ws.cell(new_row, headers["Sample date"]).number_format = "dd/mm/yyyy"
            row = new_row
            key_to_rows = rebuild_key_to_rows(ws, headers, aliases_by_key)
            stats["new_rows"] += 1
            added_rows.append(
                {
                    "row_before_sort": row,
                    "primary": aliquot["primary"],
                    "secondary": aliquot.get("secondary"),
                    "diagnosis": aliquot.get("diagnosis"),
                    "aliquots_sheet": aliquot["source_sheet"],
                    "aliquots_row": aliquot["source_row"],
                }
            )
            similar[aliquot["primary"]] = similar_names_for_new(
                ws, headers, aliquot["primary"], aliquot.get("secondary"), exclude_row=row
            )
        else:
            row = candidates[0]

        for record in sorted(records, key=lambda item: (item["detector"], item["source_date"] or "", item["source_file"])):
            detector = record["detector"]
            value = float(record["value"])
            cols = detector_columns(headers, detector)
            existing_values = numeric_values(ws, row, cols)
            if any(almost_equal(existing, value) for existing in existing_values):
                stats["already_present"] += 1
                continue
            blank_col = blank_measurement_col(ws, row, cols)
            if blank_col is None:
                stats["no_empty_slot"] += 1
                ignored.append(
                    {
                        "sample": aliquot["primary"],
                        "detector": detector,
                        "value": value,
                        "source_file": record["source_file"],
                        "reason": "row already has 3 values for this detector",
                    }
                )
                continue
            status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
            if status == "missing":
                ws.cell(row, headers["Measurement status"]).value = "measured"
                add_ok, reason = True, "row was marked missing"
            elif not existing_values:
                add_ok, reason = True, "first detector measurement for row"
            else:
                add_ok, reason = resembles_existing(existing_values, value, bars[detector]["bar"])
            if not add_ok:
                stats["contradictory_ignored"] += 1
                ignored.append(
                    {
                        "sample": aliquot["primary"],
                        "detector": detector,
                        "value": value,
                        "source_file": record["source_file"],
                        "reason": reason,
                    }
                )
                continue
            ws.cell(row, blank_col).value = value
            ws.cell(row, blank_col).number_format = "0.000000000"
            write_source_cell(ws, row, headers, detector, record["source_file"])
            added_measurements.append(
                {
                    "row_before_sort": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                    "detector": detector,
                    "measurement_slot": ws.cell(row, blank_col).coordinate,
                    "value": value,
                    "source_file": record["source_file"],
                    "reason": reason,
                }
            )
            affected_rows.add(row)
            stats["measurements_added"] += 1

    for row in sorted(affected_rows):
        reclassify_row(ws, headers, row, bars)

    for cell in ws[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor=HEADER_FILL)
        cell.font = Font(name="Calibri", size=11, bold=True, color="000000")

    sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{ws.cell(1, ws.max_column).coordinate[0]}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL_PATH)
    remove_comment_and_table_parts(FINAL_PATH)
    onedrive_copy = sync_final_to_onedrive()

    new_state = {
        "measurement_folder": str(MEASUREMENT_DIR),
        "aliquots_file": str(ALIQUOTS_PATH),
        "final_workbook": str(FINAL_PATH),
        "onedrive_final_workbook": str(onedrive_copy),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "files": {},
    }
    processed_names = {path.name for path in files_to_process}
    for name, record in current_records.items():
        record = dict(record)
        if name in processed_names:
            record["status"] = "processed"
        elif not state.get("files") and (filename_date(Path(name)) or "") <= "2026-07-28":
            record["status"] = "baseline_seen_not_imported_by_2026_importer"
        else:
            record["status"] = state.get("files", {}).get(name, {}).get("status", "seen")
        new_state["files"][name] = record
    STATE_PATH.write_text(json.dumps(new_state, ensure_ascii=False, indent=2), encoding="utf-8")

    report = {
        "final_workbook": str(FINAL_PATH),
        "onedrive_final_workbook": str(onedrive_copy),
        "backup": str(backup),
        "state_file": str(STATE_PATH),
        "files_to_process": [path.name for path in files_to_process],
        "extracted_count": len(extracted),
        "stats": dict(stats),
        "added_rows": added_rows,
        "added_measurements": added_measurements,
        "ignored": ignored,
        "similar_old_names": similar,
        "bars": {key: value["bar"] for key, value in bars.items()},
        "shipment_folder_rule": "Files in the 447 and araE 2026 folder are treated as new shipment samples and matched by sample date instead of collapsed into older rows.",
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
