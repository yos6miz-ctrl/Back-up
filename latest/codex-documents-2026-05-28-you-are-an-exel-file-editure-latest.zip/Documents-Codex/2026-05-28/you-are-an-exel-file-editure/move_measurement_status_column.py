from copy import copy
from pathlib import Path

from openpyxl import load_workbook


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
TARGET_HEADER = "Measurement status"
BEFORE_HEADER = "Diagnosis"


def clone_cell(source, target):
    target.value = source.value
    if source.has_style:
        target._style = copy(source._style)
    target.number_format = source.number_format
    target.font = copy(source.font)
    target.fill = copy(source.fill)
    target.border = copy(source.border)
    target.alignment = copy(source.alignment)
    target.protection = copy(source.protection)
    target.comment = copy(source.comment) if source.comment else None
    target.hyperlink = copy(source.hyperlink) if source.hyperlink else None


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]

    headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
    if TARGET_HEADER not in headers:
        raise RuntimeError(f"Missing header: {TARGET_HEADER}")
    if BEFORE_HEADER not in headers:
        raise RuntimeError(f"Missing header: {BEFORE_HEADER}")

    old_status_idx = headers.index(TARGET_HEADER)
    old_before_idx = headers.index(BEFORE_HEADER)
    status_header = headers.pop(old_status_idx)
    insert_idx = old_before_idx if old_status_idx > old_before_idx else old_before_idx - 1
    headers.insert(insert_idx, status_header)

    old_order = []
    original_headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
    for header in headers:
        old_order.append(original_headers.index(header) + 1)

    old_cells = {}
    old_widths = {}
    for old_col in range(1, ws.max_column + 1):
        old_widths[old_col] = ws.column_dimensions[ws.cell(1, old_col).column_letter].width
        for row in range(1, ws.max_row + 1):
            old_cells[(row, old_col)] = copy(ws.cell(row, old_col))

    for new_col, old_col in enumerate(old_order, start=1):
        ws.column_dimensions[ws.cell(1, new_col).column_letter].width = old_widths.get(old_col)
        for row in range(1, ws.max_row + 1):
            clone_cell(old_cells[(row, old_col)], ws.cell(row, new_col))

    for table in ws.tables.values():
        table.ref = f"A1:{ws.cell(ws.max_row, ws.max_column).coordinate}"
        for idx, table_col in enumerate(table.tableColumns, start=1):
            table_col.name = ws.cell(1, idx).value

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "headers": [ws.cell(1, col).value for col in range(1, ws.max_column + 1)],
        }
    )


if __name__ == "__main__":
    main()
