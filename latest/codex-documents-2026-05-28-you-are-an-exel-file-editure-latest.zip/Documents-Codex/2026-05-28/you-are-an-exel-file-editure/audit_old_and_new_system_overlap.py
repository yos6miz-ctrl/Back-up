import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


WORKBOOK = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\audit_old_and_new_system_overlap_report.json")
NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
NS_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def col_index(cell_ref):
    letters = "".join(ch for ch in cell_ref if ch.isalpha())
    result = 0
    for char in letters:
        result = result * 26 + ord(char.upper()) - ord("A") + 1
    return result


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def split_names(*values):
    result = []
    for value in values:
        if not value:
            continue
        for part in re.split(r"\s*;\s*", str(value)):
            part = part.strip()
            if part:
                result.append(part)
    return result


def keyset(names):
    keys = set()
    for name in names:
        n = norm(name)
        if n:
            keys.add(n)
        for pattern, prefix in ((r"CT\s*-?\s*(\d+)$", "CT"), (r"old\s*(\d+)$", "OLD")):
            match = re.search(pattern, name, re.I)
            if match:
                keys.add(prefix + match.group(1))
                keys.add("NUM" + match.group(1))
    return keys


def read_shared_strings(zf):
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    strings = []
    for si in root.findall(f"{NS_MAIN}si"):
        pieces = []
        for text in si.iter(f"{NS_MAIN}t"):
            pieces.append(text.text or "")
        strings.append("".join(pieces))
    return strings


def sheet_path_for_name(zf, sheet_name):
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_by_id = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels.findall(f"{NS_PKG_REL}Relationship")}
    for sheet in workbook.findall(f".//{NS_MAIN}sheet"):
        if sheet.attrib.get("name") == sheet_name:
            rid = sheet.attrib.get(f"{NS_REL}id")
            target = rel_by_id[rid]
            target = target.lstrip("/")
            return target if target.startswith("xl/") else "xl/" + target
    raise RuntimeError(f"Sheet not found: {sheet_name}")


def cell_text(cell, shared_strings):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(t.text or "" for t in cell.iter(f"{NS_MAIN}t"))
    value = cell.find(f"{NS_MAIN}v")
    if value is None:
        return ""
    text = value.text or ""
    if cell_type == "s":
        try:
            return shared_strings[int(text)]
        except Exception:
            return text
    return text


def read_rows(path, sheet_name):
    with zipfile.ZipFile(path) as zf:
        shared_strings = read_shared_strings(zf)
        sheet_path = sheet_path_for_name(zf, sheet_name)
        root = ET.fromstring(zf.read(sheet_path))
        rows = []
        for row in root.findall(f".//{NS_MAIN}row"):
            values = {}
            max_col = 0
            for cell in row.findall(f"{NS_MAIN}c"):
                index = col_index(cell.attrib["r"])
                values[index] = cell_text(cell, shared_strings)
                max_col = max(max_col, index)
            rows.append([values.get(index, "") for index in range(1, max_col + 1)])
        return rows


def main():
    rows = read_rows(WORKBOOK, "Final")
    headers = {name: index for index, name in enumerate(rows[0])}
    records = []
    status_counts = {}
    for excel_row, row in enumerate(rows[1:], start=2):
        def get(header):
            index = headers.get(header)
            return row[index] if index is not None and index < len(row) else ""

        status = get("Measurement status").strip()
        status_counts[status] = status_counts.get(status, 0) + 1
        names = split_names(get("Primary name"), get("Secondary / other name"))
        records.append(
            {
                "row": excel_row,
                "primary": get("Primary name"),
                "secondary": get("Secondary / other name"),
                "status": status,
                "diagnosis": get("Diagnosis"),
                "final": get("Final classification / decision"),
                "sample_date": get("Sample date"),
                "source": get("Measurement/source file"),
                "names": names,
                "keys": sorted(keyset(names)),
            }
        )

    old_rows = [record for record in records if record["status"].lower() == "old metering system"]
    measured_rows = [record for record in records if record["status"].lower() == "measured"]
    measured_by_key = {}
    for row in measured_rows:
        for key in row["keys"]:
            measured_by_key.setdefault(key, []).append(row)

    overlaps = []
    for old in old_rows:
        hits = []
        for key in old["keys"]:
            for measured in measured_by_key.get(key, []):
                if measured not in hits:
                    hits.append(measured)
        if hits:
            overlaps.append({"old": old, "measured": hits})

    measured_with_old_word = [
        row
        for row in measured_rows
        if re.search(
            r"\bold\b|\(old\)|old metering",
            " ".join(str(row.get(key) or "") for key in ("primary", "secondary", "source", "final")),
            re.I,
        )
    ]

    report = {
        "workbook": str(WORKBOOK),
        "status_counts": status_counts,
        "old_metering_rows_count": len(old_rows),
        "old_vs_measured_overlap_count": len(overlaps),
        "overlaps": overlaps,
        "measured_rows_with_old_word_count": len(measured_with_old_word),
        "measured_rows_with_old_word": measured_with_old_word,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
