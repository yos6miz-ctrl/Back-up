from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
KEEP_MISSING_NOT_IN_ALIQUOTS = {"F-LB-18373"}


def load_builder():
    spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def keys_for(builder, *values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def main():
    builder = load_builder()
    aliquots, _aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    aliquot_keys = set()
    for record in aliquots:
        aliquot_keys.update(record.get("identifiers", set()))
        aliquot_keys.update(record.get("strict_identifiers", set()))

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    rows_to_delete = []
    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
        if status != "missing":
            continue
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        if str(primary or "").strip() in KEEP_MISSING_NOT_IN_ALIQUOTS:
            continue
        if not (keys_for(builder, primary, secondary) & aliquot_keys):
            rows_to_delete.append((row, primary, secondary, ws.cell(row, headers["Diagnosis"]).value))

    for row, *_rest in sorted(rows_to_delete, reverse=True):
        ws.delete_rows(row, 1)

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "removed_count": len(rows_to_delete), "removed": rows_to_delete})


if __name__ == "__main__":
    main()
