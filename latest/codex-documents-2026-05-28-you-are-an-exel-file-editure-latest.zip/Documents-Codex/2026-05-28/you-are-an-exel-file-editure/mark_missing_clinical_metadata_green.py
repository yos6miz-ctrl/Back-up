from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import PatternFill


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")

GREEN_FILL = PatternFill(fill_type="solid", fgColor="C6EFCE")
NO_FILL = PatternFill(fill_type=None)

HS_DIAGNOSES = {"healthy", "hs", "h"}
IBS_DIAGNOSES = {"ibs"}
IBD_DIAGNOSES = {"cdf", "cdr", "ucf", "ucr", "uc", "ibd", "unknown"}


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def blank(value):
    return value is None or str(value).strip() == ""


def diagnosis_key(value):
    return str(value or "").strip().lower()


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    calprotectin_col = headers["Calprotectin level"]
    location_col = headers["Disease location"]
    diagnosis_col = headers["Diagnosis"]

    marked_calprotectin = 0
    marked_location = 0
    cleared_location_for_non_relevant = 0

    for row in range(2, ws.max_row + 1):
        diagnosis = diagnosis_key(ws.cell(row, diagnosis_col).value)
        calprotectin_cell = ws.cell(row, calprotectin_col)
        location_cell = ws.cell(row, location_col)

        if diagnosis in HS_DIAGNOSES:
            if blank(calprotectin_cell.value):
                calprotectin_cell.fill = NO_FILL
            if blank(location_cell.value):
                location_cell.fill = NO_FILL
            continue

        if blank(calprotectin_cell.value):
            calprotectin_cell.fill = GREEN_FILL
            marked_calprotectin += 1

        if diagnosis in IBD_DIAGNOSES and blank(location_cell.value):
            location_cell.fill = GREEN_FILL
            marked_location += 1
        elif diagnosis in IBS_DIAGNOSES and blank(location_cell.value):
            location_cell.fill = NO_FILL
            cleared_location_for_non_relevant += 1

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "marked_empty_calprotectin_cells": marked_calprotectin,
            "marked_empty_disease_location_cells": marked_location,
            "cleared_empty_ibs_location_cells": cleared_location_for_non_relevant,
        }
    )


if __name__ == "__main__":
    main()
