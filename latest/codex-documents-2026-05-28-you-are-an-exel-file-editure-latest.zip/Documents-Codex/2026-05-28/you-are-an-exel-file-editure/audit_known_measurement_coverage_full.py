from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
REPORT_PATH = WORKSPACE / "known_measurement_coverage_full.json"

spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def clean(value):
    return "" if value is None else str(value).strip()


def is_blank(value):
    return value is None or str(value).strip() == ""


def numeric_equal(left, right, tolerance=1e-5):
    try:
        return math.isclose(float(left), float(right), rel_tol=tolerance, abs_tol=tolerance)
    except Exception:
        return False


def load_known_rows():
    wb = load_workbook(FINAL_PATH, data_only=True, read_only=False)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}

    def detector_values(row, detector):
        values = []
        index = 1
        while f"{detector} measurement {index}" in headers:
            values.append(ws.cell(row, headers[f"{detector} measurement {index}"]).value)
            index += 1
        return values

    rows = []
    for row in range(2, ws.max_row + 1):
        if "Original tab" in headers and ws.cell(row, headers["Original tab"]).value != "Known":
            continue
        rows.append(
            {
                "row": row,
                "primary": ws.cell(row, headers["Primary name"]).value,
                "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                "status": ws.cell(row, headers["Measurement status"]).value,
                "final": ws.cell(row, headers["Final classification / decision"]).value,
                "pa447_values": detector_values(row, "PA447"),
                "arae_values": detector_values(row, "araE"),
                "pa447_decision": ws.cell(row, headers["PA447 decision"]).value,
                "arae_decision": ws.cell(row, headers["araE decision"]).value,
                "source": ws.cell(row, headers["Measurement/source file"]).value,
            }
        )
    return rows


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def keys_for_row(row):
    keys = set()
    for value in (row["primary"], row["secondary"]):
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def source_rank(item):
    source = item.get("source")
    if source == "edited normalized files":
        return 0
    if source == "447 and araE ALL":
        return 1
    if source == "IBD IBS OLD":
        return 2
    return 3


def source_sort_key(item):
    return (
        source_rank(item),
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item.get("source_name") or item.get("sample_name") or ""),
        str(detector_value(item, "PA447")),
        str(detector_value(item, "araE")),
    )


def measurement_identity(item, detector):
    value = detector_value(item, detector)
    source = item.get("source")
    name = item.get("source_name") or item.get("sample_name")
    if source == "IBD IBS OLD":
        return ("old", name, detector, value)
    return (
        source,
        item.get("source_file"),
        tuple(item.get("source_rows") or []),
        name,
        detector,
        value,
    )


def unique_items(items, detector):
    by_id = {}
    for item in items:
        value = detector_value(item, detector)
        if value is None:
            continue
        by_id[measurement_identity(item, detector)] = item
    return sorted(by_id.values(), key=source_sort_key)


def compatible(row, item):
    return builder.compatible(row.get("diagnosis"), item.get("diagnosis")) or builder.manual_alias_match(row, item)


def item_summary(item, detector):
    return {
        "source_name": item.get("source_name") or item.get("sample_name"),
        "value": detector_value(item, detector),
        "diagnosis": item.get("diagnosis"),
        "source": item.get("source"),
        "source_file": item.get("source_file"),
        "source_date": item.get("source_date"),
        "source_rows": item.get("source_rows"),
        "removed_reason": item.get("pa447_removed_reason"),
        "old_metering_value": item.get("old_metering_pa447"),
    }


def displayed_values(row, detector):
    values = row["pa447_values"] if detector == "PA447" else row["arae_values"]
    return [value for value in values if not is_blank(value)]


def represented_sources(row, sources, detector):
    displayed = displayed_values(row, detector)
    represented = []
    missing = []
    for item in sources:
        value = detector_value(item, detector)
        if any(numeric_equal(value, shown) for shown in displayed):
            represented.append(item)
        else:
            missing.append(item)
    return represented, missing


def main():
    known_rows = load_known_rows()
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    all_rows, all_by_key = builder.load_all_measurements()
    old_rows = builder.load_old_rows()

    rows_report = []
    clear_missing_detector_values = []
    underfilled_repeats = []
    old_source_available = []
    incompatible_available = []

    for row in known_rows:
        row_keys = expand_keys(keys_for_row(row), aliases_by_key)
        row_like = {
            "sample_name": row["primary"],
            "other_name": row["secondary"],
            "diagnosis": row["diagnosis"],
            "identifiers": row_keys,
            "strict_identifiers": row_keys,
        }
        row_summary = {
            "row": row["row"],
            "primary": row["primary"],
            "secondary": row["secondary"],
            "diagnosis": row["diagnosis"],
            "status": row["status"],
            "final": row["final"],
            "displayed": {
                "PA447": displayed_values(row, "PA447"),
                "araE": displayed_values(row, "araE"),
            },
            "available": {},
            "compatible_available_count": {},
            "incompatible_available_count": {},
        }
        for detector in ("PA447", "araE"):
            candidates = []
            for key in row_keys:
                candidates.extend(all_by_key.get(key, []))
            candidates.extend(
                item
                for item in old_rows
                if row_keys & (item.get("identifiers", set()) | item.get("strict_identifiers", set()))
            )
            compatible_items = unique_items([item for item in candidates if compatible(row_like, item)], detector)
            incompatible_items = unique_items([item for item in candidates if not compatible(row_like, item)], detector)
            represented, missing = represented_sources(row, compatible_items, detector)
            row_summary["available"][detector] = [item_summary(item, detector) for item in compatible_items]
            row_summary["compatible_available_count"][detector] = len(compatible_items)
            row_summary["incompatible_available_count"][detector] = len(incompatible_items)

            if incompatible_items:
                incompatible_available.append(
                    {
                        "row": row["row"],
                        "primary": row["primary"],
                        "secondary": row["secondary"],
                        "diagnosis": row["diagnosis"],
                        "detector": detector,
                        "incompatible_examples": [item_summary(item, detector) for item in incompatible_items[:8]],
                    }
                )

            if not displayed_values(row, detector) and compatible_items:
                clear_missing_detector_values.append(
                    {
                        "row": row["row"],
                        "primary": row["primary"],
                        "secondary": row["secondary"],
                        "diagnosis": row["diagnosis"],
                        "status": row["status"],
                        "detector": detector,
                        "available": [item_summary(item, detector) for item in compatible_items[:8]],
                    }
                )
            elif len(displayed_values(row, detector)) < min(3, len(compatible_items)) and missing:
                underfilled_repeats.append(
                    {
                        "row": row["row"],
                        "primary": row["primary"],
                        "secondary": row["secondary"],
                        "diagnosis": row["diagnosis"],
                        "status": row["status"],
                        "detector": detector,
                        "displayed_values": displayed_values(row, detector),
                        "missing_available": [item_summary(item, detector) for item in missing[:8]],
                    }
                )

            old_items = [item for item in compatible_items if item.get("source") == "IBD IBS OLD"]
            if old_items:
                old_source_available.append(
                    {
                        "row": row["row"],
                        "primary": row["primary"],
                        "secondary": row["secondary"],
                        "diagnosis": row["diagnosis"],
                        "status": row["status"],
                        "detector": detector,
                        "displayed_values": displayed_values(row, detector),
                        "old_sources": [item_summary(item, detector) for item in old_items],
                    }
                )
        rows_report.append(row_summary)

    report = {
        "final_workbook": str(FINAL_PATH),
        "stats": {
            "known_rows": len(known_rows),
            "known_status_counts": dict(Counter(row["status"] for row in known_rows)),
            "known_diagnosis_counts": dict(Counter(row["diagnosis"] for row in known_rows)),
            "clear_missing_detector_values": len(clear_missing_detector_values),
            "underfilled_repeats": len(underfilled_repeats),
            "old_source_available_rows": len(old_source_available),
            "incompatible_available_rows": len(incompatible_available),
            "source_record_counts": {
                "load_all_measurements": len(all_rows),
                "IBD_IBS_OLD": len(old_rows),
            },
        },
        "clear_missing_detector_values": clear_missing_detector_values,
        "underfilled_repeats": underfilled_repeats,
        "old_source_available": old_source_available,
        "incompatible_available": incompatible_available,
        "rows": rows_report,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report["stats"], ensure_ascii=True, indent=2, default=str))
    print("REPORT", REPORT_PATH)


if __name__ == "__main__":
    main()
