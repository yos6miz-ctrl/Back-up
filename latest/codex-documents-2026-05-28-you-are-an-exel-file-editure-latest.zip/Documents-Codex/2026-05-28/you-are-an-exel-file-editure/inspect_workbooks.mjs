import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const files = [
  "C:/Users/Popovtzer lab/.codex/Excel file editor/UN stool names.xlsx",
  "C:/Users/Popovtzer lab/.codex/Excel file editor/Unknowns trial 6.26.xlsx",
];

for (const file of files) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  console.log(`FILE\t${file}`);
  console.log(`SHEETS\t${workbook.worksheets.items.map((sheet) => sheet.name).join("\t")}`);
  for (const sheet of workbook.worksheets.items) {
    const table = await workbook.inspect({
      kind: "table",
      range: `${sheet.name}!A1:Z30`,
      include: "values,formulas",
      tableMaxRows: 30,
      tableMaxCols: 26,
    });
    console.log(`SHEET\t${sheet.name}`);
    console.log(table.ndjson);
  }
}
