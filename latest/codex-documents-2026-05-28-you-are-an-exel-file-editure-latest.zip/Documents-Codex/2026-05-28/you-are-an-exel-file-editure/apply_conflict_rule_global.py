from __future__ import annotations

from copy import copy
from datetime import datetime
from pathlib import Path
import shutil
import zipfile

from openpyxl import load_workbook

import import_2026_measurements as importer


FINAL_PATH = importer.FINAL_PATH
BACKUP_DIR = importer.BACKUP_DIR
MEASUREMENT_COL_PREFIXES = ("PA447 measurement", "araE measurement")


def headers_for(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def is_yellow(cell) -> bool:
    if not cell.fill or cell.fill.fill_type != "solid":
        return False
    rgb = cell.fill.fgColor.rgb
    return bool(rgb and str(rgb).endswith(importer.SOFT_YELLOW))


def snapshot_row(ws, headers, row):
    fields = [
        "PA447 decision",
        "araE decision",
        "Final classification / decision",
    ]
    values = {field: ws.cell(row, headers[field]).value for field in fields}
    yellows = []
    for detector in ("PA447", "araE"):
        for col in importer.detector_columns(headers, detector):
            if is_yellow(ws.cell(row, col)):
                yellows.append(ws.cell(row, col).coordinate)
    values["yellow_cells"] = tuple(yellows)
    return values


def detector_families(ws, headers, row, detector, bars):
    families = []
    values = []
    for col in importer.detector_columns(headers, detector):
        value = ws.cell(row, col).value
        if importer.is_numeric(value):
            call, _margin = importer.classifier.detector_call(float(value), bars[detector]["bar"])
            families.append(importer.call_family(call))
            values.append(float(value))
    return values, families


def workbook_has_forbidden_parts(path: Path):
    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()
    return {
        "tables": [name for name in names if name.startswith("xl/tables/")],
        "comments": [name for name in names if name.startswith("xl/comments")],
        "vml": [name for name in names if name.startswith("xl/drawings/vmlDrawing")],
    }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"{FINAL_PATH.stem}.before-global-conflict-rule.{stamp}.xlsx"
    shutil.copy2(FINAL_PATH, backup_path)

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = headers_for(ws)
    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    before = {row: snapshot_row(ws, headers, row) for row in range(2, ws.max_row + 1)}

    touched = 0
    skipped_status = {}
    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
        if status in {"missing", "לא נבדק", "old metering system"}:
            skipped_status[status] = skipped_status.get(status, 0) + 1
            continue
        importer.reclassify_row(ws, headers, row, bars)
        touched += 1

    after = {row: snapshot_row(ws, headers, row) for row in range(2, ws.max_row + 1)}

    changed_rows = []
    changed_final = []
    changed_detector = []
    changed_yellow = []
    for row in range(2, ws.max_row + 1):
        if before[row] != after[row]:
            changed_rows.append(row)
        if before[row]["Final classification / decision"] != after[row]["Final classification / decision"]:
            changed_final.append(
                {
                    "row": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                    "before": before[row]["Final classification / decision"],
                    "after": after[row]["Final classification / decision"],
                }
            )
        for field in ("PA447 decision", "araE decision"):
            if before[row][field] != after[row][field]:
                changed_detector.append(
                    {
                        "row": row,
                        "primary": ws.cell(row, headers["Primary name"]).value,
                        "field": field,
                        "before": before[row][field],
                        "after": after[row][field],
                    }
                )
        if before[row]["yellow_cells"] != after[row]["yellow_cells"]:
            changed_yellow.append(
                {
                    "row": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "before": before[row]["yellow_cells"],
                    "after": after[row]["yellow_cells"],
                }
            )

    two_conflict_rows = []
    singleton_detectors = []
    majority_outlier_rows = []
    yellow_cells = []

    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
        if status in {"missing", "לא נבדק", "old metering system"}:
            continue
        for detector in ("PA447", "araE"):
            values, families = detector_families(ws, headers, row, detector, bars)
            conclusive = [family for family in families if family in {"IBD", "IBS"}]
            if len(values) == 1:
                singleton_detectors.append((row, ws.cell(row, headers["Primary name"]).value, detector, values[0]))
            if len(values) == 2 and set(conclusive) == {"IBD", "IBS"}:
                two_conflict_rows.append((row, ws.cell(row, headers["Primary name"]).value, detector, tuple(values)))
            if len(values) == 3:
                counts = {family: families.count(family) for family in set(families)}
                if max(counts.values()) == 2 and len(counts) > 1:
                    majority_outlier_rows.append((row, ws.cell(row, headers["Primary name"]).value, detector, tuple(values), tuple(families)))
            for col in importer.detector_columns(headers, detector):
                cell = ws.cell(row, col)
                if is_yellow(cell):
                    yellow_cells.append(cell.coordinate)

    # Preserve the current workbook styling/structure but keep Excel from showing the table/comment repair message.
    wb.save(FINAL_PATH)
    importer.remove_comment_and_table_parts(FINAL_PATH)
    onedrive_copy = importer.sync_final_to_onedrive()

    forbidden = workbook_has_forbidden_parts(FINAL_PATH)
    print(f"backup={backup_path}")
    print(f"onedrive_copy={onedrive_copy}")
    print(f"rows_reclassified={touched}")
    print(f"skipped_status={skipped_status}")
    print(f"changed_rows={len(changed_rows)}")
    print(f"final_changes={len(changed_final)}")
    for item in changed_final[:40]:
        print(f"  final_change row={item['row']} primary={item['primary']} {item['before']} -> {item['after']}")
    if len(changed_final) > 40:
        print(f"  ... {len(changed_final) - 40} more final changes")
    print(f"detector_changes={len(changed_detector)}")
    print(f"yellow_changes={len(changed_yellow)}")
    print(f"two_value_conflicts_kept_and_yellow={len(two_conflict_rows)}")
    print(f"single_measurement_detectors_yellow={len(singleton_detectors)}")
    print(f"three_value_majority_outliers_yellow={len(majority_outlier_rows)}")
    print(f"yellow_measurement_cells={len(yellow_cells)}")
    print(f"forbidden_parts_after_save={forbidden}")


if __name__ == "__main__":
    main()
