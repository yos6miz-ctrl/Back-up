from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path
import json
import shutil

from openpyxl import load_workbook

import build_accounted_known_unknown as builder
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
MEASUREMENT_DIR = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "rebuild_affected_2026_slots_report.json"

REBUILD_FILES = {
    "20260813 447.xlsx",
    "20260813 araE.xlsx",
    "20260818 UN 447.xlsx",
    "20260818 UN araE.xlsx",
    "20260819 UN 447.xlsx",
    "20260819 UN araE.xlsx",
}


def n(value):
    return builder.norm(value)


def parse_sources(text):
    return importer.parse_source_cell(text)


def record_keys(record):
    return {key for key in record.get("strict_identifiers", set()) | record.get("identifiers", set()) if key}


def main():
    extracted = []
    for path in sorted(MEASUREMENT_DIR.glob("*.xlsx")):
        if path.name.startswith("~$") or path.name not in REBUILD_FILES:
            continue
        extracted.extend(importer.extract_normalized_records(path))

    by_source_detector_sample = defaultdict(list)
    for record in extracted:
        by_source_detector_sample[(record["source_file"], record["detector"])].append(record)

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before rebuilding 2026 slots {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(FINAL, backup)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    rebuilt = []
    missing_current_records = []
    affected_rows = set()

    for row in range(2, ws.max_row + 1):
        names = {n(ws.cell(row, headers["Primary name"]).value), n(ws.cell(row, headers["Secondary / other name"]).value)}
        names = {name for name in names if name}
        if not names:
            continue

        parts = parse_sources(ws.cell(row, headers["Measurement/source file"]).value)
        if not any(source in REBUILD_FILES for sources in parts.values() for source in sources):
            continue

        row_rebuilt = {"row": row, "primary": ws.cell(row, headers["Primary name"]).value, "detectors": {}}
        for detector in ("PA447", "araE"):
            sources = [source for source in parts[detector] if source in REBUILD_FILES]
            if not sources:
                continue

            desired = []
            desired_sources = []
            for source in sources:
                candidates = []
                for record in by_source_detector_sample.get((source, detector), []):
                    if names & record_keys(record):
                        candidates.append(record)
                if not candidates:
                    missing_current_records.append(
                        {
                            "row": row,
                            "primary": ws.cell(row, headers["Primary name"]).value,
                            "detector": detector,
                            "source_file": source,
                            "reason": "source file is listed on the row but no current extracted value matched this sample",
                        }
                    )
                    continue
                candidates.sort(key=lambda item: item["source_cell"])
                desired.append(float(candidates[0]["value"]))
                desired_sources.append(source)

            cols = importer.detector_columns(headers, detector)
            for idx, col in enumerate(cols):
                ws.cell(row, col).value = desired[idx] if idx < len(desired) else None
                if idx < len(desired):
                    ws.cell(row, col).number_format = "0.000000000"

            parts[detector] = desired_sources
            row_rebuilt["detectors"][detector] = {
                "sources": desired_sources,
                "values": desired,
            }
            affected_rows.add(row)

        segments = []
        for detector in ("PA447", "araE"):
            if parts[detector]:
                segments.append(f"{detector}: {', '.join(parts[detector][:3])}")
        ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments) if segments else None
        rebuilt.append(row_rebuilt)

    for row in sorted(affected_rows):
        importer.reclassify_row(ws, headers, row, bars)

    importer.sort_records(ws, headers)
    ws.auto_filter.ref = f"A1:{ws.cell(1, ws.max_column).coordinate[0]}{ws.max_row}"
    ws.freeze_panes = "A2"
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)
    shutil.copy2(FINAL, ONEDRIVE_FINAL)

    report = {
        "final": str(FINAL),
        "onedrive_final": str(ONEDRIVE_FINAL),
        "backup": str(backup),
        "rebuild_files": sorted(REBUILD_FILES),
        "extracted_count": len(extracted),
        "rebuilt_rows": rebuilt,
        "missing_current_records": missing_current_records,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
