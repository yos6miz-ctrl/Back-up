from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json

from openpyxl import load_workbook

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT_PATH = WORKSPACE / "add_previously_ignored_conflicts_report.json"


MEASUREMENTS = [
    {
        "primary": "LRS-26188",
        "detector": "PA447",
        "value": 0.1135324902411804,
        "source_file": "20260728 447 laura.xlsx",
    },
    {
        "primary": "UN FDN 119",
        "detector": "araE",
        "value": 0.08821399679370955,
        "source_file": "20260804 UN araE.xlsx",
    },
    {
        "primary": "UN FHF 510",
        "detector": "araE",
        "value": 0.12107281030393113,
        "source_file": "20260804 UN araE.xlsx",
    },
]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def numeric_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def find_row(ws, headers, primary):
    matches = []
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, headers["Primary name"]).value == primary:
            matches.append(row)
    if len(matches) != 1:
        raise RuntimeError(f"Expected one row for {primary}, found {matches}")
    return matches[0]


def add_measurement(ws, headers, item):
    row = find_row(ws, headers, item["primary"])
    cols = importer.detector_columns(headers, item["detector"])
    existing = [ws.cell(row, col).value for col in cols]
    if any(numeric_equal(value, item["value"]) for value in existing if value not in (None, "")):
        importer.write_source_cell(ws, row, headers, item["detector"], item["source_file"])
        return {"row": row, **item, "status": "already_present", "existing": existing}
    for col in cols:
        if ws.cell(row, col).value in (None, ""):
            ws.cell(row, col).value = float(item["value"])
            ws.cell(row, col).number_format = "0.000000000"
            importer.write_source_cell(ws, row, headers, item["detector"], item["source_file"])
            return {
                "row": row,
                **item,
                "status": "added",
                "cell": ws.cell(row, col).coordinate,
                "existing_before": existing,
            }
    raise RuntimeError(f"No empty {item['detector']} measurement slot for {item['primary']}")


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before adding conflicts {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    backup.write_bytes(FINAL_PATH.read_bytes())

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    results = []
    affected_rows = set()
    for item in MEASUREMENTS:
        result = add_measurement(ws, headers, item)
        results.append(result)
        affected_rows.add(result["row"])

    final_after = []
    for row in sorted(affected_rows):
        final_value = importer.reclassify_row(ws, headers, row, bars)
        final_after.append(
            {
                "row": row,
                "primary": ws.cell(row, headers["Primary name"]).value,
                "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                "final": final_value,
                "pa447": [ws.cell(row, headers[f"PA447 measurement {idx}"]).value for idx in (1, 2, 3)],
                "pa447_decision": ws.cell(row, headers["PA447 decision"]).value,
                "araE": [ws.cell(row, headers[f"araE measurement {idx}"]).value for idx in (1, 2, 3)],
                "araE_decision": ws.cell(row, headers["araE decision"]).value,
                "source": ws.cell(row, headers["Measurement/source file"]).value,
            }
        )

    wb.save(FINAL_PATH)
    importer.remove_comment_and_table_parts(FINAL_PATH)

    report = {
        "final_workbook": str(FINAL_PATH),
        "backup": str(backup),
        "added": results,
        "final_after": final_after,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
