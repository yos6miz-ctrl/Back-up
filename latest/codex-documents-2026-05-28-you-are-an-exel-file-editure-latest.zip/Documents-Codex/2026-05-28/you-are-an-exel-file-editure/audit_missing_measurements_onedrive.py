from collections import defaultdict
from pathlib import Path
import json
import re
import zipfile
from xml.etree import ElementTree as ET

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
FINAL = ROOT / "Final Known and Unknown merged.xlsx"
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\missing_measurement_candidates_onedrive.json")
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def clean(value):
    return "" if value is None else str(value).strip()


def norm(value):
    return re.sub(r"[^A-Z0-9]+", "", clean(value).upper())


def compact_number_text(value):
    text = clean(value).upper()
    return re.sub(r"[^A-Z0-9]+", "", text)


def diagnosis_prefixes(dx):
    d = clean(dx).upper()
    if d.startswith("CD"):
        return ["CD", "CDF" if d == "CDF" else "CDR" if d == "CDR" else d]
    if d.startswith("UC"):
        return ["UC", d]
    if d.startswith("HEALTHY"):
        return ["HS", "HEALTHY"]
    if d.startswith("IBS"):
        return ["IBS"]
    return []


def likely_equiv_variants(text):
    raw = clean(text)
    n = norm(raw)
    if not n:
        return set()
    out = {n}
    # CT/HS-number style.
    m = re.fullmatch(r"(?:CT|HS)?0*(\d{2,5})", n)
    if m:
        num = m.group(1)
        out.update({num, f"CT{num}", f"HS{num}"})
    # F-AA-19408, FAA19408, FAA408, UN FAA408 style.
    m = re.fullmatch(r"(?:UN)?F([A-Z]{1,4})0*(\d{2,5})", n)
    if m:
        letters, num = m.groups()
        out.update({f"F{letters}{num}", f"{letters}{num}"})
        if len(num) >= 3:
            out.update({f"F{letters}{num[-3:]}", f"{letters}{num[-3:]}"})
    # 78ALA1 -> 78AL1 style.
    out.add(n.replace("ALA", "AL"))
    out.add(n.replace("SHR", "SH"))
    return {v for v in out if v}


def row_search_keys(row):
    keys = set()
    for field in ("primary", "secondary"):
        keys.update(likely_equiv_variants(row[field]))
    for prefix in diagnosis_prefixes(row["diagnosis"]):
        for field in ("primary", "secondary"):
            for key in likely_equiv_variants(row[field]):
                keys.add(f"{prefix}{key}")
                # Prefix + terminal number is common in old measurement summaries.
                digits = re.findall(r"\d+", key)
                if digits:
                    keys.add(f"{prefix}{digits[-1]}")
    return {k for k in keys if len(k) >= 3}


def load_missing_rows():
    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = [clean(ws.cell(1, c).value) for c in range(1, ws.max_column + 1)]
    idx = {h: i + 1 for i, h in enumerate(headers)}
    rows = []
    for r in range(2, ws.max_row + 1):
        status = clean(ws.cell(r, idx["Measurement status"]).value).lower()
        final = clean(ws.cell(r, idx["Final classification / decision"]).value).lower()
        if status == "missing" or final == "missing":
            row = {
                "row": r,
                "primary": clean(ws.cell(r, idx["Primary name"]).value),
                "secondary": clean(ws.cell(r, idx["Secondary / other name"]).value),
                "diagnosis": clean(ws.cell(r, idx["Diagnosis"]).value),
                "status": clean(ws.cell(r, idx["Measurement status"]).value),
                "final": clean(ws.cell(r, idx["Final classification / decision"]).value),
            }
            row["keys"] = row_search_keys(row)
            rows.append(row)
    return rows


def col_index(ref):
    letters = re.match(r"([A-Z]+)", ref).group(1)
    out = 0
    for ch in letters:
        out = out * 26 + ord(ch) - 64
    return out


def read_shared_strings(zf):
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    strings = []
    for si in root.findall("m:si", NS):
        strings.append("".join(t.text or "" for t in si.findall(".//m:t", NS)))
    return strings


def cell_value(cell, shared):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(t.text or "" for t in cell.findall(".//m:t", NS))
    node = cell.find("m:v", NS)
    if node is None or node.text is None:
        return None
    raw = node.text
    if cell_type == "s":
        try:
            return shared[int(raw)]
        except Exception:
            return None
    try:
        return float(raw)
    except ValueError:
        return raw


def workbook_cells(path, max_cells=50000):
    with zipfile.ZipFile(path) as zf:
        shared = read_shared_strings(zf)
        sheet_files = sorted(n for n in zf.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))
        for sheet_file in sheet_files:
            cells = {}
            count = 0
            for _event, elem in ET.iterparse(zf.open(sheet_file), events=("end",)):
                if not elem.tag.endswith("}row"):
                    continue
                row_num = int(elem.attrib.get("r", "0") or 0)
                for cell in elem.findall("m:c", NS):
                    ref = cell.attrib.get("r")
                    if not ref:
                        continue
                    value = cell_value(cell, shared)
                    if value is None:
                        continue
                    cells[(row_num, col_index(ref))] = (value, ref)
                    count += 1
                    if count > max_cells:
                        break
                elem.clear()
                if count > max_cells:
                    break
            yield sheet_file, cells


def file_text_values(path):
    values = []
    with zipfile.ZipFile(path) as zf:
        try:
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", NS):
                text = "".join(t.text or "" for t in si.findall(".//m:t", NS))
                if text:
                    values.append(text)
        except KeyError:
            pass
    return values


def file_has_missing_key(path, keys):
    try:
        labels = {norm(value) for value in file_text_values(path)}
        labels.discard("")
        if labels & keys:
            return True
    except Exception:
        return False
    return False


def is_source_candidate(path):
    low = str(path).lower()
    if path.name.startswith("~$"):
        return False
    if path.resolve() == FINAL.resolve():
        return False
    blocked = [
        "gut sense one-slide",
        "gut sense performance",
        "aliqauts",
        "shipment",
        "qubit",
        "rna seq",
        "dnt",
        "not good",
        "lys buffer",
    ]
    if any(token in low for token in blocked):
        return False
    rel = str(path.relative_to(ROOT)).lower()
    relevant_roots = [
        "p447\\",
        "447 and arae 2026\\",
        "kps new detectors\\arae\\",
        "old sampels\\",
        "sample repeats\\",
        "דוח כמין\\חזרה שניה\\",
        "דוח כמין\\שנה 2\\447 and arae\\",
    ]
    if any(rel.startswith(root) for root in relevant_roots):
        return True
    # A few summary files live near the root or under reports.
    return ("447 and arae all" in low) or ("ibd ibs old" in low) or ("unknowns trial" in low) or ("merged unknowns" in low)


def detector_guess(path, cells, col):
    low = str(path).lower()
    nearby_text = " ".join(
        clean(v).lower()
        for (r, c), (v, _ref) in cells.items()
        if isinstance(v, str) and abs(c - col) <= 2 and r <= 10
    )
    if "arae" in low or "arae" in nearby_text:
        return "araE"
    if "447" in low or "pa447" in nearby_text or "p447" in nearby_text:
        return "PA447"
    return "unknown"


def is_measurement_number(value):
    if not isinstance(value, (int, float)):
        return False
    if value < -0.05 or value > 3:
        return False
    # Exclude common date/year/integer identifier noise.
    if value >= 100 and abs(value - round(value)) < 1e-9:
        return False
    return True


def nearby_numbers(cells, row, col):
    out = []
    for (r, c), (value, ref) in cells.items():
        if abs(r - row) <= 6 and abs(c - col) <= 10 and is_measurement_number(value):
            out.append({"cell": ref, "row_delta": r - row, "col_delta": c - col, "value": float(value)})
    # Prefer same column below label, then same row to the right.
    out.sort(key=lambda x: (0 if x["col_delta"] == 0 and x["row_delta"] > 0 else 1 if x["row_delta"] == 0 and x["col_delta"] > 0 else 2, abs(x["row_delta"]) + abs(x["col_delta"])))
    return out[:8]


def match_label_to_rows(label_norm, missing_rows):
    matches = []
    for row in missing_rows:
        if label_norm in row["keys"]:
            matches.append(row)
            continue
        # Also allow prefix+number labels to match row keys.
        for key in row["keys"]:
            if len(key) >= 5 and (label_norm.endswith(key) or key.endswith(label_norm)):
                matches.append(row)
                break
    return matches


def main():
    missing_rows = load_missing_rows()
    all_missing_keys = set()
    for row in missing_rows:
        all_missing_keys.update(row["keys"])
    candidates = []
    scanned_files = 0
    matching_files = 0
    errors = []
    for path in sorted(ROOT.rglob("*.xlsx")):
        if not is_source_candidate(path):
            continue
        scanned_files += 1
        if not file_has_missing_key(path, all_missing_keys):
            continue
        try:
            file_hits = 0
            for sheet_name, cells in workbook_cells(path):
                text_cells = [
                    (pos, value, ref)
                    for pos, (value, ref) in cells.items()
                    if isinstance(value, str) and len(norm(value)) >= 3
                ]
                for (r, c), value, ref in text_cells:
                    label_n = norm(value)
                    matched_rows = match_label_to_rows(label_n, missing_rows)
                    if not matched_rows:
                        continue
                    nums = nearby_numbers(cells, r, c)
                    if not nums:
                        continue
                    file_hits += 1
                    for row in matched_rows:
                        candidates.append(
                            {
                                "final_row": row["row"],
                                "primary": row["primary"],
                                "secondary": row["secondary"],
                                "diagnosis": row["diagnosis"],
                                "matched_label": clean(value),
                                "detector_guess": detector_guess(path, cells, c),
                                "source_file": str(path.relative_to(ROOT)),
                                "sheet_xml": sheet_name,
                                "label_cell": ref,
                                "nearby_values": nums,
                            }
                        )
            if file_hits:
                matching_files += 1
        except Exception as exc:
            errors.append({"file": str(path), "error": str(exc)})

    # De-duplicate exact repeated hits.
    deduped = []
    seen = set()
    for item in candidates:
        key = (
            item["final_row"],
            item["matched_label"],
            item["source_file"],
            item["label_cell"],
            tuple((v["cell"], round(v["value"], 12)) for v in item["nearby_values"]),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)

    grouped = defaultdict(list)
    for item in deduped:
        grouped[(item["final_row"], item["primary"], item["secondary"], item["diagnosis"])].append(item)

    report_rows = []
    for (row, primary, secondary, diagnosis), hits in sorted(grouped.items()):
        report_rows.append(
            {
                "final_row": row,
                "primary": primary,
                "secondary": secondary,
                "diagnosis": diagnosis,
                "candidate_count": len(hits),
                "hits": hits[:20],
            }
        )

    report = {
        "final_workbook": str(FINAL),
        "scan_root": str(ROOT),
        "missing_rows": len(missing_rows),
        "source_files_scanned": scanned_files,
        "source_files_with_hits": matching_files,
        "candidate_missing_rows": len(report_rows),
        "candidate_hits": len(deduped),
        "rows": report_rows,
        "errors": errors[:100],
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ["missing_rows", "source_files_scanned", "source_files_with_hits", "candidate_missing_rows", "candidate_hits"]}, ensure_ascii=False, indent=2))
    for row in report_rows:
        print(f"ROW {row['final_row']} | {row['primary']} | {row['secondary']} | {row['diagnosis']} | hits={row['candidate_count']}")
        for hit in row["hits"][:5]:
            vals = ", ".join(f"{v['cell']}={v['value']:.6g}" for v in hit["nearby_values"][:4])
            print(f"  {hit['detector_guess']} | {hit['matched_label']} | {hit['source_file']} | {hit['label_cell']} | {vals}")
    if errors:
        print(f"ERRORS {len(errors)}; first: {errors[0]}")


if __name__ == "__main__":
    main()
