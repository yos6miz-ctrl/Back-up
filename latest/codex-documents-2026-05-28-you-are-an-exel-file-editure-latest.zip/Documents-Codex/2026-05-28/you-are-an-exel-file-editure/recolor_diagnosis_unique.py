from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from shutil import copy2

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKBOOK = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BACKUP_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\backups")

DIAGNOSIS_STYLES = {
    "CDf": ("FFE06666", "FF000000"),
    "CDr": ("FFF4CCCC", "FF000000"),
    "UCf": ("FFF6B26B", "FF000000"),
    "UCr": ("FFFCE5CD", "FF000000"),
    "IBS": ("FF3C78D8", "FFFFFFFF"),
    "Healthy": ("FFCFE2F3", "FF000000"),
}

FALLBACK_COLORS = [
    ("FFB6D7A8", "FF000000"),
    ("FFD9EAD3", "FF000000"),
    ("FFB4A7D6", "FF000000"),
    ("FFD9D2E9", "FF000000"),
    ("FFA2C4C9", "FF000000"),
    ("FFD5A6BD", "FF000000"),
]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def main():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before diagnosis recolor {stamp}.xlsx"
    copy2(WORKBOOK, backup)

    wb = load_workbook(WORKBOOK)
    ws = wb["Final"]
    headers = header_map(ws)
    diagnosis_col = headers["Diagnosis"]

    labels = []
    for row in range(2, ws.max_row + 1):
        value = ws.cell(row, diagnosis_col).value
        if value not in (None, "") and value not in labels:
            labels.append(value)

    used_fills = {fill for fill, _font in DIAGNOSIS_STYLES.values()}
    fallback_index = 0
    for label in labels:
        if label in DIAGNOSIS_STYLES:
            continue
        while fallback_index < len(FALLBACK_COLORS) and FALLBACK_COLORS[fallback_index][0] in used_fills:
            fallback_index += 1
        if fallback_index >= len(FALLBACK_COLORS):
            raise RuntimeError(f"No unused fallback color left for diagnosis {label!r}")
        DIAGNOSIS_STYLES[label] = FALLBACK_COLORS[fallback_index]
        used_fills.add(FALLBACK_COLORS[fallback_index][0])
        fallback_index += 1

    counts = Counter()
    for row in range(2, ws.max_row + 1):
        cell = ws.cell(row, diagnosis_col)
        value = cell.value
        if value in (None, ""):
            cell.fill = PatternFill(fill_type=None)
            continue
        fill, font = DIAGNOSIS_STYLES[value]
        cell.fill = PatternFill(fill_type="solid", fgColor=fill)
        cell.font = Font(name="Calibri", size=11, color=font)
        counts[value] += 1

    color_to_labels = defaultdict(set)
    for label, (fill, _font) in DIAGNOSIS_STYLES.items():
        if label in labels:
            color_to_labels[fill].add(label)

    duplicate_color_assignments = {
        fill: sorted(values) for fill, values in color_to_labels.items() if len(values) > 1
    }
    if duplicate_color_assignments:
        raise RuntimeError(f"Diagnosis color collision: {duplicate_color_assignments}")

    wb.save(WORKBOOK)

    print(
        {
            "workbook": str(WORKBOOK),
            "backup": str(backup),
            "diagnosis_counts": dict(counts),
            "diagnosis_colors": {label: DIAGNOSIS_STYLES[label][0] for label in labels},
        }
    )


if __name__ == "__main__":
    main()
