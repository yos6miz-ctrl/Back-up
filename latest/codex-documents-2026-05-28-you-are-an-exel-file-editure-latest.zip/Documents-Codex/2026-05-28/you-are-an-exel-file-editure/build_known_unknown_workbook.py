from collections import Counter, defaultdict
from pathlib import Path
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


folder = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
merged_path = folder / "Merged Unknowns trial 6.26.xlsx"
name_path = folder / "UN stool names.xlsx"
trial_path = folder / "Unknowns trial 6.26.xlsx"
missing_path = folder / "דגימות שאין עבורן תוצאות בר אילן 5.7.26 - למשלוח.xlsx"
old_path = folder / "IBD IBS OLD.xlsx"
aliquots_path = folder / "aliqauts 20250112.xlsx"
all_path = folder / "447 and araE ALL.xlsx"
NOT_CHECKED = "לא נבדק"
MISSING = "missing"


def norm(value):
    text = "" if value is None else str(value).upper().strip()
    text = re.sub(r"\([^)]*\)", "", text)
    text = re.sub(r"^UN[\s\-_]*", "", text)
    text = re.sub(r"[^A-Z0-9]", "", text)
    return text


def old_core(value):
    text = "" if value is None else str(value).upper().strip()
    text = re.sub(r"^(CDF|CDR|IBS|UCF|UCR|UC|H)\s+", "", text)
    return norm(text)


def old_group(value):
    text = "" if value is None else str(value).upper().strip()
    match = re.match(r"^(CDF|CDR|IBS|UCF|UCR|UC|H)\b", text)
    return match.group(1) if match else None


def canonical_group(value):
    text = "" if value is None else str(value).strip()
    lookup = {
        "CDF": "CDf",
        "CDR": "CDr",
        "IBS": "IBS",
        "HEALTHY": "Healthy",
        "HS": "Healthy",
        "H": "Healthy",
        "UCF": "UCf",
        "UCR": "UCr",
        "UC": "UC",
    }
    return lookup.get(text.upper(), text)


def group_key(value):
    text = "" if value is None else str(value).upper().strip()
    return {"UCF": "UCF", "UCR": "UCR"}.get(text, text)


def diagnosis_group_key(value):
    text = canonical_group(value).upper()
    if text in {"CDF", "CDR"}:
        return "IBD"
    if text in {"IBS"}:
        return "IBS"
    return text


def is_numeric_text(value):
    return bool(re.fullmatch(r"\d+", "" if value is None else str(value).strip()))


def date_text(value):
    if value is None:
        return None
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return str(value)


def final_decision(first, second):
    values = [
        str(value).strip().lower()
        for value in [first, second]
        if value is not None and str(value).strip()
    ]
    if not values:
        return None
    if "pos" in values:
        return "IBD"
    if len(values) == 2 and all(value == "neg" for value in values):
        return "IBS"
    if "int" in values:
        return "Int"
    return None


def detector_decision(value, detector):
    if value is None or value == "":
        return None
    if detector == "PA447":
        return "Pos" if float(value) >= 0.215 else "Neg"
    return "Pos" if float(value) >= 0.15 else "Neg"


def average(values):
    nums = [float(value) for value in values if isinstance(value, (int, float))]
    if not nums:
        return None
    return sum(nums) / len(nums)


def load_missing():
    wb = load_workbook(missing_path, data_only=True)
    ws = wb.active
    rows = []
    for index, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        group, code, sample_date, source_status, sent_date = row[:5]
        if not code:
            continue
        status_text = "" if source_status is None else str(source_status).strip()
        rows.append(
            {
                "source_row": index,
                "group": str(group).strip() if group else None,
                "sample_code": str(code).strip(),
                "sample_date": date_text(sample_date),
                "sent_date": date_text(sent_date),
                "source_not_checked": "נבדק" in status_text,
            }
        )
    return rows


def load_old():
    wb = load_workbook(old_path, data_only=True)
    ws = wb.active
    rows = []
    for index, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        sample_name, pa447, arae, diagnosis = row[:4]
        if not sample_name:
            continue
        rows.append(
            {
                "source_row": index,
                "old_name": str(sample_name).strip(),
                "old_norm": norm(sample_name),
                "old_core": old_core(sample_name),
                "old_group": old_group(sample_name),
                "pa447": pa447,
                "araE": arae,
                "diagnosis": str(diagnosis).strip() if diagnosis else None,
            }
        )
    return rows


def load_all_measurements():
    wb = load_workbook(all_path, data_only=True)
    records = {}

    def add_record(sample_name, group, detector, values, source_sheet, source_row):
        measurement = average(values)
        if measurement is None:
            return
        group = canonical_group(group)
        name = str(sample_name).strip().replace("\xa0", " ")
        core = old_core(name)
        keys = {norm(name), core}
        if core.startswith("F") and len(core) > 1:
            keys.add(core[1:])
        record_key = (group_key(group), core)
        entry = records.setdefault(
            record_key,
            {
                "source_name": name,
                "diagnosis": group,
                "pa447": None,
                "araE": None,
                "pa447_source": None,
                "araE_source": None,
                "keys": set(),
            },
        )
        entry["keys"].update(key for key in keys if key)
        if detector == "PA447":
            entry["pa447"] = measurement
            entry["pa447_source"] = f"{source_sheet} row {source_row}"
        else:
            entry["araE"] = measurement
            entry["araE_source"] = f"{source_sheet} row {source_row}"

    for ws in wb.worksheets:
        detector = "PA447" if ws.title == "447" else "araE"
        group_starts = []
        for col in range(1, ws.max_column + 1):
            value = ws.cell(row=1, column=col).value
            if value:
                group_starts.append((col, canonical_group(value)))
        for row in range(2, ws.max_row + 1):
            sample_name = ws.cell(row=row, column=1).value
            if not sample_name:
                continue
            for idx, (start_col, group) in enumerate(group_starts):
                end_col = (group_starts[idx + 1][0] - 1) if idx + 1 < len(group_starts) else ws.max_column
                values = [ws.cell(row=row, column=col).value for col in range(start_col, end_col + 1)]
                add_record(sample_name, group, detector, values, ws.title, row)

    by_key = defaultdict(list)
    for entry in records.values():
        for key in entry["keys"]:
            by_key[key].append(entry)
    return list(records.values()), by_key


def load_aliases():
    wb = load_workbook(aliquots_path, data_only=True)
    rows_by_value = defaultdict(list)
    for ws in wb.worksheets:
        header_values = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        headers = [str(value).strip().lower() if value is not None else "" for value in header_values]
        for row_index, raw in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            row = list(raw)
            identifiers = set()
            numeric_identifiers = set()
            display_names = set()
            for col_index, value in enumerate(row):
                if value is None or str(value).strip() in {"", "\xa0"}:
                    continue
                text = str(value).strip()
                header = headers[col_index] if col_index < len(headers) else ""
                n = norm(text)
                if not n:
                    continue
                if re.search(r"(SAMPLE|PATIENT|NUMBER|NAME|קוד|דגימה)", header, re.I):
                    identifiers.add(n)
                    display_names.add(text)
                    if is_numeric_text(text):
                        numeric_identifiers.add(n)
                elif re.search(r"(?:^|[^A-Z])(F[-A-Z]*\d+|CT-?\d+|OB-?\d+|[A-Z]{2}-?\d+)", text.upper()):
                    identifiers.add(n)
                    display_names.add(text)
                    if is_numeric_text(text):
                        numeric_identifiers.add(n)
            if not identifiers:
                continue
            entry = {
                "sheet": ws.title,
                "row": row_index,
                "identifiers": identifiers,
                "numeric_identifiers": numeric_identifiers,
                "display_names": sorted(display_names),
            }
            for identifier in identifiers:
                rows_by_value[identifier].append(entry)
    return rows_by_value


def load_unknown_rows():
    confirmed = {
        norm("UN FSL 672"): norm("UN FLS 672"),
        norm("UN EIM19262"): norm("UN FIM19262"),
    }

    names_wb = load_workbook(name_path, data_only=True)
    names_ws = names_wb.active
    name_rows = []
    seen_name_keys = set()
    for index, row in enumerate(names_ws.iter_rows(min_row=1, max_col=2, values_only=True), start=1):
        real_name, unknown_name = row[:2]
        if not real_name and not unknown_name:
            continue
        key = (norm(real_name), norm(unknown_name))
        if key in seen_name_keys:
            continue
        seen_name_keys.add(key)
        name_rows.append(
            {
                "index": index,
                "real_name": str(real_name).strip() if real_name is not None else None,
                "unknown_name": str(unknown_name).strip() if unknown_name is not None else None,
            }
        )

    trial_wb = load_workbook(trial_path, data_only=True)
    trial_ws = trial_wb.active
    trial_rows = []
    for index, row in enumerate(trial_ws.iter_rows(min_row=2, max_col=9, values_only=True), start=2):
        if not row[0]:
            continue
        trial_rows.append(
            {
                "source_row": index,
                "unknown_name": str(row[0]).strip(),
                "values": list(row[1:9]),
            }
        )

    def find_name(trial_unknown):
        trial_key = norm(trial_unknown)
        confirmed_key = confirmed.get(trial_key)
        for i, item in enumerate(name_rows):
            keys = {norm(item["unknown_name"]), norm(item["real_name"])}
            if confirmed_key and confirmed_key in keys:
                return i, item
            if trial_key in keys:
                return i, item
        return None, None

    used_name_indexes = set()
    used_name_keys = set()
    rows = []
    for trial in trial_rows:
        index, name_item = find_name(trial["unknown_name"])
        if index is not None:
            used_name_indexes.add(index)
            used_name_keys.update(key for key in [norm(name_item["real_name"]), norm(name_item["unknown_name"])] if key)
        pa447_1, pa447_2, pa447_3, pa447_decision, arae_1, arae_2, arae_3, arae_decision = trial["values"]
        rows.append(
            [
                name_item["real_name"] if name_item else None,
                trial["unknown_name"],
                pa447_1,
                pa447_2,
                pa447_3,
                pa447_decision,
                arae_1,
                arae_2,
                arae_3,
                arae_decision,
                final_decision(pa447_decision, arae_decision),
            ]
        )

    for index, item in enumerate(name_rows):
        if index in used_name_indexes:
            continue
        item_keys = {key for key in [norm(item["real_name"]), norm(item["unknown_name"])] if key}
        if item_keys & used_name_keys:
            continue
        rows.append([item["real_name"], item["unknown_name"], None, None, None, None, None, None, None, None, None])

    return rows


def identifier_variants(item, aliases_by_value):
    variants = {norm(item["sample_code"])}
    numeric_variants = set()
    queue = [norm(item["sample_code"])]
    seen_alias_rows = set()
    alias_notes = []
    alias_display_names = []
    while queue:
        current = queue.pop()
        for entry in aliases_by_value.get(current, []):
            key = (entry["sheet"], entry["row"])
            if key in seen_alias_rows:
                continue
            seen_alias_rows.add(key)
            alias_notes.append(f"{entry['sheet']} row {entry['row']}")
            alias_display_names.extend(entry["display_names"])
            for identifier in entry["identifiers"]:
                if identifier not in variants:
                    variants.add(identifier)
                    queue.append(identifier)
            numeric_variants.update(entry["numeric_identifiers"])
    # Common sample aliases without changing meaning: F-OB-23266 can appear as OB-266.
    code = norm(item["sample_code"])
    match = re.match(r"F([A-Z]+)(\d{2})(\d{3})$", code)
    if match:
        variants.add(f"{match.group(1)}{match.group(3)}")
    clean_names = []
    sample_key = norm(item["sample_code"])
    for name in alias_display_names:
        text = str(name).strip()
        if not text or text == "\xa0":
            continue
        if norm(text) == sample_key:
            continue
        if text not in clean_names:
            clean_names.append(text)
    return variants, numeric_variants, "; ".join(alias_notes), ", ".join(clean_names[:4])


def group_compatible(missing_group, old_entry):
    mg = group_key(missing_group)
    og = old_entry["old_group"]
    if not og:
        return True
    if mg == og:
        return True
    if mg in {"CDF", "CDR"} and og in {"CDF", "CDR"}:
        return True
    if mg in {"UCF", "UCR", "UC"} and og in {"UCF", "UCR", "UC"}:
        return True
    return False


def match_measurement(item, all_by_key, aliases_by_value):
    variants, numeric_variants, alias_note, alias_name_set = identifier_variants(item, aliases_by_value)
    candidates = []
    missing_diag_key = diagnosis_group_key(item["group"])
    for variant in variants:
        for entry in all_by_key.get(variant, []):
            if missing_diag_key not in {diagnosis_group_key(entry["diagnosis"]), group_key(entry["diagnosis"])}:
                continue
            candidates.append((entry, "direct/alias sample match"))
    for numeric in numeric_variants:
        for entry in all_by_key.get(numeric, []):
            if missing_diag_key not in {diagnosis_group_key(entry["diagnosis"]), group_key(entry["diagnosis"])}:
                continue
            candidates.append((entry, "alias patient-number match"))
    if not candidates:
        return None, alias_note, alias_name_set, None
    # Prefer rows with both detectors available, then direct sample matches.
    def rank(candidate):
        entry, reason = candidate
        completeness = int(entry["pa447"] is not None) + int(entry["araE"] is not None)
        return (-completeness, 0 if reason == "direct/alias sample match" else 1)
    candidates.sort(key=rank)
    return candidates[0][0], alias_note, alias_name_set, candidates[0][1]


def match_missing_old_fallback(item, old_rows, aliases_by_value):
    variants, numeric_variants, alias_note, alias_name_set = identifier_variants(item, aliases_by_value)
    candidates = []
    for old_entry in old_rows:
        if not group_compatible(item["group"], old_entry):
            continue
        reason = None
        old_keys = {old_entry["old_norm"], old_entry["old_core"]}
        if old_entry["old_core"].startswith("F"):
            old_keys.add(old_entry["old_core"][1:])
        if old_keys & variants:
            reason = "direct/alias sample match"
        elif is_numeric_text(old_entry["old_core"]) and old_entry["old_core"] in numeric_variants:
            reason = "alias patient-number match"
        if reason:
            candidates.append((old_entry, reason))
    if not candidates:
        return None, alias_note, alias_name_set, None
    # Prefer direct sample-name/core matches over patient-number-only matches.
    candidates.sort(key=lambda item_reason: 0 if item_reason[1] == "direct/alias sample match" else 1)
    return candidates[0][0], alias_note, alias_name_set, candidates[0][1]


def known_rows(missing_rows, all_by_key, old_rows, aliases_by_value):
    rows = []
    for item in missing_rows:
        diagnosis = item["group"]
        if item.get("source_not_checked"):
            match = None
            alias_note = None
            alias_name_set = None
            match_reason = None
            source = None
        else:
            match, alias_note, alias_name_set, match_reason = match_measurement(item, all_by_key, aliases_by_value)
            source = "447 and araE ALL"
            if not match:
                match, alias_note, alias_name_set, match_reason = match_missing_old_fallback(item, old_rows, aliases_by_value)
                source = "IBD IBS OLD"
        if match and not item.get("source_not_checked"):
            pa447 = match["pa447"]
            arae = match["araE"]
            source_name = match.get("source_name") or match.get("old_name")
            pa447_decision = detector_decision(pa447, "PA447")
            arae_decision = detector_decision(arae, "araE")
            status = "measured"
            final = final_decision(pa447_decision, arae_decision)
        else:
            pa447_decision = None
            arae_decision = None
            status = NOT_CHECKED if item.get("source_not_checked") else MISSING
            final = status
            source_name = None
            pa447 = None
            arae = None
            source = None
        rows.append(
            [
                item["sample_code"],
                source_name,
                diagnosis,
                pa447,
                pa447_decision,
                arae,
                arae_decision,
                final,
                status,
                item["sample_date"],
                item["sent_date"],
                match_reason,
                source,
                alias_note,
            ]
        )
    return rows


def load_unknown_diagnosis_aliases():
    wb = load_workbook(aliquots_path, data_only=True)
    diagnosis_by_key = {}
    if "Unknown" not in wb.sheetnames:
        return diagnosis_by_key
    ws = wb["Unknown"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        real = row[1] if len(row) > 1 else None
        unknown = row[2] if len(row) > 2 else None
        disease = row[11] if len(row) > 11 else None
        if not disease:
            continue
        for value in [real, unknown]:
            key = norm(value)
            if key:
                diagnosis_by_key[key] = canonical_group(disease)
    return diagnosis_by_key


def add_unknown_diagnosis(unknown_rows, all_by_key):
    diagnosis_aliases = load_unknown_diagnosis_aliases()
    output = []
    for row in unknown_rows:
        real_name, unknown_name = row[0], row[1]
        diagnosis = diagnosis_aliases.get(norm(real_name)) or diagnosis_aliases.get(norm(unknown_name))
        if not diagnosis:
            for key in [norm(real_name), old_core(real_name), norm(unknown_name), old_core(unknown_name)]:
                entries = all_by_key.get(key, [])
                if entries:
                    diagnosis = entries[0]["diagnosis"]
                    break
        output.append([real_name, unknown_name, diagnosis, *row[2:]])
    return output


def style_sheet(ws, max_col, decision_cols, final_col=None):
    header_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
    white_fill = PatternFill(fill_type="solid", fgColor="FFFFFFFF")
    pos_fill = PatternFill(fill_type="solid", fgColor="FFF4C7C3")
    neg_fill = PatternFill(fill_type="solid", fgColor="FFCFE2F3")
    final_ibd_fill = PatternFill(fill_type="solid", fgColor="FFC00000")
    final_ibs_fill = PatternFill(fill_type="solid", fgColor="FF003399")
    int_fill = PatternFill(fill_type="solid", fgColor="FFFFE599")
    missing_fill = PatternFill(fill_type="solid", fgColor="FFE7E6E6")
    not_checked_fill = PatternFill(fill_type="solid", fgColor="FFD9D2E9")
    thin = Side(style="thin", color="FFD9D9D9")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=max_col):
        for cell in row:
            cell.fill = white_fill
            cell.font = Font(name="Calibri", size=11, color="FF000000")
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
            cell.border = border

    for cell in ws[1][:max_col]:
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=11, color="FF000000", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 36
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{ws.cell(row=1, column=max_col).column_letter}{ws.max_row}"

    for row in range(2, ws.max_row + 1):
        for col in decision_cols:
            cell = ws.cell(row=row, column=col)
            if cell.value == "Pos":
                cell.fill = pos_fill
                cell.font = Font(name="Calibri", size=11, color="FF5A1212", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif cell.value == "Neg":
                cell.fill = neg_fill
                cell.font = Font(name="Calibri", size=11, color="FF17365D", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
        if final_col:
            cell = ws.cell(row=row, column=final_col)
            if cell.value == "IBD":
                cell.fill = final_ibd_fill
                cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
            elif cell.value == "IBS":
                cell.fill = final_ibs_fill
                cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
            elif cell.value == "Int":
                cell.fill = int_fill
                cell.font = Font(name="Calibri", size=11, color="FF7F6000", bold=True)
            elif cell.value == NOT_CHECKED:
                cell.fill = not_checked_fill
                cell.font = Font(name="Calibri", size=11, color="FF4C3868", bold=True)
            elif cell.value in {"not measured", MISSING}:
                cell.fill = missing_fill
                cell.font = Font(name="Calibri", size=11, color="FF666666", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")


def main():
    missing_rows = load_missing()
    old_rows = load_old()
    _all_rows, all_by_key = load_all_measurements()
    aliases_by_value = load_aliases()
    unknown_rows = add_unknown_diagnosis(load_unknown_rows(), all_by_key)
    known = known_rows(missing_rows, all_by_key, old_rows, aliases_by_value)

    wb = Workbook()
    ws_unknown = wb.active
    ws_unknown.title = "Unknown"
    unknown_headers = [
        "Real name",
        "Unknown name",
        "Diagnosis",
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "PA447 decision",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
        "araE decision",
        "Final decision",
    ]
    ws_unknown.append(unknown_headers)
    for row in unknown_rows:
        ws_unknown.append(row)

    ws_known = wb.create_sheet("Known")
    known_headers = [
        "Sample name",
        "Matched source/sample name",
        "Diagnosis",
        "PA447 measurement",
        "PA447 decision",
        "araE measurement",
        "araE decision",
        "Final classification",
        "Measurement status",
        "Sample date",
        "Date sent",
        "Match basis",
        "Measurement source",
        "Alias source",
    ]
    ws_known.append(known_headers)
    for row in known:
        ws_known.append(row)

    ws_notes = wb.create_sheet("Match notes")
    counts = Counter(row[8] for row in known)
    final_counts = Counter(row[7] for row in known)
    ws_notes.append(["Item", "Value"])
    ws_notes.append(["Unknown rows", len(unknown_rows)])
    ws_notes.append(["Known missing-sample rows", len(known)])
    ws_notes.append(["Known measured rows", counts["measured"]])
    ws_notes.append(["Known לא נבדק rows", counts[NOT_CHECKED]])
    ws_notes.append(["Known missing rows", counts[MISSING]])
    ws_notes.append(["Known final classification counts", "; ".join(f"{key or 'blank'}: {value}" for key, value in sorted(final_counts.items(), key=lambda item: str(item[0])))])
    ws_notes.append(["Measurement source priority", "447 and araE ALL, then IBD IBS OLD only as fallback."])
    ws_notes.append(["Matching rule", "Accepted only direct source-name matches or alias matches through aliqauts sample/patient fields; loose fuzzy matches were left as not measured."])

    for ws in [ws_unknown, ws_known]:
        for col in range(1, ws.max_column + 1):
            letter = ws.cell(row=1, column=col).column_letter
            max_length = max(len(str(ws.cell(row=row, column=col).value or "")) for row in range(1, ws.max_row + 1))
            ws.column_dimensions[letter].width = min(max(max_length + 2, 12), 32)

    style_sheet(ws_unknown, 12, decision_cols=[7, 11], final_col=12)
    style_sheet(ws_known, 14, decision_cols=[5, 7], final_col=8)
    style_sheet(ws_notes, 2, decision_cols=[])
    ws_notes.column_dimensions["A"].width = 28
    ws_notes.column_dimensions["B"].width = 110

    output_path = merged_path
    try:
        wb.save(output_path)
    except PermissionError:
        output_path = folder / "Merged Unknowns trial 6.26 updated.xlsx"
        wb.save(output_path)
    print({
        "output": str(output_path),
        "unknown_rows": len(unknown_rows),
        "known_rows": len(known),
        "known_measured": counts["measured"],
        "known_not_checked": counts[NOT_CHECKED],
        "known_final_counts": dict(final_counts),
    })


if __name__ == "__main__":
    main()
