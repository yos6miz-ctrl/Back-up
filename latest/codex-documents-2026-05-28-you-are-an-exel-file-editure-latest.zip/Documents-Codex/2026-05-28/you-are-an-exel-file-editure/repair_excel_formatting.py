from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


path = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Merged Unknowns trial 6.26.xlsx")
wb = load_workbook(path)
ws = wb["Merged"]

headers = [
    "Real name",
    "Unknown name",
    "PA447 measurement 1",
    "PA447 measurement 2",
    "PA447 measurement 3",
    "PA447 decision",
    "araE measurement 1",
    "araE measurement 2",
    "araE measurement 3",
    "araE decision",
    "Final decision",
]


def final_decision(first, second):
    values = [
        str(value).strip().lower()
        for value in [first, second]
        if value is not None and str(value).strip()
    ]
    if not values:
        return None
    if "pos" in values:
        return "IBD"
    if len(values) == 2 and values[0] == "neg" and values[1] == "neg":
        return "IBS"
    if "int" in values:
        return "Int"
    return None

for col, header in enumerate(headers, start=1):
    ws.cell(row=1, column=col).value = header
for row in range(2, ws.max_row + 1):
    ws.cell(row=row, column=11).value = final_decision(ws.cell(row=row, column=6).value, ws.cell(row=row, column=10).value)

white_fill = PatternFill(fill_type="solid", fgColor="FFFFFFFF")
id_header_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
pos_fill = PatternFill(fill_type="solid", fgColor="FFF4C7C3")
neg_fill = PatternFill(fill_type="solid", fgColor="FFCFE2F3")
final_ibd_fill = PatternFill(fill_type="solid", fgColor="FFC00000")
final_ibs_fill = PatternFill(fill_type="solid", fgColor="FF003399")
final_int_fill = PatternFill(fill_type="solid", fgColor="FFFFE599")
thin_gray = Side(style="thin", color="FFD9D9D9")
border = Border(left=thin_gray, right=thin_gray, top=thin_gray, bottom=thin_gray)

for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=11):
    for cell in row:
        cell.fill = white_fill
        cell.font = Font(name="Calibri", size=11, color="FF000000", bold=False)
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
        cell.border = border

for col in range(1, 12):
    cell = ws.cell(row=1, column=col)
    cell.fill = id_header_fill
    cell.font = Font(name="Calibri", size=11, color="FF000000", bold=True)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

for row in range(2, ws.max_row + 1):
    for col in [6, 10]:
        diagnosis_cell = ws.cell(row=row, column=col)
        if diagnosis_cell.value == "Pos":
            diagnosis_cell.fill = pos_fill
            diagnosis_cell.font = Font(name="Calibri", size=11, color="FF5A1212", bold=True)
            diagnosis_cell.alignment = Alignment(horizontal="center", vertical="center")
        elif diagnosis_cell.value == "Neg":
            diagnosis_cell.fill = neg_fill
            diagnosis_cell.font = Font(name="Calibri", size=11, color="FF17365D", bold=True)
            diagnosis_cell.alignment = Alignment(horizontal="center", vertical="center")
    final_cell = ws.cell(row=row, column=11)
    if final_cell.value == "IBD":
        final_cell.fill = final_ibd_fill
        final_cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
        final_cell.alignment = Alignment(horizontal="center", vertical="center")
    elif final_cell.value == "IBS":
        final_cell.fill = final_ibs_fill
        final_cell.font = Font(name="Calibri", size=11, color="FFFFFFFF", bold=True)
        final_cell.alignment = Alignment(horizontal="center", vertical="center")
    elif final_cell.value == "Int":
        final_cell.fill = final_int_fill
        final_cell.font = Font(name="Calibri", size=11, color="FF7F6000", bold=True)
        final_cell.alignment = Alignment(horizontal="center", vertical="center")

for col in ["C", "D", "E", "G", "H", "I"]:
    for row in range(2, ws.max_row + 1):
        ws[f"{col}{row}"].number_format = "0.000"

widths = {
    "A": 18,
    "B": 22,
    "C": 16,
    "D": 16,
    "E": 16,
    "F": 18,
    "G": 16,
    "H": 16,
    "I": 16,
    "J": 18,
    "K": 16,
}
for col, width in widths.items():
    ws.column_dimensions[col].width = width
for col in ["L"]:
    ws.column_dimensions[col].width = 4

ws.row_dimensions[1].height = 36
ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:K{ws.max_row}"

wb.save(path)
print(f"saved {path}")
