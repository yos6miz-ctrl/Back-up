from copy import copy
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_row(ws, headers, primary):
    for row in range(2, ws.max_row + 1):
        if str(ws.cell(row, headers["Primary name"]).value or "").strip() == primary:
            return row
    return None


def copy_row_style(ws, source_row, target_row):
    for col in range(1, ws.max_column + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        if source.has_style:
            target._style = copy(source._style)
        target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.border = copy(source.border)
        target.fill = copy(source.fill)
        target.font = copy(source.font)


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    existing = find_row(ws, headers, "F-LB-18373")
    if existing:
        row = existing
    else:
        # Restore it in the missing CDf block, after F-ICD-21346 and before CDr missing rows.
        row = find_row(ws, headers, "F-ESH-21586") or 297
        ws.insert_rows(row)
        copy_row_style(ws, row + 1, row)
        headers = header_map(ws)

    for col in range(1, ws.max_column + 1):
        ws.cell(row, col).value = None

    values = {
        "Original tab": "Known",
        "Primary name": "F-LB-18373",
        "Secondary / other name": "CDf 373",
        "Measurement status": "missing",
        "Diagnosis": "CDf",
        "Final classification / decision": "missing",
        "Calprotectin level": None,
        "Disease location": None,
        "Sample date": datetime(2018, 12, 12),
        "Measurement/source file": None,
    }
    for header, value in values.items():
        ws.cell(row, headers[header]).value = value

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "restored_row": row})


if __name__ == "__main__":
    main()
