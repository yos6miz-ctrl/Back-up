from collections import Counter
from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill


EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
AGENT_DIR = Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
CLASSIFIER_SCRIPT = AGENT_DIR / "skills" / "classifier" / "scripts" / "run_threshold_bar_classifier.py"
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"

YELLOW = "FFF2CC"
HEADER_FILL = "D9D9D9"

FINAL_STYLES = {
    "IBD": ("C00000", "FFFFFF"),
    "IBS": ("003399", "FFFFFF"),
    "inconclusive": ("D9D2E9", "4C3868"),
    "missing": ("E7E6E6", "666666"),
    "לא נבדק": ("D9D2E9", "4C3868"),
}

DETECTOR_STYLES = {
    "Pos": ("F4C7C3", "5A1212"),
    "Neg": ("CFE2F3", "17365D"),
    "Int": ("FFF2CC", "7F6000"),
}


def load_classifier():
    spec = spec_from_file_location("ibd_ibs_classifier", CLASSIFIER_SCRIPT)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def numeric(value):
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def reset_cell(cell):
    cell.fill = PatternFill(fill_type=None)
    cell.comment = None


def style_final(cell, value):
    fill, font = FINAL_STYLES.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def style_detector(cell, value):
    fill, font = DETECTOR_STYLES.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def detector_decision_text(call):
    if call == "IBD-like":
        return "Pos"
    if call == "IBS-like":
        return "Neg"
    if call == "inconclusive":
        return "Int"
    return None


def family(call):
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    if call == "inconclusive":
        return "inconclusive"
    return None


def average(values):
    return sum(values) / len(values) if values else None


def closest_pair(entries):
    pairs = []
    for left_index, left in enumerate(entries):
        for right in entries[left_index + 1 :]:
            pairs.append((abs(left["value"] - right["value"]), left, right))
    _distance, left, right = sorted(pairs, key=lambda item: item[0])[0]
    return [left, right]


def consensus_detector(detector, values, bar, classifier):
    entries = []
    for idx, value in enumerate(values):
        if value is None:
            continue
        call, margin = classifier.detector_call(value, bar)
        entries.append({"idx": idx, "value": value, "call": call, "family": family(call), "margin": margin})

    if not entries:
        return {
            "detector": detector,
            "call": None,
            "decision": None,
            "used_value": None,
            "used_indices": [],
            "problem_indices": [],
            "problem": False,
            "reason": "No measurement values available",
            "entries": entries,
        }

    if len(entries) == 1:
        entry = entries[0]
        return {
            "detector": detector,
            "call": "inconclusive",
            "decision": "Int",
            "used_value": entry["value"],
            "used_indices": [entry["idx"]],
            "problem_indices": [entry["idx"]],
            "problem": True,
            "reason": "Only one measurement available; detector set to inconclusive",
            "entries": entries,
        }

    groups = {}
    for entry in entries:
        groups.setdefault(entry["family"], []).append(entry)

    non_inclusive = {key: value for key, value in groups.items() if key in {"IBD", "IBS"}}
    has_ibd = bool(non_inclusive.get("IBD"))
    has_ibs = bool(non_inclusive.get("IBS"))

    used_entries = None
    problem_entries = []
    reason = ""
    force_final_call = False
    if len(entries) == 2:
        if has_ibd and has_ibs:
            used_entries = entries
            problem_entries = entries
            final_call = "inconclusive"
            force_final_call = True
            reason = "Two measurements conflict: one IBD-like and one IBS-like; detector set to inconclusive"
        else:
            used_entries = entries
            final_call, _margin = classifier.detector_call(average([entry["value"] for entry in used_entries]), bar)
            reason = "Two compatible measurements averaged"
    else:
        sorted_groups = sorted(groups.items(), key=lambda item: len(item[1]), reverse=True)
        majority_family, majority_entries = sorted_groups[0]
        if len(majority_entries) >= 2:
            non_majority = [entry for entry in entries if entry["family"] != majority_family]
            if non_majority:
                used_entries = majority_entries
                problem_entries = non_majority
                reason = "Three measurements include an outlier; averaged only the two agreeing measurements"
            else:
                used_entries = entries
                reason = "Three compatible measurements averaged"
            final_call, _margin = classifier.detector_call(average([entry["value"] for entry in used_entries]), bar)
        elif has_ibd and has_ibs:
            used_entries = closest_pair(entries)
            problem_entries = [entry for entry in entries if entry not in used_entries]
            final_call, _margin = classifier.detector_call(average([entry["value"] for entry in used_entries]), bar)
            reason = "No majority; averaged the two closest measurements and marked the distant value"
        else:
            used_entries = entries
            final_call, _margin = classifier.detector_call(average([entry["value"] for entry in used_entries]), bar)
            reason = "Measurements compatible with inconclusive zone; averaged"

    used_value = average([entry["value"] for entry in used_entries]) if used_entries else None
    if used_value is not None and not force_final_call:
        final_call, final_margin = classifier.detector_call(used_value, bar)
    else:
        final_margin = None

    return {
        "detector": detector,
        "call": final_call,
        "decision": detector_decision_text(final_call),
        "used_value": used_value,
        "used_indices": [entry["idx"] for entry in used_entries],
        "problem_indices": [entry["idx"] for entry in problem_entries],
        "problem": bool(problem_entries) or len(entries) == 1,
        "reason": reason,
        "entries": entries,
        "margin": final_margin,
    }


def final_from_detector_results(classifier, results):
    calls = [result["call"] for result in results if result["call"]]
    if not calls:
        return "missing"
    return classifier.final_classification(calls)


def main():
    classifier = load_classifier()
    training, feature_cols, _fill_values, sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    final_col = headers["Final classification / decision"]
    status_col = headers["Measurement status"]
    original_tab_col = headers["Original tab"]
    name_col = headers["Primary name"]
    secondary_col = headers["Secondary / other name"]
    diagnosis_col = headers["Diagnosis"]

    measurement_cols = {
        "PA447": [headers[f"PA447 measurement {idx}"] for idx in (1, 2, 3)],
        "araE": [headers[f"araE measurement {idx}"] for idx in (1, 2, 3)],
    }
    decision_cols = {
        "PA447": headers["PA447 decision"],
        "araE": headers["araE decision"],
    }

    records = []
    changed = []
    problem_cells = []
    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, status_col).value or "").strip()
        sample = ws.cell(row, name_col).value
        secondary = ws.cell(row, secondary_col).value
        diagnosis = ws.cell(row, diagnosis_col).value

        for detector, cols in measurement_cols.items():
            for col in cols:
                reset_cell(ws.cell(row, col))

        if status in {"missing", "לא נבדק"}:
            final_value = status
            ws.cell(row, final_col).value = final_value
            style_final(ws.cell(row, final_col), final_value)
            records.append({"row": row, "sample": sample, "status": status, "final": final_value, "note": "status row"})
            continue

        if status == "old metering system":
            records.append({"row": row, "sample": sample, "status": status, "final": ws.cell(row, final_col).value, "note": "old metering system skipped"})
            continue

        detector_results = []
        row_record = {
            "row": row,
            "original_tab": ws.cell(row, original_tab_col).value,
            "sample": sample,
            "secondary": secondary,
            "diagnosis": diagnosis,
            "status": status,
        }
        for detector in [str(feature) for feature in feature_cols]:
            values = [numeric(ws.cell(row, col).value) for col in measurement_cols[detector]]
            result = consensus_detector(detector, values, bars[detector]["bar"], classifier)
            row_record[f"{detector} values"] = ", ".join("" if value is None else f"{value:.9g}" for value in values)
            row_record[f"{detector} used value"] = result["used_value"]
            row_record[f"{detector} call"] = result["call"]
            row_record[f"{detector} decision"] = result["decision"]
            row_record[f"{detector} reason"] = result["reason"]
            row_record[f"{detector} problem positions"] = ", ".join(str(idx + 1) for idx in result["problem_indices"])

            decision = result["decision"]
            ws.cell(row, decision_cols[detector]).value = decision
            style_detector(ws.cell(row, decision_cols[detector]), decision)

            for idx in result["problem_indices"]:
                cell = ws.cell(row, measurement_cols[detector][idx])
                cell.fill = PatternFill(fill_type="solid", fgColor=YELLOW)
                cell.comment = Comment(result["reason"], "Codex")
                problem_cells.append((row, sample, detector, idx + 1, cell.value, result["reason"]))

            if result["call"]:
                detector_results.append(result)

        final_value = final_from_detector_results(classifier, detector_results)
        old_final = ws.cell(row, final_col).value
        ws.cell(row, final_col).value = final_value
        style_final(ws.cell(row, final_col), final_value)
        if old_final != final_value:
            changed.append((row, sample, old_final, final_value))
        row_record["final"] = final_value
        records.append(row_record)

    try:
        wb.save(FINAL_PATH)
        saved_path = FINAL_PATH
    except PermissionError:
        saved_path = EXCEL_DIR / "Final Known and Unknown merged consensus-classifier.xlsx"
        wb.save(saved_path)

    run_date = datetime.now().strftime("%Y-%m-%d")
    result_path = AGENT_DIR / f"results {run_date}.xlsx"
    out = Workbook()
    out_ws = out.active
    out_ws.title = "Consensus classifier"
    headers_out = [
        "Row",
        "Original tab",
        "Sample",
        "Secondary",
        "Diagnosis",
        "Status",
        "PA447 values",
        "PA447 used value",
        "PA447 call",
        "PA447 decision",
        "PA447 reason",
        "PA447 problem positions",
        "araE values",
        "araE used value",
        "araE call",
        "araE decision",
        "araE reason",
        "araE problem positions",
        "Final classification",
    ]
    out_ws.append(headers_out)
    for record in records:
        out_ws.append(
            [
                record.get("row"),
                record.get("original_tab"),
                record.get("sample"),
                record.get("secondary"),
                record.get("diagnosis"),
                record.get("status"),
                record.get("PA447 values"),
                record.get("PA447 used value"),
                record.get("PA447 call"),
                record.get("PA447 decision"),
                record.get("PA447 reason"),
                record.get("PA447 problem positions"),
                record.get("araE values"),
                record.get("araE used value"),
                record.get("araE call"),
                record.get("araE decision"),
                record.get("araE reason"),
                record.get("araE problem positions"),
                record.get("final"),
            ]
        )
    for cell in out_ws[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor=HEADER_FILL)
        cell.font = Font(bold=True)
    for row_cells in out_ws.iter_rows(min_row=2):
        for cell in row_cells:
            if cell.value in {"IBD-like", "Pos", "IBD"}:
                cell.fill = PatternFill(fill_type="solid", fgColor="F4C7C3")
            elif cell.value in {"IBS-like", "Neg", "IBS"}:
                cell.fill = PatternFill(fill_type="solid", fgColor="CFE2F3")
            elif cell.value in {"inconclusive", "Int"}:
                cell.fill = PatternFill(fill_type="solid", fgColor=YELLOW)
        if row_cells[11].value or row_cells[17].value:
            for cell in row_cells:
                cell.fill = PatternFill(fill_type="solid", fgColor=YELLOW)
    out_ws.freeze_panes = "A2"
    for col in range(1, out_ws.max_column + 1):
        out_ws.column_dimensions[out_ws.cell(1, col).column_letter].width = 20
    out_ws.column_dimensions["K"].width = 58
    out_ws.column_dimensions["Q"].width = 58
    out.save(result_path)

    print(
        {
            "saved_final": str(saved_path),
            "agent_results": str(result_path),
            "bars": {key: value["bar"] for key, value in bars.items()},
            "training_sources": sources,
            "final_counts": dict(Counter(record.get("final") for record in records)),
            "changed_final_count": len(changed),
            "changed_final_examples": changed[:20],
            "problem_measurement_count": len(problem_cells),
            "problem_examples": problem_cells[:20],
        }
    )


if __name__ == "__main__":
    main()
