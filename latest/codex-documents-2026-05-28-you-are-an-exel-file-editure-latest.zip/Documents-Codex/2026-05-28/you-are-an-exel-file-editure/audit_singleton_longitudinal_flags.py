import json
import re
import zipfile
from collections import defaultdict
from pathlib import Path

import audit_final_dates_against_sources as fast_xlsx

FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\audit_singleton_longitudinal_flags_report.json")


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", clean(value)).upper()


def split_names(value):
    return [part.strip() for part in re.split(r"\s*;\s*", clean(value)) if part.strip()]


def numeric_or_blank(value):
    text = clean(value)
    if text == "":
        return 0
    try:
        return int(float(text))
    except ValueError:
        return text


def read_final_rows():
    with zipfile.ZipFile(FINAL) as zf:
        shared_strings = fast_xlsx.read_shared_strings(zf)
        root = fast_xlsx.ET.fromstring(zf.read(fast_xlsx.sheet_path_for_name(zf, "Final")))
        raw_rows = []
        for row_node in root.findall(f".//{fast_xlsx.NS_MAIN}row"):
            values = {}
            max_col = 0
            for cell in row_node.findall(f"{fast_xlsx.NS_MAIN}c"):
                index = fast_xlsx.col_index(cell.attrib["r"])
                values[index] = fast_xlsx.cell_text(cell, shared_strings)
                max_col = max(max_col, index)
            raw_rows.append([values.get(index, "") for index in range(1, max_col + 1)])
    headers = {name: index for index, name in enumerate(raw_rows[0])}
    rows = []
    for row_number, values in enumerate(raw_rows[1:], start=2):
        def get(name):
            idx = headers.get(name)
            return values[idx] if idx is not None and idx < len(values) else ""

        primary = get("Primary name")
        secondary = get("Secondary / other name")
        patient_code = get("Patient unique code")
        if clean(patient_code):
            group = f"patient:{clean(patient_code)}"
        else:
            keys = [norm(primary), *[norm(part) for part in split_names(secondary)]]
            numeric_aliases = [key for key in keys if key.isdigit()]
            group = f"num:{numeric_aliases[0]}" if numeric_aliases else f"row:{norm(primary)}"
        rows.append(
            {
                "row": row_number,
                "primary": clean(primary),
                "secondary": clean(secondary),
                "patient_unique_code": clean(patient_code),
                "diagnosis": clean(get("Diagnosis")),
                "sample_date": clean(get("Sample date")),
                "longitudinal": numeric_or_blank(get("Longitudinal sample")),
                "group": group,
            }
        )
    return rows


def main():
    rows = read_final_rows()
    groups = defaultdict(list)
    for row in rows:
        groups[row["group"]].append(row)
    singleton_nonzero = []
    multi_groups = []
    for group, items in groups.items():
        nonzero = [item for item in items if item["longitudinal"] not in (0, "0", "", None)]
        if len(items) == 1 and nonzero:
            singleton_nonzero.extend(nonzero)
        if len(items) > 1:
            values = sorted({str(item["longitudinal"]) for item in items})
            dates = sorted({item["sample_date"] for item in items})
            multi_groups.append(
                {
                    "group": group,
                    "count": len(items),
                    "longitudinal_values": values,
                    "dates": dates,
                    "rows": items,
                }
            )
    report = {
        "final": str(FINAL),
        "row_count": len(rows),
        "group_count": len(groups),
        "multi_group_count": len(multi_groups),
        "singleton_nonzero_count": len(singleton_nonzero),
        "singleton_nonzero": singleton_nonzero,
        "multi_groups_preview": multi_groups[:120],
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
