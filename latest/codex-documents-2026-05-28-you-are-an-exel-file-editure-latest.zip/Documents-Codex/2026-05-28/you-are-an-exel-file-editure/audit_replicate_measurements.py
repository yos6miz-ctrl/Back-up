from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
REPORT_PATH = WORKSPACE / "replicate_measurement_audit.json"


spec = spec_from_file_location("builder", WORKSPACE / "build_accounted_known_unknown.py")
builder = module_from_spec(spec)
spec.loader.exec_module(builder)


def load_final_rows():
    wb = load_workbook(FINAL_PATH, data_only=True)
    ws = wb["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    rows = []
    for row in range(2, ws.max_row + 1):
        rows.append(
            {
                "row": row,
                "primary": ws.cell(row, headers["Primary name"]).value,
                "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                "status": ws.cell(row, headers["Measurement status"]).value,
                "final": ws.cell(row, headers["Final classification / decision"]).value,
                "pa447_values": [
                    ws.cell(row, headers[f"PA447 measurement {idx}"]).value
                    for idx in (1, 2, 3)
                ],
                "arae_values": [
                    ws.cell(row, headers[f"araE measurement {idx}"]).value
                    for idx in (1, 2, 3)
                ],
                "source": ws.cell(row, headers["Measurement/source file"]).value,
            }
        )
    return rows


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def keys_for_row(row):
    keys = set()
    for value in (row["primary"], row["secondary"]):
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def detector_value(item, detector):
    return item.get("pa447") if detector == "PA447" else item.get("araE")


def source_sort_key(item):
    return (
        0 if item.get("source") == "edited normalized files" else 1,
        str(item.get("source_date") or ""),
        str(item.get("source_file") or ""),
        str(item.get("source_name") or ""),
        str(item.get("record_id") or ""),
    )


def unique_measurements(items, detector):
    unique = {}
    for item in items:
        value = detector_value(item, detector)
        if value is None:
            continue
        key = item.get("record_id") or (
            item.get("source"),
            item.get("source_file"),
            item.get("source_name"),
            value,
        )
        unique[key] = item
    return sorted(unique.values(), key=source_sort_key)


def item_summary(item, detector):
    return {
        "source_name": item.get("source_name"),
        "value": detector_value(item, detector),
        "diagnosis": item.get("diagnosis"),
        "source": item.get("source"),
        "source_file": item.get("source_file"),
        "source_date": item.get("source_date"),
        "source_rows": item.get("source_rows"),
        "removed_reason": item.get("pa447_removed_reason"),
        "old_metering_value": item.get("old_metering_pa447"),
    }


def main():
    final_rows = load_final_rows()
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    all_rows, all_by_key = builder.load_all_measurements()
    old_rows = builder.load_old_rows()

    per_row = []
    ct130 = []
    source_label_hits = []
    for row in final_rows:
        row_keys = expand_keys(keys_for_row(row), aliases_by_key)
        detector_matches = {}
        for detector in ("PA447", "araE"):
            candidates = []
            for key in row_keys:
                candidates.extend(all_by_key.get(key, []))
            if detector == "PA447":
                candidates.extend(
                    item for item in old_rows if row_keys & (item.get("identifiers", set()) | item.get("strict_identifiers", set()))
                )
            matches = unique_measurements(candidates, detector)
            detector_matches[detector] = matches
        record = {
            **row,
            "pa447_source_count": len(detector_matches["PA447"]),
            "arae_source_count": len(detector_matches["araE"]),
            "pa447_sources": [item_summary(item, "PA447") for item in detector_matches["PA447"]],
            "arae_sources": [item_summary(item, "araE") for item in detector_matches["araE"]],
        }
        per_row.append(record)
        if row_keys & {"CT130", "HS130", "130"} or builder.norm(row["primary"]) in {"CT130", "HS130"}:
            ct130.append(record)

    target_keys = {"CT130", "HS130", "130"}
    for item in all_rows + old_rows:
        keys = item.get("identifiers", set()) | item.get("strict_identifiers", set())
        if keys & target_keys:
            source_label_hits.append(
                {
                    "source_name": item.get("source_name") or item.get("sample_name"),
                    "source": item.get("source"),
                    "source_file": item.get("source_file"),
                    "source_rows": item.get("source_rows"),
                    "pa447": item.get("pa447"),
                    "araE": item.get("araE"),
                    "old_metering_pa447": item.get("old_metering_pa447"),
                    "removed_reason": item.get("pa447_removed_reason"),
                }
            )

    source_count_stats = {
        "rows": len(per_row),
        "pa447_source_count_distribution": Counter(item["pa447_source_count"] for item in per_row),
        "arae_source_count_distribution": Counter(item["arae_source_count"] for item in per_row),
        "both_detectors_with_at_least_two_sources": sum(
            1 for item in per_row if item["pa447_source_count"] >= 2 and item["arae_source_count"] >= 2
        ),
        "pa447_with_at_least_two_sources": sum(1 for item in per_row if item["pa447_source_count"] >= 2),
        "arae_with_at_least_two_sources": sum(1 for item in per_row if item["arae_source_count"] >= 2),
    }
    report = {
        "final_workbook": str(FINAL_PATH),
        "source_count_stats": {
            key: (dict(value) if isinstance(value, Counter) else value)
            for key, value in source_count_stats.items()
        },
        "ct130_final_rows": ct130,
        "ct130_source_label_hits": source_label_hits,
        "rows_with_single_displayed_value_but_multiple_sources": [
            {
                "row": item["row"],
                "primary": item["primary"],
                "secondary": item["secondary"],
                "status": item["status"],
                "pa447_displayed_nonblank": sum(value is not None for value in item["pa447_values"]),
                "arae_displayed_nonblank": sum(value is not None for value in item["arae_values"]),
                "pa447_source_count": item["pa447_source_count"],
                "arae_source_count": item["arae_source_count"],
            }
            for item in per_row
            if (
                sum(value is not None for value in item["pa447_values"]) <= 1
                and item["pa447_source_count"] > 1
            )
            or (
                sum(value is not None for value in item["arae_values"]) <= 1
                and item["arae_source_count"] > 1
            )
        ],
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(json.dumps(report["source_count_stats"], ensure_ascii=True, indent=2, default=str))
    print(json.dumps({"ct130_rows": len(ct130), "ct130_label_hits": len(source_label_hits)}, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
