from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "remove_requested_metadata_columns_report.json"

REMOVE_COLUMNS = [
    "Diagnosis match",
    "Shipment patient number (Study)",
    "Shipment patient number (Project)",
    "Study number",
    "Shipment box",
    "Shipment aliquots",
]


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def style_final_sheet(ws):
    headers = header_map(ws)
    for row in range(2, ws.max_row + 1):
        importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
        importer.style_final(
            ws.cell(row, headers["Final classification / decision"]),
            ws.cell(row, headers["Final classification / decision"]).value,
        )
        importer.style_detector(ws.cell(row, headers["PA447 decision"]), ws.cell(row, headers["PA447 decision"]).value)
        importer.style_detector(ws.cell(row, headers["araE decision"]), ws.cell(row, headers["araE decision"]).value)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "Longitudinal sample": 16,
        "Patient unique code": 18,
        "Bar Ilan v4 final classification": 18,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    for name, col in headers.items():
        if name and ("measurement" in str(name).lower()) and ("source" not in str(name).lower()):
            widths[name] = 13.5
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    measurement_cols = {
        col for name, col in headers.items()
        if name and ("measurement" in str(name).lower()) and ("source" not in str(name).lower())
    }
    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_cols:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif headers.get("Sample date") == col:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.zoomScale = 85


def remove_columns(path: Path):
    wb = load_workbook(path)
    ws = wb["Final"]
    before_headers = list(header_map(ws).keys())
    headers = header_map(ws)
    removed = []
    for name in sorted(REMOVE_COLUMNS, key=lambda item: headers.get(item, 0), reverse=True):
        col = headers.get(name)
        if not col:
            continue
        ws.delete_cols(col)
        removed.append(name)
        headers = header_map(ws)
    style_final_sheet(ws)
    wb.save(path)
    importer.remove_comment_and_table_parts(path)
    after_headers = list(header_map(load_workbook(path, read_only=True)["Final"]).keys())
    return before_headers, removed, after_headers


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"Final Known and Unknown merged before metadata column cleanup {stamp}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)
    before_headers, removed, after_headers = remove_columns(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)
    report = {
        "final": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "removed": removed,
        "kept_bar_ilan_v4_final_classification": "Bar Ilan v4 final classification" in after_headers,
        "before_column_count": len(before_headers),
        "after_column_count": len(after_headers),
        "after_headers": after_headers,
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
