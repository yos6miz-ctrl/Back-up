from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import re

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BUILDER_PATH = WORKSPACE / "build_accounted_known_unknown.py"
CLASSIFIER_PATH = (
    Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
    / "skills"
    / "classifier"
    / "scripts"
    / "run_threshold_bar_classifier.py"
)


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load_module("builder", BUILDER_PATH)
classifier = load_module("classifier", CLASSIFIER_PATH)


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def filename(value):
    if not value:
        return None
    return str(value).replace("/", "\\").split("\\")[-1]


def detector_value(record, detector):
    return record.get("pa447") if detector == "PA447" else record.get("araE")


def almost_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def expand_keys(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def keys_for_values(*values):
    keys = set()
    for value in values:
        keys.update(builder.identifier_variants(value))
        keys.update(builder.strict_identifier_variants(value))
    return {key for key in keys if key}


def row_keyset(ws, headers, row, aliases_by_key):
    primary = ws.cell(row, headers["Primary name"]).value
    secondary = ws.cell(row, headers["Secondary / other name"]).value
    return expand_keys(keys_for_values(primary, secondary), aliases_by_key)


def rebuild_key_to_rows(ws, headers, aliases_by_key):
    key_to_rows = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        for key in row_keyset(ws, headers, row, aliases_by_key):
            key_to_rows[key].append(row)
    return key_to_rows


def final_row_candidates(record, key_to_rows, ws, headers, aliases_by_key):
    record_keys = expand_keys(record.get("identifiers", set()) | record.get("strict_identifiers", set()), aliases_by_key)
    rows = []
    seen = set()
    for key in record_keys:
        for row in key_to_rows.get(key, []):
            if row in seen:
                continue
            seen.add(row)
            row_diagnosis = ws.cell(row, headers["Diagnosis"]).value
            if builder.compatible(row_diagnosis, record.get("diagnosis")) or record.get("diagnosis") is None:
                rows.append(row)
    return sorted(rows)


def detector_columns(headers, detector):
    return [headers[f"{detector} measurement {idx}"] for idx in (1, 2, 3)]


def numeric_values(ws, row, cols):
    values = []
    for col in cols:
        value = ws.cell(row, col).value
        if isinstance(value, (int, float)):
            values.append(float(value))
    return values


def blank_measurement_col(ws, row, cols):
    for col in cols:
        if ws.cell(row, col).value in (None, ""):
            return col
    return None


def call_family(value, bar):
    call, _margin = classifier.detector_call(value, bar)
    if call == "IBD-like":
        return "IBD"
    if call == "IBS-like":
        return "IBS"
    if call == "inconclusive":
        return "inconclusive"
    return None


def resembles_existing(existing_values, candidate_value, bar):
    candidate_family = call_family(candidate_value, bar)
    existing_families = [call_family(value, bar) for value in existing_values]
    conclusive = {family for family in existing_families if family in {"IBD", "IBS"}}
    if len(conclusive) > 1:
        return False, "existing detector values already conflict"
    if candidate_family in {"IBD", "IBS"} and conclusive and candidate_family not in conclusive:
        return False, "candidate contradicts existing detector diagnosis"
    if candidate_family in {"IBD", "IBS"} and not conclusive:
        return True, "candidate adds first conclusive detector diagnosis"
    if candidate_family == "inconclusive":
        return True, "candidate is inconclusive and does not contradict existing values"
    return True, "candidate matches existing detector diagnosis"


def parse_source_cell(text):
    parts = {"PA447": [], "araE": []}
    if not text:
        return parts
    for detector in parts:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE|Metadata):|$)", str(text), flags=re.I)
        if not match:
            continue
        for item in match.group(1).split(","):
            name = filename(item.strip())
            if name and name.lower().endswith(".xlsx") and name not in parts[detector]:
                parts[detector].append(name)
    return parts


def write_source_cell(ws, row, headers, detector, source_file):
    if not source_file:
        return
    source_col = headers["Measurement/source file"]
    parts = parse_source_cell(ws.cell(row, source_col).value)
    if source_file not in parts[detector]:
        parts[detector].append(source_file)
    segments = []
    for name in ("PA447", "araE"):
        if parts[name]:
            segments.append(f"{name}: {', '.join(parts[name][:3])}")
    ws.cell(row, source_col).value = "; ".join(segments) if segments else None


def main():
    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    training, feature_cols, _fill_values, _sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)
    key_to_rows = rebuild_key_to_rows(ws, headers, aliases_by_key)

    records = sorted(
        builder.load_edited_normalized_measurements(),
        key=lambda item: (
            str(item.get("source_date") or ""),
            str(item.get("source_file") or ""),
            str(item.get("source_name") or ""),
            str(item.get("record_id") or ""),
        ),
    )

    stats = Counter()
    added_examples = []
    ignored_examples = []
    for record in records:
        detector = "PA447" if record.get("pa447") is not None else "araE"
        if detector not in bars:
            stats["ignored_no_detector_bar"] += 1
            continue
        value = detector_value(record, detector)
        source_file = filename(record.get("source_file"))
        candidates = final_row_candidates(record, key_to_rows, ws, headers, aliases_by_key)
        if not candidates:
            stats["ignored_no_matching_final_row"] += 1
            ignored_examples.append((record.get("source_name"), detector, value, source_file, "no matching final row"))
            continue
        if len(candidates) > 1:
            stats["ignored_multiple_possible_rows"] += 1
            ignored_examples.append((record.get("source_name"), detector, value, source_file, f"rows {candidates}"))
            continue

        row = candidates[0]
        cols = detector_columns(headers, detector)
        existing_values = numeric_values(ws, row, cols)
        if any(almost_equal(existing, value) for existing in existing_values):
            stats["already_present"] += 1
            continue

        blank_col = blank_measurement_col(ws, row, cols)
        if blank_col is None:
            stats["ignored_no_empty_measurement_slot"] += 1
            ignored_examples.append((record.get("source_name"), detector, value, source_file, f"row {row} already has 3 values"))
            continue

        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
        if status == builder.NOT_CHECKED:
            stats["ignored_not_checked"] += 1
            continue
        if status == builder.OLD_METERING_SYSTEM:
            stats["ignored_old_metering_row"] += 1
            continue

        if status == builder.MISSING:
            should_add = True
            reason = "row was marked missing"
            ws.cell(row, headers["Measurement status"]).value = "measured"
        else:
            should_add, reason = resembles_existing(existing_values, float(value), bars[detector]["bar"])

        if not should_add:
            stats["ignored_contradictory"] += 1
            ignored_examples.append((record.get("source_name"), detector, value, source_file, reason))
            continue

        ws.cell(row, blank_col).value = float(value)
        ws.cell(row, blank_col).number_format = "0.000000000"
        write_source_cell(ws, row, headers, detector, source_file)
        stats["added"] += 1
        added_examples.append(
            (
                row,
                ws.cell(row, headers["Primary name"]).value,
                detector,
                value,
                source_file,
                reason,
            )
        )

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "stats": dict(stats),
            "added_examples": added_examples[:30],
            "ignored_examples": ignored_examples[:30],
        }
    )


if __name__ == "__main__":
    main()
