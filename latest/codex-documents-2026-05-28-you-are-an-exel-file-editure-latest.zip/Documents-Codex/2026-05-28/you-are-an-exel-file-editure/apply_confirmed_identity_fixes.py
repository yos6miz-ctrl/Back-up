from pathlib import Path

from openpyxl import load_workbook


FINAL_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def find_row(ws, headers, primary, secondary=None):
    for row in range(2, ws.max_row + 1):
        primary_value = str(ws.cell(row, headers["Primary name"]).value or "").strip()
        secondary_value = str(ws.cell(row, headers["Secondary / other name"]).value or "").strip()
        if primary_value != primary:
            continue
        if secondary is not None and secondary_value != secondary:
            continue
        return row
    return None


def add_value_if_space(ws, headers, row, detector, value):
    for idx in range(1, 4):
        cell = ws.cell(row, headers[f"{detector} measurement {idx}"])
        if isinstance(cell.value, (int, float)) and abs(float(cell.value) - float(value)) <= 5e-6:
            return False
    for idx in range(1, 4):
        cell = ws.cell(row, headers[f"{detector} measurement {idx}"])
        if cell.value in (None, ""):
            cell.value = float(value)
            cell.number_format = "0.000000000"
            return True
    return False


def main():
    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    removed = None
    duplicate_row = find_row(ws, headers, "UN F-DY-23247", "F-DY-23247")
    if duplicate_row:
        removed = {
            "row": duplicate_row,
            "primary": ws.cell(duplicate_row, headers["Primary name"]).value,
            "secondary": ws.cell(duplicate_row, headers["Secondary / other name"]).value,
        }
        ws.delete_rows(duplicate_row, 1)
        headers = header_map(ws)

    faa_row = find_row(ws, headers, "UN FAA113", "F-AA-19113")
    added_faa = False
    if faa_row:
        added_faa = add_value_if_space(ws, headers, faa_row, "PA447", 0.2820185302240163)

    wb.save(FINAL_PATH)
    print({"saved": str(FINAL_PATH), "removed": removed, "faa_row": faa_row, "added_faa": added_faa})


if __name__ == "__main__":
    main()
