import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const mapPath = "C:/Users/Popovtzer lab/.codex/Excel file editor/UN stool names.xlsx";
const trialPath = "C:/Users/Popovtzer lab/.codex/Excel file editor/Unknowns trial 6.26.xlsx";

async function values(file, range) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const table = await workbook.inspect({
    kind: "table",
    range: `${sheet.name}!${range}`,
    include: "values,formulas",
    tableMaxRows: 500,
    tableMaxCols: 20,
  });
  const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
  return JSON.parse(line).values;
}

async function chunkedValues(file, columnEnd, maxRow, chunkSize) {
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheet = workbook.worksheets.items[0];
  const rows = [];
  for (let start = 1; start <= maxRow; start += chunkSize) {
    const end = Math.min(maxRow, start + chunkSize - 1);
    const table = await workbook.inspect({
      kind: "table",
      range: `${sheet.name}!A${start}:${columnEnd}${end}`,
      include: "values,formulas",
      tableMaxRows: chunkSize,
      tableMaxCols: 26,
    });
    const line = table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{"));
    const parsed = JSON.parse(line);
    const matrix = parsed.values ?? [];
    for (let i = 0; i < matrix.length; i++) {
      rows.push({ sourceRow: start + i, values: matrix[i] });
    }
  }
  return rows;
}

function norm(value) {
  return String(value ?? "")
    .toUpperCase()
    .replace(/\([^)]*\)/g, "")
    .replace(/^UN\s*/, "")
    .replace(/[^A-Z0-9.]/g, "");
}

function compact(value) {
  return norm(value).replace(/\./g, "");
}

function editDistance(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[a.length][b.length];
}

function score(a, b) {
  const x = compact(a);
  const y = compact(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.includes(y) || y.includes(x)) return Math.min(x.length, y.length) / Math.max(x.length, y.length);
  const dist = editDistance(x, y);
  return 1 - dist / Math.max(x.length, y.length);
}

const mapRows = (await values(mapPath, "A1:B500"))
  .map((row, index) => ({ sourceRow: index + 1, realName: row[0], unknownName: row[1] }))
  .filter((row) => row.realName || row.unknownName);

const trialRows = (await chunkedValues(trialPath, "I", 200, 30))
  .map(({ sourceRow, values: row }) => ({
    sourceRow,
    unknownName: row[0],
    pa447_1: row[1],
    pa447_2: row[2],
    pa447_3: row[3],
    pa447_decision: row[4],
    araE_1: row[5],
    araE_2: row[6],
    araE_3: row[7],
    araE_decision: row[8],
  }))
  .filter((row) => row.sourceRow > 1 && row.unknownName);

const direct = [];
const fuzzy = [];
const unmatchedTrials = [];
const usedMap = new Set();

for (const trial of trialRows) {
  const candidates = mapRows
    .map((mapped, index) => ({
      index,
      mapped,
      byUnknown: score(trial.unknownName, mapped.unknownName),
      byReal: score(trial.unknownName, mapped.realName),
    }))
    .map((entry) => ({ ...entry, best: Math.max(entry.byUnknown, entry.byReal) }))
    .sort((a, b) => b.best - a.best);
  const best = candidates[0];
  if (best?.best === 1) {
    direct.push({ trial, mapped: best.mapped, score: best.best });
    usedMap.add(best.index);
  } else if (best?.best >= 0.72) {
    fuzzy.push({
      trial: trial.unknownName,
      trialRow: trial.sourceRow,
      suggestedReal: best.mapped.realName,
      suggestedUnknown: best.mapped.unknownName,
      mapRow: best.mapped.sourceRow,
      score: Number(best.best.toFixed(3)),
      runnerUp: candidates[1]
        ? {
            realName: candidates[1].mapped.realName,
            unknownName: candidates[1].mapped.unknownName,
            mapRow: candidates[1].mapped.sourceRow,
            score: Number(candidates[1].best.toFixed(3)),
          }
        : null,
    });
  } else {
    unmatchedTrials.push({
      trial: trial.unknownName,
      trialRow: trial.sourceRow,
      bestSuggestion: best
        ? {
            realName: best.mapped.realName,
            unknownName: best.mapped.unknownName,
            mapRow: best.mapped.sourceRow,
            score: Number(best.best.toFixed(3)),
          }
        : null,
    });
  }
}

const unmatchedMap = mapRows
  .filter((_, index) => !usedMap.has(index))
  .map((row) => ({ mapRow: row.sourceRow, realName: row.realName, unknownName: row.unknownName }));

console.log(JSON.stringify({ counts: { mapRows: mapRows.length, trialRows: trialRows.length, direct: direct.length, fuzzy: fuzzy.length, unmatchedTrials: unmatchedTrials.length, unmatchedMap: unmatchedMap.length }, fuzzy, unmatchedTrials, unmatchedMap }, null, 2));
