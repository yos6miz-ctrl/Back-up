from pathlib import Path
from difflib import SequenceMatcher
import re

from openpyxl import load_workbook


folder = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
missing_path = folder / "דגימות שאין עבורן תוצאות בר אילן 5.7.26 - למשלוח.xlsx"
old_path = folder / "IBD IBS OLD.xlsx"
aliquots_path = folder / "aliqauts 20250112.xlsx"


def norm(value):
    text = "" if value is None else str(value).upper().strip()
    text = re.sub(r"\([^)]*\)", "", text)
    text = re.sub(r"[^A-Z0-9]", "", text)
    return text


def digits(value):
    return "".join(re.findall(r"\d+", "" if value is None else str(value)))


def prefix(value):
    text = "" if value is None else str(value).upper().strip()
    match = re.match(r"([A-Z]+)", re.sub(r"^[A-Z]+F?\s+", "", text))
    return match.group(1) if match else ""


def sample_tokens(value):
    text = "" if value is None else str(value).upper().strip()
    return re.findall(r"[A-Z]+|\d+", text)


def score(a, b):
    an = norm(a)
    bn = norm(b)
    if not an or not bn:
        return 0
    if an == bn:
        return 1
    ad = digits(a)
    bd = digits(b)
    digit_score = 0
    if ad and bd:
        if ad == bd:
            digit_score = 0.75
        elif ad.endswith(bd) or bd.endswith(ad):
            digit_score = 0.55 + 0.2 * min(len(ad), len(bd)) / max(len(ad), len(bd))
    return max(SequenceMatcher(None, an, bn).ratio(), digit_score)


def load_missing():
    wb = load_workbook(missing_path, data_only=True)
    ws = wb.active
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        group, code, sample_date, _, sent_date = row[:5]
        if not code:
            continue
        rows.append({
            "group": str(group).strip() if group else None,
            "sample_code": str(code).strip(),
            "sample_date": sample_date,
            "sent_date": sent_date,
        })
    return rows


def load_old():
    wb = load_workbook(old_path, data_only=True)
    ws = wb.active
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        sample_name, pa447, arae, diagnosis = row[:4]
        if not sample_name:
            continue
        rows.append({
            "old_name": str(sample_name).strip(),
            "pa447": pa447,
            "araE": arae,
            "diagnosis": str(diagnosis).strip() if diagnosis else None,
        })
    return rows


def load_aliases():
    wb = load_workbook(aliquots_path, data_only=True)
    aliases = {}
    rows = []
    for ws in wb.worksheets:
        header = [str(cell.value).strip() if cell.value is not None else "" for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        for raw in ws.iter_rows(min_row=2, values_only=True):
            values = list(raw)
            texts = [str(v).strip() for v in values if v is not None and str(v).strip() and str(v).strip() != "\xa0"]
            # Heuristic: collect F-/CT-style sample IDs and any disease/status-like fields on the row.
            sample_like = [t for t in texts if re.search(r"(?:^|[^A-Z])(F[-A-Z]*\d+|CT-?\d+|OB-?\d+|[A-Z]{2}-?\d+)", t.upper())]
            disease_like = [t for t in texts if t.upper() in {"IBS", "CDF", "CDR", "UC", "UCF", "UCR", "HEALTHY"}]
            if sample_like:
                rows.append({"sheet": ws.title, "samples": sample_like, "disease": disease_like})
            for s in sample_like:
                aliases.setdefault(norm(s), []).append({"sheet": ws.title, "samples": sample_like, "disease": disease_like})
    return aliases, rows


missing = load_missing()
old = load_old()
aliases, alias_rows = load_aliases()

matches = []
for item in missing:
    candidates = []
    group = (item["group"] or "").upper()
    code = item["sample_code"]
    code_digits = digits(code)
    alias_hits = aliases.get(norm(code), [])
    for old_row in old:
        old_name = old_row["old_name"]
        old_digits = digits(old_name)
        s = score(code, old_name)
        if group and group in old_name.upper():
            s += 0.12
        if code_digits and old_digits and (old_digits.endswith(code_digits[-3:]) or code_digits.endswith(old_digits[-3:])):
            s += 0.08
        candidates.append((min(s, 1), old_row))
    candidates.sort(key=lambda x: x[0], reverse=True)
    best_score, best = candidates[0]
    matches.append({
        **item,
        "alias_hits": alias_hits[:3],
        "best_score": round(best_score, 3),
        "best_old_name": best["old_name"],
        "pa447": best["pa447"],
        "araE": best["araE"],
        "diagnosis": best["diagnosis"],
        "runner_up": candidates[1][1]["old_name"] if len(candidates) > 1 else None,
        "runner_up_score": round(candidates[1][0], 3) if len(candidates) > 1 else None,
        "accepted": best_score >= 0.82,
    })

print("OLD ROWS")
for row in old:
    print(row)
print("\nMISSING MATCHES")
for row in matches:
    print(row)
print("\nSUMMARY", {
    "missing": len(missing),
    "accepted": sum(1 for row in matches if row["accepted"]),
    "unmatched": sum(1 for row in matches if not row["accepted"]),
})
