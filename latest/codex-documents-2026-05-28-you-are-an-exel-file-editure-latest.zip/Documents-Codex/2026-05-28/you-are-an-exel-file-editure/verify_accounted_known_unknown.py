from collections import Counter
from pathlib import Path
import importlib.util

from openpyxl import load_workbook


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
BUILDER_PATH = WORKSPACE / "build_accounted_known_unknown.py"
spec = importlib.util.spec_from_file_location("builder", BUILDER_PATH)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

OUTPUT_PATH = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Merged Unknowns trial 6.26.xlsx")


def workbook_keys(ws, columns):
    keys = set()
    for row in range(2, ws.max_row + 1):
        values = [ws.cell(row=row, column=col).value for col in columns]
        keys.update(builder.strict_identifier_variants(*values))
        keys.update(builder.identifier_variants(*values))
    return keys


def workbook_strict_keys(ws, columns):
    keys = set()
    for row in range(2, ws.max_row + 1):
        values = [ws.cell(row=row, column=col).value for col in columns]
        keys.update(builder.strict_identifier_variants(*values))
    return keys


def main():
    wb = load_workbook(OUTPUT_PATH, data_only=True)
    unknown = wb["Unknown"]
    known = wb["Known"]
    notes = wb["Match notes"]
    issues = []

    expected_unknown_headers = [
        "Real name",
        "Unknown name",
        "PA447 measurement 1",
        "PA447 measurement 2",
        "PA447 measurement 3",
        "PA447 decision",
        "araE measurement 1",
        "araE measurement 2",
        "araE measurement 3",
        "araE decision",
        "Final decision",
        "Diagnosis",
    ]
    expected_known_headers = [
        "Sample name",
        "Synonym / other name",
        "PA447 measurement",
        "PA447 decision",
        "araE measurement",
        "araE decision",
        "Final classification",
        "Diagnosis",
        "Measurement status",
        "Sample date",
        "Date sent",
        "Match basis",
        "Measurement/source file",
    ]
    unknown_headers = [unknown.cell(row=1, column=col).value for col in range(1, len(expected_unknown_headers) + 1)]
    known_headers = [known.cell(row=1, column=col).value for col in range(1, len(expected_known_headers) + 1)]
    if unknown_headers != expected_unknown_headers:
        issues.append(f"Unknown headers mismatch: {unknown_headers}")
    if known_headers != expected_known_headers:
        issues.append(f"Known headers mismatch: {known_headers}")
    if any("Group" == header or "Aliquots aliases" == header for header in known_headers + unknown_headers):
        issues.append("Removed columns are still present")

    aliquots, _aliases, _rows = builder.load_aliquots_inventory()
    old_rows = builder.load_old_rows()
    old_strict = set().union(*(row["strict_identifiers"] for row in old_rows))
    output_unknown_keys = workbook_keys(unknown, [1, 2])
    output_unknown_strict_keys = workbook_strict_keys(unknown, [1, 2])
    output_known_keys = workbook_keys(known, [1, 2])

    for record in aliquots:
        expected_unknown = record["source_sheet"] == "Unknown" and not (record["strict_identifiers"] & old_strict)
        if expected_unknown:
            if not (record["identifiers"] & output_unknown_keys):
                issues.append(f"Aliquots Unknown row not present in Unknown output: {record['source_sheet']} {record['source_row']} {record['sample_name']}")
        elif not (record["identifiers"] & output_known_keys):
            issues.append(f"Aliquots Known row not present in Known output: {record['source_sheet']} {record['source_row']} {record['sample_name']}")

    old_in_unknown = old_strict & output_unknown_strict_keys
    if old_in_unknown:
        issues.append(f"Old-file identities still appear in Unknown output: {sorted(old_in_unknown)[:12]}")
    for old in old_rows:
        if not (old["identifiers"] & output_known_keys):
            issues.append(f"Old row not represented in Known output: {old['sample_name']}")

    unknown_names = [unknown.cell(row=row, column=2).value for row in range(2, unknown.max_row + 1)]
    if len(unknown_names) != len(set(unknown_names)):
        issues.append("Duplicate Unknown names remain")
    known_names = [known.cell(row=row, column=1).value for row in range(2, known.max_row + 1)]
    duplicates = [name for name, count in Counter(known_names).items() if name and count > 1]
    if duplicates:
        issues.append(f"Duplicate Known sample names remain: {duplicates[:12]}")

    for row in range(2, known.max_row + 1):
        status = known.cell(row=row, column=9).value
        final = known.cell(row=row, column=7).value
        if status == "not measured":
            issues.append(f"English not measured remains at Known row {row}")
        if status == builder.NOT_CHECKED and final != builder.NOT_CHECKED:
            issues.append(f"לא נבדק row has wrong final value at Known row {row}")
        if status == builder.MISSING and final != builder.MISSING:
            issues.append(f"missing row has wrong final value at Known row {row}")
        if status == builder.OLD_METERING_SYSTEM:
            if final is not None:
                issues.append(f"old metering system row has filled final value at Known row {row}")
            if known.cell(row=row, column=3).value is None:
                issues.append(f"old metering system row is missing PA447 value at Known row {row}")
            if known.cell(row=row, column=4).value is not None:
                issues.append(f"old metering system row has PA447 decision at Known row {row}")
        if status == "measured":
            expected = builder.final_decision(
                known.cell(row=row, column=4).value,
                known.cell(row=row, column=6).value,
            )
            if final != expected:
                issues.append(f"Final decision mismatch at Known row {row}: {final} != {expected}")

    style_checks = {
        "unknown_header_fill": unknown["A1"].fill.fgColor.rgb,
        "known_header_fill": known["A1"].fill.fgColor.rgb,
        "notes_header_fill": notes["A1"].fill.fgColor.rgb,
        "known_ibd_fill": None,
        "known_ibs_fill": None,
        "known_not_checked_fill": None,
    }
    for row in range(2, known.max_row + 1):
        final = known.cell(row=row, column=7).value
        if final == "IBD" and not style_checks["known_ibd_fill"]:
            style_checks["known_ibd_fill"] = known.cell(row=row, column=7).fill.fgColor.rgb
        if final == "IBS" and not style_checks["known_ibs_fill"]:
            style_checks["known_ibs_fill"] = known.cell(row=row, column=7).fill.fgColor.rgb
        if final == builder.NOT_CHECKED and not style_checks["known_not_checked_fill"]:
            style_checks["known_not_checked_fill"] = known.cell(row=row, column=7).fill.fgColor.rgb

    print(
        {
            "unknown_rows": unknown.max_row - 1,
            "known_rows": known.max_row - 1,
            "aliquots_records": len(aliquots),
            "old_rows": len(old_rows),
            "known_status_counts": dict(Counter(known.cell(row=row, column=9).value for row in range(2, known.max_row + 1))),
            "known_final_counts": dict(Counter(known.cell(row=row, column=7).value for row in range(2, known.max_row + 1))),
            "style_checks": style_checks,
            "issues": issues,
        }
    )


if __name__ == "__main__":
    main()
