from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXCEL_DIR = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
AGENT_DIR = Path(r"C:\Users\Popovtzer lab\.codex\IBD-IBS Sample Classifier")
FINAL_PATH = EXCEL_DIR / "Final Known and Unknown merged.xlsx"
BUILDER_PATH = WORKSPACE / "build_accounted_known_unknown.py"
CLASSIFIER_SCRIPT = AGENT_DIR / "skills" / "classifier" / "scripts" / "run_threshold_bar_classifier.py"


def load_module(path, name):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def expand_with_aliases(keys, aliases_by_key):
    expanded = set(keys)
    changed = True
    while changed:
        changed = False
        for key in list(expanded):
            for alias in aliases_by_key.get(key, set()):
                if alias not in expanded:
                    expanded.add(alias)
                    changed = True
    return expanded


def row_keys(builder, primary, secondary):
    keys = set()
    keys.update(builder.identifier_variants(primary, secondary))
    keys.update(builder.strict_identifier_variants(primary, secondary))
    return {key for key in keys if key}


def final_from_call(call):
    if call == "IBD-like":
        return "IBD*"
    if call == "IBS-like":
        return "IBS*"
    return "inconclusive*"


def decision_from_call(call):
    if call == "IBD-like":
        return "Pos"
    if call == "IBS-like":
        return "Neg"
    return "Int"


def style_final(cell, value):
    base = str(value or "").rstrip("*")
    styles = {
        "IBD": ("C00000", "FFFFFF"),
        "IBS": ("003399", "FFFFFF"),
        "inconclusive": ("D9D2E9", "4C3868"),
    }
    fill, font = styles.get(base, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def style_detector(cell, value):
    styles = {
        "Pos": ("F4C7C3", "5A1212"),
        "Neg": ("CFE2F3", "17365D"),
        "Int": ("FFF2CC", "7F6000"),
    }
    fill, font = styles.get(value, ("FFFFFF", "000000"))
    cell.fill = PatternFill(fill_type="solid", fgColor=fill)
    cell.font = Font(name="Calibri", size=11, color=font, bold=True)


def find_old_metering_item(builder, all_by_key, keys):
    for key in keys:
        for item in all_by_key.get(key, []):
            if item.get("pa447_removed_reason") == "Found in 447-old without GA/glutaric marker":
                return item
    return None


def main():
    builder = load_module(BUILDER_PATH, "builder")
    classifier = load_module(CLASSIFIER_SCRIPT, "ibd_ibs_classifier")
    training, feature_cols, _fill_values, sources = classifier.load_training()
    bars = classifier.learn_detector_bars(training, feature_cols)

    _aliquots, aliases_by_key, _rows_by_key = builder.load_aliquots_inventory()
    _all_rows, all_by_key = builder.load_all_measurements()

    wb = load_workbook(FINAL_PATH)
    ws = wb["Final"]
    headers = header_map(ws)

    restored = []
    missing_source = []
    for row in range(2, ws.max_row + 1):
        if ws.cell(row, headers["Measurement status"]).value != "old metering system":
            continue
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        keys = expand_with_aliases(row_keys(builder, primary, secondary), aliases_by_key)
        item = find_old_metering_item(builder, all_by_key, keys)
        if not item or item.get("old_metering_pa447") is None:
            missing_source.append((row, primary, secondary))
            continue

        value = item["old_metering_pa447"]
        call, margin = classifier.detector_call(value, bars["PA447"]["bar"])
        final = final_from_call(call)
        decision = decision_from_call(call)

        ws.cell(row, headers["PA447 measurement 1"]).value = value
        ws.cell(row, headers["PA447 measurement 2"]).value = None
        ws.cell(row, headers["PA447 measurement 3"]).value = None
        ws.cell(row, headers["PA447 decision"]).value = decision
        style_detector(ws.cell(row, headers["PA447 decision"]), decision)

        for header in ["araE measurement 1", "araE measurement 2", "araE measurement 3", "araE decision"]:
            ws.cell(row, headers[header]).value = None

        final_cell = ws.cell(row, headers["Final classification / decision"])
        final_cell.value = final
        style_final(final_cell, final)
        final_cell.comment = Comment(
            "Old metering system: keep the value, but interpret lightly; this is not a clean final decision.",
            "Codex",
        )
        restored.append((row, primary, value, decision, final, margin))

    wb.save(FINAL_PATH)
    print(
        {
            "saved": str(FINAL_PATH),
            "restored_old_metering_rows": len(restored),
            "missing_source_rows": missing_source,
            "bars": {key: value["bar"] for key, value in bars.items()},
            "training_sources": sources,
            "examples": restored[:20],
        }
    )


if __name__ == "__main__":
    main()
