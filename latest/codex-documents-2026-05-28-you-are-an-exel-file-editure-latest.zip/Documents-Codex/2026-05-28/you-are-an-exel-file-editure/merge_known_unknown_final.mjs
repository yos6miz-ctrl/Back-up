import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/.codex/Excel file editor/Merged Unknowns trial 6.26.xlsx";
const outputPath = "C:/Users/Popovtzer lab/.codex/Excel file editor/Final Known and Unknown merged.xlsx";
const previewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/you-are-an-exel-file-editure/previews/Final_merged.png";
const metadataPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/you-are-an-exel-file-editure/merged_metadata_overrides.json";

const source = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const unknown = source.worksheets.getItem("Unknown");
const known = source.worksheets.getItem("Known");
const metadataReport = JSON.parse(await fs.readFile(metadataPath, "utf8"));
const metadata = metadataReport.overrides ?? {};

function nonEmptyRows(values) {
  return values.slice(1).filter((row) => row.some((value) => value !== null && value !== ""));
}

function numericOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

const unknownValues = unknown.getUsedRange(true).values;
const knownValues = known.getUsedRange(true).values;
const unknownRows = nonEmptyRows(unknownValues);
const knownRows = nonEmptyRows(knownValues);

const headers = [
  "Original tab",
  "Primary name",
  "Secondary / other name",
  "Diagnosis",
  "Final classification / decision",
  "Calprotectin level",
  "Disease location",
  "PA447 measurement 1",
  "PA447 measurement 2",
  "PA447 measurement 3",
  "PA447 decision",
  "araE measurement 1",
  "araE measurement 2",
  "araE measurement 3",
  "araE decision",
  "Measurement status",
  "Sample date",
  "Measurement/source file",
];

const merged = [headers];
const sourceIds = [];

for (const [index, row] of unknownRows.entries()) {
  const originalRow = index + 2;
  const extra = metadata[`Unknown:${originalRow}`] ?? {};
  const metadataSources = extra.metadata_sources?.length
    ? `; Metadata: ${extra.metadata_sources.join("; ")}`
    : "";
  const calprotectinLevel = numericOrNull(extra.calprotectin_level);
  merged.push([
    "Unknown",
    row[1],
    row[0],
    row[11],
    row[10],
    calprotectinLevel,
    extra.disease_location ?? null,
    row[2],
    row[3],
    row[4],
    row[5],
    row[6],
    row[7],
    row[8],
    row[9],
    extra.measurement_status ?? null,
    extra.sample_date ?? null,
    (extra.measurement_source_file ?? null) ? `${extra.measurement_source_file}${metadataSources}` : null,
  ]);
  sourceIds.push(`Unknown:${originalRow}`);
}

for (const [index, row] of knownRows.entries()) {
  const originalRow = index + 2;
  const extra = metadata[`Known:${originalRow}`] ?? {};
  const sampleDate = row[9] ?? extra.sample_date ?? null;
  const metadataSources = extra.metadata_sources?.length
    ? `; Metadata: ${extra.metadata_sources.join("; ")}` 
    : "";
  const calprotectinLevel = numericOrNull(extra.calprotectin_level);
  const sourceFile = row[12]
    ? `${row[12]}${metadataSources}`
    : (extra.metadata_sources?.length ? `Metadata: ${extra.metadata_sources.join("; ")}` : null);
  merged.push([
    "Known",
    row[0],
    row[1],
    row[7],
    row[6],
    calprotectinLevel,
    extra.disease_location ?? null,
    row[2],
    null,
    null,
    row[3],
    row[4],
    null,
    null,
    row[5],
    row[8],
    sampleDate,
    sourceFile,
  ]);
  sourceIds.push(`Known:${originalRow}`);
}

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Final");
sheet.getRangeByIndexes(0, 0, merged.length, headers.length).values = merged;
sheet.freezePanes.freezeRows(1);
sheet.freezePanes.freezeColumns(3);
sheet.showGridLines = false;

const usedRange = sheet.getRangeByIndexes(0, 0, merged.length, headers.length);
usedRange.format = {
  font: { color: "#000000" },
  borders: { preset: "all", style: "thin", color: "#D9D9D9" },
};
sheet.getRangeByIndexes(0, 0, 1, headers.length).format = {
  fill: "#D9D9D9",
  font: { bold: true, color: "#000000" },
  wrapText: true,
};

const widths = [12, 18, 20, 12, 18, 15, 26, 11, 11, 11, 12, 11, 11, 11, 12, 20, 13, 38];
for (const [col, width] of widths.entries()) {
  sheet.getRangeByIndexes(0, col, merged.length, 1).format.columnWidth = width;
}

function colorCell(rowIndex, colIndex, fill, fontColor = "#000000", bold = true) {
  sheet.getCell(rowIndex, colIndex).format = {
    fill,
    font: { color: fontColor, bold },
  };
}

for (let row = 1; row < merged.length; row += 1) {
  const originalTab = merged[row][0];
  const diagnosis = merged[row][3];
  const finalDecision = merged[row][4];
  const pa447Decision = merged[row][10];
  const araeDecision = merged[row][14];
  const status = merged[row][15];

  if (originalTab === "Known") colorCell(row, 0, "#E7E6E6");
  if (originalTab === "Unknown") colorCell(row, 0, "#D9EAD3");

  if (diagnosis === "CDf") colorCell(row, 3, "#E06666", "#FFFFFF");
  if (diagnosis === "CDr") colorCell(row, 3, "#F4CCCC", "#5A1212");
  if (diagnosis === "Healthy" || diagnosis === "HS") colorCell(row, 3, "#CFE2F3", "#17365D");
  if (diagnosis === "IBS") colorCell(row, 3, "#3C78D8", "#FFFFFF");

  for (const [value, col] of [[pa447Decision, 10], [araeDecision, 14]]) {
    if (value === "Pos") colorCell(row, col, "#F4C7C3", "#5A1212");
    if (value === "Neg") colorCell(row, col, "#CFE2F3", "#17365D");
  }

  if (finalDecision === "IBD") colorCell(row, 4, "#C00000", "#FFFFFF");
  if (finalDecision === "IBS") colorCell(row, 4, "#003399", "#FFFFFF");
  if (finalDecision === "Int") colorCell(row, 4, "#FFE599", "#7F6000");
  if (finalDecision === "missing") colorCell(row, 4, "#E7E6E6", "#666666");
  if (finalDecision === "לא נבדק") colorCell(row, 4, "#D9D2E9", "#4C3868");
  if (finalDecision === "לא נבדק") colorCell(row, 5, "#D9D2E9", "#4C3868");
  if (status === "old metering system") colorCell(row, 15, "#FFE599", "#7F6000");
}

sheet.tables.add(`A1:R${merged.length}`, true, "FinalMergedTable");

await fs.mkdir("C:/Users/Popovtzer lab/.codex/Excel file editor", { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
let savedOutputPath = outputPath;
try {
  await output.save(outputPath);
} catch (error) {
  if (error?.code !== "EBUSY") throw error;
  savedOutputPath = outputPath.replace(/\.xlsx$/i, " classifier-filled.xlsx");
  await output.save(savedOutputPath);
}

await fs.mkdir("C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/you-are-an-exel-file-editure/previews", { recursive: true });
const preview = await workbook.render({ sheetName: "Final", range: "A1:R26", scale: 1, format: "png" });
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));

const duplicateSourceIds = sourceIds.filter((id, index) => sourceIds.indexOf(id) !== index);
const primaryNames = merged.slice(1).map((row) => row[1]).filter(Boolean);
const duplicatePrimaryNames = primaryNames.filter((name, index) => primaryNames.indexOf(name) !== index);

console.log(JSON.stringify({
  sourceUnknownRows: unknownRows.length,
  sourceKnownRows: knownRows.length,
  expectedRows: unknownRows.length + knownRows.length,
  mergedRows: merged.length - 1,
  duplicateSourceIds: [...new Set(duplicateSourceIds)],
  duplicatePrimaryNames: [...new Set(duplicatePrimaryNames)],
  outputPath: savedOutputPath,
  intendedOutputPath: outputPath,
  previewPath,
}, null, 2));
