from pathlib import Path
from openpyxl import load_workbook

path = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\447 and araE ALL.xlsx")
wb = load_workbook(path, data_only=True)
for ws in wb.worksheets:
    print("SHEET", ws.title, "rows", ws.max_row, "cols", ws.max_column)
    for r in range(1, min(ws.max_row, 18) + 1):
        cells = []
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if v not in (None, ""):
                cells.append(f"{c}:{v}")
        print(r, " | ".join(cells))
    print("TAIL NONEMPTY")
    for r in range(max(1, ws.max_row - 10), ws.max_row + 1):
        cells = []
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if v not in (None, ""):
                cells.append(f"{c}:{v}")
        print(r, " | ".join(cells))
    print()
