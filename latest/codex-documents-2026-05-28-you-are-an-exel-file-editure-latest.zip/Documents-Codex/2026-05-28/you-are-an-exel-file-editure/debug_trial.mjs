import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const input = await FileBlob.load("C:/Users/Popovtzer lab/.codex/Excel file editor/Unknowns trial 6.26.xlsx");
const workbook = await SpreadsheetFile.importXlsx(input);
const sheet = workbook.worksheets.items[0];
for (const range of ["A1:I30", "A1:Z30", "A1:Z200", "A1:I200"]) {
  const table = await workbook.inspect({
    kind: "table",
    range: `${sheet.name}!${range}`,
    include: "values,formulas",
    tableMaxRows: 300,
    tableMaxCols: 26,
  });
  const obj = JSON.parse(table.ndjson.trim().split(/\r?\n/).find((entry) => entry.startsWith("{")));
  console.log(range, obj.rows, obj.cols, obj.values.slice(0, 5).map((row) => row.slice(0, 10)));
}
