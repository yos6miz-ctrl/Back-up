import json
from collections import defaultdict
from pathlib import Path

from audit_longitudinal_sequence_consistency import date_key
from audit_singleton_longitudinal_flags import read_final_rows

REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\audit_same_date_longitudinal_bug_pattern_report.json")


def nonzero(value):
    return value not in (None, "", 0, "0")


def main():
    rows = [row for row in read_final_rows() if row["primary"]]
    groups = defaultdict(list)
    for row in rows:
        groups[row["group"]].append(row)

    same_date_multirow_nonzero = []
    singleton_nonzero = []
    for group, items in groups.items():
        dated = {date_key(item["sample_date"]) for item in items if date_key(item["sample_date"])}
        if len(items) > 1 and len(dated) <= 1 and any(nonzero(item["longitudinal"]) for item in items):
            same_date_multirow_nonzero.append(
                {
                    "group": group,
                    "distinct_dates": sorted(dated),
                    "rows": items,
                }
            )
        if len(items) == 1 and nonzero(items[0]["longitudinal"]):
            singleton_nonzero.append(items[0])

    report = {
        "same_date_multirow_nonzero_count": len(same_date_multirow_nonzero),
        "same_date_multirow_nonzero": same_date_multirow_nonzero,
        "singleton_nonzero_count": len(singleton_nonzero),
        "singleton_nonzero": singleton_nonzero,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
