import json
import re
from pathlib import Path

import openpyxl

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FILES = [
    ROOT / "Final Known and Unknown merged.xlsx",
    ROOT / "aliqauts 20260801.xlsx",
    WORKSPACE / "aliqauts 20260801 working copy.xlsx",
]
TARGET_PATTERNS = [
    re.compile(r"\bCT\s*-?\s*113\b", re.I),
    re.compile(r"\bDS\s*2\s*d\s*0?527\b", re.I),
    re.compile(r"\bDS\s*2d0?527\b", re.I),
    re.compile(r"\b2d0?527\b", re.I),
]


def clean(value):
    return str(value or "").replace("\xa0", " ").strip()


def main():
    out = {}
    for path in FILES:
        if not path.exists():
            continue
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        matches = []
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                values = [cell.value for cell in row]
                text = " | ".join(clean(value) for value in values)
                if any(pattern.search(text) for pattern in TARGET_PATTERNS):
                    matches.append(
                        {
                            "sheet": ws.title,
                            "row": row[0].row,
                            "values": values[: min(len(values), 35)],
                        }
                    )
        wb.close()
        out[str(path)] = matches
    print(json.dumps(out, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
