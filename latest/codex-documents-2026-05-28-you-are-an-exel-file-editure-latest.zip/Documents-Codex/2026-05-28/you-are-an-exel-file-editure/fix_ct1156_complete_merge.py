import json
import re
import shutil
import zipfile
from pathlib import Path

from openpyxl import load_workbook

import expand_measurement_columns_and_show_all as expander
import import_2026_measurements as importer


FINAL_CODEX = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
FINAL_ONEDRIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\fix_ct1156_complete_merge_report.json")

PA447_RAW_TRACE_OLD_1156 = {
    "value": 0.3283287853563772,
    "source_file": "20230928 447 15 eddited.xlsx",
}


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def detector_cols(headers, detector):
    cols = []
    index = 1
    while f"{detector} measurement {index}" in headers:
        cols.append(headers[f"{detector} measurement {index}"])
        index += 1
    return cols


def numeric_equal(left, right, tolerance=5e-6):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def add_alias(existing, alias):
    parts = []
    for value in (existing, alias):
        if not value:
            continue
        for part in re.split(r"\s*;\s*", str(value)):
            part = part.strip()
            if not part:
                continue
            part = part.replace("CDf 1156 old (old)", "CDf 1156 old")
            if part not in parts:
                parts.append(part)
    return "; ".join(parts)


def source_parts(value):
    return importer.parse_source_cell(value)


def write_sources(ws, headers, row, parts):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for label in parts.get(detector, []):
            label = str(label).strip()
            if label and label not in labels:
                labels.append(label)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments) if segments else None


def measurement_entries(ws, headers, row, detector):
    entries = []
    for col in detector_cols(headers, detector):
        value = ws.cell(row, col).value
        if importer.is_numeric(value):
            entries.append(float(value))
    return entries


def set_measurements(ws, headers, row, detector, values):
    cols = detector_cols(headers, detector)
    if len(values) > len(cols):
        raise RuntimeError(f"Need {len(values)} {detector} columns but only have {len(cols)}")
    for idx, col in enumerate(cols):
        cell = ws.cell(row, col)
        cell.value = values[idx] if idx < len(values) else None
        if cell.value is not None:
            cell.number_format = "0.000000000"


def workbook_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "tables": [name for name in zf.namelist() if name.startswith("xl/tables/")],
        }


def main():
    wb = load_workbook(FINAL_CODEX)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    ct_rows = []
    yd_rows = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        primary_norm = norm(primary)
        secondary_norm = norm(secondary)
        if primary_norm == "CT1156":
            ct_rows.append(row)
        if primary_norm in {"CDFFYD21156", "FYD21156"} or secondary_norm in {"CDFFYD21156", "FYD21156"}:
            yd_rows.append(row)

    if len(ct_rows) != 1 or len(yd_rows) != 1:
        raise RuntimeError(f"Expected one CT1156 row and one F-YD21156 row; found {ct_rows=} {yd_rows=}")

    target = ct_rows[0]
    duplicate = yd_rows[0]
    before = {
        "target_row": target,
        "duplicate_row": duplicate,
        "target_secondary": ws.cell(target, headers["Secondary / other name"]).value,
        "duplicate_primary": ws.cell(duplicate, headers["Primary name"]).value,
        "target_pa447": measurement_entries(ws, headers, target, "PA447"),
        "duplicate_pa447": measurement_entries(ws, headers, duplicate, "PA447"),
    }

    ws.cell(target, headers["Secondary / other name"]).value = add_alias(
        ws.cell(target, headers["Secondary / other name"]).value,
        "CDf 1156 old",
    )
    ws.cell(target, headers["Secondary / other name"]).value = add_alias(
        ws.cell(target, headers["Secondary / other name"]).value,
        "CDf F-YD21156",
    )

    merged_sources = source_parts(ws.cell(target, headers["Measurement/source file"]).value)
    dup_sources = source_parts(ws.cell(duplicate, headers["Measurement/source file"]).value)
    for detector in ("PA447", "araE"):
        for source in dup_sources[detector]:
            if source not in merged_sources[detector]:
                merged_sources[detector].append(source)
    if PA447_RAW_TRACE_OLD_1156["source_file"] not in merged_sources["PA447"]:
        merged_sources["PA447"].append(PA447_RAW_TRACE_OLD_1156["source_file"])
    write_sources(ws, headers, target, merged_sources)

    # Keep all displayed values. Order old values first by source/date, then today's repeat.
    pa447_values = []
    for value in measurement_entries(ws, headers, duplicate, "PA447"):
        if not any(numeric_equal(value, existing) for existing in pa447_values):
            pa447_values.append(value)
    for value in measurement_entries(ws, headers, target, "PA447"):
        if not any(numeric_equal(value, existing) for existing in pa447_values):
            pa447_values.append(value)
    if not any(numeric_equal(PA447_RAW_TRACE_OLD_1156["value"], existing) for existing in pa447_values):
        pa447_values.insert(1, PA447_RAW_TRACE_OLD_1156["value"])
    set_measurements(ws, headers, target, "PA447", pa447_values)

    arae_values = measurement_entries(ws, headers, target, "araE")
    set_measurements(ws, headers, target, "araE", arae_values)

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)
    final_after = expander.reclassify_row_majority(ws, headers, target, bars)

    ws.delete_rows(duplicate, 1)
    importer.sort_records(ws, headers)
    wb.save(FINAL_CODEX)
    importer.remove_comment_and_table_parts(FINAL_CODEX)

    copy_error = None
    try:
        shutil.copy2(FINAL_CODEX, FINAL_ONEDRIVE)
    except PermissionError as exc:
        copy_error = str(exc)

    check_wb = load_workbook(FINAL_CODEX, read_only=False, data_only=True)
    check_ws = check_wb["Final"]
    check_headers = importer.header_map(check_ws)
    found = []
    duplicate_rows_after = []
    for row in range(2, check_ws.max_row + 1):
        primary = check_ws.cell(row, check_headers["Primary name"]).value
        secondary = check_ws.cell(row, check_headers["Secondary / other name"]).value
        if norm(primary) == "CT1156":
            found.append(
                {
                    "row": row,
                    "primary": primary,
                    "secondary": secondary,
                    "final": check_ws.cell(row, check_headers["Final classification / decision"]).value,
                    "pa447": measurement_entries(check_ws, check_headers, row, "PA447"),
                    "pa447_decision": check_ws.cell(row, check_headers["PA447 decision"]).value,
                    "arae": measurement_entries(check_ws, check_headers, row, "araE"),
                    "arae_decision": check_ws.cell(row, check_headers["araE decision"]).value,
                    "sources": check_ws.cell(row, check_headers["Measurement/source file"]).value,
                }
            )
        if norm(primary) in {"CDF1156OLD", "CDFFYD21156", "FYD21156"}:
            duplicate_rows_after.append({"row": row, "primary": primary, "secondary": secondary})
    # Capture CT1156 cell styles after sort.
    style_check = []
    if found:
        row = found[0]["row"]
        for detector in ("PA447", "araE"):
            for idx, col in enumerate(detector_cols(check_headers, detector), start=1):
                cell = check_ws.cell(row, col)
                if importer.is_numeric(cell.value):
                    fill = cell.fill.fgColor.rgb if cell.fill and cell.fill.fill_type == "solid" else None
                    style_check.append(
                        {
                            "detector": detector,
                            "slot": idx,
                            "value": float(cell.value),
                            "bold": bool(cell.font.bold),
                            "fill": fill,
                        }
                    )
    check_wb.close()

    report = {
        "before": before,
        "final_after_before_sort": final_after,
        "ct1156_after": found,
        "duplicate_rows_after": duplicate_rows_after,
        "style_check": style_check,
        "copy_error": copy_error,
        "codex_health": workbook_health(FINAL_CODEX),
        "onedrive_health": None if copy_error else workbook_health(FINAL_ONEDRIVE),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
