from __future__ import annotations

from collections import defaultdict
from copy import copy
from datetime import datetime
from pathlib import Path
import json
import math
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

import expand_measurement_columns_and_show_all as repeat_logic
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "merge_aug25_duplicate_shipments_report.json"

NEW_SOURCE_FILES = {
    "20260824 UN 447.xlsx",
    "20260825 UN 447.xlsx",
    "20260824 UN araE.xlsx",
    "20260825 UN araE.xlsx",
}


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def parse_sources(text):
    parts = {"PA447": [], "araE": []}
    text = clean(text)
    if not text:
        return parts
    if "PA447:" not in text and "araE:" not in text:
        for detector in parts:
            parts[detector].append(text)
        return parts
    for detector in parts:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if not match:
            continue
        for item in match.group(1).split(","):
            label = clean(item.replace("/", "\\").split("\\")[-1])
            if label and label not in parts[detector]:
                parts[detector].append(label)
    return parts


def write_sources(ws, headers, row, source_parts):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for label in source_parts[detector]:
            label = clean(str(label).replace("/", "\\").split("\\")[-1])
            if label and label not in labels:
                labels.append(label)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments) if segments else None


def almost_equal(left, right, tolerance=5e-10):
    try:
        return abs(float(left) - float(right)) <= tolerance
    except Exception:
        return False


def first_blank_or_existing(ws, row, cols, value):
    for col in cols:
        if is_numeric(ws.cell(row, col).value) and almost_equal(ws.cell(row, col).value, value):
            return col, False
    for col in cols:
        if ws.cell(row, col).value in (None, ""):
            return col, True
    return None, False


def copy_measurement_style(ws, src_row, src_col, dest_row, dest_col):
    src = ws.cell(src_row, src_col)
    dest = ws.cell(dest_row, dest_col)
    if src.has_style:
        dest._style = copy(src._style)
    dest.number_format = src.number_format or "0.000000000"
    dest.alignment = copy(src.alignment) if src.alignment else Alignment(horizontal="right", vertical="center")


def row_key(ws, headers, row):
    return clean(ws.cell(row, headers["Primary name"]).value)


def is_aug25_duplicate_row(ws, headers, row):
    source_text = clean(ws.cell(row, headers["Measurement/source file"]).value) or ""
    return (
        ws.cell(row, headers["Diagnosis"]).value in (None, "")
        and ws.cell(row, headers["Sample date"]).value in (None, "")
        and any(name in source_text for name in NEW_SOURCE_FILES)
    )


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before Aug25 duplicate merge {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    rows_by_primary = defaultdict(list)
    for row in range(2, ws.max_row + 1):
        key = row_key(ws, headers, row)
        if key:
            rows_by_primary[key].append(row)

    merges = []
    delete_rows = []
    changed_targets = set()
    for primary, rows in sorted(rows_by_primary.items()):
        dup_rows = [row for row in rows if is_aug25_duplicate_row(ws, headers, row)]
        target_rows = [
            row
            for row in rows
            if row not in dup_rows
            and ws.cell(row, headers["Sample date"]).value not in (None, "")
            and ws.cell(row, headers["Diagnosis"]).value not in (None, "")
        ]
        if not dup_rows or not target_rows:
            continue
        target_row = min(target_rows, key=lambda row: row)
        target_sources = parse_sources(ws.cell(target_row, headers["Measurement/source file"]).value)
        for dup_row in dup_rows:
            dup_sources = parse_sources(ws.cell(dup_row, headers["Measurement/source file"]).value)
            moved = {"primary": primary, "target_row_before_delete": target_row, "duplicate_row": dup_row, "values": []}
            for detector in ("PA447", "araE"):
                cols = detector_cols(headers, detector)
                for col in cols:
                    value = ws.cell(dup_row, col).value
                    if not is_numeric(value):
                        continue
                    dest_col, should_add = first_blank_or_existing(ws, target_row, cols, value)
                    if dest_col is None:
                        moved["values"].append(
                            {
                                "detector": detector,
                                "value": value,
                                "status": "overflow-not-added",
                            }
                        )
                        continue
                    if should_add:
                        ws.cell(target_row, dest_col).value = float(value)
                        copy_measurement_style(ws, dup_row, col, target_row, dest_col)
                    moved["values"].append(
                        {
                            "detector": detector,
                            "value": value,
                            "destination": ws.cell(target_row, dest_col).coordinate,
                            "status": "added" if should_add else "already-present",
                        }
                    )
                for label in dup_sources[detector]:
                    if label not in target_sources[detector]:
                        target_sources[detector].append(label)
            write_sources(ws, headers, target_row, target_sources)
            delete_rows.append(dup_row)
            changed_targets.add(target_row)
            merges.append(moved)

    for row in sorted(delete_rows, reverse=True):
        ws.delete_rows(row, 1)

    headers = header_map(ws)
    reclassified = []
    for row in range(2, ws.max_row + 1):
        primary = row_key(ws, headers, row)
        if primary in {item["primary"] for item in merges}:
            old_final = ws.cell(row, headers["Final classification / decision"]).value
            new_final = repeat_logic.reclassify_row_majority(ws, headers, row, bars)
            reclassified.append({"row": row, "primary": primary, "old_final": old_final, "new_final": new_final})

    # Keep current readable layout conventions for source/detector columns.
    for row in range(2, ws.max_row + 1):
        for detector in ("PA447", "araE"):
            for col in detector_cols(headers, detector):
                ws.cell(row, col).number_format = "0.000000000"
        ws.cell(row, headers["Measurement/source file"]).alignment = Alignment(wrap_text=False, vertical="center")
        ws.cell(row, headers["Sample date"]).number_format = "yyyy-mm-dd"

    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    final_rows = []
    for row in range(2, check_ws.max_row + 1):
        primary = clean(check_ws.cell(row, check_headers["Primary name"]).value)
        if primary in {item["primary"] for item in merges}:
            final_rows.append(
                {
                    "row": row,
                    "primary": primary,
                    "diagnosis": check_ws.cell(row, check_headers["Diagnosis"]).value,
                    "final": check_ws.cell(row, check_headers["Final classification / decision"]).value,
                    "date": check_ws.cell(row, check_headers["Sample date"]).value,
                    "pa447": [
                        check_ws.cell(row, col).value
                        for col in detector_cols(check_headers, "PA447")
                        if is_numeric(check_ws.cell(row, col).value)
                    ],
                    "araE": [
                        check_ws.cell(row, col).value
                        for col in detector_cols(check_headers, "araE")
                        if is_numeric(check_ws.cell(row, col).value)
                    ],
                    "source": check_ws.cell(row, check_headers["Measurement/source file"]).value,
                }
            )

    report = {
        "workbook": str(ONEDRIVE_FINAL),
        "backup": str(backup),
        "deleted_duplicate_rows": sorted(delete_rows),
        "merges": merges,
        "reclassified": reclassified,
        "final_dimensions": {"rows": check_ws.max_row, "columns": check_ws.max_column},
        "final_rows": final_rows,
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
