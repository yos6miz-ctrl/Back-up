from collections import Counter, defaultdict
from pathlib import Path
import json
import re
import zipfile
from xml.etree import ElementTree as ET

from openpyxl import load_workbook

import build_accounted_known_unknown as builder


FOLDER = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
REPORT_PATH = WORKSPACE / "unmatched_measurement_names_report.json"
ROOTS = [FOLDER / "447 new", FOLDER / "447-old", FOLDER / "araE"]
XML_NS = {"main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def clean(value):
    return builder.clean(value)


def label_match_candidates(value):
    text = clean(value)
    if not text:
        return []
    candidates = [text]
    stripped = re.sub(r"^(?:P?A?0?447|447|ARAE)\s*[-:]?\s*", "", text, flags=re.I)
    if stripped and stripped not in candidates:
        candidates.append(stripped)
    stripped_unknown = re.sub(r"^(?:UNKNOWN\s+SAMPLES?|UNKNOWN|UN)\s*[-:]?\s*", "", stripped, flags=re.I)
    if stripped_unknown and stripped_unknown not in candidates:
        candidates.append(stripped_unknown)
    return candidates


def key_set(*values):
    keys = set()
    for value in values:
        for candidate in label_match_candidates(value):
            keys.update(builder.identifier_variants(candidate))
            keys.update(builder.strict_identifier_variants(candidate))
    return {key for key in keys if key}


def add_known_keys(keys, *values):
    keys.update(key_set(*values))


def final_workbook_keys():
    keys = set()
    for path in [FOLDER / "Merged Unknowns trial 6.26.xlsx", FOLDER / "Final Known and Unknown merged.xlsx"]:
        if not path.exists():
            continue
        wb = load_workbook(path, data_only=True, read_only=True)
        for ws in wb.worksheets:
            if not ws.max_row or not ws.max_column:
                continue
            headers = [cell.value for cell in ws[1]]
            name_cols = [
                idx + 1
                for idx, header in enumerate(headers)
                if header in {
                    "Real name",
                    "Unknown name",
                    "Sample name",
                    "Synonym / other name",
                    "Primary name",
                    "Secondary / other name",
                }
            ]
            for row in range(2, ws.max_row + 1):
                add_known_keys(keys, *[ws.cell(row, col).value for col in name_cols])
    return keys


def source_list_keys():
    keys = final_workbook_keys()
    for names in builder.MANUAL_SAMPLE_ALIASES:
        add_known_keys(keys, *names)

    aliquots, _aliases, _rows = builder.load_aliquots_inventory()
    for record in aliquots:
        keys.update(record.get("identifiers", set()))
        keys.update(record.get("strict_identifiers", set()))
        add_known_keys(keys, record.get("sample_name"), record.get("other_name"), record.get("patient_name"), record.get("raw_sample_name"))

    for row in builder.load_old_rows():
        keys.update(row.get("identifiers", set()))
        keys.update(row.get("strict_identifiers", set()))
        add_known_keys(keys, row.get("sample_name"), row.get("source_name"))

    for row in builder.load_missing_rows():
        keys.update(row.get("identifiers", set()))
        keys.update(row.get("strict_identifiers", set()))
        add_known_keys(keys, row.get("sample_name"))

    for _key, record in builder.load_unknown_trial_rows().items():
        add_known_keys(keys, record.get("real"), record.get("unknown"))

    return keys


def is_known_name(label, known_keys):
    return bool(key_set(label) & known_keys)


def detector_from_path(path):
    return "araE" if "arae" in str(path).lower() else "PA447"


def file_kind(path):
    name = path.name.lower()
    if "edit" in name or "eddit" in name:
        return "edited"
    return "raw_or_summary"


def useful_sample_label(value):
    text = clean(value)
    if not text:
        return False
    if text.startswith("="):
        return False
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?(?:E[-+]?\d+)?", text, flags=re.I):
        return False
    if not builder.is_sample_label(text):
        return False
    low = text.lower()
    if re.fullmatch(r"ibs\s+p\d+(?:\s*w\d+)?", low):
        return False
    phrase = f" {low} "
    blocked_fragments = [
        "channel",
        " i vs t ",
        "glucose",
        "glutaric",
        "glutacric",
        "glutarc",
        "gluteric",
        " glu ",
        "lysine",
        " lys ",
        " ara ",
        "arabinose",
    ]
    if any(fragment in phrase for fragment in blocked_fragments):
        return False
    blocked = {
        "blank",
        "empty",
        "sample",
        "sample #",
        "name",
        "number",
        "date",
        "diagnosis",
        "healthy",
        "crohn",
        "remission",
    }
    if low in blocked:
        return False
    if len(builder.norm(text)) < 2:
        return False
    return True


def column_index(cell_ref):
    letters = re.match(r"([A-Z]+)", cell_ref).group(1)
    col = 0
    for letter in letters:
        col = col * 26 + ord(letter) - 64
    return col


def read_shared_strings(zf):
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    strings = []
    for si in root.findall("main:si", XML_NS):
        pieces = [node.text or "" for node in si.findall(".//main:t", XML_NS)]
        strings.append("".join(pieces))
    return strings


def cell_value(cell, shared_strings):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(node.text or "" for node in cell.findall(".//main:t", XML_NS))
    value_node = cell.find("main:v", XML_NS)
    if value_node is None or value_node.text is None:
        return None
    raw = value_node.text
    if cell_type == "s":
        try:
            return shared_strings[int(raw)]
        except (ValueError, IndexError):
            return None
    try:
        return float(raw)
    except ValueError:
        return raw


def iter_top_sheet_cells(path, max_row=20):
    with zipfile.ZipFile(path) as zf:
        shared_strings = read_shared_strings(zf)
        sheet_files = sorted(
            name
            for name in zf.namelist()
            if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name)
        )
        for sheet_file in sheet_files:
            cells = {}
            for _event, elem in ET.iterparse(zf.open(sheet_file), events=("end",)):
                if elem.tag.endswith("}row"):
                    row_index = int(elem.attrib.get("r", "0") or 0)
                    if row_index > max_row:
                        elem.clear()
                        break
                    for cell in elem.findall("main:c", XML_NS):
                        ref = cell.attrib.get("r")
                        if not ref:
                            continue
                        value = cell_value(cell, shared_strings)
                        if value is None:
                            continue
                        col_index = column_index(ref)
                        cells[(row_index, col_index)] = (value, ref)
                    elem.clear()
            yield sheet_file, cells


def has_numeric_neighbor(cells, row, col):
    for r in range(row, row + 5):
        for c in range(max(1, col - 1), col + 5):
            found = cells.get((r, c))
            if found and isinstance(found[0], (int, float)):
                return True
    return False


def scan_visible_measured_labels(known_keys):
    """Conservative broad scan: sample-like labels with numeric cells nearby."""
    unmatched = []
    total_labels = 0
    matched_labels = 0
    for root in ROOTS:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*.xlsx")):
            try:
                sheets = list(iter_top_sheet_cells(path))
            except Exception:
                continue
            rel_path = str(path.relative_to(FOLDER))
            for sheet_name, cells in sheets:
                for (row, col), (value, cell_ref) in cells.items():
                    if not isinstance(value, str):
                        continue
                    label = clean(value)
                    if not useful_sample_label(label):
                        continue
                    if not has_numeric_neighbor(cells, row, col):
                        continue
                    total_labels += 1
                    if is_known_name(label, known_keys):
                        matched_labels += 1
                        continue
                    unmatched.append(
                        {
                            "label": label,
                            "detector": detector_from_path(path),
                            "file_kind": file_kind(path),
                            "source_file": rel_path,
                            "sheet": sheet_name,
                            "cell": cell_ref,
                        }
                    )
    return unmatched, {"visible_sample_labels": total_labels, "visible_sample_labels_matched": matched_labels}


def normalized_measurement_unmatched(known_keys):
    # The visible-label scan already catches the sample headers for the edited
    # normalized tables. Avoid a separate formula scan here because these files
    # have many formula cells and formulas can be mistaken for sample names.
    return [], {"normalized_records": 0, "normalized_records_matched": 0}


def dedupe(items):
    out = []
    seen = set()
    for item in items:
        key = (builder.norm(item.get("label")), item.get("detector"), item.get("source_file"), tuple(item.get("source_rows") or [item.get("sheet"), item.get("cell")]))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def summarize_by_label(items):
    grouped = defaultdict(list)
    for item in items:
        grouped[item["label"]].append(item)
    summary = []
    for label, rows in sorted(grouped.items(), key=lambda pair: builder.norm(pair[0])):
        summary.append(
            {
                "label": label,
                "detectors": sorted(set(row.get("detector") for row in rows if row.get("detector"))),
                "occurrences": len(rows),
                "examples": rows[:5],
            }
        )
    return summary


def main():
    known_keys = source_list_keys()
    normalized_unmatched, normalized_stats = normalized_measurement_unmatched(known_keys)
    visible_unmatched, visible_stats = scan_visible_measured_labels(known_keys)

    normalized_unmatched = dedupe(normalized_unmatched)
    visible_unmatched = dedupe(visible_unmatched)

    report = {
        "stats": {
            "known_identifier_keys": len(known_keys),
            **normalized_stats,
            **visible_stats,
            "normalized_unmatched_records": len(normalized_unmatched),
            "visible_unmatched_records": len(visible_unmatched),
            "normalized_unmatched_unique_labels": len({builder.norm(item["label"]) for item in normalized_unmatched}),
            "visible_unmatched_unique_labels": len({builder.norm(item["label"]) for item in visible_unmatched}),
        },
        "normalized_unmatched_by_label": summarize_by_label(normalized_unmatched),
        "visible_unmatched_by_label": summarize_by_label(visible_unmatched),
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report["stats"], ensure_ascii=False, indent=2))
    if report["normalized_unmatched_by_label"]:
        print("NORMALIZED_UNMATCHED_EXAMPLES")
        print(json.dumps(report["normalized_unmatched_by_label"][:30], ensure_ascii=False, indent=2, default=str))
    if report["visible_unmatched_by_label"]:
        print("VISIBLE_UNMATCHED_EXAMPLES")
        print(json.dumps(report["visible_unmatched_by_label"][:30], ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
