from __future__ import annotations

from copy import copy
from datetime import datetime
from pathlib import Path
import json
import math
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

import expand_measurement_columns_and_show_all as repeat_logic
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "remove_ichilov_v4_measurements_report.json"

V4_SOURCE = "merged - Ichilov v4.xlsx"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return text or None


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def detector_cols(headers, detector):
    cols = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        cols.append(headers[f"{detector} measurement {idx}"])
        idx += 1
    return cols


def parse_sources(text):
    parts = {"PA447": [], "araE": []}
    text = clean(text)
    if not text:
        return parts
    if "PA447:" not in text and "araE:" not in text:
        if text.lower().endswith(".xlsx"):
            return {"PA447": [text], "araE": [text]}
        return parts
    for detector in parts:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if not match:
            continue
        for item in match.group(1).split(","):
            label = clean(item.replace("/", "\\").split("\\")[-1])
            if label:
                parts[detector].append(label)
    return parts


def format_sources(source_parts):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for label in source_parts[detector]:
            if label and label not in labels:
                labels.append(label)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    return "; ".join(segments) if segments else None


def clear_cell(cell):
    cell.value = None
    cell.fill = PatternFill(fill_type=None)
    cell.font = Font(name="Calibri", size=11, color="000000", bold=False)
    cell.number_format = "0.000000000"
    cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)


def rewrite_detector_values(ws, headers, row, detector, kept_entries):
    cols = detector_cols(headers, detector)
    for col in cols:
        clear_cell(ws.cell(row, col))
    for entry, col in zip(kept_entries, cols):
        cell = ws.cell(row, col)
        cell.value = entry["value"]
        cell.number_format = entry.get("number_format") or "0.000000000"
        cell.font = copy(entry["font"]) if entry.get("font") else Font(name="Calibri", size=11, color="000000")
        cell.fill = copy(entry["fill"]) if entry.get("fill") else PatternFill(fill_type=None)
        cell.alignment = copy(entry["alignment"]) if entry.get("alignment") else Alignment(horizontal="right", vertical="center")


def numeric_entries(ws, headers, row, detector):
    entries = []
    for col in detector_cols(headers, detector):
        cell = ws.cell(row, col)
        if is_numeric(cell.value):
            entries.append(
                {
                    "value": float(cell.value),
                    "font": copy(cell.font),
                    "fill": copy(cell.fill),
                    "alignment": copy(cell.alignment),
                    "number_format": cell.number_format,
                }
            )
    return entries


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before removing Ichilov v4 measurements {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    changed_rows = []
    for row in range(2, ws.max_row + 1):
        source_text = clean(ws.cell(row, headers["Measurement/source file"]).value)
        if not source_text or V4_SOURCE not in source_text:
            continue

        source_parts = parse_sources(source_text)
        before = {
            "row": row,
            "primary": ws.cell(row, headers["Primary name"]).value,
            "secondary": ws.cell(row, headers["Secondary / other name"]).value,
            "status": ws.cell(row, headers["Measurement status"]).value,
            "final": ws.cell(row, headers["Final classification / decision"]).value,
            "source": source_text,
        }
        removed = {"PA447": [], "araE": []}
        kept_values = {"PA447": [], "araE": []}
        kept_sources = {"PA447": [], "araE": []}

        for detector in ("PA447", "araE"):
            entries = numeric_entries(ws, headers, row, detector)
            labels = list(source_parts[detector])
            # Source labels and measurement values were written in the same order.
            # If labels are shorter, keep unlabelled numeric values rather than guessing.
            for idx, entry in enumerate(entries):
                label = labels[idx] if idx < len(labels) else None
                if label == V4_SOURCE:
                    removed[detector].append(entry["value"])
                else:
                    kept_values[detector].append(entry)
                    if label:
                        kept_sources[detector].append(label)
            rewrite_detector_values(ws, headers, row, detector, kept_values[detector])

        remaining_any = any(kept_values[detector] for detector in ("PA447", "araE"))
        ws.cell(row, headers["Measurement/source file"]).value = format_sources(kept_sources)
        if not remaining_any:
            ws.cell(row, headers["Measurement status"]).value = "missing"
            ws.cell(row, headers["Final classification / decision"]).value = "missing"
            importer.style_final(ws.cell(row, headers["Final classification / decision"]), "missing")
            for detector in ("PA447", "araE"):
                ws.cell(row, headers[f"{detector} decision"]).value = None
                importer.style_detector(ws.cell(row, headers[f"{detector} decision"]), None)
        else:
            ws.cell(row, headers["Measurement status"]).value = "measured"
            repeat_logic.reclassify_row_majority(ws, headers, row, bars)

        changed_rows.append(
            {
                **before,
                "removed": removed,
                "remaining_PA447": [entry["value"] for entry in kept_values["PA447"]],
                "remaining_araE": [entry["value"] for entry in kept_values["araE"]],
                "new_status": ws.cell(row, headers["Measurement status"]).value,
                "new_final": ws.cell(row, headers["Final classification / decision"]).value,
                "new_source": ws.cell(row, headers["Measurement/source file"]).value,
            }
        )

    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=True)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    remaining_v4 = []
    measured_without_values = []
    measured_with_values_no_source = []
    for row in range(2, check_ws.max_row + 1):
        source = clean(check_ws.cell(row, check_headers["Measurement/source file"]).value)
        if source and V4_SOURCE in source:
            remaining_v4.append(row)
        values = []
        for detector in ("PA447", "araE"):
            for col in detector_cols(check_headers, detector):
                value = check_ws.cell(row, col).value
                if is_numeric(value):
                    values.append(value)
        status = clean(check_ws.cell(row, check_headers["Measurement status"]).value)
        if status == "measured" and not values:
            measured_without_values.append(row)
        if status == "measured" and values and not source:
            measured_with_values_no_source.append(row)

    report = {
        "workbook": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "changed_rows_count": len(changed_rows),
        "changed_rows": changed_rows,
        "remaining_v4_source_rows": remaining_v4,
        "measured_without_values": measured_without_values,
        "measured_with_values_no_source": measured_with_values_no_source,
        "dimensions": {"rows": check_ws.max_row, "columns": check_ws.max_column},
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
