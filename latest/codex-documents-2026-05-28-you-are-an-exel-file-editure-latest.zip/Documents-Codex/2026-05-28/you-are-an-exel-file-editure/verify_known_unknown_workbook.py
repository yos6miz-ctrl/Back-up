from collections import Counter
from pathlib import Path

from openpyxl import load_workbook


path = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Merged Unknowns trial 6.26.xlsx")
old_path = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\IBD IBS OLD.xlsx")


def close_enough(a, b):
    if a in (None, "") and b in (None, ""):
        return True
    if isinstance(a, (int, float)) or isinstance(b, (int, float)):
        return abs(float(a) - float(b)) < 1e-10
    return str(a) == str(b)


wb = load_workbook(path, data_only=False)
unknown = wb["Unknown"]
known = wb["Known"]
notes = wb["Match notes"]

old_wb = load_workbook(old_path, data_only=True)
old_ws = old_wb.active
old = {}
for row in old_ws.iter_rows(min_row=2, values_only=True):
    if row[0]:
        old[str(row[0]).strip()] = row[:4]

issues = []
if unknown.max_row - 1 != 140:
    issues.append(f"Unknown row count is {unknown.max_row - 1}, expected 140")
if known.max_row - 1 != 58:
    issues.append(f"Known row count is {known.max_row - 1}, expected 58")

unknown_names = [unknown.cell(row=row, column=2).value for row in range(2, unknown.max_row + 1) if unknown.cell(row=row, column=2).value]
if len(unknown_names) != len(set(unknown_names)):
    issues.append("Duplicate Unknown sample names found")

known_sample_names = [known.cell(row=row, column=2).value for row in range(2, known.max_row + 1) if known.cell(row=row, column=2).value]
if len(known_sample_names) != len(set(known_sample_names)):
    issues.append("Duplicate Known sample names found")

for row in range(2, known.max_row + 1):
    status = known.cell(row=row, column=9).value
    final = known.cell(row=row, column=8).value
    matched = known.cell(row=row, column=3).value
    if status == "measured":
        if not matched or matched not in old:
            issues.append(f"Known row {row}: measured but old match not found")
            continue
        _, old_pa447, old_arae, old_diag = old[matched]
        if not close_enough(known.cell(row=row, column=4).value, old_pa447):
            issues.append(f"Known row {row}: PA447 mismatch")
        if not close_enough(known.cell(row=row, column=6).value, old_arae):
            issues.append(f"Known row {row}: araE mismatch")
        if final != old_diag:
            issues.append(f"Known row {row}: diagnosis mismatch")
    elif status == "not measured":
        if final != "not measured":
            issues.append(f"Known row {row}: not measured final classification mismatch")
        if any(known.cell(row=row, column=col).value not in (None, "") for col in [3, 4, 5, 6, 7]):
            issues.append(f"Known row {row}: not measured row has measurement/match values")

style_checks = {
    "Unknown A1 header gray": unknown["A1"].fill.fgColor.rgb,
    "Known A1 header gray": known["A1"].fill.fgColor.rgb,
    "Known final IBD fill": None,
    "Known final IBS fill": None,
    "Known not measured fill": None,
}
for row in range(2, known.max_row + 1):
    value = known.cell(row=row, column=8).value
    if value == "IBD" and style_checks["Known final IBD fill"] is None:
        style_checks["Known final IBD fill"] = known.cell(row=row, column=8).fill.fgColor.rgb
    if value == "IBS" and style_checks["Known final IBS fill"] is None:
        style_checks["Known final IBS fill"] = known.cell(row=row, column=8).fill.fgColor.rgb
    if value == "not measured" and style_checks["Known not measured fill"] is None:
        style_checks["Known not measured fill"] = known.cell(row=row, column=8).fill.fgColor.rgb

known_counts = Counter(known.cell(row=row, column=9).value for row in range(2, known.max_row + 1))
known_final_counts = Counter(known.cell(row=row, column=8).value for row in range(2, known.max_row + 1))
unknown_final_counts = Counter(unknown.cell(row=row, column=11).value for row in range(2, unknown.max_row + 1))

print({
    "sheets": wb.sheetnames,
    "unknown_rows": unknown.max_row - 1,
    "known_rows": known.max_row - 1,
    "known_status_counts": dict(known_counts),
    "known_final_counts": dict(known_final_counts),
    "unknown_final_counts": dict(unknown_final_counts),
    "style_checks": style_checks,
    "issues": issues,
})
