import json
import re
from pathlib import Path

import openpyxl


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
REPORT = WORKSPACE / "audit_1156_sources_report.json"

TERMS = [
    "CT1156",
    "CT-1156",
    "CDf 1156",
    "CDf old 1156",
    "CDf 1156 old",
    "F-YD21156",
    "CDf F-YD21156",
    "YD21156",
    "21156",
]


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


NTERMS = {term: norm(term) for term in TERMS}


def relevant_text(value):
    text = norm(value)
    if not text:
        return False
    if any(term in text for term in NTERMS.values()):
        return True
    return False


def scan_workbook(path):
    hits = []
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        return [{"error": str(exc)}]
    for ws in wb.worksheets:
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
            vals = ["" if value is None else str(value) for value in row]
            joined = " | ".join(vals)
            if relevant_text(joined):
                nonblank = [value for value in vals if value != ""]
                matched = [term for term, nterm in NTERMS.items() if nterm in norm(joined)]
                hits.append(
                    {
                        "sheet": ws.title,
                        "row": row_idx,
                        "matched": matched,
                        "values": nonblank[:30],
                    }
                )
    wb.close()
    return hits


def main():
    files = [
        ROOT / "aliqauts 20260801.xlsx",
        ROOT / "Old sampels" / "All Stool aliquots updated 10.8.23.xlsx",
        ROOT / "Old sampels" / "Bar Ilan  July 25 blinded.xlsx",
        ROOT / "Old sampels" / "Final Bar ilan 6.23 blinds.xlsx",
        ROOT / "Old sampels" / "Oct 24 to BarIlan Blinded.xlsx",
        ROOT / "Old sampels" / "Shipment Bar Ilan 7.26 - Blinded.xlsx",
        ROOT / "Old sampels" / "Shipment Bar Ilan 7.26 Blinded.xlsx",
        ROOT / "Old sampels" / "Stool aliquots updated.xlsx",
    ]
    report = {}
    for path in files:
        if path.exists():
            hits = scan_workbook(path)
            if hits:
                report[str(path)] = hits
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
