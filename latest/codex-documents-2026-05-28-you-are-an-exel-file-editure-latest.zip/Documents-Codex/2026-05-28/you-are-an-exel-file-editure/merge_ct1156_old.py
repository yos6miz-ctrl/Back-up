import json
import re
import shutil
import zipfile
from pathlib import Path

from openpyxl import load_workbook

import import_2026_measurements as importer


FINAL_CODEX = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
FINAL_ONEDRIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\merge_ct1156_old_report.json")


def norm(value):
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()


def source_parts(value):
    return importer.parse_source_cell(value)


def write_sources(ws, headers, row, parts):
    segments = []
    for detector in ("PA447", "araE"):
        labels = []
        for item in parts.get(detector, []):
            name = str(item).strip()
            if name and name not in labels:
                labels.append(name)
        if labels:
            segments.append(f"{detector}: {', '.join(labels)}")
    ws.cell(row, headers["Measurement/source file"]).value = "; ".join(segments) if segments else None


def merge_secondary(existing, alias):
    pieces = []
    for value in (existing, alias):
        if not value:
            continue
        for part in re.split(r"\s*;\s*", str(value)):
            part = part.strip()
            if part and part not in pieces:
                pieces.append(part)
    return "; ".join(pieces) if pieces else None


def workbook_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "tables": [name for name in zf.namelist() if name.startswith("xl/tables/")],
        }


def main():
    wb = load_workbook(FINAL_CODEX)
    ws = wb["Final"]
    headers = importer.header_map(ws)

    ct_rows = []
    old_rows = []
    for row in range(2, ws.max_row + 1):
        primary = ws.cell(row, headers["Primary name"]).value
        secondary = ws.cell(row, headers["Secondary / other name"]).value
        if norm(primary) == "CT1156":
            ct_rows.append(row)
        if norm(primary) == "CDF1156OLD" or norm(secondary) == "CDF1156OLD":
            old_rows.append(row)

    if len(ct_rows) != 1 or len(old_rows) != 1:
        raise RuntimeError(f"Expected one CT1156 row and one CDf 1156 old row; found {ct_rows=} {old_rows=}")

    target = ct_rows[0]
    duplicate = old_rows[0]

    before = {
        "target_row": target,
        "duplicate_row": duplicate,
        "target_secondary": ws.cell(target, headers["Secondary / other name"]).value,
        "duplicate_primary": ws.cell(duplicate, headers["Primary name"]).value,
    }

    ws.cell(target, headers["Secondary / other name"]).value = merge_secondary(
        ws.cell(target, headers["Secondary / other name"]).value,
        "CDf 1156 old (old)",
    )

    target_sources = source_parts(ws.cell(target, headers["Measurement/source file"]).value)
    dup_sources = source_parts(ws.cell(duplicate, headers["Measurement/source file"]).value)
    for detector in ("PA447", "araE"):
        for source in dup_sources[detector]:
            if source not in target_sources[detector]:
                target_sources[detector].append(source)
    write_sources(ws, headers, target, target_sources)

    ws.delete_rows(duplicate, 1)
    wb.save(FINAL_CODEX)
    importer.remove_comment_and_table_parts(FINAL_CODEX)

    copy_error = None
    try:
        shutil.copy2(FINAL_CODEX, FINAL_ONEDRIVE)
    except PermissionError as exc:
        copy_error = str(exc)

    verify_wb = load_workbook(FINAL_CODEX, read_only=True, data_only=True)
    verify_ws = verify_wb["Final"]
    verify_headers = {cell.value: idx + 1 for idx, cell in enumerate(verify_ws[1])}
    ct_after = []
    old_after = []
    for row in range(2, verify_ws.max_row + 1):
        primary = verify_ws.cell(row, verify_headers["Primary name"]).value
        secondary = verify_ws.cell(row, verify_headers["Secondary / other name"]).value
        if norm(primary) == "CT1156":
            ct_after.append(
                {
                    "row": row,
                    "primary": primary,
                    "secondary": secondary,
                    "measurement_status": verify_ws.cell(row, verify_headers["Measurement status"]).value,
                    "diagnosis": verify_ws.cell(row, verify_headers["Diagnosis"]).value,
                    "final": verify_ws.cell(row, verify_headers["Final classification / decision"]).value,
                    "sources": verify_ws.cell(row, verify_headers["Measurement/source file"]).value,
                }
            )
        if norm(primary) == "CDF1156OLD" or norm(secondary) == "CDF1156OLD":
            old_after.append(row)
    verify_wb.close()

    report = {
        "before": before,
        "ct1156_after": ct_after,
        "cdf_1156_old_rows_after": old_after,
        "copy_error": copy_error,
        "codex_health": workbook_health(FINAL_CODEX),
        "onedrive_health": None if copy_error else workbook_health(FINAL_ONEDRIVE),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
