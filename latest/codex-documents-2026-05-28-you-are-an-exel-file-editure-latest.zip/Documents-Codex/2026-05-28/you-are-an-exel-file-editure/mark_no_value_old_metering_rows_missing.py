from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import re
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
ONEDRIVE_FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
CODEX_FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "mark_no_value_old_metering_rows_missing_report.json"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def measurement_columns(headers):
    return [
        col
        for name, col in headers.items()
        if name and re.match(r"^(PA447|araE) measurement \d+$", str(name))
    ]


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def style_sheet(ws):
    headers = header_map(ws)
    for row in range(2, ws.max_row + 1):
        importer.style_diagnosis(ws.cell(row, headers["Diagnosis"]), ws.cell(row, headers["Diagnosis"]).value)
        importer.style_final(
            ws.cell(row, headers["Final classification / decision"]),
            ws.cell(row, headers["Final classification / decision"]).value,
        )
        importer.style_detector(ws.cell(row, headers["PA447 decision"]), ws.cell(row, headers["PA447 decision"]).value)
        importer.style_detector(ws.cell(row, headers["araE decision"]), ws.cell(row, headers["araE decision"]).value)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "Longitudinal sample": 16,
        "Patient unique code": 18,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    meas_cols = set(measurement_columns(headers))
    for name, col in headers.items():
        if col in meas_cols:
            widths[name] = 13.5
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in meas_cols:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.zoomScale = 85


def main():
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / f"Final Known and Unknown merged before no-value old-metering cleanup {datetime.now():%Y%m%d-%H%M%S}.xlsx"
    shutil.copy2(ONEDRIVE_FINAL, backup)

    wb = load_workbook(ONEDRIVE_FINAL)
    ws = wb["Final"]
    headers = header_map(ws)
    meas_cols = measurement_columns(headers)
    changed = []
    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip().lower()
        values = [ws.cell(row, col).value for col in meas_cols if ws.cell(row, col).value not in (None, "")]
        if status == "old metering system" and not values:
            changed.append(
                {
                    "row": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                    "old_status": ws.cell(row, headers["Measurement status"]).value,
                    "old_final": ws.cell(row, headers["Final classification / decision"]).value,
                }
            )
            ws.cell(row, headers["Measurement status"]).value = "missing"
            ws.cell(row, headers["Final classification / decision"]).value = "missing"

    style_sheet(ws)
    wb.save(ONEDRIVE_FINAL)
    importer.remove_comment_and_table_parts(ONEDRIVE_FINAL)
    CODEX_FINAL.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ONEDRIVE_FINAL, CODEX_FINAL)

    check_wb = load_workbook(ONEDRIVE_FINAL, data_only=True, read_only=False)
    check_ws = check_wb["Final"]
    check_headers = header_map(check_ws)
    remaining = []
    check_meas_cols = measurement_columns(check_headers)
    for row in range(2, check_ws.max_row + 1):
        status = str(check_ws.cell(row, check_headers["Measurement status"]).value or "").strip().lower()
        values = [check_ws.cell(row, col).value for col in check_meas_cols if check_ws.cell(row, col).value not in (None, "")]
        if status == "old metering system" and not values:
            remaining.append(
                {
                    "row": row,
                    "primary": check_ws.cell(row, check_headers["Primary name"]).value,
                    "secondary": check_ws.cell(row, check_headers["Secondary / other name"]).value,
                }
            )
    report = {
        "final": str(ONEDRIVE_FINAL),
        "codex_copy": str(CODEX_FINAL),
        "backup": str(backup),
        "changed_count": len(changed),
        "changed": changed,
        "remaining_old_metering_without_values": remaining,
        "rows": check_ws.max_row - 1,
        "columns": check_ws.max_column,
        "zip_health": zip_health(ONEDRIVE_FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2, default=str))


if __name__ == "__main__":
    main()
