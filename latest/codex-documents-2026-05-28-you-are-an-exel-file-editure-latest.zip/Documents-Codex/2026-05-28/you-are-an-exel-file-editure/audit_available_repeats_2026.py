from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import json

from openpyxl import load_workbook

import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
MEASUREMENT_DIR = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\447 and araE 2026")
REPORT = WORKSPACE / "available_repeats_2026_audit.json"


def main():
    aliquots = importer.load_sample_records()
    aliases_by_key = importer.build_aliases_from_aliquots(aliquots)

    wb = load_workbook(FINAL, data_only=True, read_only=True)
    ws = wb["Final"]
    headers = importer.header_map(ws)
    key_to_rows = importer.rebuild_key_to_rows(ws, headers, aliases_by_key)

    all_records = []
    extraction_errors = []
    for path in sorted(MEASUREMENT_DIR.glob("*.xlsx")):
        if path.name.startswith("~$"):
            continue
        try:
            all_records.extend(importer.extract_normalized_records(path))
        except Exception as exc:
            extraction_errors.append({"file": path.name, "error": str(exc)})

    matched = defaultdict(list)
    unmatched = []
    multiple = []
    for record in all_records:
        aliquot = importer.aliquot_for_record(record, aliquots, aliases_by_key)
        if not aliquot:
            unmatched.append({"record": record, "reason": "no aliquot match"})
            continue
        row_probe = {
            "identifiers": aliquot["identifiers"],
            "strict_identifiers": aliquot["strict_identifiers"],
            "sample_date": aliquot.get("sample_date"),
        }
        candidates = importer.final_row_candidates(row_probe, key_to_rows, aliases_by_key)
        if record.get("is_new_shipment"):
            candidates = importer.shipment_row_candidates_by_date(row_probe, candidates, ws, headers)
        if len(candidates) != 1:
            item = {
                "sample": record["sample_name"],
                "detector": record["detector"],
                "value": record["value"],
                "source_file": record["source_file"],
                "aliquot_primary": aliquot.get("primary"),
                "sample_date": aliquot.get("sample_date"),
                "candidate_rows": candidates,
            }
            (multiple if candidates else unmatched).append(item)
            continue
        matched[(candidates[0], record["detector"])].append(record)

    rows = []
    for (row, detector), records in sorted(matched.items()):
        records = sorted(records, key=lambda item: (item.get("source_date") or "", item["source_file"], item["source_cell"]))
        visible_cols = importer.detector_columns(headers, detector)
        visible = [ws.cell(row, col).value for col in visible_cols]
        numeric_visible = [value for value in visible if importer.is_numeric(value)]
        gaps = []
        seen_blank = False
        for idx, value in enumerate(visible, start=1):
            if value in (None, ""):
                seen_blank = True
            elif seen_blank:
                gaps.append(idx)
        if len(records) > len(visible_cols) or gaps:
            rows.append(
                {
                    "row": row,
                    "primary": ws.cell(row, headers["Primary name"]).value,
                    "secondary": ws.cell(row, headers["Secondary / other name"]).value,
                    "diagnosis": ws.cell(row, headers["Diagnosis"]).value,
                    "detector": detector,
                    "available_count": len(records),
                    "visible_numeric_count": len(numeric_visible),
                    "visible_slots": visible,
                    "gap_slots": gaps,
                    "records": [
                        {
                            "value": record["value"],
                            "source_file": record["source_file"],
                            "source_cell": record["source_cell"],
                            "sample_name": record["sample_name"],
                        }
                        for record in records
                    ],
                }
            )

    report = {
        "measurement_folder": str(MEASUREMENT_DIR),
        "final": str(FINAL),
        "extracted_count": len(all_records),
        "rows_needing_more_columns_or_gap_review": rows,
        "max_available_by_detector": {
            detector: max((len(records) for (row, det), records in matched.items() if det == detector), default=0)
            for detector in ("PA447", "araE")
        },
        "unmatched_count": len(unmatched),
        "multiple_count": len(multiple),
        "unmatched": unmatched[:100],
        "multiple": multiple[:100],
        "extraction_errors": extraction_errors,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
