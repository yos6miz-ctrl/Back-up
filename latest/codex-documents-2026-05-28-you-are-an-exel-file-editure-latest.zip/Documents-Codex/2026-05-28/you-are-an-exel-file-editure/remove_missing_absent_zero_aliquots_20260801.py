from __future__ import annotations

from pathlib import Path
import json
import shutil
import zipfile

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import count_missing_absent_or_zero_aliquots as audit
import import_2026_measurements as importer


WORKSPACE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
FINAL = Path(r"C:\Users\Popovtzer lab\.codex\Excel file editor\Final Known and Unknown merged.xlsx")
ONEDRIVE_ORIGINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
ONEDRIVE_COPY = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged - expanded repeats.xlsx")
BACKUP_DIR = WORKSPACE / "backups"
REPORT = WORKSPACE / "remove_missing_absent_zero_aliquots_20260801_report.json"


def header_map(ws):
    return {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}


def detector_headers(headers, detector):
    names = []
    idx = 1
    while f"{detector} measurement {idx}" in headers:
        names.append(f"{detector} measurement {idx}")
        idx += 1
    return names


def zip_health(path):
    with zipfile.ZipFile(path) as zf:
        return {
            "bad_file": zf.testzip(),
            "table_parts": [name for name in zf.namelist() if name.startswith("xl/tables/")],
            "comment_parts": [name for name in zf.namelist() if "comments" in name.lower()],
        }


def classify_missing_rows():
    aliquot_index, _aliquot_rows = audit.load_aliquot_index()
    missing_rows = audit.load_missing_rows()
    remove_rows = []
    keep_rows = []
    for item in missing_rows:
        matches = []
        seen = set()
        for key in item["keys"]:
            for record in aliquot_index.get(key, []):
                unique = (record["sheet"], record["row"])
                if unique not in seen:
                    seen.add(unique)
                    matches.append(record)
        if not matches:
            remove_rows.append({**item, "remove_reason": "absent from aliqauts 20260801", "matches": []})
        elif any(audit.numeric_positive(record["aliquots"]) for record in matches):
            keep_rows.append({**item, "keep_reason": "present with positive aliquots", "matches": matches})
        elif any(audit.numeric_zero(record["aliquots"]) for record in matches):
            remove_rows.append({**item, "remove_reason": "present with 0 aliquots", "matches": matches})
        else:
            keep_rows.append({**item, "keep_reason": "present with blank/non-numeric aliquots", "matches": matches})
    return remove_rows, keep_rows


def apply_clean_layout(ws):
    headers = header_map(ws)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    ws.sheet_view.showGridLines = True
    ws.sheet_view.zoomScale = 85

    widths = {
        "Primary name": 20,
        "Secondary / other name": 20,
        "Measurement status": 16,
        "Diagnosis": 12,
        "Final classification / decision": 22,
        "Calprotectin level": 16,
        "Disease location": 28,
        "PA447 decision": 12,
        "araE decision": 12,
        "Sample date": 14,
        "Measurement/source file": 52,
    }
    for name in detector_headers(headers, "PA447"):
        widths[name] = 13.5
    for name in detector_headers(headers, "araE"):
        widths[name] = 13.5
    for name, col in headers.items():
        ws.column_dimensions[get_column_letter(col)].width = widths.get(name, 14)

    header_fill = PatternFill(fill_type="solid", fgColor=importer.HEADER_FILL)
    header_border = Border(bottom=Side(style="thin", color="808080"))
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(1, col)
        cell.fill = header_fill
        cell.font = Font(name="Calibri", size=10, bold=True, color="000000")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = header_border
    ws.row_dimensions[1].height = 42

    measurement_columns = {
        headers[name]
        for detector in ("PA447", "araE")
        for name in detector_headers(headers, detector)
    }
    center_columns = {
        headers["Calprotectin level"],
        headers["Sample date"],
        headers["PA447 decision"],
        headers["araE decision"],
    }
    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 18
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row, col)
            if col in measurement_columns:
                cell.number_format = "0.000000000"
                cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=False)
            elif col == headers["Calprotectin level"]:
                cell.number_format = "0"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col == headers["Sample date"]:
                cell.number_format = "yyyy-mm-dd"
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            elif col in center_columns:
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)


def main():
    remove_rows, keep_rows = classify_missing_rows()
    BACKUP_DIR.mkdir(exist_ok=True)
    backup = BACKUP_DIR / "Final Known and Unknown merged before removing missing absent zero aliquots.xlsx"
    shutil.copy2(FINAL, backup)

    wb = load_workbook(FINAL)
    ws = wb["Final"]
    for item in sorted(remove_rows, key=lambda row: row["row"], reverse=True):
        ws.delete_rows(item["row"], 1)
    apply_clean_layout(ws)
    wb.save(FINAL)
    importer.remove_comment_and_table_parts(FINAL)

    copy_errors = {}
    for target in (ONEDRIVE_ORIGINAL, ONEDRIVE_COPY):
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(FINAL, target)
            copy_errors[str(target)] = None
        except PermissionError as exc:
            copy_errors[str(target)] = str(exc)

    remaining_remove, remaining_keep = classify_missing_rows()
    report = {
        "removed_count": len(remove_rows),
        "removed_absent_count": sum(item["remove_reason"].startswith("absent") for item in remove_rows),
        "removed_zero_aliquots_count": sum(item["remove_reason"].endswith("0 aliquots") for item in remove_rows),
        "kept_missing_positive_aliquots_count": len(keep_rows),
        "removed": remove_rows,
        "remaining_absent_or_zero_after_edit": remaining_remove,
        "remaining_missing_positive_after_edit": remaining_keep,
        "backup": str(backup),
        "final": str(FINAL),
        "copy_errors": copy_errors,
        "zip_health_final": zip_health(FINAL),
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
