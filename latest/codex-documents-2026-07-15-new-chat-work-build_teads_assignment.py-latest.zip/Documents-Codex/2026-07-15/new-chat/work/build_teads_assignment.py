from __future__ import annotations

import math
import re
from copy import deepcopy
from pathlib import Path
from typing import Iterable, Sequence

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-07-15\new-chat")
WORK = ROOT / "work"
ASSETS = WORK / "assets"
OUTPUTS = ROOT / "outputs"
ASSETS.mkdir(parents=True, exist_ok=True)
OUTPUTS.mkdir(parents=True, exist_ok=True)
OUT = OUTPUTS / "Teads_TA_Interview_Assignment_clean_English.docx"


NAVY = "0B1437"
COBALT = "1B63FF"
CORAL = "FF7A78"
PINK = "E768B5"
TEAL = "168F8A"
GREEN = "2E8B57"
AMBER = "D98C10"
RED = "C0392B"
INK = "1E2633"
MUTED = "5B6573"
LIGHT = "F2F4F7"
PALE_BLUE = "EAF1FF"
PALE_CORAL = "FFF0EF"
PALE_GREEN = "EAF7F0"
WHITE = "FFFFFF"
GRID = "D7DCE2"


SOURCES = {
    "S01": ("Interview assignment supplied by Teads", "Candidate-provided source file", ""),
    "S02": ("Teads — Cloud Platform Engineer, Netanya", "Role scope, requirements, scale, hybrid tag", "https://job-boards.eu.greenhouse.io/teads1/jobs/4924757101"),
    "S03": ("Teads Investor Relations — Company overview", "Headcount, footprint, customers and reach", "https://investors.teads.com/"),
    "S04": ("Teads Investor Relations — FAQs", "Legacy company founding dates and merger date", "https://investors.teads.com/ir-resources/faqs"),
    "S05": ("Outbrain completes the acquisition of Teads", "February 2025 combination, scale and transaction context", "https://www.teads.com/blog/outbrain-completes-the-acquisition-of-teads/3145/"),
    "S06": ("Corporate name change to Teads Holding Co.", "June 2025 rebrand", "https://investors.teads.com/news-releases/news-release-details/outbrain-completes-change-corporate-name-teads"),
    "S07": ("About Teads", "Purpose, culture and five published values", "https://www.teads.com/about-teads/"),
    "S08": ("Teads Engineering — Join us", "Engineering hubs, culture and operating model", "https://engineering.teads.com/join-us/"),
    "S09": ("Teads leadership", "Executive and technology/product leadership", "https://www.teads.com/teads-leadership/"),
    "S10": ("Teads Greenhouse job board", "Live hiring mix and locations; snapshot 15 July 2026", "https://job-boards.eu.greenhouse.io/teads1"),
    "S11": ("Teads 2025 Annual Report (Form 10-K)", "Hybrid-work and operating-location disclosure", "https://investors.teads.com/static-files/9819c719-65c9-46f0-b770-a9257060fcfb"),
    "S12": ("Teads Q1 2026 results", "Current financial context and strategic priorities", "https://investors.teads.com/news-releases/news-release-details/teads-holding-co-announces-first-quarter-2026-results"),
    "S13": ("Teads Q4 and FY2025 results", "Organization simplification, CTV growth and 2026 priorities", "https://investors.teads.com/news-releases/news-release-details/teads-holding-co-announces-fourth-quarter-and-full-year-2025"),
    "S14": ("Teads launches EngageOS", "June 2026 publisher product and predictive-ML direction", "https://investors.teads.com/news-releases/news-release-details/teads-launches-its-ai-driven-operating-system-teads-engageos"),
    "S15": ("Teads launches CTV Ensemble", "June 2026 omnichannel/CTV orchestration", "https://www.teads.com/blog/teads-launches-ctv-ensemble-for-unified-omnichannel-orchestration/11116/"),
    "S16": ("Teads expands premium CTV access through TiVo", "July 2026 product and inventory development", "https://investors.teads.com/news-releases/news-release-details/teads-expands-premium-ctv-access-through-strategic-partnership"),
    "S17": ("Teads on LinkedIn", "Employer-brand reach and recent company content; snapshot 15 July 2026", "https://www.linkedin.com/company/teads"),
    "S18": ("Teads reviews on Glassdoor", "Directional employee sentiment; anonymous reviews", "https://www.glassdoor.co.uk/Reviews/Teads-Reviews-E929611.htm"),
    "S19": ("Teads jobs on LinkedIn", "Current public posting-age sample; snapshot 15 July 2026", "https://www.linkedin.com/jobs/teads-jobs-worldwide?f_C=70931947%2C100988850%2C2691523"),
    "S20": ("Cloud Platform Engineer — Runtime Platform Team", "Recent Netanya posting age and applicant count", "https://il.linkedin.com/jobs/view/cloud-platform-engineer-runtime-platform-team-k8s-kafka-at-teads-4356645138"),
    "S21": ("Israel Innovation Authority — State of High-Tech 2026", "Israeli technology employment and open-role context", "https://innovationisrael.org.il/en/press_release/israeli-high-tech-report-2026/"),
    "S22": ("Gem 2025 Recruiting Benchmarks", "Engineering/Product time-to-hire and conversion benchmarks", "https://lp.gem.com/rs/972-IVV-330/images/2025%20Recruiting%20Benchmarks%20-%20Gem.pdf"),
    "S23": ("SmartRecruiters — Technology recruiting benchmarks", "Technology median time-to-hire, applications and acceptance", "https://www.smartrecruiters.com/resources/article/technology-benchmark-recruiting-metrics/"),
    "S24": ("LinkedIn Help — InMail response rate", "Platform response-rate policy floor", "https://www.linkedin.com/help/linkedin/answer/a414226/finding-your-inmail-response-rate?lang=en"),
    "S25": ("Tal Asulin — LinkedIn", "Public candidate evidence", "https://il.linkedin.com/in/tal-asulin-7b2367119"),
    "S26": ("Ashraf Hamad — public professional record", "Public candidate evidence and tenure cross-check", "https://www.signalhire.com/profiles/ashraf-hamad%27s-email/143210864"),
    "S27": ("Rotem Hochman — LinkedIn", "Public candidate evidence", "https://il.linkedin.com/in/rotem-hochman"),
    "S28": ("Tal Ayalon — LinkedIn", "Public candidate evidence", "https://il.linkedin.com/in/tal-ayalon"),
    "S29": ("Erez Neiderman — LinkedIn", "Public candidate evidence", "https://il.linkedin.com/in/erez-neiderman-69344660"),
    "S30": ("AWS User Group Israel", "Potential technical community partner", "https://awsug.co.il/"),
    "S31": ("DevOpsDays Tel Aviv community", "Potential reliability/platform community partner", "https://il.linkedin.com/company/devopsdays-tel-aviv"),
    "S32": ("she codes", "Potential inclusive engineering-community partner", "https://she-codes.org/"),
    "S33": ("Tsofen", "Potential Arab-tech community partner", "https://tsofen.org/en/"),
    "S34": ("Olim in Tech", "Potential immigrant-tech community partner", "https://www.linkedin.com/company/olim-in-tech"),
    "S35": ("Israel Tech Challenge", "Potential education/talent ecosystem partner", "https://www.jewishagency.org/israel-tech-challenge/"),
    "S36": ("Teads for media owners", "Publisher proposition, monetization and brand safety", "https://www.teads.com/media-owners"),
    "S37": ("Teads Enterprise", "Advertiser proposition, Teads Studio and Teads Ad Manager", "https://www.teads.com/advertisers/enterprise/"),
    "S38": ("Teads offices", "Global office footprint and hub locations", "https://www.teads.com/teads-offices/"),
}


def rgb(hex_value: str) -> RGBColor:
    return RGBColor.from_string(hex_value)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, **edges) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_borders = tc_pr.first_child_found_in("w:tcBorders")
    if tc_borders is None:
        tc_borders = OxmlElement("w:tcBorders")
        tc_pr.append(tc_borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV", "start", "end"):
        if edge in edges:
            tag = "w:" + edge
            element = tc_borders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tc_borders.append(element)
            for key, value in edges[edge].items():
                element.set(qn("w:" + key), str(value))


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    cant_split.set(qn("w:val"), "true")
    tr_pr.append(cant_split)


def set_table_geometry(table, widths: Sequence[int], total: int | None = None, indent: int = 120) -> None:
    total = total or sum(widths)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent))
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            width = widths[min(idx, len(widths) - 1)]
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_repeat_keep(paragraph) -> None:
    paragraph.paragraph_format.keep_with_next = True


def add_field(run, field: str) -> None:
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = field
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr_text, fld_char2])


def add_hyperlink(paragraph, text: str, url: str, color: str = COBALT, underline: bool = True, bold: bool = False):
    part = paragraph.part
    r_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), r_id)
    new_run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    c = OxmlElement("w:color")
    c.set(qn("w:val"), color)
    r_pr.append(c)
    if bold:
        b = OxmlElement("w:b")
        b.set(qn("w:val"), "true")
        r_pr.append(b)
    if underline:
        u = OxmlElement("w:u")
        u.set(qn("w:val"), "single")
        r_pr.append(u)
    new_run.append(r_pr)
    t = OxmlElement("w:t")
    t.text = text
    new_run.append(t)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)
    return hyperlink


def add_bookmark(paragraph, name: str, bookmark_id: int) -> None:
    start = OxmlElement("w:bookmarkStart")
    start.set(qn("w:id"), str(bookmark_id))
    start.set(qn("w:name"), name)
    end = OxmlElement("w:bookmarkEnd")
    end.set(qn("w:id"), str(bookmark_id))
    paragraph._p.insert(0, start)
    paragraph._p.append(end)


def add_internal_link(paragraph, text: str, anchor: str):
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("w:anchor"), anchor)
    new_run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    c = OxmlElement("w:color")
    c.set(qn("w:val"), COBALT)
    r_pr.append(c)
    u = OxmlElement("w:u")
    u.set(qn("w:val"), "single")
    r_pr.append(u)
    new_run.append(r_pr)
    t = OxmlElement("w:t")
    t.text = text
    new_run.append(t)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)


def set_alt_text(shape, title: str, description: str) -> None:
    doc_pr = shape._inline.docPr
    doc_pr.set("title", title)
    doc_pr.set("descr", description)


def set_repeat_table_headers(table) -> None:
    if table.rows:
        repeat_table_header(table.rows[0])


def configure_styles(doc: Document) -> None:
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = rgb(INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name, size, color, before, after in (
        ("Title", 30, NAVY, 0, 12),
        ("Heading 1", 16, COBALT, 16, 8),
        ("Heading 2", 13, NAVY, 12, 6),
        ("Heading 3", 11.5, "1F4D78", 8, 4),
    ):
        style = styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = rgb(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for name in ("List Bullet", "List Number"):
        style = styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(10.5)
        style.paragraph_format.left_indent = Inches(0.5)
        style.paragraph_format.first_line_indent = Inches(-0.25)
        style.paragraph_format.space_after = Pt(5)
        style.paragraph_format.line_spacing = 1.10

    caption = styles["Caption"]
    caption.font.name = "Calibri"
    caption.font.size = Pt(8.5)
    caption.font.italic = True
    caption.font.color.rgb = rgb(MUTED)
    caption.paragraph_format.space_before = Pt(3)
    caption.paragraph_format.space_after = Pt(6)

    table_style = styles["Table Grid"]
    table_style.font.name = "Calibri"
    table_style.font.size = Pt(9)


def configure_section(section, landscape: bool = False, compact: bool = False) -> None:
    if landscape:
        section.orientation = WD_ORIENT.LANDSCAPE
        section.page_width = Inches(11)
        section.page_height = Inches(8.5)
        margin = 0.45 if compact else 0.6
    else:
        section.orientation = WD_ORIENT.PORTRAIT
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        margin = 1.0
    section.top_margin = Inches(margin)
    section.bottom_margin = Inches(margin)
    section.left_margin = Inches(margin)
    section.right_margin = Inches(margin)
    section.header_distance = Inches(0.28 if compact else 0.42)
    section.footer_distance = Inches(0.28 if compact else 0.42)


def add_header_footer(section, label: str, first_page_blank: bool = False) -> None:
    section.different_first_page_header_footer = first_page_blank
    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(label.upper())
    r.font.name = "Calibri"
    r.font.size = Pt(7.5)
    r.font.bold = True
    r.font.color.rgb = rgb(MUTED)
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run("TEADS INTERVIEW ASSIGNMENT  •  15 JULY 2026  •  ")
    r.font.name = "Calibri"
    r.font.size = Pt(7.5)
    r.font.color.rgb = rgb(MUTED)
    add_field(p.add_run(), "PAGE")
    if first_page_blank:
        first_header = section.first_page_header
        first_header.paragraphs[0].text = ""
        first_footer = section.first_page_footer
        fp = first_footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        fr = fp.add_run("CONFIDENTIAL RECRUITMENT EXERCISE  •  JULY 2026")
        fr.font.size = Pt(7.5)
        fr.font.color.rgb = rgb(MUTED)


def start_portrait_section(doc: Document, label: str):
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    configure_section(section)
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    add_header_footer(section, label)
    return section


def add_kicker(doc: Document, text: str, color: str = CORAL) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text.upper())
    r.font.name = "Calibri"
    r.font.size = Pt(9)
    r.font.bold = True
    r.font.color.rgb = rgb(color)
    r.font.letter_spacing = Pt(0.6) if hasattr(r.font, "letter_spacing") else None


def add_label_run(paragraph, label: str, text: str, label_color: str = NAVY) -> None:
    r = paragraph.add_run(label)
    r.bold = True
    r.font.color.rgb = rgb(label_color)
    paragraph.add_run(text)


def add_bullet(doc: Document, text: str, level: int = 0) -> None:
    p = doc.add_paragraph(style="List Bullet")
    if level:
        p.paragraph_format.left_indent = Inches(0.5 + 0.25 * level)
    p.add_run(text)


def add_number(doc: Document, text: str) -> None:
    p = doc.add_paragraph(style="List Number")
    p.add_run(text)


def add_callout(doc: Document, title: str, body: str, fill: str = PALE_BLUE, accent: str = COBALT, width: int = 9360) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_geometry(table, [width], width)
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    set_cell_border(cell, left={"val": "single", "sz": "22", "color": accent}, top={"val": "nil"}, bottom={"val": "nil"}, right={"val": "nil"})
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(title)
    r.bold = True
    r.font.color.rgb = rgb(accent)
    p = cell.add_paragraph(body)
    p.paragraph_format.space_after = Pt(0)
    if fill == NAVY:
        for run in p.runs:
            run.font.color.rgb = rgb(WHITE)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_compact_takeaway(doc: Document, text: str, fill: str, accent: str, width: int, font_size: float = 8.5, indent: int = 120) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_geometry(table, [width], width, indent=indent)
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    set_cell_border(cell, left={"val": "single", "sz": "18", "color": accent}, top={"val": "nil"}, bottom={"val": "nil"}, right={"val": "nil"})
    set_cell_margins(cell, top=55, start=110, bottom=55, end=110)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    set_run_font(p.add_run(text), size=font_size, bold=True, color=NAVY)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_section_title(doc: Document, part: str, title: str, subtitle: str, bookmark: str, bookmark_id: int) -> None:
    add_kicker(doc, part)
    h = doc.add_heading(title, level=1)
    add_bookmark(h, bookmark, bookmark_id)
    if subtitle:
        p = doc.add_paragraph(subtitle)
        p.paragraph_format.space_after = Pt(9)
        p.runs[0].font.size = Pt(11.5)
        p.runs[0].font.color.rgb = rgb(MUTED)


def add_table(doc: Document, headers: Sequence[str], rows: Sequence[Sequence[str]], widths: Sequence[int], font_size: float = 8.8,
              header_fill: str = LIGHT, first_col_bold: bool = False, total: int | None = None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        set_cell_shading(cell, header_fill)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(header)
        r.bold = True
        r.font.color.rgb = rgb(NAVY)
        r.font.size = Pt(font_size)
    for row_values in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row_values):
            p = cells[i].paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(value))
            r.font.size = Pt(font_size)
            if first_col_bold and i == 0:
                r.bold = True
                r.font.color.rgb = rgb(NAVY)
    set_table_geometry(table, widths, total=total or sum(widths))
    set_repeat_table_headers(table)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def add_candidate_card(doc: Document, name: str, source_id: str, score: str, summary: str, evidence: Sequence[str], validate: Sequence[str], angle: str) -> None:
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    set_table_geometry(table, [6900, 2460], 9360)
    left, right = table.rows[0].cells
    set_cell_shading(left, PALE_BLUE)
    set_cell_shading(right, NAVY)
    p = left.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    add_hyperlink(p, name, SOURCES[source_id][2], color=NAVY, underline=False, bold=True)
    p = left.add_paragraph(summary)
    p.paragraph_format.space_after = Pt(0)
    p.runs[0].font.size = Pt(9.3)
    p = right.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(score)
    r.bold = True
    r.font.size = Pt(16)
    r.font.color.rgb = rgb(WHITE)
    r2 = p.add_run("\nPROVISIONAL FIT")
    r2.font.size = Pt(7.5)
    r2.font.color.rgb = rgb(WHITE)

    detail = doc.add_table(rows=1, cols=3)
    detail.style = "Table Grid"
    set_table_geometry(detail, [3900, 3000, 2460], 9360)
    labels = [("PUBLIC EVIDENCE", evidence, PALE_GREEN), ("VALIDATE", validate, PALE_CORAL), ("OUTREACH ANGLE", [angle], LIGHT)]
    for idx, (label, items, fill) in enumerate(labels):
        c = detail.rows[0].cells[idx]
        set_cell_shading(c, fill)
        p = c.paragraphs[0]
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(label)
        r.bold = True
        r.font.size = Pt(8)
        r.font.color.rgb = rgb(NAVY)
        for item in items:
            p = c.add_paragraph(style="List Bullet")
            p.paragraph_format.left_indent = Inches(0.18)
            p.paragraph_format.first_line_indent = Inches(-0.12)
            p.paragraph_format.space_after = Pt(2)
            rr = p.add_run(item)
            rr.font.size = Pt(8.2)
    doc.add_paragraph().paragraph_format.space_after = Pt(3)


def make_funnel_chart(path: Path, title: str, stages: Sequence[str], counts: Sequence[int], colors: Sequence[str]) -> None:
    width, height = 1400, 470
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular_path = Path(r"C:\Windows\Fonts\arial.ttf")
    bold_path = Path(r"C:\Windows\Fonts\arialbd.ttf")
    regular = ImageFont.truetype(str(regular_path), 25)
    bold = ImageFont.truetype(str(bold_path), 27)
    title_font = ImageFont.truetype(str(bold_path), 31)
    draw.text((25, 18), title, fill="#" + NAVY, font=title_font)
    label_x = 25
    # Keep generous white space around both sides so the complete funnel remains
    # visible when Word scales the image inside the two-column stakeholder page.
    center_x = 790
    max_funnel = 650
    min_funnel = 190
    max_count = max(counts)
    row_top, segment_h = 82, 58
    funnel_widths = [max(min_funnel, int(max_funnel * math.sqrt(count / max_count))) for count in counts]
    for idx, (stage, count, color) in enumerate(zip(stages, counts, colors)):
        y_top = row_top + idx * segment_h
        top_w = funnel_widths[idx]
        bottom_w = funnel_widths[idx + 1] if idx + 1 < len(funnel_widths) else max(min_funnel - 45, int(top_w * 0.78))
        polygon = [
            (center_x - top_w // 2, y_top),
            (center_x + top_w // 2, y_top),
            (center_x + bottom_w // 2, y_top + segment_h - 3),
            (center_x - bottom_w // 2, y_top + segment_h - 3),
        ]
        draw.polygon(polygon, fill="#" + color)
        draw.text((label_x, y_top + 12), stage, fill="#" + INK, font=regular)
        count_text = str(count)
        bbox = draw.textbbox((0, 0), count_text, font=bold)
        draw.text((center_x - (bbox[2] - bbox[0]) / 2, y_top + 10), count_text, fill="white", font=bold)
    image.save(path, "PNG", optimize=True)


def strip_source_tokens(doc: Document) -> None:
    """Remove appendix-style [Sxx] tokens after the source register is omitted."""
    parts = [doc._element]
    for section in doc.sections:
        parts.extend([section.header._element, section.footer._element])
    for part in parts:
        for text_node in part.iter(qn("w:t")):
            if text_node.text:
                text_node.text = re.sub(r"\s*\[S\d{2}\]", "", text_node.text)


def set_run_font(run, name: str = "Calibri", size: float | None = None, bold: bool | None = None, color: str | None = None) -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = rgb(color)


def add_code_box(doc: Document, text: str, width: int = 9360, font_size: float = 8.2, output_text: str | None = None) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_geometry(table, [width], width)
    c = table.cell(0, 0)
    set_cell_shading(c, "F7F8FA")
    set_cell_border(c, top={"val":"single","sz":"6","color":GRID}, bottom={"val":"single","sz":"6","color":GRID}, start={"val":"single","sz":"6","color":GRID}, end={"val":"single","sz":"6","color":GRID})
    p = c.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.05
    r = p.add_run(text)
    set_run_font(r, "Consolas", font_size, color=INK)
    if output_text is not None:
        p = c.add_paragraph()
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.05
        r = p.add_run("Output:")
        set_run_font(r, "Consolas", font_size, bold=True, color=NAVY)
        r = p.add_run(" " + output_text)
        set_run_font(r, "Consolas", font_size, color=INK)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_source_note(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text, style="Caption")
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(6)


def add_dashboard_metric(cell, value: str, label: str, status: str, status_color: str) -> None:
    set_cell_shading(cell, WHITE)
    set_cell_border(cell, top={"val":"single","sz":"8","color":GRID}, bottom={"val":"single","sz":"8","color":GRID}, start={"val":"single","sz":"8","color":GRID}, end={"val":"single","sz":"8","color":GRID})
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(value)
    set_run_font(r, size=17, bold=True, color=NAVY)
    p = cell.add_paragraph(label)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(1)
    set_run_font(p.runs[0], size=7.6, bold=True, color=MUTED)
    p = cell.add_paragraph(status)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    set_run_font(p.runs[0], size=7.4, bold=True, color=status_color)


def build_document() -> Path:
    product_chart = ASSETS / "product_target_funnel.png"
    rd_chart = ASSETS / "rd_target_funnel.png"
    make_funnel_chart(product_chart, "PRODUCT • monthly target-state cohort", ["Qualified leads", "Recruiter screen", "HM screen", "Case / panel", "Offer", "Accept"], [100, 32, 18, 9, 4, 3], [COBALT, "3978FF", "5B8FFF", "7EA8FF", CORAL, GREEN])
    make_funnel_chart(rd_chart, "R&D • monthly target-state cohort", ["Qualified leads", "Recruiter screen", "Technical screen", "Panel", "Offer", "Accept"], [140, 42, 24, 12, 4, 3], [COBALT, "3978FF", "5B8FFF", "7EA8FF", CORAL, GREEN])

    doc = Document()
    configure_styles(doc)
    section = doc.sections[0]
    configure_section(section)
    add_header_footer(section, "Teads • Technical Talent Acquisition", first_page_blank=True)

    # Cover — editorial cover pattern.
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run("TEADS")
    set_run_font(r, size=18, bold=True, color=COBALT)
    r2 = p.add_run("  /  PEOPLE + TECHNOLOGY")
    set_run_font(r2, size=9, bold=True, color=MUTED)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(38)
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run("LEAD TECHNICAL TALENT\nACQUISITION SPECIALIST")
    set_run_font(r, size=29, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(22)
    r = p.add_run("Interview assignment • Israel, France & Slovenia")
    set_run_font(r, size=14, color=COBALT)

    cover_tbl = doc.add_table(rows=1, cols=3)
    cover_tbl.style = "Table Grid"
    set_table_geometry(cover_tbl, [3100, 3100, 3160], 9360, indent=0)
    for i, (num, label, fill) in enumerate((("01", "Market mapping\nCloud Engineer — platform-focused", PALE_BLUE), ("02", "Stakeholder one-pager\nTech & Product", PALE_CORAL), ("03", "Employer brand\nIsrael", PALE_GREEN))):
        c = cover_tbl.cell(0, i)
        set_cell_shading(c, fill)
        set_cell_border(c, top={"val":"nil"}, bottom={"val":"nil"}, start={"val":"nil"}, end={"val":"nil"})
        p = c.paragraphs[0]
        p.paragraph_format.space_after = Pt(5)
        rr = p.add_run(num)
        set_run_font(rr, size=20, bold=True, color=COBALT if i == 0 else CORAL if i == 1 else TEAL)
        p = c.add_paragraph(label)
        p.paragraph_format.space_after = Pt(2)
        set_run_font(p.runs[0], size=10, bold=True, color=NAVY)

    doc.add_page_break()

    # Part 1.
    add_section_title(doc, "Part 1", "Source five prospects for the Cloud Engineer — platform-focused role—and build the market around them", "", "part1", 3)
    add_callout(doc, "Role calibration", "Must-have evidence: substantial AWS or Azure workloads, Terraform/IaC, programming and automation, design/documentation, and collaboration. Bonus evidence: highly available high-traffic multi-region systems and adtech/e-commerce. The work connects AWS/Azure to on-prem, global networking and automated provisioning. [S02]")

    doc.add_heading("Exact sourcing searches", level=2)
    add_table(doc, ["SEARCH", "EXACT QUERY"], [
        ("LinkedIn Boolean", '("platform engineer" OR "site reliability engineer" OR SRE OR DevOps) AND (AWS OR Azure) AND (Terraform OR IaC) AND (Kubernetes OR networking OR "hybrid cloud")'),
        ("Google X-ray", 'site:linkedin.com/in ("platform engineer" OR "site reliability engineer" OR SRE OR DevOps) (AWS OR Azure) (Terraform OR IaC) (Israel OR "Tel Aviv" OR Netanya)'),
    ], [1800, 7560], font_size=7.8, first_col_bold=True)
    p = doc.add_paragraph()
    add_label_run(p, "Filters: ", "Israel; current or past Platform, SRE or DevOps titles; 5–12 years as a guide; relevant companies. Use Open to Work only to prioritize. Never filter on protected characteristics.")

    start_portrait_section(doc, "Teads • Technical Talent Acquisition")
    doc.add_heading("Simple sourcing process", level=2)
    p = doc.add_paragraph("1. Define must-haves → 2. Map target companies → 3. Search LinkedIn/Google/GitHub → 4. Use AI to organize evidence → 5. Manually check → 6. Contact candidates.")
    p.paragraph_format.space_after = Pt(2)
    p = doc.add_paragraph()
    add_label_run(p, "Tools: ", "LinkedIn Recruiter, Google X-ray, GitHub Search, ChatGPT/Claude, Greenhouse.")
    p.paragraph_format.space_after = Pt(5)
    doc.add_heading("Company adjacency map", level=2)
    add_table(doc, ["TIER", "TARGET COMPANIES", "WHY"], [
        ("1 • Adtech / high scale", "Taboola, AppsFlyer, Similarweb, Nexxen/Tremor, Perion, Playtika, Unity/ironSource, Minute Media", "Closest domain, streaming, bidding/measurement and latency parallels."),
        ("2 • Platform / infrastructure", "Wix, monday.com, JFrog, BMC, Amdocs, NICE, CyberArk, Check Point, Cato Networks, Akamai", "Large SaaS, hybrid estates, networking, developer platforms and operational rigor."),
        ("3 • Commerce / fintech", "Rapyd, eToro, Payoneer, Riskified, Forter, Melio, Global-e, Yotpo, FundGuard", "Multi-region availability, regulated workloads, traffic spikes and production ownership."),
    ], [1750, 4750, 2860], font_size=8.4, first_col_bold=True)

    start_portrait_section(doc, "Teads • Technical Talent Acquisition")

    add_kicker(doc, "Part 1 • Shortlist", color=COBALT)
    doc.add_heading("Five prospects to validate", level=1)
    add_candidate_card(doc, "Rotem Hochman", "S27", "16 / 20", "Autodesk senior DevOps engineer in Israel with 7+ years of experience, public multi-region AWS automation evidence and relevant Computer Science academic education.",
                       ["LinkedIn states 7+ years in senior DevOps roles.", "Public material covers multi-region AWS-account deployments, IaC, Terraform and Spinnaker.", "Computer Science B.Sc. study is listed at the College of Management Academic Studies."],
                       ["Degree completion and current hands-on scope.", "Azure, on-prem and production-networking depth.", "Availability and Netanya hybrid fit."],
                       "Own Teads' multi-cloud foundation, applying proven multi-region automation to global networking and provisioning at ad-serving scale.")
    add_candidate_card(doc, "Tal Asulin", "S25", "16 / 20", "AppsFlyer platform engineer in Israel; directly adjacent advertising/measurement environment with Kubernetes and Kafka reliability signals.",
                       ["Platform engineering and cloud-based solutions in public summary.", "AppsFlyer platform group combines software and DevOps.", "Published/shared work on Kubernetes stateful applications and Kafka leader-election trade-offs."],
                       ["Terraform and AWS/Azure depth.", "Global networking / on-prem experience.", "Current level, location and interest."],
                       "Move from adjacent adtech scale to a foundation role where reliability choices affect approximately 2 million ad requests/second and four engineering hubs.")
    add_candidate_card(doc, "Erez Neiderman", "S29", "14 / 20", "Senior individual-contributor DevOps profile now at NVIDIA, with public SAP software-lifecycle experience and university education at Ben-Gurion University.",
                       ["LinkedIn describes senior DevOps work at SAP and software-lifecycle development.", "Current NVIDIA and prior SAP experience provide large-enterprise engineering adjacency.", "Ben-Gurion University education is listed for 2007–2011."],
                       ["Degree field/completion and current IC remit.", "AWS/Azure, Terraform, Kubernetes and networking depth.", "Architecture ownership and Netanya schedule."],
                       "Offer a hands-on step from enterprise lifecycle DevOps into ownership of Teads' global cloud foundation and reliability problems.")
    start_portrait_section(doc, "Teads • Technical Talent Acquisition")
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(10)

    add_kicker(doc, "Part 1 • Shortlist", color=COBALT)
    add_candidate_card(doc, "Ashraf Hamad", "S26", "15 / 20", "Tenure-matched Staff DevOps prospect in Israel: public experience records show every listed role lasting at least 2 years 4 months across Bitsight/Cybersixgill and Ex Libris.",
                       ["Staff/Senior DevOps and cloud-production progression is public.", "Each listed role spans at least 2 years 4 months; Ex Libris totals nearly eight years.", "Software Engineering education is listed at Jerusalem College of Engineering."],
                       ["Manually confirm dates in LinkedIn Recruiter before outreach.", "AWS/Azure, Terraform, Kubernetes and networking evidence.", "Staff-level scope, motivation and Netanya fit."],
                       "A stable long-tenure progression into a platform charter where cloud reliability and internal developer enablement have global impact.")
    add_candidate_card(doc, "Tal Ayalon", "S28", "15 / 20", "Wix senior DevOps engineer with 7+ years across Wix, Redis and MAMRAM; the public record adds recognized-company depth and strong cloud-native signals.",
                       ["LinkedIn states 7+ years and current senior DevOps work at Wix.", "A public career post lists Docker, Kubernetes, Jenkins, Ansible, Python, Linux and CI/CD.", "Earlier experience includes Redis and four years in MAMRAM."],
                       ["Terraform, Azure and on-prem/global-networking depth.", "Current architecture ownership and production scale.", "Availability and Netanya hybrid fit."],
                       "Apply cloud-native automation from recognized platform companies to an ad platform operating at measurable global scale.")

    doc.add_heading("Exact AI evidence-review prompt (LLM = large language model)", level=2)
    p = doc.add_paragraph("An LLM is the AI model behind tools such as ChatGPT or Claude. Here it organizes supplied public evidence into a reviewable structure; it does not make the hiring decision.")
    p.paragraph_format.space_after = Pt(3)
    set_run_font(p.runs[0], size=8.1, color=MUTED)
    add_code_box(doc, "Act as a skeptical technical sourcer. You may use only evidence in the supplied public snippets and URLs.\nRole JSON: {must_haves:[AWS_or_Azure, Terraform_IaC, programming_automation, design_documentation, collaboration], bonuses:[HA_high_traffic, multi_region, adtech_ecommerce], location:Netanya_hybrid}\nCandidate evidence: <paste exact public snippets + URLs>\nReturn JSON with: candidate_name, location_evidence, current_company_title_evidence, must_have_evidence[], bonus_evidence[], missing_or_unverified[], risk_flags[], provisional_score_out_of_20, source_urls[], confidence. Write 'unknown' when not explicit. Never infer age, ethnicity, family status, religion, military background, compensation, willingness to commute or job-search status. Down-rank title-only matches. Explain every score in one sentence.", font_size=7.7)

    doc.add_heading("AI-assisted hidden talent-pool discovery prompt", level=2)
    add_code_box(doc, "Using the Cloud Engineer — platform-focused scorecard and the seed companies AppsFlyer, Taboola, Wix, Cato Networks and Rapyd, identify 10 adjacent Israeli talent pools based on similar technical problems rather than exact job titles.\nFor each pool, provide: relevant companies, alternative job titles, likely cloud and infrastructure signals, public sources to search, LinkedIn Boolean strings, Google X-ray queries, GitHub search ideas and why this pool may be overlooked.\nUse only public professional information. Do not infer protected characteristics, and do not treat the absence of GitHub activity as negative evidence. Every profile must be manually verified before outreach.", font_size=7.7, output_text="prioritized adjacent talent pools that feed the company map, Boolean searches, public-artifact research and referral strategy.")

    doc.add_heading("Multi-channel local campaign • 16-day sequence", level=2)
    add_table(doc, ["DAY", "CHANNEL", "MESSAGE / ASSET", "SUCCESS SIGNAL"], [
        ("0", "Warm graph", "Ask Teads engineers and adjacent-company alumni for a specific introduction using the role scorecard.", "Intro accepted or evidence added"),
        ("1", "Recruiter InMail", "Recruiter: cite one verified signal and connect it to the role. ‘Your work on [signal] stood out; this role owns [matching platform problem]. Open to a 20-minute conversation with the hiring architect?’", "Reply / positive reply"),
        ("3", "Connection note", "Short Hebrew or English note; no duplicate pitch.", "Connection accepted"),
        ("5", "Relevant VP follow-up", "Only if there is no reply, via LinkedIn or lawful professional email: ‘I lead [org] at Teads. Your [evidence] maps to [business priority/impact]. If relevant, I would value a brief confidential conversation—no pressure if timing is not right.’", "Reply / conversation"),
        ("8", "Proof touch", "Share a relevant engineering article or invite the candidate to a short ‘150ms Reliability Lab’: a practical discussion about keeping ad responses below the ~150-millisecond (0.15-second) target during failures.", "Content engagement"),
        ("12", "Phone / WhatsApp", "Only when supplied by the prospect, a trusted referral or explicit opt-in.", "Conversation booked"),
        ("16", "Close loop", "Respectful final note; offer talent-community content; record opt-out and next-contact date.", "Clear yes / no / later"),
    ], [600, 1600, 5050, 2110], font_size=7.8, first_col_bold=True)
    add_source_note(doc, "This is a branching sequence, not seven mandatory touches. Select referral, recruiter or opt-in channels according to response and lawful contact basis; the recruiter and VP coordinate one follow-up, then stop or close the loop.")
    # Part 2 dashboard landscape section.
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    configure_section(section, landscape=True, compact=True)
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    add_header_footer(section, "Bonus one-pager • Hiring Efficiency — Tech & Product")

    banner = doc.add_table(rows=1, cols=1)
    banner.style = "Table Grid"
    set_table_geometry(banner, [14544], 14544, indent=0)
    cell = banner.cell(0, 0)
    set_cell_shading(cell, NAVY)
    set_cell_border(cell, top={"val":"nil"}, bottom={"val":"nil"}, start={"val":"nil"}, end={"val":"nil"})
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run("PART 2 • BONUS DELIVERABLE")
    set_run_font(r, size=7.5, bold=True, color=CORAL)
    p = cell.add_paragraph()
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run("STAKEHOLDER ONE-PAGER")
    set_run_font(r, size=20, bold=True, color=WHITE)
    p = cell.add_paragraph("Standalone hiring-efficiency report • ready to send to the Lead P&C BP and Engineering VP")
    p.paragraph_format.space_after = Pt(0)
    set_run_font(p.runs[0], size=8.5, bold=True, color=WHITE)

    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run("HIRING EFFICIENCY — TECH & PRODUCT")
    set_run_font(r, size=18, bold=True, color=NAVY)
    r2 = p.add_run("   |   Standalone leadership report")
    set_run_font(r2, size=10, color=MUTED)
    p = doc.add_paragraph("ILLUSTRATIVE TARGET-STATE • NOT TEADS ATS PERFORMANCE • example assumes 2 recruiters × 3 accepts/month • replace with Greenhouse/HRIS data")
    p.paragraph_format.space_after = Pt(5)
    set_run_font(p.runs[0], size=7.5, bold=True, color=RED)

    metrics = doc.add_table(rows=1, cols=6)
    metrics.style = "Table Grid"
    set_table_geometry(metrics, [2424]*6, 14544, indent=0)
    for cell, args in zip(metrics.rows[0].cells, [
        ("12", "OPEN REQS", "2 open >30 days", AMBER),
        ("4 / 6", "HIRES THIS MONTH / TARGET", "67% to plan", AMBER),
        ("5.8", "FORECAST ACCEPTS", "−0.2 vs target", AMBER),
        ("21d", "MEDIAN DAYS OPEN", "target ≤30d", GREEN),
        ("78%", "OFFER ACCEPTANCE", "target ≥80%", AMBER),
        ("24h", "FEEDBACK SLA", "82% compliant", AMBER),
    ]):
        add_dashboard_metric(cell, *args)

    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run("FORECAST BY RECRUITER / HIRING TRACK")
    set_run_font(r, size=8, bold=True, color=NAVY)
    forecast = add_table(doc, ["RECRUITER / TRACK", "TARGET", "PROBABILITY-WEIGHTED FORECAST", "ON TRACK?", "NEXT STEP"], [
        ("Recruiter A • Product", "3.0", "2.6", "NEEDS ACTION", "Move one more qualified Product candidate to the final panel; decide within 24 hours."),
        ("Recruiter B • R&D", "3.0", "3.2", "ON TRACK", "Keep interview slots available and discuss motivation and offer expectations early."),
    ], [2400, 1200, 2600, 1500, 6844], font_size=7.6, first_col_bold=True, total=14544)

    add_compact_takeaway(doc, "Forecast: 5.8 accepts against a target of 6 — Product requires one additional panel-ready candidate.\nHM discussion: 1) Product is 0.4 below plan—add one panel-ready candidate. 2) R&D needs 40% more qualified leads for the same three accepts—intensify evidence-led sourcing and referrals. 3) Panel-to-offer is weakest (Product 44%; R&D 33%)—simplify assessment, calibrate the bar and decide within 24–48 hours.", PALE_CORAL, CORAL, 14544, font_size=7.4, indent=0)

    chart_tbl = doc.add_table(rows=1, cols=2)
    chart_tbl.style = "Table Grid"
    set_table_geometry(chart_tbl, [7272, 7272], 14544, indent=0)
    for idx, (chart_path, alt_title, alt_desc) in enumerate([
        (product_chart, "Product target-state hiring funnel", "Product: 100 qualified leads, 32 recruiter screens, 18 hiring-manager screens, 9 cases or panels, 4 offers and 3 accepts."),
        (rd_chart, "R&D target-state hiring funnel", "R&D: 140 qualified leads, 42 recruiter screens, 24 technical screens, 12 panels, 4 offers and 3 accepts."),
    ]):
        cell = chart_tbl.rows[0].cells[idx]
        set_cell_border(cell, top={"val":"nil"}, bottom={"val":"nil"}, start={"val":"nil"}, end={"val":"nil"})
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        shape = p.add_run().add_picture(str(chart_path), width=Inches(4.4))
        set_alt_text(shape, alt_title, alt_desc)

    bottom = doc.add_table(rows=1, cols=3)
    bottom.style = "Table Grid"
    set_table_geometry(bottom, [4800, 4800, 4944], 14544, indent=0)
    bottom_items = [
        ("PRODUCT BOTTLENECK", "Primary loss: Case/panel → offer is 44%.\nOffer → accept is 75% (1 of 4 lost): record the candidate-stated reason—compensation, competing offer, scope/level, work model/commute, timing or other.\nFix: Use one ≤90-minute task/live option, decide the same day and code every decline.", PALE_CORAL),
        ("R&D BOTTLENECK", "Primary loss: Panel → offer is 33%.\nOffer → accept is 75% (1 of 4 lost): use the same candidate-stated reason taxonomy; do not assume the cause.\nFix: Use one 60-minute practical, reserve interview slots, decide within 48 hours and code every decline.", PALE_BLUE),
    ]
    for cell, (label, body, fill) in zip(bottom.rows[0].cells[:2], bottom_items):
        set_cell_shading(cell, fill)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        set_run_font(p.add_run(label), size=7.6, bold=True, color=NAVY)
        p = cell.add_paragraph(body)
        p.paragraph_format.space_after = Pt(0)
        set_run_font(p.runs[0], size=6.9, color=INK)

    location_cell = bottom.rows[0].cells[2]
    set_cell_shading(location_cell, PALE_GREEN)
    p = location_cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    set_run_font(p.add_run("LOCATION DROP-OFF HEATMAP • ILLUSTRATIVE"), size=7.5, bold=True, color=NAVY)
    location_heatmap = location_cell.add_table(rows=4, cols=4)
    location_heatmap.style = "Table Grid"
    set_table_geometry(location_heatmap, [1900, 850, 900, 900], 4550, indent=120)
    location_rows = [
        ("STAGE", "IL", "FR", "SI"),
        ("Recruiter → HM/tech", "56%", "61%", "49%"),
        ("HM/tech → panel", "50%", "46%", "58%"),
        ("Panel → offer", "33%", "41%", "29%"),
    ]
    heat_fills = [
        (LIGHT, LIGHT, LIGHT, LIGHT),
        (WHITE, PALE_BLUE, PALE_GREEN, PALE_CORAL),
        (WHITE, PALE_BLUE, PALE_CORAL, PALE_GREEN),
        (WHITE, PALE_CORAL, PALE_CORAL, PALE_CORAL),
    ]
    for row_idx, (row, values, fills) in enumerate(zip(location_heatmap.rows, location_rows, heat_fills)):
        prevent_row_split(row)
        for idx, (cell, value, fill) in enumerate(zip(row.cells, values, fills)):
            set_cell_shading(cell, fill)
            set_cell_margins(cell, top=25, start=45, bottom=25, end=45)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0)
            set_run_font(p.add_run(value), size=7.1, bold=(row_idx == 0 or idx == 0), color=NAVY if (row_idx == 0 or idx == 0) else INK)
    set_repeat_table_headers(location_heatmap)
    p = location_cell.add_paragraph("Primary drop-off: IL commute/hybrid • FR language/location • SI senior-pool size")
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(0)
    set_run_font(p.runs[0], size=7.1, color=INK)

    p = doc.add_paragraph("Forecast = Σ(active candidates counted once at furthest stage × historical P(accepted | stage, track, location, source)).")
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(1)
    set_run_font(p.runs[0], size=7.2, color=MUTED)
    p = doc.add_paragraph("In plain English: each active candidate is counted once at their most advanced stage and weighted by the historical likelihood that a similar candidate—based on stage, role, location and source—will ultimately accept an offer.")
    p.paragraph_format.space_after = Pt(0)
    set_run_font(p.runs[0], size=7.2, color=INK)

    # Return to portrait.
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    configure_section(section)
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    add_header_footer(section, "Part 2 • Hiring Efficiency")

    add_section_title(doc, "Part 2 • Data Visibility & Reporting", "Exact metrics, definitions and decision rules", "The preceding landscape page is the requested standalone stakeholder one-pager; the definitions below make it consistent across Product, R&D, Israel, France and Slovenia.", "part2", 4)

    add_compact_takeaway(doc, "Metric assumptions: illustrative target-state, not Teads ATS actuals; two recruiters with three accepted hires each per month; active candidates counted once at their furthest stage; conversion history segmented by track, location and source; 30-day requisition target, 24-hour feedback SLA and 80% offer-acceptance target; duplicates and candidate-requested pauses excluded.", PALE_BLUE, COBALT, 9360, font_size=7.8)

    doc.add_heading("What the weekly hiring dashboard should show", level=2)
    add_table(doc, ["BUSINESS QUESTION", "WHAT TO TRACK", "VIEW BY"], [
        ("Are we hiring fast enough?", "Open roles; hires this month/quarter; forecast versus target; days open", "Product/R&D; country; recruiter; level"),
        ("Do we have enough qualified candidates?", "Candidates at each stage; pipeline coverage; source results; inactive candidates", "Role; source; location; stage; age"),
        ("Where are candidates waiting?", "Time to kickoff and first shortlist; days in each stage; scheduling, feedback and offer time", "Role and location; typical time and slowest cases"),
        ("Are we using time well?", "Applications, interviews and interviewer hours per hire; source results; recruiter workload; cost per hire", "Source; role difficulty; new/replacement"),
        ("Are we making strong hires?", "Offer acceptance; decline/withdrawal reasons; candidate feedback; 90-day retention/ramp; manager satisfaction", "Cohort; source; recruiter; role; location"),
    ], [2200, 4320, 2840], font_size=8.2, first_col_bold=True)

    doc.add_page_break()

    add_kicker(doc, "Part 2 • Funnel design", color=CORAL)
    doc.add_heading("Separate funnels, explicit math", level=1)
    p = doc.add_paragraph("Each target-state cohort back-solves from three accepts. Sourced quality and fast decisions must improve together.")
    p.paragraph_format.space_after = Pt(6)
    set_run_font(p.runs[0], size=9.0, bold=True, color=CORAL)

    doc.add_heading("Product track • illustrative monthly target", level=2)
    add_compact_takeaway(doc, "Product funnel assumptions: one monthly cohort; 100 manually verified qualified leads; target of three accepts; conversions are illustrative back-solved targets, not Teads history; one ≤90-minute case/live option; reserved interview capacity; elapsed time excludes candidate-requested pauses.", PALE_BLUE, COBALT, 9360, font_size=7.7)
    add_table(doc, ["STAGE", "COUNT", "PASS-THROUGH", "AVG TIME", "DROP-OFF / BOTTLENECK", "IMPROVEMENT"], [
        ("Qualified leads", "100", "—", "7d to engage", "Low relevance or no response", "Adtech/CTV adjacency map; evidence-led messages; referrals"),
        ("Recruiter screen", "32", "32%", "3d", "Work model / scope / compensation mismatch", "Share range and Netanya/work-model expectations before call"),
        ("HM screen", "18", "56%", "4d", "Unclear level or platform/domain bar", "Scorecard with 3 outcomes + 5 evidence signals"),
        ("Case / panel", "9", "50%", "8d", "Take-home burden; scheduling; inconsistent rubric", "≤90-min sample/live option; pre-book panels; rubric anchors"),
        ("Offer", "4", "44%", "3d", "Late compensation alignment; slow approval", "Pre-close at panel; same-day debrief; 48h approval"),
        ("Accept", "3", "75%", "6d", "Reason unknown until candidate confirms", "Code: compensation; competing offer; scope/level; work model/commute; timing; other"),
    ], [1450, 600, 1100, 850, 2640, 2720], font_size=8.0, first_col_bold=True)
    add_source_note(doc, "Target elapsed time: ~31 calendar days if stages flow without queues. The largest designed choke point is case/panel → offer; monitor panel hours, case withdrawal and candidate-stated offer-decline reasons separately.")

    doc.add_page_break()
    doc.add_heading("R&D track • illustrative monthly target", level=2)
    add_compact_takeaway(doc, "R&D funnel assumptions: one monthly cohort; 140 qualified leads for a narrower skill pool; target of three accepts; conversions are illustrative back-solved targets, not Teads history; one 60-minute practical; reserved cross-hub technical panels; elapsed time excludes candidate-requested pauses.", PALE_BLUE, COBALT, 9360, font_size=7.7)
    add_table(doc, ["STAGE", "COUNT", "PASS-THROUGH", "AVG TIME", "DROP-OFF / BOTTLENECK", "IMPROVEMENT"], [
        ("Qualified leads", "140", "—", "7d to engage", "Title-only matches; no reply", "Skill-evidence map; optional public artifacts; referrals"),
        ("Recruiter screen", "42", "30%", "3d", "Netanya commute, hybrid or scope mismatch", "Share office cadence and role boundaries before call"),
        ("Technical screen", "24", "57%", "7d", "Scheduling and abstract trivia", "60-min production scenario; weekly interviewer pods"),
        ("Panel", "12", "50%", "8d", "Duplicate tests; cross-hub coordination", "Map each competency once; parallelize; 24h feedback"),
        ("Offer", "4", "33%", "3d", "Calibration variance; approval latency", "Evidence-based debrief; no extra round; 48h decision"),
        ("Accept", "3", "75%", "6d", "Reason unknown until candidate confirms", "Code: compensation; competing offer; scope/level; work model/commute; timing; other"),
    ], [1450, 600, 1100, 850, 2640, 2720], font_size=8.0, first_col_bold=True)
    add_source_note(doc, "Target elapsed time: ~34 calendar days. Track candidate-stated offer-decline reasons separately from panel rejections and approval delays.")
    start_portrait_section(doc, "Part 2 • Hiring Efficiency")
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(10)

    add_kicker(doc, "Part 2 • Bottlenecks", color=CORAL)
    doc.add_heading("Where Teads is most likely to lose time—and the practical fix", level=1)
    add_table(doc, ["LIKELY BOTTLENECK", "TEADS-SPECIFIC SIGNAL", "DIAGNOSTIC", "ACTION"], [
        ("Post-merger calibration", "The 2025 combination and name change can increase role-scope or team-identity ambiguity. [S05][S06]", "High HM-screen rejection variance; reopened reqs; changed scorecards", "60-minute kickoff with role outcomes, level anchors and ‘must have now vs learn’ split; monthly calibration council"),
        ("Rare platform scope", "The role combines AWS/Azure, on-prem, global networking, IaC and high scale. [S02]", "Many applicants but low technical-screen pass; repeated missing evidence", "Map adjacent pools; score evidence, not exact title; publish a technical ‘day in the life’"),
        ("Interview inflation", "External data shows 39 Engineering and 42 Product interviews per hire. [S22]", "High interviewer hours/hire; same competency tested twice", "Competency-to-interviewer map; one structured practical; eliminate redundant round"),
        ("Cross-hub scheduling", "Technical teams operate across Netanya, Ljubljana, Paris and Montpellier. [S08]", "Scheduling lag >3 business days; feedback SLA misses by hub", "Reserved interviewer pods by track/time zone; auto-escalate at 24h"),
        ("Netanya / hybrid clarity", "Public materials indicate hybrid work; the annual report describes three office days/two remote. [S02][S11]", "Israel withdrawal before screen or after work-model disclosure", "State office cadence, location and interview path in the first message/job page; offer commute-sensitive slots"),
        ("Brand transition", "The company combined two legacy brands and changed its corporate name in 2025. [S05][S06]", "Candidates ask ‘Outbrain or Teads?’; lower close confidence", "One approved integration narrative with roadmap proof, team stability facts and honest unknowns"),
    ], [1780, 2840, 2100, 2640], font_size=7.5, first_col_bold=True)

    doc.add_heading("Location-aware operating choices", level=2)
    add_table(doc, ["LOCATION", "LOCAL WATCH-OUT", "PROCESS CHOICE", "MEASURE"], [
        ("Israel • Netanya", "Commute and a three-day office rhythm; Sunday–Thursday operating context; periods of reserve/care disruption", "Disclose work model early; flexible interview slots; opt-in WhatsApp only; never penalize service/care gaps", "Pre-screen withdrawals; schedule lag; acceptance; candidate feedback"),
        ("France • Paris / Montpellier", "Two hubs and possible bilingual candidate journey; candidates need contract/location clarity", "Choose French/English touchpoints; clear home hub and interview language; local P&C review of messaging", "Reply and withdrawal by language/hub; days in approval"),
        ("Slovenia • Ljubljana", "Smaller senior platform pool and cross-border competition", "Prioritize referrals, community mapping and adjacent Central European talent; publish English technical content", "Qualified leads per week; referral yield; aging by skill"),
    ], [1600, 2700, 3190, 1870], font_size=7.8, first_col_bold=True)

    # Part 3.
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    configure_section(section)
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    add_header_footer(section, "Part 3 • Employer Brand Israel")

    add_section_title(doc, "Part 3 • Local Employer Branding", "Teads Israel: current status and action plan", "A focused assessment of the local employer brand, followed by short-term actions and long-term community plays.", "part3", 5)

    doc.add_heading("Current-status audit — what candidates can see today", level=2)
    p = doc.add_paragraph("This audit compares publicly visible employer-brand strengths with gaps that may affect candidate trust and conversion. ‘Public proof’ is evidence already visible to candidates; ‘gap / risk’ is a hypothesis Teads should validate with employees, candidate feedback and recruiting data before using it in messaging.")
    p.paragraph_format.space_after = Pt(5)
    set_run_font(p.runs[0], size=8.6, color=INK)
    add_table(doc, ["STRENGTH TO AMPLIFY", "PUBLIC PROOF", "GAP / RISK TO SOLVE"], [
        ("Exceptional engineering scale", "Company role materials cite ~2 million ad requests/sec, 100 billion events/day, responses below 150 milliseconds and 18 million predictions/sec. [S02]", "Current employer content can lead with office/perks; technical proof should become the hero."),
        ("Ownership culture", "‘You build it, you run it, you monitor it’; 400+ engineers across four hubs. [S08]", "Needs local engineer voices, specific decisions and honest trade-offs."),
        ("Visible local signals", "Hybrid work, Netanya office content, parking and pet-friendly signals are visible publicly. [S02][S17]", "Perks cannot substitute for level clarity, interview transparency and career evidence."),
        ("Brand-transition clarity", "The combined company adopted the Teads name in 2025. [S05][S06]", "Candidates may still ask what changed after the combination; recruiters need one honest, approved explanation."),
        ("Large review footprint", "Glassdoor snapshot: 3.7/5, 689 reviews and 74% recommend; anonymous sentiment is directional. [S18]", "Mixed post-merger commentary can create uncertainty; respond with themes and actions, never review manipulation."),
    ], [2450, 3810, 3100], font_size=7.9, first_col_bold=True)

    doc.add_page_break()
    add_kicker(doc, "Part 3 • Action plan", color=TEAL)
    doc.add_heading("Short-term, low-cost actions and long-term plays", level=1)
    add_table(doc, ["WHEN", "WHAT TO DO", "WHY IT MATTERS", "OWNER / MEASURE"], [
        ("0–30 days", "Interview 12 employees, review candidate drop-off and public feedback, and publish one clear FAQ about Teads after the combination.", "Gives recruiters and candidates one consistent explanation.", "TA + P&C + Comms / five evidence-based themes; FAQ use"),
        ("0–45 days", "Rewrite Israel job pages with the mission, technical scale, first-90-day goals, work model, interview stages and decision timing.", "Helps candidates decide earlier whether the role fits.", "TA + hiring manager / qualified applications; early withdrawals"),
        ("30–60 days", "Create a volunteer group of 8–12 engineers and product employees who can share approved, honest stories.", "Lets candidates hear directly from employees.", "Engineering + Product + employer brand / two local stories per month"),
        ("45–90 days", "Run short talks explaining how Teads engineers design systems for approximately 2 million ad requests every second, plus honest updates about the company combination.", "Turns Teads’ real engineering scale into a clear local story.", "Ambassadors / attendance; completion; qualified conversations"),
        ("3–6 months", "Run a quarterly reliability challenge focused on keeping mocked ad requests below the ~150-millisecond (0.15-second) response-time target, with AWS User Group Israel or DevOpsDays Tel Aviv.", "Shows the real technical problem while giving value to the community.", "DevRel + Platform / participant NPS; opt-in community; qualified leads; recruiter-screen conversion; hires influenced"),
        ("3–9 months", "Run Open Internet Build Nights with she codes, Tsofen and Olim in Tech.", "Builds long-term community relationships and widens access.", "P&C + partners / participation; return rate; qualified-pool reach where lawful"),
        ("6–12 months", "Create a Netanya engineering fellowship or open-source education partnership.", "Builds local reputation beyond open jobs.", "CTO org + P&C / contributions; brand search; hires influenced"),
    ], [1250, 3450, 2860, 1800], font_size=7.7, first_col_bold=True)
    add_compact_takeaway(doc, "Event participation, return rate and NPS are leading indicators. The final impact will be measured through source-attributed qualified leads, positive response rate, recruiter-screen conversion, offer acceptance and hires influenced for the Netanya hub.", PALE_GREEN, TEAL, 9360, font_size=8.2)
    add_source_note(doc, "Potential partners: AWS User Group Israel [S30], DevOpsDays Tel Aviv [S31], she codes [S32], Tsofen [S33], Olim in Tech [S34] and Israel Tech Challenge [S35]. Partnership requires co-design, consent and reciprocal value—not extracting candidate lists.")

    doc.add_heading("Three employer-brand ideas to test", level=2)
    concepts = doc.add_table(rows=1, cols=3)
    concepts.style = "Table Grid"
    set_table_geometry(concepts, [3120, 3120, 3120], 9360)
    for cell, (label, body, fill) in zip(concepts.rows[0].cells, [
        ("150ms RELIABILITY CHALLENGE", "A quarterly hands-on session where Teads engineers and guests keep a mocked ad request below ~150 milliseconds (0.15 seconds) during failures. It teaches; it is not a candidate test.", PALE_BLUE),
        ("OPEN-INTERNET BUILD NIGHT", "Teads engineers and community partners work together on public tools or tutorials. Participants learn and may opt into future contact.", PALE_GREEN),
        ("WHAT CHANGED AT TEADS", "A leader and engineer explain one post-combination system change, the trade-off and what comes next. Candidates get a clear, honest story.", PALE_CORAL),
    ]):
        set_cell_shading(cell, fill)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(3)
        set_run_font(p.add_run(label), size=9, bold=True, color=NAVY)
        p = cell.add_paragraph(body)
        p.paragraph_format.space_after = Pt(0)
        set_run_font(p.runs[0], size=8.3, color=INK)

    # Core properties and compatibility.
    doc.core_properties.title = "Teads Lead Technical Talent Acquisition Specialist — Interview Assignment"
    doc.core_properties.subject = "Cloud engineering sourcing, hiring efficiency, and employer brand Israel"
    doc.core_properties.author = "Interview candidate"
    doc.core_properties.keywords = "Teads, technical recruiting, sourcing, hiring funnel, employer brand, Israel"
    settings = doc.settings._element
    update_fields = OxmlElement("w:updateFields")
    update_fields.set(qn("w:val"), "true")
    settings.append(update_fields)

    strip_source_tokens(doc)
    doc.save(OUT)
    # Normalize the OPC package through a second serialization pass. Microsoft Word's
    # PDF engine is sensitive to the first-pass package ordering when mixed portrait
    # and landscape sections are present, even though the XML payload is equivalent.
    normalized = OUT.with_name(OUT.stem + "_normalized.docx")
    normalized_doc = Document(OUT)
    normalized_body = normalized_doc._element.body
    final_sect_pr = deepcopy(normalized_body[-1])
    normalized_body.remove(normalized_body[-1])
    normalized_body.append(final_sect_pr)
    normalized_doc.save(normalized)
    normalized.replace(OUT)
    return OUT


if __name__ == "__main__":
    result = build_document()
    print(result)
