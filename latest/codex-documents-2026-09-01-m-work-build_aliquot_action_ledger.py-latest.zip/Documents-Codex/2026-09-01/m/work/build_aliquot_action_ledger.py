from __future__ import annotations

import json
import re
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m")
LIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
ORIGINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Excel file editor\Final Known and Unknown merged.xlsx")
ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
OUT = ROOT / r"work\aliquot_action_ledger.json"


def text(v):
    return "" if v is None else str(v).strip()


def norm(v):
    return re.sub(r"[^A-Z0-9]", "", text(v).upper())


def rgb(cell):
    color = cell.fill.fgColor
    return color.rgb.upper() if color.type == "rgb" and color.rgb else ""


def parse_qty(v):
    if v is None or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = text(v).replace(",", ".")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return 0.0
    value = float(m.group(0))
    return max(value, 0.0)


def load_inventory():
    wb = load_workbook(ALIQUOTS, data_only=True, read_only=True)
    inventory = []
    sheet_info = []
    for ws in wb.worksheets:
        values = list(ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, 1000), max_col=min(ws.max_column or 1, 40), values_only=True))
        quantity_col = None
        id_cols = []
        count = 0
        for row_number, row in enumerate(values, start=1):
            lower = [text(v).lower() for v in row]
            q_candidates = [i for i, v in enumerate(lower) if "aliquot" in v]
            if q_candidates:
                quantity_col = q_candidates[0]
                id_cols = [
                    i for i, v in enumerate(lower)
                    if ("sample" in v or "patient number" in v or v == "name" or "מספר מטופל" in v)
                    and "status" not in v
                ]
                continue
            if quantity_col is None or quantity_col >= len(row):
                continue
            qty_raw = row[quantity_col]
            # Keep zero/blank quantities when the row has a recognizable identifier;
            # they prove that the sample exists but no usable aliquot remains.
            identifiers = []
            for i in id_cols:
                if i < len(row) and text(row[i]):
                    identifiers.append({"column": i + 1, "value": text(row[i]), "norm": norm(row[i])})
            identifiers = [x for x in identifiers if x["norm"]]
            if not identifiers:
                continue
            rec = {
                "sheet": ws.title,
                "row": row_number,
                "quantity_raw": text(qty_raw),
                "quantity": parse_qty(qty_raw),
                "identifiers": identifiers,
            }
            inventory.append(rec)
            count += 1
        sheet_info.append({"sheet": ws.title, "records": count})
    wb.close()
    return inventory, sheet_info


def find_matches(a, b, inventory):
    na, nb = norm(a), norm(b)
    primary = [r for r in inventory if na and any(x["norm"] == na for x in r["identifiers"])]
    secondary = [r for r in inventory if nb and any(x["norm"] == nb for x in r["identifiers"])]
    matches = primary if primary else secondary
    method = "primary" if primary else ("secondary" if secondary else "none")
    if primary and secondary:
        pkeys = {(r["sheet"], r["row"]) for r in primary}
        skeys = {(r["sheet"], r["row"]) for r in secondary}
        if pkeys == skeys:
            method = "both"
    return method, matches


def current_actions(inventory):
    wb = load_workbook(LIVE, data_only=False, read_only=False)
    rows = []
    for ws in wb.worksheets:
        for r in range(2, min(ws.max_row, 1000) + 1):
            a = text(ws.cell(r, 1).value)
            b = text(ws.cell(r, 2).value)
            status = text(ws.cell(r, 3).value)
            yellow = []
            for c in list(range(8, 16)) + list(range(17, 23)):
                if rgb(ws.cell(r, c)).endswith("FFD966"):
                    yellow.append(ws.cell(r, c).coordinate)
            if status != "missing" and not yellow:
                continue
            method, matches = find_matches(a, b, inventory)
            available = any(m["quantity"] > 0 for m in matches)
            ambiguous = len({(m["sheet"], m["row"]) for m in matches}) > 1
            action = "none"
            if status == "missing" and available:
                action = "highlight_missing_status"
            elif status == "measured" and yellow and not available:
                action = "measured_and_empty"
            rows.append({
                "sheet": ws.title,
                "row": r,
                "primary": a,
                "secondary": b,
                "status": status,
                "yellow_measurements": yellow,
                "match_method": method,
                "matches": matches,
                "aliquot_available": available,
                "ambiguous": ambiguous,
                "action": action,
            })
    wb.close()
    return rows


def rows_by_status(path):
    wb = load_workbook(path, data_only=True, read_only=False)
    out = []
    for ws in wb.worksheets:
        for r in range(2, min(ws.max_row, 1000) + 1):
            a, b, status = (text(ws.cell(r, c).value) for c in (1, 2, 3))
            if a or b:
                out.append({"sheet": ws.title, "row": r, "primary": a, "secondary": b, "status": status})
    wb.close()
    return out


def match_current(old_row, current_rows):
    na, nb = norm(old_row["primary"]), norm(old_row["secondary"])
    by_a = [r for r in current_rows if na and norm(r["primary"]) == na]
    if len(by_a) == 1:
        return by_a[0]
    by_b = [r for r in current_rows if nb and norm(r["secondary"]) == nb]
    if len(by_b) == 1:
        return by_b[0]
    return None


inventory, sheet_info = load_inventory()
actions = current_actions(inventory)
old_rows = rows_by_status(ORIGINAL)
current_rows = rows_by_status(LIVE)

not_tested_trace = []
missing_trace = []
for old in old_rows:
    if old["status"] not in {"לא נבדק", "missing"}:
        continue
    cur = match_current(old, current_rows)
    rec = {"old": old, "current": cur}
    if old["status"] == "לא נבדק":
        not_tested_trace.append(rec)
    else:
        missing_trace.append(rec)

result = {
    "aliquot_file": str(ALIQUOTS),
    "inventory_records": len(inventory),
    "inventory_by_sheet": sheet_info,
    "flagged_rows": actions,
    "action_counts": {
        "highlight_missing_status": sum(r["action"] == "highlight_missing_status" for r in actions),
        "measured_and_empty": sum(r["action"] == "measured_and_empty" for r in actions),
        "none": sum(r["action"] == "none" for r in actions),
    },
    "ambiguous_rows": [r for r in actions if r["ambiguous"]],
    "unmatched_rows": [r for r in actions if r["match_method"] == "none"],
    "not_tested_trace": not_tested_trace,
    "missing_trace": missing_trace,
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

print(json.dumps({
    "inventory_records": result["inventory_records"],
    "inventory_by_sheet": sheet_info,
    "action_counts": result["action_counts"],
    "flagged_rows": len(actions),
    "ambiguous_rows": len(result["ambiguous_rows"]),
    "unmatched_rows": len(result["unmatched_rows"]),
    "not_tested_trace": len(not_tested_trace),
    "not_tested_changed_or_missing": sum(not x["current"] or x["current"]["status"] != "לא נבדק" for x in not_tested_trace),
    "missing_trace": len(missing_trace),
    "missing_changed_or_missing": sum(not x["current"] or x["current"]["status"] != "missing" for x in missing_trace),
}, ensure_ascii=False, indent=2))
