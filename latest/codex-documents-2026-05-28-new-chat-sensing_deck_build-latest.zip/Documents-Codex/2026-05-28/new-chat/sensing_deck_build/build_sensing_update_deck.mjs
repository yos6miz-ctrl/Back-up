import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile } from "@oai/artifact-tool";
import JSZip from "jszip";

const OUT = String.raw`C:\Users\Popovtzer lab\.codex\אדמה ירוקה\03_חישה ודטקטורים\מצגת עדכון קבוצת החישה.pptx`;
const BUILD_DIR = String.raw`C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\sensing_deck_build`;
const P_GRAPH = String.raw`C:\Users\Popovtzer lab\.codex\אדמה ירוקה\03_חישה ודטקטורים\גרפים\puxpB_phosphate_starvation_report_graph.png`;
const LUX_GEL = String.raw`C:\Users\Popovtzer lab\OneDrive - Bar Ilan University (1)\Banin Lab Files\Lab members\Yosi\sensor\אדמה ירוקה\Detectors\starvation\Luciferase\pvdA and glnK ofr lux.jpeg`;
const ALK_GEL = String.raw`C:\Users\Popovtzer lab\OneDrive - Bar Ilan University (1)\Banin Lab Files\Lab members\Yosi\sensor\אדמה ירוקה\Detectors\Alkanes\Detector\colony dh5a pBBR palkS-sfGFP.jpeg`;

const W = 1280;
const H = 720;
const ink = "#111111";
const muted = "#4F5965";
const panel = "#F2F2F2";
const rule = "#B8BCC4";
const blue = "#3D8DFF";
const lightBlue = "#6DCBF4";
const green = "#2E7D32";
const orange = "#F28E2B";
const red = "#C74747";

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

async function imageBytes(filePath) {
  const bytes = await fs.readFile(filePath);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

async function markHebrewParagraphsRtl(filePath) {
  const bytes = await fs.readFile(filePath);
  const zip = await JSZip.loadAsync(bytes);
  const hebrew = /[\u0590-\u05FF]/;
  const slideXml = Object.keys(zip.files).filter((name) =>
    /ppt\/(slides|notesSlides)\/.*\.xml$/.test(name),
  );

  for (const name of slideXml) {
    const file = zip.file(name);
    if (!file) continue;
    const xml = await file.async("string");
    if (!hebrew.test(xml)) continue;
    const fixed = xml.replace(/<a:pPr(?![^>]*\srtl=)/g, '<a:pPr rtl="1"');
    zip.file(name, fixed);
  }

  const fixedBytes = await zip.generateAsync({ type: "nodebuffer" });
  await fs.writeFile(filePath, fixedBytes);
}

function addText(slide, text, pos, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    position: pos,
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    fontSize: opts.size ?? 24,
    bold: opts.bold ?? false,
    color: opts.color ?? ink,
    alignment: opts.align ?? "right",
    typeface: "Arial",
    autoFit: opts.autoFit ?? "shrinkText",
  };
  return shape;
}

function addPanel(slide, pos, fill = panel) {
  return slide.shapes.add({
    geometry: "rect",
    position: pos,
    fill,
    line: { style: "solid", fill: "#E0E0E0", width: 1 },
  });
}

function addFooter(slide, n) {
  addText(slide, "אדמה ירוקה | קבוצת החישה", { left: 40, top: 665, width: 520, height: 24 }, { size: 14, color: muted, align: "left" });
  addText(slide, String(n), { left: 1190, top: 665, width: 48, height: 24 }, { size: 14, color: muted, align: "right" });
}

function addTitle(slide, title, subtitle = "") {
  addText(slide, title, { left: 70, top: 38, width: 1140, height: 76 }, { size: 41, bold: true });
  if (subtitle) addText(slide, subtitle, { left: 70, top: 116, width: 1140, height: 44 }, { size: 23, color: muted });
}

function addBulletBlock(slide, lines, pos, opts = {}) {
  const text = lines.join("\n");
  return addText(slide, text, pos, { size: opts.size ?? 25, color: opts.color ?? ink, align: "right" });
}

function addMetric(slide, x, value, label, color = blue) {
  addPanel(slide, { left: x, top: 315, width: 345, height: 250 });
  addText(slide, value, { left: x + 24, top: 350, width: 297, height: 84 }, { size: 50, bold: true, color, align: "center" });
  addText(slide, label, { left: x + 24, top: 450, width: 297, height: 74 }, { size: 24, align: "center", color: ink });
}

function setNotes(slide, notes) {
  slide.speakerNotes.textFrame.setText(notes);
  slide.speakerNotes.setVisible(true);
}

async function build() {
  await fs.mkdir(BUILD_DIR, { recursive: true });
  await fs.mkdir(path.dirname(OUT), { recursive: true });
  const deck = Presentation.create({ slideSize: { width: W, height: H } });

  const s1 = deck.slides.add();
  s1.background.fill = "#FFFFFF";
  addText(s1, "אדמה ירוקה", { left: 70, top: 48, width: 520, height: 45 }, { size: 26, color: muted, align: "left" });
  addText(s1, "עדכון קבוצת החישה", { left: 70, top: 190, width: 950, height: 120 }, { size: 66, bold: true, align: "right" });
  addText(s1, "דטקטורי הרעבה, פוספט, לוציפראז ואלקנים/אלכוהולים", { left: 70, top: 330, width: 960, height: 78 }, { size: 31, color: muted, align: "right" });
  addText(s1, "אוגוסט 2026", { left: 70, top: 560, width: 480, height: 36 }, { size: 24, color: muted, align: "left" });
  addFooter(s1, 1);
  setNotes(s1, `[Sources]\nתיקיית מקור: C:\\Users\\Popovtzer lab\\OneDrive - Bar Ilan University (1)\\Banin Lab Files\\Lab members\\Yosi\\sensor\\אדמה ירוקה\\Detectors`);

  const s2 = deck.slides.add();
  s2.background.fill = "#FFFFFF";
  addTitle(s2, "שלושה דטקטורי הרעבה מציגים תגובה כמותית", "חנקן וברזל כבר מבוססים; דטקטור הפוספט עובד ונכנס לתוצאות.");
  s2.charts.add("bar", {
    position: { left: 70, top: 185, width: 690, height: 415 },
    categories: ["glnK / N", "pvdA / Fe", "uxpB / P"],
    series: [{ name: "Signal / noise", values: [17.1, 8.7, 4.6], fill: blue }],
    hasLegend: false,
    dataLabels: { showValue: true, position: "outEnd", textStyle: { fontSize: 18, bold: true, fill: ink } },
    yAxis: {
      title: { text: "Signal / noise", textStyle: { fontSize: 15, fill: ink } },
      min: 0,
      max: 20,
      majorUnit: 5,
      majorGridlines: { style: "solid", fill: "#E6E8EB", width: 1 },
      textStyle: { fontSize: 13, fill: muted },
    },
    xAxis: { textStyle: { fontSize: 14, fill: ink } },
    barOptions: { direction: "column", grouping: "clustered", gapWidth: 75 },
    chartFill: "#FFFFFF",
    plotAreaFill: { type: "none" },
    chartLine: { style: "solid", fill: "#FFFFFF", width: 0 },
  });
  addBulletBlock(s2, [
    "פרומוטור glnK מגיב למחסור בחנקן עם יחס אות/רעש של 17.1:1.",
    "פרומוטור pvdA מגיב למחסור בברזל עם יחס אות/רעש של 8.7:1.",
    "פרומוטור uxpB מגיב למחסור בפוספט עם יחס אות/רעש של 4.6:1.",
  ], { left: 805, top: 210, width: 385, height: 300 }, { size: 24 });
  addFooter(s2, 2);
  setNotes(s2, `[Sources]\nחנקן/ברזל: starvation\\מדידות\\20260610 does.xlsx\nפוספט: starvation\\P\\YOSSI  P starv  18.8.xlsx\nערכים מוצגים כיחס אות/רעש מחושב מהמדידות המעובדות.`);

  const s3 = deck.slides.add();
  s3.background.fill = "#FFFFFF";
  addTitle(s3, "דטקטור הפוספט עובד", "puxpB מראה תגובת מינון ברורה כאשר ריכוז הפוספט יורד.");
  s3.images.add({
    blob: await imageBytes(P_GRAPH),
    contentType: "image/png",
    alt: "puxpB phosphate starvation dose response with error bars",
    fit: "contain",
    position: { left: 55, top: 145, width: 765, height: 475 },
  });
  addPanel(s3, { left: 855, top: 190, width: 350, height: 300 });
  addText(s3, "נקודת המסר", { left: 880, top: 218, width: 300, height: 36 }, { size: 25, bold: true, align: "right" });
  addBulletBlock(s3, [
    "נבדקה סדרת ריכוזי פוספט.",
    "100 µM נתן את התגובה החזקה ביותר.",
    "הנתונים מוצגים עם סטיית תקן ושש חזרות.",
  ], { left: 880, top: 280, width: 300, height: 190 }, { size: 22 });
  addText(s3, "S/N = 4.6:1", { left: 880, top: 500, width: 300, height: 56 }, { size: 32, bold: true, color: green, align: "center" });
  addFooter(s3, 3);
  setNotes(s3, `[Sources]\nגרף פוספט מעובד: ${P_GRAPH}\nמקור מדידה: starvation\\P\\YOSSI  P starv  18.8.xlsx`);

  const s4 = deck.slides.add();
  s4.background.fill = "#FFFFFF";
  addTitle(s4, "העברה למערכת לוציפראז", "המטרה היא להתאים את הקריאה למערכת שאפשר להעביר ולהפעיל במעבדת ראמז.");
  addBulletBlock(s4, [
    "פרומוטורי pvdA ו-glnK הפעילים כבר נמצאים בתהליך העברה למערכת לוציפראז.",
    "דטקטור הפוספט עובד במערכת GFP; העברה ללוציפראז עדיין בתהליך.",
    "לאחר הבנייה יידרש אימות פונקציונלי של קריאת האור.",
  ], { left: 685, top: 185, width: 515, height: 260 }, { size: 24 });
  s4.images.add({
    blob: await imageBytes(LUX_GEL),
    contentType: "image/jpeg",
    alt: "Gel image for luciferase construct preparation",
    fit: "cover",
    position: { left: 70, top: 170, width: 555, height: 385 },
  });
  addText(s4, "בנייה מולקולרית: pvdA/glnK לכיוון lux", { left: 80, top: 570, width: 530, height: 36 }, { size: 20, color: muted, align: "center" });
  addFooter(s4, 4);
  setNotes(s4, `[Sources]\nLuciferase primers and assembly files: starvation\\Luciferase\\Starvation primers for luc.docx; Assembled pglnK luX.dna; Assembled ppvdA luX.dna\nGel image: ${LUX_GEL}`);

  const s5 = deck.slides.add();
  s5.background.fill = "#FFFFFF";
  addTitle(s5, "אלקנים ואלכוהולים: שני כיווני חישה משלימים", "הבנייה קיימת/מתקדמת, אבל תנאי הבדיקה עדיין צריכים החלטה.");
  addPanel(s5, { left: 70, top: 175, width: 520, height: 355 });
  addPanel(s5, { left: 690, top: 175, width: 520, height: 355 });
  addText(s5, "דטקטור אלקנים", { left: 105, top: 210, width: 450, height: 42 }, { size: 30, bold: true, align: "right" });
  addBulletBlock(s5, [
    "מבוסס על מערכת alkS / PalkB.",
    "מיועד לחישה של אלקנים, שהם רכיבים הידרופוביים של דלקים.",
    "האתגר המרכזי: בחירת סובסטרטים ותנאי חשיפה מתאימים.",
  ], { left: 105, top: 275, width: 450, height: 205 }, { size: 22 });
  addText(s5, "דטקטור אלכוהולים", { left: 725, top: 210, width: 450, height: 42 }, { size: 30, bold: true, align: "right" });
  addBulletBlock(s5, [
    "מיועד לחישה של תרכובות מחומצנות ופולריות יותר מאלקנים.",
    "אלכוהולים בדרך כלל מסיסים ונגישים יותר במדיום, ולכן תנאי החשיפה והבקרה שונים.",
    "מחכים להנחיות על אילו חומרים לבדוק ובאיזה פורמט.",
  ], { left: 725, top: 275, width: 450, height: 205 }, { size: 22 });
  addFooter(s5, 5);
  setNotes(s5, `[Sources]\nAlkanes files: Alkanes\\alkS\\alkS expression.docx; Alkanes\\Detector\\alkB sfGFP.docx; Alkanes\\Detector\\PalkB_sfgfp in pBBR1MCS-2.dna\nהבחנה מדעית: אלקנים הם פחמימנים לא פולריים; אלכוהולים מכילים קבוצת הידרוקסיל ולכן שונים במסיסות ובתנאי חשיפה.`);

  const s6 = deck.slides.add();
  s6.background.fill = "#FFFFFF";
  addTitle(s6, "מה צריך לסגור לשלב הבא", "העבודה עברה מהוכחת תגובה לבחירת פורמט בדיקה והעברה למערכות קריאה נוספות.");
  addMetric(s6, 70, "3", "דטקטורי הרעבה פעילים", green);
  addMetric(s6, 465, "2", "פרומוטורים בהעברה ללוציפראז", blue);
  addMetric(s6, 860, "2", "דטקטורי אלקנים/אלכוהולים בהמתנה לתנאי בדיקה", orange);
  addBulletBlock(s6, [
    "לקבוע עם הצוות אילו אלקנים ואלכוהולים לבדוק.",
    "להגדיר ריכוזים, ממס ובקרות שליליות/חיוביות.",
    "להשלים העברה ואימות של מערכת הלוציפראז.",
  ], { left: 90, top: 165, width: 1070, height: 110 }, { size: 24 });
  addFooter(s6, 6);
  setNotes(s6, `[Sources]\nסיכום סטטוס מבוסס על קבצי Detectors ועל הנחיות המשתמש בשיחה הנוכחית.`);

  for (const [i, slide] of deck.slides.items.entries()) {
    const png = await deck.export({ slide, format: "png", scale: 1 });
    await writeBlob(path.join(BUILD_DIR, `slide-${String(i + 1).padStart(2, "0")}.png`), png);
    const layout = await slide.export({ format: "layout" });
    await fs.writeFile(path.join(BUILD_DIR, `slide-${String(i + 1).padStart(2, "0")}.layout.json`), await layout.text(), "utf8");
  }
  const montage = await deck.export({ format: "webp", montage: true, scale: 1 });
  await writeBlob(path.join(BUILD_DIR, "sensing-update-montage.webp"), montage);
  const pptx = await PresentationFile.exportPptx(deck);
  await pptx.save(OUT);
  await markHebrewParagraphsRtl(OUT);
  console.log(OUT);
}

build().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
