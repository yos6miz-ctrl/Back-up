from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE = "YOSSI 13.8.26.xlsx"


def safe(value) -> str:
    if value is None:
        return ""
    return str(value)


def main() -> None:
    path = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE
    wb = load_workbook(path, data_only=False, read_only=True)
    print("path=", str(path).encode("unicode_escape").decode("ascii"))
    print("sheets=", [s.encode("unicode_escape").decode("ascii") for s in wb.sheetnames])
    for ws in wb.worksheets:
        print("\nSHEET", ws.title.encode("unicode_escape").decode("ascii"), ws.max_row, ws.max_column)
        for r in range(1, min(ws.max_row, 45) + 1):
            vals = [safe(ws.cell(r, c).value) for c in range(1, min(ws.max_column, 24) + 1)]
            if any(vals):
                print(r, " | ".join(vals).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
