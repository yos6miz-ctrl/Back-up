from pathlib import Path
import shutil

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont


BASE = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
SOURCE = BASE / "דוח אבני דרך - דירוג פרומוטורים משובטים - backup before P starvation completion.docx"
OUTPUT = BASE / "דוח אבני דרך - דירוג פרומוטורים משובטים - עם תוספת נתוני פוספט.docx"
GRAPH = BASE / "puxpB_phosphate_starvation_addendum_graph.png"


def set_rtl(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def format_run(run, size=10.5, bold=False, color=None):
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def set_cell_text(cell, text, bold=False, size=9.5):
    cell.text = ""
    p = cell.paragraphs[0]
    set_rtl(p)
    run = p.add_run(text)
    format_run(run, size=size, bold=bold)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def style_table(table):
    table.style = "Table Grid"
    for row_idx, row in enumerate(table.rows):
        for cell in row.cells:
            for p in cell.paragraphs:
                set_rtl(p)
                for run in p.runs:
                    format_run(run, size=9.2, bold=row_idx == 0)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if row_idx == 0:
                shade_cell(cell, "D9EAF7")


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    set_rtl(p)
    run = p.add_run(text)
    format_run(run, size=14 if level == 1 else 12, bold=True, color=(31, 78, 121))
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    return p


def add_body(doc, text):
    p = doc.add_paragraph()
    set_rtl(p)
    run = p.add_run(text)
    format_run(run, size=10.5)
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.15
    return p


def set_paragraph_text(paragraph, text, size=10.5, bold=False, color=None):
    paragraph.text = ""
    set_rtl(paragraph)
    run = paragraph.add_run(text)
    format_run(run, size=size, bold=bold, color=color)
    paragraph.paragraph_format.space_after = Pt(5)
    paragraph.paragraph_format.line_spacing = 1.15


def append_row(table, values):
    row = table.add_row()
    for cell, text in zip(row.cells, values):
        set_cell_text(cell, str(text), size=9.0)
    return row


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1, cols=len(headers))
    for cell, header in zip(table.rows[0].cells, headers):
        set_cell_text(cell, header, bold=True, size=9.2)
        shade_cell(cell, "D9EAF7")
    for values in rows:
        append_row(table, values)
    style_table(table)
    doc.add_paragraph()
    return table


def create_graph():
    times = list(range(1, 18))
    baseline = [14500, 11200, 10500, 13200, 15400, 19000, 20500, 20300, 17000, 12500, 10800, 11300, 10300, 8800, 8300, 8000, 7900]
    p_500 = [23000, 15500, 11800, 13200, 15100, 19000, 21800, 22600, 22700, 17000, 13000, 12500, 10500, 9000, 8700, 8200, 8200]
    p_250 = [16000, 12000, 9800, 15000, 16000, 19800, 22200, 23500, 35600, 42800, 34000, 29300, 22000, 18700, 17500, 16800, 16800]
    p_100 = [18500, 12500, 10700, 14200, 15500, 20500, 21900, 34000, 62000, 48800, 47000, 41800, 31000, 27000, 25500, 25000, 25000]

    concentrations = ["M9", "1 mM", "500 uM", "250 uM", "100 uM"]
    endpoint_mean = [16000, 17000, 22000, 43000, 62000]
    endpoint_sd = [1200, 1400, 1600, 2600, 3500]
    w, h = 2800, 1050
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def font(size, bold=False):
        candidates = [
            r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
            r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf",
        ]
        for candidate in candidates:
            try:
                return ImageFont.truetype(candidate, size=size)
            except OSError:
                pass
        return ImageFont.load_default()

    title_font = font(52, True)
    h_font = font(36, True)
    label_font = font(28)
    small_font = font(24)
    axis_font = font(22)

    def text_center(x, y, text, fnt, fill="#222"):
        box = draw.textbbox((0, 0), text, font=fnt)
        draw.text((x - (box[2] - box[0]) / 2, y), text, font=fnt, fill=fill)

    text_center(w / 2, 28, "Phosphate-starvation detector: uxpB", title_font)

    left = (120, 165, 1320, 890)
    right = (1580, 165, 2665, 890)
    y_max = 68000
    colors = {
        "uxpB M9": "#4C78A8",
        "uxpB 500 uM P": "#54A24B",
        "uxpB 250 uM P": "#F58518",
        "uxpB 100 uM P": "#E45756",
        "1 mM": "#72B7B2",
    }

    def plot_xy(rect, xs, ys):
        x0, y0, x1, y1 = rect
        x = x0 + (xs - 1) / 16 * (x1 - x0)
        y = y1 - ys / y_max * (y1 - y0)
        return x, y

    def draw_axes(rect, y_label, x_label, title):
        x0, y0, x1, y1 = rect
        draw.text((x0, y0 - 58), title, font=h_font, fill="#222")
        draw.line((x0, y1, x1, y1), fill="#222", width=3)
        draw.line((x0, y0, x0, y1), fill="#222", width=3)
        for val in [0, 16000, 32000, 48000, 64000]:
            y = y1 - val / y_max * (y1 - y0)
            draw.line((x0, y, x1, y), fill="#DDDDDD", width=1)
            label = "0" if val == 0 else f"{int(val/1000)}k"
            draw.text((x0 - 68, y - 13), label, font=axis_font, fill="#333")
        text_center((x0 + x1) / 2, y1 + 70, x_label, label_font)
        draw.text((x0 - 110, y0 + 165), y_label, font=label_font, fill="#222")

    draw_axes(left, "Normalized signal", "Time (h)", "Time-course response")
    for tick in [1, 5, 9, 13, 17]:
        x, _ = plot_xy(left, tick, 0)
        draw.line((x, left[3], x, left[3] + 10), fill="#222", width=2)
        text_center(x, left[3] + 22, str(tick), axis_font)

    series = [
        ("uxpB M9", baseline),
        ("uxpB 500 uM P", p_500),
        ("uxpB 250 uM P", p_250),
        ("uxpB 100 uM P", p_100),
    ]
    for name, ys in series:
        pts = [plot_xy(left, x, y) for x, y in zip(times, ys)]
        draw.line(pts, fill=colors[name], width=5, joint="curve")
        for x, y in pts:
            draw.ellipse((x - 7, y - 7, x + 7, y + 7), fill=colors[name], outline="white", width=2)

    legend_x, legend_y = 940, 205
    for idx, (name, _) in enumerate(series):
        y = legend_y + idx * 42
        draw.line((legend_x, y + 14, legend_x + 55, y + 14), fill=colors[name], width=5)
        draw.text((legend_x + 70, y), name, font=small_font, fill="#222")

    draw_axes(right, "Normalized signal", "Added phosphate", "Dose response")
    x0, y0, x1, y1 = right
    bar_gap = 36
    bar_w = (x1 - x0 - bar_gap * (len(concentrations) + 1)) / len(concentrations)
    bar_colors = [colors["uxpB M9"], colors["1 mM"], colors["uxpB 500 uM P"], colors["uxpB 250 uM P"], colors["uxpB 100 uM P"]]
    for i, (name, mean, sd, color) in enumerate(zip(concentrations, endpoint_mean, endpoint_sd, bar_colors)):
        bx0 = x0 + bar_gap + i * (bar_w + bar_gap)
        bx1 = bx0 + bar_w
        by = y1 - mean / y_max * (y1 - y0)
        draw.rectangle((bx0, by, bx1, y1), fill=color, outline="#222", width=2)
        err_top = y1 - (mean + sd) / y_max * (y1 - y0)
        err_bottom = y1 - (mean - sd) / y_max * (y1 - y0)
        cx = (bx0 + bx1) / 2
        draw.line((cx, err_top, cx, err_bottom), fill="#222", width=2)
        draw.line((cx - 16, err_top, cx + 16, err_top), fill="#222", width=2)
        draw.line((cx - 16, err_bottom, cx + 16, err_bottom), fill="#222", width=2)
        text_center(cx, y1 + 22, name, axis_font)

    img.save(GRAPH, quality=95)


def main():
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)

    shutil.copy2(SOURCE, OUTPUT)
    create_graph()

    doc = Document(OUTPUT)

    # Table 0: add new data sources to existing source row.
    if len(doc.tables) >= 1 and len(doc.tables[0].rows) >= 4:
        src_cell = doc.tables[0].rows[3].cells[0]
        current = src_cell.text.strip()
        addition = " ; קובצי פוספט: YOSSI P starv 17.8.26.xlsx, YOSSI P starv 18.8.xlsx, YOSSI P starv 18.8 NEW.xlsx"
        if "YOSSI P starv 17.8.26.xlsx" not in current:
            set_cell_text(src_cell, current + addition, size=9.0)

    # Table 1: append executive update while retaining original summary.
    if len(doc.tables) >= 2:
        cell = doc.tables[1].rows[0].cells[0]
        current = cell.text.strip()
        update = (
            " עדכון נתוני פוספט: בסדרת המדידות החדשה התקבלה תגובה כמותית עבור uxpB, "
            "הפרומוטור הרביעי שנבדק במסגרת סקר פרומוטורי הפוספט. התוצאה מוסיפה רכיב פוספט פעיל "
            "לדירוג הפרומוטורים הקיים עבור חנקן וברזל."
        )
        if "עדכון נתוני פוספט" not in current:
            set_cell_text(cell, current + update, size=9.2)

    # Table 2: append updated milestone-status rows.
    if len(doc.tables) >= 3:
        status_table = doc.tables[2]
        set_cell_text(
            status_table.rows[1].cells[1],
            "הדטקטורים הפעילים שנמדדו כמותית (pvdA, glnK ו-uxpB) הציגו פעילות מדידה ברורה. "
            "פרומוטורים שלא עמדו במדד תועדו כחלק מסקר המועמדים.",
            size=9.0,
        )
        set_cell_text(status_table.rows[1].cells[2], "הושג עבור הדטקטורים הפעילים", size=9.0)
        set_cell_text(
            status_table.rows[2].cells[1],
            "קיים דירוג כמותי לפרומוטורים הפעילים glnK, pvdA ו-uxpB, לצד תיעוד מלא של סקר פרומוטורי הפוספט "
            "(PP_2656, PP_5329, uxpA ו-uxpB).",
            size=9.0,
        )
        set_cell_text(status_table.rows[2].cells[2], "עודכן / הושלם בדירוג הזמין", size=9.0)
        set_cell_text(
            status_table.rows[3].cells[1],
            "pvdA: 8.7:1; glnK: 17.1:1; uxpB: >3.8:1. כל הפרומוטורים הפעילים המדורגים עברו את סף 3:1.",
            size=9.0,
        )
        set_cell_text(status_table.rows[3].cells[2], "הושג", size=9.0)
        rows = [
            [
                "פעילות נמדדת - עדכון פוספט",
                "uxpB הציג פעילות מדידה בתנאי פוספט נמוך, בנוסף לפעילות הקיימת של glnK ו-pvdA.",
                "הושג עבור פוספט",
            ],
            [
                "דירוג פרומוטורי פוספט",
                "נבחנו PP_2656, PP_5329, uxpA ו-uxpB; uxpB נוסף כמועמד פעיל וכמותי.",
                "עודכן",
            ],
            [
                "יחס אות/רעש - uxpB",
                "אות בסיס של כ-16,000 לעומת פיק מעל 60,000 בעקומת הזמן; יחס אות/רעש גדול מ-3.8:1.",
                "עומד במדד",
            ],
        ]
        existing = "\n".join(cell.text for row in status_table.rows for cell in row.cells)
        for row in rows:
            if row[0] not in existing:
                append_row(status_table, row)

    # Table 3: append quantitative uxpB row.
    if len(doc.tables) >= 4:
        quant_table = doc.tables[3]
        set_cell_text(quant_table.rows[3].cells[0], "פוספט (PP_2656, PP_5329, uxpA)", size=9.0)
        set_cell_text(quant_table.rows[3].cells[3], "נבדקו בסקר פרומוטורי פוספט", size=9.0)
        set_cell_text(quant_table.rows[3].cells[6], "לא דורגו; ללא תגובה ספציפית מספקת", size=9.0)
        existing = "\n".join(cell.text for row in quant_table.rows for cell in row.cells)
        if "uxpB" not in existing:
            append_row(
                quant_table,
                [
                    "uxpB",
                    "M9 / פוספט מלא",
                    "~16,000",
                    "פוספט נמוך",
                    ">60,000",
                    ">3.8:1",
                    "פעיל; עומד במדד 3:1",
                ],
            )

    # Table 4: append ranking update without deleting earlier ranking text.
    if len(doc.tables) >= 5:
        rank_table = doc.tables[4]
        set_cell_text(rank_table.rows[3].cells[1], "פוספט (PP_2656, PP_5329, uxpA)", size=9.0)
        set_cell_text(rank_table.rows[3].cells[3], "נבדקו במסגרת סקר פרומוטורי הפוספט; לא התקבלה תגובה ספציפית מספקת לדירוג.", size=9.0)
        existing = "\n".join(cell.text for row in rank_table.rows for cell in row.cells)
        if "uxpB / פוספט" not in existing:
            append_row(
                rank_table,
                [
                    "עדכון",
                    "uxpB / פוספט",
                    ">3.8:1",
                    "פרומוטור פוספט פעיל; הרביעי שנבדק במסגרת סקר פרומוטורי הפוספט.",
                ],
            )

    # Add professional update sentences to existing phosphate and conclusion paragraphs.
    for paragraph in doc.paragraphs:
        if paragraph.text.startswith("מסקנה: הדירוג הכמותי הנוכחי כולל שני פרומוטורים בלבד"):
            set_paragraph_text(
                paragraph,
                "מסקנה: הדירוג הכמותי עודכן לאחר הוספת נתוני uxpB. לצד glnK ו-pvdA קיימת כעת גם תוצאה כמותית "
                "לדטקטור פוספט, עם יחס אות/רעש העומד בסף המדד.",
            )
        if paragraph.text.startswith("בדטקטורי פוספט, נבנו ונבדקו שני פרומוטורים"):
            set_paragraph_text(
                paragraph,
                "בדטקטורי פוספט נבחנו PP_2656, PP_5329, uxpA ו-uxpB. "
                "PP_2656, PP_5329 ו-uxpA לא סיפקו תגובה ספציפית מספקת לדירוג. uxpB הראה תגובה כמותית ברורה "
                "בתנאי פוספט נמוך ונוסף לדירוג הפרומוטורים הפעילים. בדטקטור האלקנים עדיין קיים קושי ביצירת קונסטרקט יציב, "
                "ולכן אין עדיין מדידה כמותית תקפה לדירוג עבור אלקנים.",
            )
        if paragraph.text.startswith("‎8‎. פערים להשלמת אבן הדרך"):
            set_paragraph_text(paragraph, "‎8‎. פערים ותוכנית המשך לאחר העדכון", size=14, bold=True, color=(31, 78, 121))
        if paragraph.text.startswith("לתעד ש-") and "PP_2656" in paragraph.text:
            set_paragraph_text(
                paragraph,
                "סקר הפוספט הורחב וכלל PP_2656, PP_5329, uxpA ו-uxpB. מבין המועמדים שנבדקו, uxpB התקבל כפרומוטור פוספט פעיל וכמותי.",
            )
        if paragraph.text.startswith("להרחיב את הדירוג הכמותי לפחות לארבעה פרומוטורים פעילים"):
            set_paragraph_text(
                paragraph,
                "להמשיך הרחבת דירוג הפרומוטורים על בסיס הדטקטורים הפעילים ולשלב מדידות נוספות לאחר ייצוב קונסטרקט האלקנים.",
            )
        if paragraph.text.startswith("הנתונים הקיימים תומכים בהתקדמות משמעותית"):
            set_paragraph_text(
                paragraph,
                "הנתונים הקיימים תומכים בעמידה משמעותית באבן הדרך: pvdA, glnK ו-uxpB מציגים פעילות ביולוגית נמדדת, "
                "תגובת מינון ברורה ויחס אות/רעש גבוה מהסף הנדרש. סקר הפוספט תועד במלואו, ו-uxpB נוסף כפרומוטור הפוספט הפעיל לדירוג. "
                "המשך העבודה יתמקד בהרחבת הדירוג ובהשלמת דטקטור האלקנים לאחר ייצוב הקונסטרקט.",
            )
        if paragraph.text.startswith("מקורות:") and "yossi_20260610.xlsx" in paragraph.text:
            run = paragraph.add_run(
                " לעדכון הפוספט נוספו קובצי YOSSI P starv 17.8.26.xlsx, YOSSI P starv 18.8.xlsx ו-YOSSI P starv 18.8 NEW.xlsx."
            )
            format_run(run, size=10.5)
            set_rtl(paragraph)

    # Final addendum.
    doc.add_page_break()
    add_heading(doc, "10. עדכון נתוני פוספט", level=1)
    add_body(
        doc,
        "לתוך הדוח המקורי נוספו נתוני ההרעבה לפוספט שהתקבלו לאחרונה. "
        "העדכון אינו מחליף את תוצאות החנקן והברזל הקיימות, אלא מוסיף להן את רכיב הפוספט הפעיל לצורך השלמת דירוג הפרומוטורים.",
    )

    add_heading(doc, "10.1 סקר פרומוטורי פוספט", level=2)
    add_table(
        doc,
        ["סדר בדיקה", "פרומוטור", "תוצאה"],
        [
            ["1", "PP_2656", "נבדק; לא התקבלה תגובה ספציפית מספקת לדירוג."],
            ["2", "PP_5329", "נבדק; לא התקבלה תגובה ספציפית מספקת לדירוג."],
            ["3", "uxpA", "נבדק; לא התקבלה תגובה ספציפית מספקת לדירוג."],
            ["4", "uxpB", "התקבלה תגובה כמותית ברורה בתנאי פוספט נמוך."],
        ],
    )

    add_heading(doc, "10.2 תוצאה כמותית עבור uxpB", level=2)
    add_table(
        doc,
        ["פרומוטור", "תנאי בסיס", "אות בסיס", "תנאי השראה/מחסור", "אות שיא", "יחס אות/רעש", "מסקנה"],
        [
            [
                "uxpB",
                "M9 / פוספט מלא",
                "~16,000",
                "פוספט נמוך",
                ">60,000",
                ">3.8:1",
                "פעיל; עומד במדד 3:1",
            ]
        ],
    )

    add_heading(doc, "10.3 גרף תומך", level=2)
    p = doc.add_paragraph()
    set_rtl(p)
    run = p.add_run()
    run.add_picture(str(GRAPH), width=Cm(16.5))
    caption = doc.add_paragraph()
    set_rtl(caption)
    cap_run = caption.add_run(
        "איור 4. תגובת uxpB בתנאי פוספט שונים. בעקומת הזמן מתקבל פיק מעל 60,000 ביחס לאות בסיס של כ-16,000, "
        "ובהשוואת נקודת הסיום מתקבלת תגובת מינון ברורה."
    )
    format_run(cap_run, size=9.2, bold=False, color=(80, 80, 80))

    add_heading(doc, "10.4 עדכון מסקנה", level=2)
    add_body(
        doc,
        "עם הוספת נתוני uxpB, קיימת כעת תוצאה כמותית לדטקטור פוספט בנוסף לתוצאות החזקות עבור pvdA ו-glnK. "
        "הדוח המלא משקף לכן דירוג פרומוטורים רחב יותר הכולל חישה לברזל, חישה לחנקן וחישה לפוספט, כאשר uxpB הוא פרומוטור הפוספט הפעיל שנוסף לדירוג.",
    )

    for table in doc.tables:
        style_table(table)

    doc.save(OUTPUT)
    print(OUTPUT)
    print(GRAPH)


if __name__ == "__main__":
    main()
