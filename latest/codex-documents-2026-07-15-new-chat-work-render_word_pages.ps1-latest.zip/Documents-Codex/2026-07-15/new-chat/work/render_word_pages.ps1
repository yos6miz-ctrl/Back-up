param(
    [Parameter(Mandatory=$true)][string]$DocPath,
    [Parameter(Mandatory=$true)][string]$OutputDir
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$resolvedDoc = (Resolve-Path -LiteralPath $DocPath).Path
$resolvedOut = [System.IO.Path]::GetFullPath($OutputDir)
New-Item -ItemType Directory -Path $resolvedOut -Force | Out-Null

$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($resolvedDoc, $false, $true)
    $doc.Repaginate()
    $totalPages = $doc.ComputeStatistics(2)
    for ($pageNo = 1; $pageNo -le $totalPages; $pageNo++) {
        $range = $doc.GoTo(1, 1, $pageNo)
        $range.Select()
        $pageRange = $word.Selection.Bookmarks.Item('\Page').Range
        $emfPath = Join-Path $resolvedOut ("page-{0:D2}.emf" -f $pageNo)
        [System.IO.File]::WriteAllBytes($emfPath, [byte[]]$pageRange.EnhMetaFileBits)
        $image = [System.Drawing.Image]::FromFile($emfPath)
        try {
            $pngPath = Join-Path $resolvedOut ("page-{0:D2}.png" -f $pageNo)
            $image.Save($pngPath, [System.Drawing.Imaging.ImageFormat]::Png)
        }
        finally {
            $image.Dispose()
            Remove-Item -LiteralPath $emfPath -Force
        }
    }
    Write-Output "TOTAL_PAGES=$totalPages"
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
