from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


BASE = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
SOURCE = BASE / "03_חישה ודטקטורים" / "YOSSI  P starv  18.8.xlsx"
MEDIA_OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\docx_media_extract2\image4.png")
GRAPH_OUT = BASE / "03_חישה ודטקטורים" / "גרפים" / "puxpB_phosphate_starvation_report_graph.png"


def font(size, bold=False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def parse_data():
    df = pd.read_excel(SOURCE, sheet_name="Sheet1", header=None)
    conditions = [str(x).strip() for x in df.iloc[0, 1:12].tolist()]
    records = []
    for t in range(18):
        g_start = t * 8
        f_start = 144 + t * 8
        growth = df.iloc[g_start + 1 : g_start + 7, 1:12].astype(float).to_numpy()
        fluorescence = df.iloc[f_start + 1 : f_start + 7, 1:12].astype(float).to_numpy()
        growth_control = growth[:, -1]
        fluorescence_control = fluorescence[:, -1]
        for idx, condition in enumerate(conditions[:-1]):
            normalized = (fluorescence[:, idx] - fluorescence_control) / (growth[:, idx] - growth_control)
            records.append(
                {
                    "time": t,
                    "condition": condition,
                    "mean": float(np.nanmean(normalized)),
                    "sd": float(np.nanstd(normalized, ddof=1)),
                    "n": int(np.sum(np.isfinite(normalized))),
                }
            )
    data = pd.DataFrame(records)
    puxpb = data[data["condition"].str.startswith("puxpB")].copy()
    baseline = puxpb[puxpb["condition"] == "puxpB M9"][["time", "mean"]].rename(columns={"mean": "baseline_mean"})
    puxpb = puxpb.merge(baseline, on="time", how="left")
    puxpb["fold"] = puxpb["mean"] / puxpb["baseline_mean"]
    best = puxpb[puxpb["condition"] != "puxpB M9"].sort_values("fold", ascending=False).iloc[0]
    return puxpb, int(best["time"])


def fmt_condition(label):
    if label == "puxpB M9":
        return "34mM"
    return label.replace("puxpB ", "").replace("uM", " uM")


def draw_rotated_text(base, xy, text, angle, font_obj, fill):
    dummy = Image.new("RGBA", (10, 10), (255, 255, 255, 0))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), text, font=font_obj)
    txt = Image.new("RGBA", (bbox[2] - bbox[0] + 10, bbox[3] - bbox[1] + 10), (255, 255, 255, 0))
    td = ImageDraw.Draw(txt)
    td.text((5, 5), text, font=font_obj, fill=fill)
    rot = txt.rotate(angle, expand=True)
    base.alpha_composite(rot, xy)


def draw_chart():
    data, best_time = parse_data()
    colors = {
        "puxpB M9": "#4E79A7",
        "puxpB 1mM": "#59A14F",
        "puxpB 500uM": "#F28E2B",
        "puxpB 250uM": "#E15759",
        "puxpB 100uM": "#B07AA1",
    }
    img = Image.new("RGBA", (1800, 960), "white")
    draw = ImageDraw.Draw(img)
    f_title = font(34, True)
    f_axis = font(24, True)
    f_label = font(21)
    f_small = font(18)
    f_legend = font(19)
    f_note = font(17)
    dark = "#222222"
    grid = "#D9DEE7"
    axis = "#222222"

    draw.text((60, 34), "Phosphate-starvation detector: puxpB", font=f_title, fill=dark)
    draw.text((60, 78), "Normalized GFP/OD after blank subtraction; mean ± SD, n=6", font=f_label, fill="#555555")

    # Left panel: time course.
    lx0, ly0, lx1, ly1 = 120, 170, 1040, 735
    draw.text((lx0 + 250, 125), "Time-course response", font=f_axis, fill=dark)
    y_max = 65000
    for y in range(0, y_max + 1, 10000):
        py = ly1 - (y / y_max) * (ly1 - ly0)
        draw.line((lx0, py, lx1, py), fill=grid, width=2)
        draw.text((lx0 - 80, py - 12), f"{y//1000}k" if y else "0", font=f_small, fill="#444444")
    draw.line((lx0, ly0, lx0, ly1), fill=axis, width=3)
    draw.line((lx0, ly1, lx1, ly1), fill=axis, width=3)
    for t in range(18):
        px = lx0 + (t / 17) * (lx1 - lx0)
        if t % 2 == 0:
            draw.line((px, ly1, px, ly1 + 8), fill=axis, width=2)
            draw.text((px - 7, ly1 + 14), str(t), font=f_small, fill="#444444")
    draw.text((lx0 + 375, ly1 + 48), "Time point", font=f_label, fill=dark)
    draw_rotated_text(img, (20, ly0 + 150), "Normalized signal", 270, f_label, dark)

    for cond, c in colors.items():
        sub = data[data["condition"] == cond].sort_values("time")
        pts = []
        for _, row in sub.iterrows():
            x = lx0 + (row["time"] / 17) * (lx1 - lx0)
            y = ly1 - (row["mean"] / y_max) * (ly1 - ly0)
            pts.append((x, y))
        for a, b in zip(pts, pts[1:]):
            draw.line((a[0], a[1], b[0], b[1]), fill=c, width=5)
        for i, (_, row) in enumerate(sub.iterrows()):
            x, y = pts[i]
            draw.ellipse((x - 5, y - 5, x + 5, y + 5), fill=c, outline="white", width=2)
            if int(row["time"]) in {9, 11, 13, 17}:
                err = (row["sd"] / y_max) * (ly1 - ly0)
                draw.line((x, y - err, x, y + err), fill=c, width=2)
                draw.line((x - 9, y - err, x + 9, y - err), fill=c, width=2)
                draw.line((x - 9, y + err, x + 9, y + err), fill=c, width=2)

    legend_x, legend_y = 720, 180
    for idx, (cond, c) in enumerate(colors.items()):
        y = legend_y + idx * 30
        draw.line((legend_x, y + 10, legend_x + 35, y + 10), fill=c, width=5)
        draw.text((legend_x + 45, y), fmt_condition(cond), font=f_legend, fill=dark)

    # Right panel: dose response at best fold-change time point.
    rx0, ry0, rx1, ry1 = 1160, 170, 1730, 735
    draw.text((rx0 + 75, 125), f"Dose response at time point {best_time}", font=f_axis, fill=dark)
    best_sub = data[data["time"] == best_time].set_index("condition").loc[list(colors.keys())].reset_index()
    bar_ymax = 55000
    for y in range(0, bar_ymax + 1, 10000):
        py = ry1 - (y / bar_ymax) * (ry1 - ry0)
        draw.line((rx0, py, rx1, py), fill=grid, width=2)
        draw.text((rx0 - 75, py - 12), f"{y//1000}k" if y else "0", font=f_small, fill="#444444")
    draw.line((rx0, ry0, rx0, ry1), fill=axis, width=3)
    draw.line((rx0, ry1, rx1, ry1), fill=axis, width=3)
    n = len(best_sub)
    slot = (rx1 - rx0) / n
    for i, row in best_sub.iterrows():
        c = colors[row["condition"]]
        x_center = rx0 + slot * (i + 0.5)
        bar_w = slot * 0.62
        y = ry1 - (row["mean"] / bar_ymax) * (ry1 - ry0)
        draw.rectangle((x_center - bar_w / 2, y, x_center + bar_w / 2, ry1), fill=c)
        err = (row["sd"] / bar_ymax) * (ry1 - ry0)
        draw.line((x_center, y - err, x_center, y + err), fill=dark, width=3)
        draw.line((x_center - 13, y - err, x_center + 13, y - err), fill=dark, width=3)
        draw.line((x_center - 13, y + err, x_center + 13, y + err), fill=dark, width=3)
        label = fmt_condition(row["condition"])
        tw = draw.textlength(label, font=f_small)
        draw.text((x_center - tw / 2, ry1 + 14), label, font=f_small, fill="#444444")
    draw.text((rx0 + 185, ry1 + 50), "Added phosphate", font=f_label, fill=dark)
    draw_rotated_text(img, (1070, ry0 + 165), "Normalized signal", 270, f_label, dark)

    m9 = best_sub[best_sub["condition"] == "puxpB M9"].iloc[0]
    u100 = best_sub[best_sub["condition"] == "puxpB 100uM"].iloc[0]
    ratio = u100["mean"] / m9["mean"]
    note = f"Peak S/N, 100 uM vs 34mM: {ratio:.1f}:1"
    values = f"{u100['mean']:,.0f} ± {u100['sd']:,.0f} vs {m9['mean']:,.0f}"
    draw.text((rx0, 830), note, font=f_note, fill="#444444")
    draw.text((rx0, 858), values, font=f_note, fill="#444444")

    img = img.convert("RGB")
    MEDIA_OUT.parent.mkdir(parents=True, exist_ok=True)
    GRAPH_OUT.parent.mkdir(parents=True, exist_ok=True)
    img.save(MEDIA_OUT, quality=95)
    img.save(GRAPH_OUT, quality=95)
    print(MEDIA_OUT)
    print(GRAPH_OUT)


if __name__ == "__main__":
    draw_chart()
