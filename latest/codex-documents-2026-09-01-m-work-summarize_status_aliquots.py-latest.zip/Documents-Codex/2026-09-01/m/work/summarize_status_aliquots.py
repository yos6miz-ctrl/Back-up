import json
from pathlib import Path

p = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\status_aliquot_analysis.json")
d = json.loads(p.read_text(encoding="utf-8"))

print("VERSIONS")
for v in d["versions"]:
    ids = [f'{x["A"]}|{x["B"]}' if x["B"] else x["A"] for x in v["not_tested"]]
    parent = Path(v["path"]).parent.name
    print(parent, len(ids), "; ".join(ids))
    for s in v["sheets"]:
        print("  ", s["name"], s["dimensions"], "C:", json.dumps(s["status_C"], ensure_ascii=False), "E:", json.dumps(s["decision_E"], ensure_ascii=False))

print("\nCURRENT FLAGGED")
for x in d["current"]["rows"]:
    print(x["sheet"], x["row"], x["A"], "|", x["B"], "status=", x["status"], "status_fill=", x["status_fill"], "yellow=", ",".join(x["yellow_measurements"]))

print("\nCT606")
ct = d["current"]["ct606"]
print(ct["sheet"], ct["row"])
for cell, rec in ct["fonts"].items():
    print(cell, json.dumps(rec, ensure_ascii=False))

print("\nALIQUOT FILES")
for f in d["aliquot_files"]:
    print("FILE", f["path"])
    for s in f["sheets"]:
        print("SHEET", s["name"], s["dimensions"])
        for i, row in enumerate(s["first_rows"], start=1):
            print(i, " | ".join(row))
        if s["ct606"]:
            print("CT606", json.dumps(s["ct606"], ensure_ascii=False))
