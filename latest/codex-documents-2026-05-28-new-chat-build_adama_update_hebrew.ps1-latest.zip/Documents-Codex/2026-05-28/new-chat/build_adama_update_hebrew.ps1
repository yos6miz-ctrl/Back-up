$ErrorActionPreference = "Stop"

$outDir = "C:\Users\Popovtzer lab\.codex\אדמה ירוקה"
$outFile = Join-Path $outDir "אדמה ירוקה - מצגת עדכון קצרה.pptx"
$chartDir = "C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\starvation_chart_exports"
$endpointGraph = Join-Path $chartDir "normalized_expression_13_3h.png"
$pvdGraph = Join-Path $chartDir "pvdA_Fe_response.png"
$glnGraph = Join-Path $chartDir "glnK_N_response.png"
$upoGel = "C:\Users\Popovtzer lab\.codex\אדמה ירוקה\UPO\UPO19 gel.jpeg"

$ppLayoutBlank = 12
$msoTextOrientationHorizontal = 1
$msoTrue = -1
$msoFalse = 0

$C = @{
  Ink = 0x1A1A1A
  Muted = 0x666666
  Green = 0x2E6B3F
  Blue = 0x8A6F1F
  Orange = 0x2B6BFF
  PaleGreen = 0xEFF7EF
  PaleBlue = 0xF7F1E8
  PaleGray = 0xF4F4F4
  White = 0xFFFFFF
  Rule = 0xC8C8C8
}

function Add-Text {
  param(
    $Slide,
    [string]$Text,
    [double]$X,
    [double]$Y,
    [double]$W,
    [double]$H,
    [double]$Size = 18,
    [bool]$Bold = $false,
    [int]$Color = 0x1A1A1A,
    [string]$Align = "Right"
  )
  $shape = $Slide.Shapes.AddTextbox($msoTextOrientationHorizontal, $X, $Y, $W, $H)
  $shape.TextFrame2.TextRange.Text = $Text
  $shape.TextFrame2.MarginLeft = 4
  $shape.TextFrame2.MarginRight = 4
  $shape.TextFrame2.MarginTop = 3
  $shape.TextFrame2.MarginBottom = 3
  $shape.TextFrame2.WordWrap = $msoTrue
  $shape.TextFrame2.TextRange.Font.Name = "Arial"
  $shape.TextFrame2.TextRange.Font.Size = $Size
  $shape.TextFrame2.TextRange.Font.Bold = if ($Bold) { $msoTrue } else { $msoFalse }
  $shape.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = $Color
  switch ($Align) {
    "Center" { $shape.TextFrame2.TextRange.ParagraphFormat.Alignment = 2 }
    "Left" { $shape.TextFrame2.TextRange.ParagraphFormat.Alignment = 1 }
    default { $shape.TextFrame2.TextRange.ParagraphFormat.Alignment = 3 }
  }
  return $shape
}

function Add-Panel {
  param($Slide, [double]$X, [double]$Y, [double]$W, [double]$H, [int]$Fill, [int]$Line = 0xD8D8D8)
  $shape = $Slide.Shapes.AddShape(1, $X, $Y, $W, $H)
  $shape.Fill.ForeColor.RGB = $Fill
  $shape.Line.ForeColor.RGB = $Line
  $shape.Line.Weight = 0.75
  return $shape
}

function Add-Header {
  param($Slide, [string]$Title, [string]$Subtitle = "")
  Add-Text $Slide "אדמה ירוקה | עדכון תקופתי" 42 22 360 24 11 $true $C.Muted "Left" | Out-Null
  Add-Text $Slide $Title 340 50 570 50 28 $true $C.Ink "Right" | Out-Null
  if ($Subtitle.Length -gt 0) {
    Add-Text $Slide $Subtitle 210 96 700 28 13 $false $C.Muted "Right" | Out-Null
  }
  $rule = $Slide.Shapes.AddShape(1, 42, 132, 876, 1.2)
  $rule.Fill.ForeColor.RGB = $C.Rule
  $rule.Line.ForeColor.RGB = $C.Rule
}

function Add-BulletList {
  param($Slide, [string[]]$Items, [double]$X, [double]$Y, [double]$W, [double]$LineH = 34, [int]$Color = 0x1A1A1A)
  $yNow = $Y
  foreach ($item in $Items) {
    Add-Text $Slide $item $X $yNow ($W - 24) 30 15 $false $Color "Right" | Out-Null
    $dot = $Slide.Shapes.AddShape(9, ($X + $W - 12), ($yNow + 10), 7, 7)
    $dot.Fill.ForeColor.RGB = $Color
    $dot.Line.ForeColor.RGB = $Color
    $yNow += $LineH
  }
}

function Add-Card {
  param($Slide, [string]$Title, [string]$Body, [double]$X, [double]$Y, [double]$W, [double]$H, [int]$Accent = 0x2E6B3F)
  Add-Panel $Slide $X $Y $W $H $C.PaleGray | Out-Null
  $bar = $Slide.Shapes.AddShape(1, ($X + $W - 6), $Y, 6, $H)
  $bar.Fill.ForeColor.RGB = $Accent
  $bar.Line.ForeColor.RGB = $Accent
  Add-Text $Slide $Title ($X + 18) ($Y + 16) ($W - 38) 26 17 $true $Accent "Right" | Out-Null
  Add-Text $Slide $Body ($X + 18) ($Y + 48) ($W - 38) ($H - 58) 13 $false $C.Muted "Right" | Out-Null
}

function Add-StatusRow {
  param($Slide, [string]$Task, [string]$Status, [string]$Next, [double]$Y, [int]$Accent)
  Add-Panel $Slide 64 $Y 832 48 $C.White | Out-Null
  $mark = $Slide.Shapes.AddShape(1, 888, $Y, 8, 48)
  $mark.Fill.ForeColor.RGB = $Accent
  $mark.Line.ForeColor.RGB = $Accent
  Add-Text $Slide $Task 680 ($Y + 9) 195 28 13.5 $true $C.Ink "Right" | Out-Null
  Add-Text $Slide $Status 365 ($Y + 9) 285 28 13 $false $C.Muted "Right" | Out-Null
  Add-Text $Slide $Next 84 ($Y + 9) 250 28 13 $false $C.Muted "Right" | Out-Null
}

$ppt = $null
$presentation = $null
try {
  $ppt = New-Object -ComObject PowerPoint.Application
  $ppt.Visible = $msoTrue
  $presentation = $ppt.Presentations.Add()
  $presentation.PageSetup.SlideWidth = 960
  $presentation.PageSetup.SlideHeight = 540

  # Slide 1
  $s = $presentation.Slides.Add(1, $ppLayoutBlank)
  $s.Background.Fill.ForeColor.RGB = $C.White
  Add-Panel $s 0 0 960 540 0xF7FAF5 0xF7FAF5 | Out-Null
  $accent = $s.Shapes.AddShape(1, 760, 0, 200, 540)
  $accent.Fill.ForeColor.RGB = 0xE4F1E3
  $accent.Line.ForeColor.RGB = 0xE4F1E3
  Add-Text $s "אדמה ירוקה" 420 140 430 60 38 $true $C.Green "Right" | Out-Null
  Add-Text $s "מצגת עדכון קצרה" 430 205 420 42 25 $true $C.Ink "Right" | Out-Null
  Add-Text $s "סיכום ביצוע, תוצרים, אבני דרך ותוכנית לחציון שני" 300 260 550 40 16 $false $C.Muted "Right" | Out-Null
  Add-Text $s "מעבדת בנין | בר-אילן" 60 450 300 26 14 $true $C.Muted "Left" | Out-Null

  # Slide 2
  $s = $presentation.Slides.Add(2, $ppLayoutBlank)
  Add-Header $s "סיכום ביצוע" "תמונת מצב קצרה של שתי זרועות העבודה"
  Add-Card $s "קבוצה 1 | UPO19" "נבנה רצף UPO19 מותאם קודונים לפסאודומונס פוטידה, עם אות הפרשה ו-His-tag. הקונסטרקטים הוחדרו לשני פלסמידים, ובוצעו בדיקות ראשוניות לביטוי וללוקליזציה של החלבון." 498 180 380 170 $C.Green
  Add-Card $s "קבוצה 3 | דטקטורים" "דטקטורי הרעבה לחנקן ולברזל פועלים ומציגים תגובת מינון ברורה. דטקטור הפוספט עדיין בפיתוח, ודטקטור האלקנים נמצא בשלבי בנייה מתקדמים." 82 180 380 170 $C.Blue
  Add-Panel $s 82 385 796 64 0xEFF7EF | Out-Null
  Add-Text $s "שורה תחתונה: יש תוצרים פעילים להעברה לשותפים במדידות, לצד רכיבים שנמצאים עדיין באופטימיזציה ובאימות." 110 402 735 32 16 $true $C.Green "Right" | Out-Null

  # Slide 3
  $s = $presentation.Slides.Add(3, $ppLayoutBlank)
  Add-Header $s "תוצרים עיקריים לתקופה" "מה קיים כיום ויכול לשמש להמשך העבודה"
  Add-Card $s "דטקטור חנקן" "תגובה חזקה וברורה להורדת ריכוזי חנקן; מתאים להמשך העברה לפורמטי קריאה נוספים." 658 172 220 132 $C.Green
  Add-Card $s "דטקטור ברזל" "תגובה תלויה בריכוז ברזל, עם אות גבוה בתנאי מחסור בברזל." 390 172 220 132 $C.Blue
  Add-Card $s "מערכת UPO19" "קונסטרקטים מותאמים לפוטידה, כולל אות הפרשה ותג ניקוי; אות חלבון זוהה בבדיקות Western." 122 172 220 132 $C.Green
  Add-Card $s "פורמטי מדידה" "המערכות העובדות מועברות למדידה אמפרומטרית ולמערכת לוציפראז עבור שותפי הפרויקט." 498 330 380 118 $C.Blue
  Add-Card $s "דטקטור אלקנים" "מערכת מבוססת רצפטור וגן דיווח נמצאת בבנייה וצפויה להיות מוכנה בקרוב לבדיקות פונקציונליות." 82 330 380 118 $C.Orange

  # Slide 4
  $s = $presentation.Slides.Add(4, $ppLayoutBlank)
  Add-Header $s "עמידה ביעדים ואבני דרך" "סטטוס לפי רכיבי העבודה המרכזיים"
  Add-Text $s "משימה" 690 158 180 20 12 $true $C.Muted "Right" | Out-Null
  Add-Text $s "סטטוס" 400 158 240 20 12 $true $C.Muted "Right" | Out-Null
  Add-Text $s "המשך נדרש" 110 158 220 20 12 $true $C.Muted "Right" | Out-Null
  Add-StatusRow $s "UPO19 מותאם קודונים" "נבנה בשני וקטורים; בוצעו בדיקות ביטוי ראשוניות" "אימות ריצוף, לוקליזציה ופעילות" 186 $C.Green
  Add-StatusRow $s "דטקטורי חנקן וברזל" "הושגה תגובת מינון ברורה וניתנת לשחזור" "הרחבת מדידות בפורמטים החדשים" 246 $C.Blue
  Add-StatusRow $s "דטקטור פוספט" "שני פרומוטורים לא היו ספציפיים; קונסטרקט שלישי בבנייה" "סיום בנייה ובדיקת ספציפיות" 306 $C.Orange
  Add-StatusRow $s "דטקטור אלקנים" "רכיבי הרצפטור והדיווח בבנייה" "השלמת קונסטרקט ובדיקת תגובה" 366 $C.Orange
  Add-StatusRow $s "העברה לשותפים" "החלה העברה לאמפרומטריה וללוציפראז" "סטנדרטיזציה, SOP ותיקוף בין-מעבדתי" 426 $C.Blue

  # Slide 5
  $s = $presentation.Slides.Add(5, $ppLayoutBlank)
  Add-Header $s "שיתופי פעולה והעברת ידע" "מה מועבר, למי, ולאיזו מטרה"
  Add-Card $s "מעבדת הדר" "העברת הדטקטורים העובדים לפורמט אמפרומטרי, כדי להתאים את המדידה למערכת אלקטרוכימית." 590 176 290 142 $C.Blue
  Add-Card $s "מעבדת ראמז" "בניית סט מקביל עם אנזים לומינסנטי, לטובת מערכת קריאה מבוססת לוציפראז." 335 176 220 142 $C.Green
  Add-Card $s "ליאנט / UPO" "בחירת UPO19, קבלת זנים, ריצוף פלסמידים והמשך עבודה מול רצף מותאם לפוטידה." 82 176 220 142 $C.Green
  Add-Panel $s 82 360 798 68 0xF7F1E8 | Out-Null
  Add-Text $s "העברת הידע מתמקדת לא רק בזנים עצמם, אלא גם בפרוטוקולי מדידה, תנאי אינדוקציה, פורמט הדיווח וקריטריונים להצלחה." 118 379 728 30 15.5 $true $C.Ink "Right" | Out-Null

  # Slide 6
  $s = $presentation.Slides.Add(6, $ppLayoutBlank)
  Add-Header $s "שינויים ועדכונים בתוכנית העבודה" "התאמות שבוצעו בעקבות תוצאות הניסוי"
  Add-BulletList $s @(
    "רצפי אנזימים מקוריים נפסלו לביטוי בפוטידה בגלל GC נמוך; נבחר פתרון של התאמת קודונים.",
    "ל-UPO19 נוספו אות הפרשה ו-His-tag כדי לאפשר לוקליזציה, ניקוי ובדיקת פעילות בהמשך.",
    "בדטקטור הפוספט שני פרומוטורים לא נתנו תגובה ספציפית; לכן נבנה קונסטרקט שלישי.",
    "בדטקטור האלקנים העבודה מורכבת יותר כי הגנים אינם נטיביים לפוטידה ונמצאים על פלסמידים סביבתיים.",
    "הדגש מועבר ממדידות GFP בלבד לפורמטים ישימים יותר: אמפרומטריה ולוציפראז."
  ) 95 182 760 43 $C.Ink

  # Slide 7
  $s = $presentation.Slides.Add(7, $ppLayoutBlank)
  Add-Header $s "תוכנית כללית לחציון שני" "צעדים מרכזיים להמשך"
  Add-Card $s "1. UPO19" "אימות ריצוף, חזרה על Western לפי פרקציות, אופטימיזציה של הפרשה, ניקוי His-tag ושליחה לבדיקת פעילות." 590 174 290 170 $C.Green
  Add-Card $s "2. דטקטורי הרעבה" "השלמת דטקטור פוספט שלישי, הרחבת מדידות לחנקן/ברזל והעברה מסודרת לפורמטי הקריאה של השותפים." 335 174 220 170 $C.Blue
  Add-Card $s "3. אלקנים" "השלמת קונסטרקט רצפטור-גן דיווח, הכנסת המערכת לפוטידה ובדיקת תגובה לאלקנים." 82 174 220 170 $C.Orange
  Add-Panel $s 82 382 798 70 0xEFF7EF | Out-Null
  Add-Text $s "תוצר יעד לחציון: סט זנים וקונסטרקטים מתועד, נתוני תיקוף ראשוניים, ופרוטוקול העברה לשותפים למדידה חוזרת." 120 402 720 28 16 $true $C.Green "Right" | Out-Null

  # Slide 8
  $s = $presentation.Slides.Add(8, $ppLayoutBlank)
  Add-Header $s "נספח נתונים קצר" "דוגמה לתגובת הדטקטורים הפעילים"
  if (Test-Path $pvdGraph) { $s.Shapes.AddPicture($pvdGraph, $false, $true, 64, 174, 402, 190) | Out-Null }
  if (Test-Path $glnGraph) { $s.Shapes.AddPicture($glnGraph, $false, $true, 494, 174, 402, 190) | Out-Null }
  if (Test-Path $endpointGraph) { $s.Shapes.AddPicture($endpointGraph, $false, $true, 222, 378, 516, 122) | Out-Null }
  Add-Text $s "הגרפים מוצגים כנספח תומך בלבד; ניתן להסיר שקופית זו אם נדרשת מצגת מילולית קצרה בלבד." 60 504 835 22 10.5 $false $C.Muted "Center" | Out-Null

  $presentation.SaveAs($outFile)
  Write-Output "saved=$outFile"
} finally {
  if ($presentation) { $presentation.Close() | Out-Null }
  if ($ppt) { $ppt.Quit() | Out-Null }
}
