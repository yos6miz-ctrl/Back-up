from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BASE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-06-03\your-task-is-to-help-me")
OUT = BASE / "outputs" / "filtered_mock_stool_and_1x_m9_recipes.docx"


def set_font(run, size=11, bold=False, color=None):
    run.font.name = "Calibri"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def set_cell_text(cell, text, bold=False, center=False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(str(text))
    set_font(run, size=9.5, bold=bold)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_table_geometry(table, widths_in):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for row in table.rows:
        for i, width in enumerate(widths_in):
            row.cells[i].width = Inches(width)

    tbl = table._tbl
    tbl_pr = tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), "9360")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:type"), "dxa")
    tbl_ind.set(qn("w:w"), "120")

    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "D9E2F3")


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    for i, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], header, bold=True, center=True)
        shade_cell(table.rows[0].cells[i], "E8EEF5")
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            set_cell_text(cells[i], value, center=i in (1, 2, 4))
    set_table_geometry(table, widths)
    return table


def add_note(doc, label, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(label)
    set_font(r, bold=True, color="1F4D78")
    r = p.add_run(text)
    set_font(r)


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.25
    set_font(p.runs[0] if p.runs else p.add_run(text))
    if len(p.runs) == 1 and not p.text:
        p.runs[0].text = text


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    styles["Normal"].font.name = "Calibri"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    styles["Normal"].font.size = Pt(11)
    styles["Normal"].paragraph_format.space_after = Pt(6)
    styles["Normal"].paragraph_format.line_spacing = 1.25

    for style_name, size, before, after, color in [
        ("Heading 1", 16, 18, 10, "2E74B5"),
        ("Heading 2", 13, 14, 7, "2E74B5"),
        ("Heading 3", 12, 10, 5, "1F4D78"),
    ]:
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.line_spacing = 1.25

    title = doc.add_paragraph()
    title.paragraph_format.space_after = Pt(3)
    r = title.add_run("Filtered Mock Stool Extract and 1x M9 Recipes")
    set_font(r, size=18, bold=True, color="1F4D78")

    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(8)
    r = subtitle.add_run("Bench recipe document")
    set_font(r, size=10, color="555555")

    doc.add_heading("1. Filtered Mock Stool Extract, 10 mL", level=1)
    mock_rows = [
        ["1", "DDW / sterile water", "-", "-", "-", "Start with ~8 mL"],
        ["2", "Sodium chloride", "38", "4", "100 mM", "58.4 mg"],
        ["3", "KH2PO4", "32", "4", "5 mM", "6.8 mg"],
        ["4", "K2HPO4", "34", "4", "5 mM", "8.7 mg"],
        ["5", "Proteose Peptone no. 3", "Media 20", "11", "1 mg/mL", "10 mg"],
        ["6", "Bile salts", "305", "5", "0.05 mg/mL", "0.5 mg"],
        ["7", "Mucin from porcine stomach", "149", "Refrigerator", "3 mg/mL", "30 mg"],
        ["8", "DDW / sterile water", "-", "-", "-", "Bring to 10 mL"],
    ]
    add_table(
        doc,
        ["Order", "Component", "Item no.", "Shelf", "Final conc.", "Amount"],
        mock_rows,
        [0.55, 2.15, 0.85, 1.05, 1.0, 0.9],
    )
    add_note(
        doc,
        "Handling: ",
        "Mix/rotate until mucin is hydrated and evenly cloudy. Do not autoclave. Filter the same way as the real stool extract and use the filtrate.",
    )
    add_note(
        doc,
        "Freezing: ",
        "Safe to freeze after filtration. Aliquot, freeze at -20 C, avoid repeated freeze-thaw cycles, and mix well after thawing.",
    )

    doc.add_heading("2. 1x M9 Medium, 10 mL", level=1)
    m9_rows = [
        ["1", "M9, no carbon", "5x", "1x", "2.0 mL"],
        ["2", "Glycerol", "4%", "0.4%", "1.0 mL"],
        ["3", "Glucose", "4%", "0.05%", "125 uL"],
        ["4", "Mg", "1000x", "1 mM", "10 uL"],
        ["5", "Ca", "1000x", "1 mM", "10 uL"],
        ["6", "FeSO4", "1000x", "10 uM", "10 uL"],
        ["7", "Sterile water", "-", "-", "6.845 mL"],
    ]
    add_table(
        doc,
        ["Order", "Component", "Stock", "Final conc.", "Add for 10 mL"],
        m9_rows,
        [0.6, 2.2, 1.1, 1.2, 1.4],
    )
    add_note(doc, "Note: ", "No CA. Add FeSO4 fresh and last if possible.")

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("Recipes generated August 2026")
    set_font(r, size=8, color="555555")

    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
