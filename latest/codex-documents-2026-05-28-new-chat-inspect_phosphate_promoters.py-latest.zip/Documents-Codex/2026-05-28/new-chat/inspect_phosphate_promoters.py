from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook


TERMS = (
    "phosphate",
    "phosph",
    "pho",
    "pst",
    "ppk",
    "pit",
    "phn",
    "זרחן",
    "פוספט",
    "promoter",
    "פרומוטור",
)


def printable(value) -> str:
    return str(value).encode("unicode_escape").decode("ascii")


def main() -> None:
    project_name = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
    root = Path.home() / ".codex" / project_name
    for xlsx in sorted(root.rglob("*.xlsx")):
        try:
            wb = load_workbook(xlsx, data_only=False, read_only=True)
        except Exception as exc:
            print("ERR", printable(xlsx), exc)
            continue

        file_hit = False
        sheet_outputs: list[tuple[str, list[str]]] = []
        for ws in wb.worksheets:
            rows: list[str] = []
            for row in ws.iter_rows():
                vals = [cell.value for cell in row if cell.value is not None]
                if not vals:
                    continue
                joined = " | ".join(str(v) for v in vals)
                lower = joined.lower()
                if any(term in lower for term in TERMS):
                    rows.append(printable(joined))
            if rows:
                file_hit = True
                sheet_outputs.append((ws.title, rows[:80]))

        if file_hit:
            print("\nFILE", printable(xlsx))
            print("SHEETS", [printable(name) for name in wb.sheetnames])
            for title, rows in sheet_outputs:
                print(" SHEET", printable(title))
                for row in rows:
                    print("  ", row)


if __name__ == "__main__":
    main()
