import {
  Presentation,
  PresentationFile,
  column,
  row,
  grid,
  panel,
  text,
  image,
  chart,
  shape,
  rule,
  fill,
  hug,
  fixed,
  wrap,
  fr,
  auto,
} from "@oai/artifact-tool";
import { writeFile, mkdir, copyFile, readFile } from "node:fs/promises";

const presentation = Presentation.create({
  slideSize: { width: 1920, height: 1080 },
});

const OUT_DIR = "C:/Users/Popovtzer lab/.codex/אדמה ירוקה";
const WORK_OUT = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat";
const PPTX_NAME = "טמפלייט - מצגת ממולאת.pptx";
const PREVIEW_DIR = `${WORK_OUT}/adama_deck_previews`;
const plasmidMap = `${WORK_OUT}/plasmid_map_small.jpg`;
const plasmidMapDataUrl = `data:image/jpeg;base64,${(await readFile(plasmidMap)).toString("base64")}`;

const C = {
  bg: "#F7FAF4",
  ink: "#143D2B",
  muted: "#4B5E54",
  line: "#BDD4BE",
  tableLine: "#D7E4D4",
  soft: "#EAF3E8",
  soft2: "#F0F5EA",
  accent: "#3F7D47",
  accent2: "#C9A227",
  risk: "#B45309",
  white: "#FFFFFF",
};

const baseText = {
  fontFace: "Arial",
  color: C.ink,
  alignment: "right",
};

function T(value, opts = {}) {
  return text(value, {
    width: opts.width ?? fill,
    height: opts.height ?? hug,
    columnSpan: opts.columnSpan,
    rowSpan: opts.rowSpan,
    name: opts.name,
    style: {
      ...baseText,
      fontSize: opts.size ?? 28,
      bold: opts.bold ?? false,
      color: opts.color ?? C.ink,
      alignment: opts.align ?? "right",
    },
  });
}

function B(value, opts = {}) {
  return row({ width: fill, height: hug, gap: 14, align: "center", justify: "end" }, [
    T(value, { size: opts.size ?? 26, color: opts.color ?? C.muted, width: fill }),
    shape({
      width: fixed(12),
      height: fixed(12),
      geometry: "ellipse",
      fill: opts.dot ?? C.accent,
      line: { color: opts.dot ?? C.accent, transparency: 100 },
    }),
  ]);
}

function cell(value, opts = {}) {
  return panel(
    {
      width: fill,
      height: opts.height ?? fixed(82),
      padding: { x: opts.px ?? 14, y: opts.py ?? 10 },
      fill: opts.fill ?? C.white,
      line: { color: opts.line ?? C.tableLine, weight: 1 },
      align: "end",
      justify: "center",
    },
    T(value, {
      size: opts.size ?? 21,
      bold: opts.bold,
      color: opts.color ?? C.ink,
      width: fill,
    }),
  );
}

function sectionTitle(title, subtitle, slideNo) {
  return row({ width: fill, height: hug, align: "center", justify: "between" }, [
    panel(
      {
        width: fixed(70),
        height: fixed(70),
        fill: C.ink,
        borderRadius: "rounded",
        align: "center",
        justify: "center",
      },
      T(String(slideNo), { size: 26, bold: true, color: C.white, align: "center", width: fill }),
    ),
    column({ width: fill, height: hug, gap: 8, align: "end" }, [
      T(title, { size: 50, bold: true }),
      subtitle ? T(subtitle, { size: 22, color: C.muted }) : T("מעבדת בנין, אוניברסיטת בר-אילן", { size: 20, color: C.muted }),
    ]),
  ]);
}

function slideFrame(title, subtitle, slideNo, body) {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.bg, padding: { x: 72, y: 52 } },
      grid(
        {
          name: `slide-${slideNo}-root`,
          width: fill,
          height: fill,
          rows: [auto, fr(1), auto],
          columns: [fr(1)],
          rowGap: 28,
        },
        [
          sectionTitle(title, subtitle, slideNo),
          body,
          row({ width: fill, height: hug, align: "center", justify: "between" }, [
            T(`מאגד אדמה ירוקה | שקף ${slideNo}`, { size: 16, color: "#708278", align: "left", width: fill }),
            rule({ width: fixed(220), stroke: C.line, weight: 3 }),
          ]),
        ],
      ),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
  return slide;
}

function cover() {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.bg, padding: { x: 86, y: 72 } },
      grid(
        { width: fill, height: fill, columns: [fr(0.75), fr(1.25)], rows: [fr(1), auto], columnGap: 58 },
        [
          panel(
            {
              width: fill,
              height: fill,
              fill: C.soft,
              line: { color: C.line, weight: 2 },
              padding: 26,
            },
            image({
              dataUrl: plasmidMapDataUrl,
              contentType: "image/jpeg",
              width: fill,
              height: fill,
              fit: "contain",
              alt: "מפות פלסמידים של UPO19 ב-pJN105 וב-pBBR1mcs2",
            }),
          ),
          column({ width: fill, height: fill, gap: 26, align: "end", justify: "center" }, [
            T("דוח סיכום פעילות חציון 1", { size: 72, bold: true }),
            T("מעבדת בנין, אוניברסיטת בר-אילן", { size: 34, color: C.muted }),
            rule({ width: fixed(420), stroke: C.accent, weight: 5 }),
            T('מאגד "אדמה ירוקה"', { size: 31, bold: true, color: C.accent }),
            T("קבוצה 1: מערכת ייצור והפרשת אנזים ב-Pseudomonas putida\nקבוצה 3: דטקטורים ביולוגיים לתנאי קרקע וזיהום אלקנים", {
              size: 27,
              color: C.muted,
            }),
          ]),
          T("יש להכין מצגת באורך 5 דקות לשותף", { size: 18, color: "#708278", align: "left", columnSpan: 2 }),
        ],
      ),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
}

function slide2() {
  const rows = [
    ["תוצר לשותפים", "%", "סטטוס ביצוע", "שם משימה", "#"],
    ["ליאנט / המשך ביטוי והפרשה", "55", "נבנה רצף UPO19 מותאם קודונים עם SP ו-His-tag. נשלח לריצוף.", "קבוצה 1 - התאמת UPO19 לביטוי והפרשה", "1"],
    ["ליאנט / אפיון המשך", "50", "הרצף הוכנס ל-pBBR1mcs-2 ול-pJN105. ממתינים לתוצאות ריצוף.", "קבוצה 1 - וקטורי ביטוי קונסטיטוטיבי ואינדוסבילי", "2"],
    ["הדר וראמז", "70", "דטקטורי חנקן וברזל פעילים במדידות GFP. פוספט בבניית קונסטרקט שלישי.", "קבוצה 3 - דטקטורי הרעבה", "3"],
    ["הדר וראמז", "35", "פלסמידים סביבתיים בידינו. מערכת רצפטור וגן דיווח בבנייה.", "קבוצה 3 - דטקטור אלקנים", "4"],
  ];
  const children = [];
  for (let r = 0; r < rows.length; r++) {
    const isHeader = r === 0;
    for (let c = 0; c < rows[r].length; c++) {
      children.push(
        cell(rows[r][c], {
          height: isHeader ? fixed(56) : fixed(112),
          fill: isHeader ? C.ink : c === 1 ? C.soft2 : C.white,
          color: isHeader ? C.white : C.ink,
          bold: isHeader || c === 1 || c === 4,
          size: isHeader ? 20 : c === 1 || c === 4 ? 24 : 19,
        }),
      );
    }
  }
  slideFrame(
    "סיכום ביצוע",
    "סטטוס טכני מתחילת התקופה ועד עכשיו, ביחס לתכנון המקורי",
    2,
    grid(
      {
        width: fill,
        height: hug,
        columns: [fr(1.45), fr(0.45), fr(1.9), fr(2.1), fr(0.3)],
        rows: [auto, auto, auto, auto, auto],
        columnGap: 0,
        rowGap: 0,
      },
      children,
    ),
  );
}

function slide3() {
  slideFrame(
    "תוצרים עיקריים לתקופה",
    "תוצרים מרכזיים שהתקבלו והוכחת תגובה ראשונית",
    3,
    grid(
      { width: fill, height: fill, columns: [fr(1.05), fr(0.95)], rows: [fr(1)], columnGap: 36 },
      [
        column({ width: fill, height: fill, gap: 18 }, [
          panel(
            { width: fill, height: fixed(472), fill: C.white, line: { color: C.line, weight: 2 }, padding: 18 },
            image({
              dataUrl: plasmidMapDataUrl,
              contentType: "image/jpeg",
              width: fill,
              height: fill,
              fit: "contain",
              alt: "מפות הפלסמידים pJN105 ו-pBBR1mcs2 עם UPO19 מותאם",
            }),
          ),
          T("קבוצה 1: נבנו שני קונסטרקטים של UPO19 מותאם ל-P. putida", { size: 23, bold: true }),
          B("התאמת קודונים בעקבות GC נמוך ברצפי המקור", { size: 22, dot: C.accent2 }),
          B("הוספת signal peptide להפרשה ו-His-tag לניקוי", { size: 22 }),
          B("החדרה ל-pJN105 אינדוסבילי ול-pBBR1mcs-2 קונסטיטוטיבי", { size: 22 }),
        ]),
        column({ width: fill, height: fill, gap: 18 }, [
          T("קבוצה 3: דטקטורי הרעבה", { size: 30, bold: true }),
          chart({
            name: "starvation-response-chart",
            chartType: "bar",
            width: fill,
            height: fixed(420),
            config: {
              title: "Fold change at 15:50 h",
              categories: ["pvdA Fe-", "glnK N-", "pstS P-"],
              series: [{ name: "Signal / M9", values: [9.6, 9.4, 1.35] }],
            },
          }),
          B("ברזל וחנקן: תגובה חזקה וספציפית במדידות GFP", { size: 23 }),
          B("פוספט: שני פרומוטורים לא נתנו ספציפיות מספקת", { size: 23, dot: C.risk }),
          B("סט נוסף נבנה לקריאה אלקטרוכימית ולומינסנטית", { size: 23, dot: C.accent2 }),
        ]),
      ],
    ),
  );
}

function slide4() {
  const rows = [
    ["סטטוס והסברים", "תאריך בפועל", "תאריך מתוכנן", "שם אבן הדרך / התניה", "#"],
    ["בביצוע. דטקטורי חנקן וברזל פעילים; פוספט בבנייה של קונסטרקט שלישי. מועד אבן הדרך טרם הגיע.", "", "31.8.2026", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק", "1"],
    ["בביצוע מוקדם. UPO19 נבחר, עבר התאמת קודונים, נוספו SP ו-His-tag ונבנו שני קונסטרקטים. ממתינים לריצוף.", "", "28.2.2027", "שיבוט מטריצת אותות הפרשה Sec/Tat, Sec, Tat, Type I היברידי", "2"],
  ];
  const children = [];
  for (let r = 0; r < rows.length; r++) {
    const isHeader = r === 0;
    for (let c = 0; c < rows[r].length; c++) {
      children.push(
        cell(rows[r][c], {
          height: isHeader ? fixed(60) : fixed(180),
          fill: isHeader ? C.ink : C.white,
          color: isHeader ? C.white : C.ink,
          bold: isHeader || c === 4,
          size: isHeader ? 20 : 21,
        }),
      );
    }
  }
  slideFrame(
    "סטטוס אבני דרך",
    "אבני הדרך כפי שהוגדרו בתוכנית, עם סטטוס ביניים",
    4,
    column({ width: fill, height: fill, gap: 24 }, [
      grid({ width: fill, height: hug, columns: [fr(2.4), fr(0.75), fr(0.9), fr(2.2), fr(0.25)] }, children),
      panel(
        { width: fill, height: hug, fill: C.soft, line: { color: C.line, weight: 1 }, padding: { x: 24, y: 18 } },
        T("תרומה לאבני דרך מאגדיות: מעבר ממדידות GFP לזנים ומערכות קריאה המתאימות להמשך שילוב במעבדות השותפים.", {
          size: 25,
          bold: true,
          color: C.accent,
        }),
      ),
    ]),
  );
}

function slide5() {
  slideFrame(
    "שינויים עיקריים בביצוע",
    "פערים טכניים, סיכונים ומה נעשה כדי לסגור אותם",
    5,
    grid(
      { width: fill, height: fill, columns: [fr(1), fr(1)], rows: [fr(1), fr(1)], columnGap: 28, rowGap: 28 },
      [
        panel({ width: fill, height: fill, fill: C.white, line: { color: C.tableLine, weight: 1 }, padding: 26 }, column({ width: fill, height: fill, gap: 14 }, [
          T("GC נמוך ברצפי המקור", { size: 27, bold: true, color: C.risk }),
          T("רצפי הפלסמידים מ-E. coli היו סביב 30% GC ולא התאימו לביטוי מיטבי ב-P. putida.", { size: 22, color: C.muted }),
          T("פתרון: סינתזה של UPO19 מותאם קודונים, עם SP ו-His-tag.", { size: 23, bold: true }),
        ])),
        panel({ width: fill, height: fill, fill: C.white, line: { color: C.tableLine, weight: 1 }, padding: 26 }, column({ width: fill, height: fill, gap: 14 }, [
          T("דטקטור פוספט", { size: 27, bold: true, color: C.risk }),
          T("שני פרומוטורים שנבדקו לא הראו תגובה ספציפית מספקת להרעבה לפוספט.", { size: 22, color: C.muted }),
          T("פתרון: קונסטרקט שלישי נמצא בבנייה וייבחן מול תנאי ביקורת.", { size: 23, bold: true }),
        ])),
        panel({ width: fill, height: fill, fill: C.white, line: { color: C.tableLine, weight: 1 }, padding: 26 }, column({ width: fill, height: fill, gap: 14 }, [
          T("דטקטור אלקנים", { size: 27, bold: true, color: C.risk }),
          T("הגנים הרלוונטיים אינם נטיביים ל-P. putida אלא מצויים על פלסמידים מזנים סביבתיים.", { size: 22, color: C.muted }),
          T("פתרון: הפלסמידים בידינו, ומערכת רצפטור וגן דיווח נמצאת בבנייה.", { size: 23, bold: true }),
        ])),
        panel({ width: fill, height: fill, fill: C.soft, line: { color: C.line, weight: 1 }, padding: 26 }, column({ width: fill, height: fill, gap: 14 }, [
          T("המשך קדימה", { size: 27, bold: true, color: C.accent }),
          T("אישור ריצוף הקונסטרקטים של UPO19, מעבר לביטוי והפרשה, והעברת דטקטורים עובדים לקריאות אלקטרוכימיות ולומינסנטיות.", { size: 23, color: C.ink }),
        ])),
      ],
    ),
  );
}

function slide6() {
  const rows = [
    ["הסברים היה ונדרש", "אומדן ביצוע עד עכשיו", "תקציב מאושר 18 חודש", ""],
    ["", "", "", 'כ"א'],
    ["", "", "", "חומרים"],
    ["", "", "", 'קב"מ בארץ'],
    ["", "", "", 'קב"מ בחו"ל'],
    ["", "", "", "ציוד"],
    ["", "", "", "ציוד יעודי"],
    ["", "", "", "שונות"],
    ["", "", "", 'סה"כ'],
  ];
  const children = [];
  for (let r = 0; r < rows.length; r++) {
    const isHeader = r === 0;
    const isTotal = r === rows.length - 1;
    for (let c = 0; c < rows[r].length; c++) {
      children.push(
        cell(rows[r][c], {
          height: isHeader ? fixed(54) : fixed(66),
          fill: isHeader ? C.ink : isTotal ? C.soft : C.white,
          color: isHeader ? C.white : C.ink,
          bold: isHeader || isTotal || c === 3,
          size: isHeader ? 20 : 22,
        }),
      );
    }
  }
  slideFrame(
    "טבלת השוואה תקציבית (ש״ח)",
    "נשאר פתוח למילוי לפי טיוטת הדוח הפיננסי",
    6,
    grid({ width: fill, height: hug, columns: [fr(2), fr(1), fr(1), fr(0.85)] }, children),
  );
}

function slide7() {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.ink, padding: { x: 96, y: 80 } },
      column({ width: fill, height: fill, align: "end", justify: "center", gap: 28 }, [
        T("תודה רבה!", { size: 86, bold: true, color: C.white }),
        T("מעבדת בנין | מאגד אדמה ירוקה", { size: 30, color: "#DDECDD" }),
        rule({ width: fixed(360), stroke: C.accent2, weight: 5 }),
      ]),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
}

cover();
slide2();
slide3();
slide4();
slide5();
slide6();
slide7();

await mkdir(PREVIEW_DIR, { recursive: true });

const pptxBlob = await PresentationFile.exportPptx(presentation);
const workPptx = `${WORK_OUT}/${PPTX_NAME}`;
const finalPptx = `${OUT_DIR}/${PPTX_NAME}`;
await pptxBlob.save(workPptx);
await copyFile(workPptx, finalPptx);

for (let i = 0; i < presentation.slides.count; i++) {
  const slide = presentation.slides.getItem(i);
  const png = await slide.export({ format: "png" });
  await writeFile(`${PREVIEW_DIR}/slide-${String(i + 1).padStart(2, "0")}.png`, Buffer.from(await png.arrayBuffer()));
}

console.log(JSON.stringify({ pptx: finalPptx, previews: PREVIEW_DIR, slides: presentation.slides.count }, null, 2));
