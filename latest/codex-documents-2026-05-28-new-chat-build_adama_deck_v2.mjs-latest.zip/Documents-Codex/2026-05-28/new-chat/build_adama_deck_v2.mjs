import {
  Presentation,
  PresentationFile,
  column,
  row,
  grid,
  panel,
  text,
  image,
  chart,
  shape,
  rule,
  fill,
  hug,
  fixed,
  wrap,
  fr,
  auto,
} from "@oai/artifact-tool";
import { writeFile, mkdir, copyFile, readFile } from "node:fs/promises";

const presentation = Presentation.create({ slideSize: { width: 1920, height: 1080 } });

const OUT_DIR = "C:/Users/Popovtzer lab/.codex/\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4/V2";
const WORK_OUT = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat";
const PPTX_NAME = "\u05d8\u05de\u05e4\u05dc\u05d9\u05d9\u05d8 - \u05de\u05e6\u05d2\u05ea \u05e0\u05ea\u05d5\u05e0\u05d9 \u05d4\u05e8\u05e2\u05d1\u05d4 \u05de\u05e2\u05d5\u05d3\u05db\u05e0\u05ea.pptx";
const PREVIEW_DIR = `${WORK_OUT}/adama_deck_previews_starvation`;

async function dataUrl(path, type = "image/jpeg") {
  return `data:${type};base64,${(await readFile(path)).toString("base64")}`;
}

const coverImage = await dataUrl(`${WORK_OUT}/cover_image_deck.jpg`);
const plasmidImage = await dataUrl(`${WORK_OUT}/plasmid_map_deck.jpg`);
const endpointGraph = await dataUrl(`${WORK_OUT}/starvation_chart_exports/normalized_expression_13_3h.png`, "image/png");
const pvdAGraph = await dataUrl(`${WORK_OUT}/starvation_chart_exports/pvdA_Fe_response.png`, "image/png");
const glnKGraph = await dataUrl(`${WORK_OUT}/starvation_chart_exports/glnK_N_response.png`, "image/png");

const C = {
  bg: "#F6FAF3",
  ink: "#123D2A",
  muted: "#4E6257",
  line: "#C5D8C2",
  soft: "#EAF4E7",
  pale: "#F1F6ED",
  white: "#FFFFFF",
  gold: "#C59B22",
  blue: "#1D6F8A",
  warn: "#B45309",
};

const rtl = { fontFace: "Arial", alignment: "right", color: C.ink };

function T(value, opts = {}) {
  return text(value, {
    name: opts.name,
    width: opts.width ?? fill,
    height: opts.height ?? hug,
    columnSpan: opts.columnSpan,
    rowSpan: opts.rowSpan,
    style: {
      ...rtl,
      fontSize: opts.size ?? 34,
      bold: opts.bold ?? false,
      color: opts.color ?? C.ink,
      alignment: opts.align ?? "right",
    },
  });
}

function latin(value, opts = {}) {
  return text(value, {
    width: opts.width ?? fill,
    height: opts.height ?? hug,
    style: {
      fontFace: "Arial",
      fontSize: opts.size ?? 28,
      bold: opts.bold ?? false,
      color: opts.color ?? C.muted,
      alignment: opts.align ?? "right",
    },
  });
}

function Dot(textValue, opts = {}) {
  return row({ width: fill, height: hug, gap: 18, align: "center", justify: "end" }, [
    T(textValue, { size: opts.size ?? 32, color: opts.color ?? C.muted, width: fill }),
    shape({
      width: fixed(14),
      height: fixed(14),
      geometry: "ellipse",
      fill: opts.dot ?? C.ink,
      line: { color: opts.dot ?? C.ink, transparency: 100 },
    }),
  ]);
}

function BigStat(value, label, color = C.ink) {
  return panel(
    { width: fill, height: fixed(180), fill: C.white, line: { color: C.line, weight: 1 }, padding: 26 },
    column({ width: fill, height: fill, gap: 8, align: "end", justify: "center" }, [
      T(value, { size: 56, bold: true, color }),
      T(label, { size: 27, color: C.muted }),
    ]),
  );
}

function Header(title, subtitle, n) {
  return row({ width: fill, height: hug, align: "center", justify: "between" }, [
    panel({ width: fixed(72), height: fixed(72), fill: C.ink, align: "center", justify: "center" }, T(String(n), { size: 28, bold: true, color: C.white, align: "center" })),
    column({ width: fill, height: hug, gap: 8, align: "end" }, [
      T(title, { size: 58, bold: true }),
      T(subtitle, { size: 28, color: C.muted }),
    ]),
  ]);
}

function Slide(title, subtitle, n, body) {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.bg, padding: { x: 76, y: 54 } },
      grid(
        { width: fill, height: fill, rows: [auto, fr(1), auto], columns: [fr(1)], rowGap: 32 },
        [
          Header(title, subtitle, n),
          body,
          row({ width: fill, height: hug, align: "center", justify: "between" }, [
            T(`מאגד אדמה ירוקה | שקף ${n}`, { size: 18, color: "#6F8277", align: "left" }),
            rule({ width: fixed(220), stroke: C.line, weight: 3 }),
          ]),
        ],
      ),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
}

function Cover() {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.bg, padding: { x: 70, y: 48 } },
      grid(
        { width: fill, height: fill, rows: [fr(0.66), fr(0.34)], columns: [fr(1)], rowGap: 18 },
        [
          panel({ width: fill, height: fill, fill: C.white, line: { color: C.line, weight: 1 }, padding: 0 },
            image({ dataUrl: coverImage, contentType: "image/jpeg", width: fill, height: fill, fit: "contain", alt: "תרשים חיידק מפריש אנזים בקרקע" })),
          row({ width: fill, height: fill, align: "center", justify: "between" }, [
            column({ name: "cover-meta", width: fixed(500), height: hug, gap: 6, align: "start" }, [
              T('מאגד "אדמה ירוקה"', { size: 30, bold: true, color: C.gold, align: "left" }),
              T("מעבדת בנין, בר-אילן", { size: 28, color: C.muted, align: "left" }),
            ]),
            column({ name: "cover-title", width: fill, height: hug, gap: 8, align: "end" }, [
              T("דוח סיכום פעילות", { size: 66, bold: true }),
              T("חציון 1", { size: 40, color: C.muted }),
            ]),
          ]),
        ],
      ),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
}

function Slide2() {
  function rowCard(num, task, percent, status, transfer, color = C.ink) {
    return panel(
      { width: fill, height: fixed(166), fill: C.white, line: { color: C.line, weight: 1 }, padding: { x: 24, y: 20 } },
      grid({ width: fill, height: fill, columns: [fr(1.55), fr(1.25), fr(0.36), fr(1.4), fr(0.22)], columnGap: 20 }, [
        T(transfer, { size: 28, bold: true, color }),
        T(status, { size: 25, color: C.muted }),
        T(`${percent}%`, { size: 38, bold: true, color, align: "center" }),
        T(task, { size: 27, bold: true }),
        T(num, { size: 28, bold: true, align: "center" }),
      ]),
    );
  }
  Slide(
    "סיכום ביצוע",
    "הדגש: מה כבר מוכן להעברה לשותפים",
    2,
    column({ width: fill, height: fill, gap: 18 }, [
      rowCard("1", "UPO19 מותאם - קבוצה 1", "55", "קונסטרקטים נבנו ונשלחו לריצוף", "עדיין לא מוכן להעברה", C.warn),
      rowCard("2", "דטקטורי הרעבה - קבוצה 3", "70", "חנקן וברזל עובדים במערכת GFP", "מועבר לאלקטרוכימי ולומינסנציה", C.blue),
      rowCard("3", "דטקטור אלקנים - קבוצה 3", "35", "רצפטור וגן דיווח בבנייה", "עדיין לא מוכן להעברה", C.warn),
    ]),
  );
}

function Slide3() {
  Slide(
    "תוצרים עיקריים לתקופה",
    "שני תוצרים בשלים יותר, ושני תוצרים בשלבי בנייה",
    3,
    grid({ width: fill, height: fill, columns: [fr(1), fr(1)], rows: [fr(1)], columnGap: 34 }, [
      panel(
        { width: fill, height: fill, fill: C.white, line: { color: C.line, weight: 1 }, padding: 28 },
        column({ width: fill, height: fill, gap: 18 }, [
          T("קבוצה 1", { size: 38, bold: true }),
          image({ dataUrl: plasmidImage, contentType: "image/jpeg", width: fill, height: fixed(355), fit: "contain", alt: "מפות פלסמידים UPO19" }),
          T("נבנו מספר קונסטרקטים של האנזים UPO19", { size: 31, bold: true }),
          latin("pJN105  |  pBBR1mcs-2", { size: 30, bold: true, color: C.blue }),
          Dot("רצף מותאם קודונים לפסאודומונס", { size: 28, dot: C.gold }),
          Dot("נוסף אות הפרשה ותג ניקוי", { size: 28 }),
        ]),
      ),
      panel(
        { width: fill, height: fill, fill: C.white, line: { color: C.line, weight: 1 }, padding: 28 },
        column({ width: fill, height: fill, gap: 18 }, [
          T("קבוצה 3", { size: 38, bold: true }),
          T("דטקטורים שהראו תגובה", { size: 32, bold: true, color: C.blue }),
          image({
            dataUrl: endpointGraph,
            contentType: "image/png",
            width: fill,
            height: fixed(475),
            fit: "contain",
            alt: "Detector endpoint response with M9 control and starvation condition for each detector",
          }),
          Dot("ברזל וחנקן: תגובה חזקה וברורה", { size: 27, dot: C.blue }),
          Dot("פוספט: ממשיך לקונסטרקט שלישי", { size: 27, dot: C.warn }),
        ]),
      ),
    ]),
  );
}

function StarvationResults() {
  function resultPanel(label, graphData, stat, note, alt) {
    return panel(
      { width: fill, height: fill, fill: C.white, line: { color: C.line, weight: 1 }, padding: 20 },
      grid({ width: fill, height: fill, columns: [fr(1.75), fr(0.55)], columnGap: 24 }, [
        image({ dataUrl: graphData, contentType: "image/png", width: fill, height: fill, fit: "contain", alt }),
        column({ width: fill, height: fill, gap: 12, align: "end", justify: "center" }, [
          latin(label, { size: 35, bold: true, color: C.blue }),
          T(stat, { size: 34, bold: true }),
          T(note, { size: 25, color: C.muted }),
        ]),
      ]),
    );
  }

  Slide(
    "תוצאות דטקטורי ההרעבה",
    "מדידה קינטית מנורמלת לאורך סדרת ריכוזים | 10.6.2026",
    4,
    grid({ width: fill, height: fill, columns: [fr(1)], rows: [fr(1), fr(1)], rowGap: 20 }, [
      resultPanel("pvdA / Fe", pvdAGraph, "28,182 → 244,316", "ב־13.3 שעות: מ־20 mM Fe לתנאי ללא ברזל", "pvdA iron starvation detector time course"),
      resultPanel("glnK / N", glnKGraph, "11,819 → 202,038", "ב־13.3 שעות: מ־10 mM N ל־2 mM N", "glnK nitrogen starvation detector time course"),
    ]),
  );
}

function Slide4() {
  function milestone(title, date, status, color = C.ink) {
    return panel(
      { width: fill, height: fixed(245), fill: C.white, line: { color: C.line, weight: 1 }, padding: 28 },
      grid({ width: fill, height: fill, columns: [fr(2.2), fr(0.55), fr(1.4)], columnGap: 28 }, [
        T(status, { size: 30, color: C.muted }),
        T(date, { size: 33, bold: true, color, align: "center" }),
        T(title, { size: 32, bold: true }),
      ]),
    );
  }
  Slide(
    "סטטוס אבני דרך",
    "שתי אבני הדרך עדיין לפני מועד היעד",
    5,
    column({ width: fill, height: fill, gap: 28 }, [
      milestone("דירוג פרומוטורים", "31.8.2026", "חנקן וברזל עובדים; פוספט בבנייה נוספת; אלקנים בבנייה", C.blue),
      milestone("מטריצת אותות הפרשה", "28.2.2027", "נבנו קונסטרקטים ראשונים עם מטריצת הפרשה UPO19; ממתינים לריצוף לטובת בדיקות ראשוניות", C.gold),
      panel({ width: fill, height: hug, fill: C.soft, line: { color: C.line, weight: 1 }, padding: 24 },
        T("תרומה למאגד: מעבר ממדידות GFP למערכות קריאה אצל הדר וראמז.", { size: 34, bold: true, color: C.ink })),
    ]),
  );
}

function Slide5() {
  function issue(title, body, action, color = C.warn) {
    return panel(
      { width: fill, height: fill, fill: C.white, line: { color: C.line, weight: 1 }, padding: 28 },
      column({ width: fill, height: fill, gap: 18 }, [
        T(title, { size: 34, bold: true, color }),
        T(body, { size: 27, color: C.muted }),
        rule({ width: fixed(160), stroke: color, weight: 4 }),
        T(action, { size: 29, bold: true }),
      ]),
    );
  }
  Slide(
    "שינויים וסיכונים",
    "הפערים ברורים ויש לכל אחד כיוון פתרון",
    6,
    grid({ width: fill, height: fill, columns: [fr(1), fr(1), fr(1)], columnGap: 28 }, [
      issue("GC נמוך", "רצפי המקור לא התאימו לביטוי בפסאודומונס.", "סונתז UPO19 מותאם קודונים."),
      issue("פוספט", "שני פרומוטורים לא נתנו ספציפיות מספקת.", "נבנה קונסטרקט שלישי."),
      issue("אלקנים", "הגנים אינם נטיביים לפסאודומונס.", "בונים מערכת עם רצפטור וגן דיווח."),
    ]),
  );
}

function Slide6() {
  const cats = ['כ"א', "חומרים", 'קב"מ בארץ', 'קב"מ בחו״ל', "ציוד", "ציוד יעודי", "שונות", 'סה"כ'];
  const cells = [
    T("הסברים", { size: 26, bold: true, color: C.white, align: "center" }),
    T("ביצוע", { size: 26, bold: true, color: C.white, align: "center" }),
    T("תקציב", { size: 26, bold: true, color: C.white, align: "center" }),
    T("סעיף", { size: 26, bold: true, color: C.white, align: "center" }),
  ];
  for (const cat of cats) {
    cells.push(T("", { size: 28 }), T("", { size: 28 }), T("", { size: 28 }), T(cat, { size: 30, bold: true, align: "center" }));
  }
  Slide(
    "טבלת השוואה תקציבית",
    "נשאר פתוח למילוי לפי הדוח הפיננסי",
    7,
    panel({ width: fill, height: hug, fill: C.white, line: { color: C.line, weight: 1 }, padding: 0 },
      grid({ width: fill, height: hug, columns: [fr(2), fr(1), fr(1), fr(0.8)], rows: [fixed(64), ...cats.map(() => fixed(78))] },
        cells.map((c, i) => panel({
          width: fill,
          height: fill,
          fill: i < 4 ? C.ink : (i >= 4 * cats.length ? C.soft : C.white),
          line: { color: C.line, weight: 1 },
          padding: { x: 16, y: 10 },
          align: "center",
          justify: "center",
        }, c)),
      )),
  );
}

function Slide7() {
  const slide = presentation.slides.add();
  slide.compose(
    panel(
      { width: fill, height: fill, fill: C.ink, padding: { x: 96, y: 84 } },
      column({ width: fill, height: fill, align: "end", justify: "center", gap: 30 }, [
        T("תודה רבה", { size: 88, bold: true, color: C.white }),
        T("מעבדת בנין | מאגד אדמה ירוקה", { size: 34, color: "#DAEADA" }),
        rule({ width: fixed(360), stroke: C.gold, weight: 5 }),
      ]),
    ),
    { frame: { left: 0, top: 0, width: 1920, height: 1080 }, baseUnit: 8 },
  );
}

Cover();
Slide2();
Slide3();
StarvationResults();
Slide4();
Slide5();
Slide6();
Slide7();

await mkdir(PREVIEW_DIR, { recursive: true });

const pptxBlob = await PresentationFile.exportPptx(presentation);
const workPptx = `${WORK_OUT}/${PPTX_NAME}`;
const finalPptx = `${OUT_DIR}/${PPTX_NAME}`;
await pptxBlob.save(workPptx);
await copyFile(workPptx, finalPptx);

for (let i = 0; i < presentation.slides.count; i++) {
  const slide = presentation.slides.getItem(i);
  const png = await slide.export({ format: "png" });
  await writeFile(`${PREVIEW_DIR}/slide-${String(i + 1).padStart(2, "0")}.png`, Buffer.from(await png.arrayBuffer()));
}

console.log(JSON.stringify({ pptx: finalPptx, previews: PREVIEW_DIR, slides: presentation.slides.count }, null, 2));
process.exit(0);
