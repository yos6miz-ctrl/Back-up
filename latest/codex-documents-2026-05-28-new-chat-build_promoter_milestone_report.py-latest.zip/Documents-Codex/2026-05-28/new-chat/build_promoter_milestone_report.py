from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat")
PROJECT = Path("C:/Users/Popovtzer lab/.codex/\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4")
OUT = PROJECT / "דוח אבני דרך - דירוג פרומוטורים משובטים.docx"
METRICS = ROOT / "promoter_milestone_metrics.json"
CHARTS = ROOT / "starvation_chart_exports"


BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
INK = RGBColor(20, 20, 20)
MUTED = RGBColor(85, 85, 85)
GREEN = RGBColor(40, 107, 63)
ORANGE = RGBColor(180, 83, 9)
RED = RGBColor(155, 28, 28)
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
LIGHT_GREEN = "EAF4EA"
LIGHT_ORANGE = "FFF1E6"


def set_run_font(run, size=None, color=None, bold=None, name="Arial"):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run._element.rPr.rFonts.set(qn("w:cs"), name)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color
    if bold is not None:
        run.bold = bold


def set_paragraph_rtl(paragraph, align=WD_ALIGN_PARAGRAPH.RIGHT):
    paragraph.alignment = align
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_text(cell, text, bold=False, color=INK, size=10.2, align=WD_ALIGN_PARAGRAPH.RIGHT):
    cell.text = ""
    p = cell.paragraphs[0]
    set_paragraph_rtl(p, align)
    run = p.add_run(str(text))
    set_run_font(run, size=size, color=color, bold=bold)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_table_bidi(table):
    tbl_pr = table._tbl.tblPr
    bidi = tbl_pr.find(qn("w:bidiVisual"))
    if bidi is None:
        bidi = OxmlElement("w:bidiVisual")
        tbl_pr.append(bidi)


def set_table_width(table, widths):
    table.alignment = WD_TABLE_ALIGNMENT.RIGHT
    table.autofit = False
    for row in table.rows:
        for idx, width in enumerate(widths):
            cell = row.cells[idx]
            cell.width = Inches(width)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(int(width * 1440)))
            tc_w.set(qn("w:type"), "dxa")


def add_para(doc, text="", size=11, color=INK, bold=False, style=None, after=6, align=WD_ALIGN_PARAGRAPH.RIGHT):
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.15
    set_paragraph_rtl(p, align)
    if text:
        run = p.add_run(text)
        set_run_font(run, size=size, color=color, bold=bold)
    return p


def add_heading(doc, text, level=1):
    style = f"Heading {level}"
    p = doc.add_paragraph(style=style)
    set_paragraph_rtl(p)
    run = p.add_run(text)
    if level == 1:
        set_run_font(run, size=16, color=BLUE, bold=True)
        p.paragraph_format.space_before = Pt(16)
        p.paragraph_format.space_after = Pt(8)
    elif level == 2:
        set_run_font(run, size=13, color=BLUE, bold=True)
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(6)
    else:
        set_run_font(run, size=12, color=DARK_BLUE, bold=True)
        p.paragraph_format.space_before = Pt(8)
        p.paragraph_format.space_after = Pt(4)
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    set_paragraph_rtl(p)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text)
    set_run_font(run, size=10.8, color=INK)
    return p


def add_callout(doc, title, body, fill=LIGHT_GREEN, color=GREEN):
    table = doc.add_table(rows=1, cols=1)
    set_table_bidi(table)
    set_table_width(table, [6.5])
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    p = cell.paragraphs[0]
    set_paragraph_rtl(p)
    r = p.add_run(title)
    set_run_font(r, size=12.2, color=color, bold=True)
    p.add_run("\n")
    r2 = p.add_run(body)
    set_run_font(r2, size=10.6, color=INK)
    add_para(doc, "", after=2)


def add_status_table(doc):
    rows = [
        ["מדד אבן הדרך", "תוצאה עד כה", "סטטוס"],
        ["פעילות נמדדת בלפחות 80% מהקונסטרוקטים", "שני הפרומוטורים שנבדקו כמותית (pvdA, glnK) הציגו פעילות נמדדת. יתר הקונסטרוקטים הרלוונטיים עדיין בבנייה, לא יציבים או לא נתנו ספציפיות מספקת, ולכן אין עדיין בסיס לקביעת 80% מכלל הקונסטרוקטים.", "חלקי / בהמשך"],
        ["דירוג ברור של לפחות 4 פרומוטורים", "קיים דירוג כמותי ברור לשני פרומוטורים פעילים: glnK ו-pvdA. שני פרומוטורים נוספים לפוספט עדיין בבנייה, וקונסטרקט האלקנים עדיין לא יציב.", "טרם הושלם"],
        ["יחס אות/רעש גדול מ-3:1", "pvdA: 8.7:1; glnK: 17.1:1 לפי מדידת 13.3 שעות ויחס בין תנאי אינדוקציה חזקים לבין תנאי בסיס.", "הושג עבור 2 פרומוטורים"],
    ]
    table = doc.add_table(rows=len(rows), cols=3)
    table.style = "Table Grid"
    set_table_bidi(table)
    widths = [1.65, 3.55, 1.3]
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx, c_idx)
            if r_idx == 0:
                set_cell_shading(cell, LIGHT_BLUE)
                set_cell_text(cell, val, bold=True, color=DARK_BLUE, size=10.5)
            else:
                set_cell_text(cell, val, size=9.4)
                if c_idx == 2:
                    if "הושג" in val:
                        set_cell_shading(cell, LIGHT_GREEN)
                    elif "טרם" in val:
                        set_cell_shading(cell, LIGHT_ORANGE)
                    else:
                        set_cell_shading(cell, LIGHT_GRAY)
    set_table_width(table, widths)
    add_para(doc, "", after=4)


def add_quant_table(doc, metrics):
    rows = [
        ["פרומוטור / דטקטור", "תנאי בסיס", "אות בסיס ממוצע", "תנאי אינדוקציה/מחסור", "אות מקסימלי ממוצע", "יחס אות/רעש", "מסקנה"],
        [
            "pvdA",
            "20 mM Fe",
            f"{metrics['pvdA_baseline']['mean']:,.0f}",
            "-Fe",
            f"{metrics['pvdA_signal']['mean']:,.0f}",
            f"{metrics['pvdA_ratio']:.1f}:1",
            "פעיל; עומד במדד 3:1",
        ],
        [
            "glnK",
            "10 mM N",
            f"{metrics['glnK_baseline']['mean']:,.0f}",
            "2 mM N",
            f"{metrics['glnK_signal']['mean']:,.0f}",
            f"{metrics['glnK_ratio']:.1f}:1",
            "פעיל; עומד במדד 3:1",
        ],
        [
            "פוספט",
            "לא רלוונטי",
            "לא נקבע",
            "שני פרומוטורים נוספים בבנייה",
            "לא נקבע",
            "לא נקבע",
            "טרם דורג",
        ],
        [
            "אלקנים",
            "לא רלוונטי",
            "לא נקבע",
            "קונסטרקט לא יציב",
            "לא נקבע",
            "לא נקבע",
            "טרם דורג",
        ],
    ]
    table = doc.add_table(rows=len(rows), cols=7)
    table.style = "Table Grid"
    set_table_bidi(table)
    widths = [0.9, 0.85, 0.9, 1.15, 0.95, 0.8, 0.95]
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx, c_idx)
            if r_idx == 0:
                set_cell_shading(cell, LIGHT_BLUE)
                set_cell_text(cell, val, bold=True, color=DARK_BLUE, size=8.2)
            else:
                set_cell_text(cell, val, size=8.0)
                if c_idx == 6:
                    if "פעיל" in val:
                        set_cell_shading(cell, LIGHT_GREEN)
                    else:
                        set_cell_shading(cell, LIGHT_ORANGE)
    set_table_width(table, widths)
    add_para(doc, "הערה: יחס אות/רעש חושב כאן כיחס בין האות הממוצע בתנאי ההשראה/המחסור החזק ביותר לבין תנאי הבסיס המתאים באותה סדרת מדידה.", size=9.2, color=MUTED, after=8)


def add_endpoint_table(doc, metrics):
    rows = [["דטקטור", "תנאי", "ממוצע ביטוי מנורמל ב-13.3 שעות", "SD", "n"]]
    for r in metrics["rows"]:
        rows.append([r["detector"], r["condition"], f"{r['mean']:,.0f}", f"{r['sd']:,.0f}", str(r["n"])])
    table = doc.add_table(rows=len(rows), cols=5)
    table.style = "Table Grid"
    set_table_bidi(table)
    widths = [0.8, 1.7, 2.0, 1.1, 0.4]
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx, c_idx)
            if r_idx == 0:
                set_cell_shading(cell, LIGHT_BLUE)
                set_cell_text(cell, val, bold=True, color=DARK_BLUE, size=8.8)
            else:
                set_cell_text(cell, val, size=8.5, align=WD_ALIGN_PARAGRAPH.CENTER if c_idx >= 2 else WD_ALIGN_PARAGRAPH.RIGHT)
    set_table_width(table, widths)


def add_picture_if_exists(doc, path, caption):
    if path.exists():
        p = doc.add_paragraph()
        set_paragraph_rtl(p, WD_ALIGN_PARAGRAPH.CENTER)
        run = p.add_run()
        run.add_picture(str(path), width=Inches(5.9))
        add_para(doc, caption, size=9.2, color=MUTED, align=WD_ALIGN_PARAGRAPH.CENTER, after=8)


def setup_doc(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    normal._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    normal.font.size = Pt(11)

    for style_name, size, color in [
        ("Heading 1", 16, BLUE),
        ("Heading 2", 13, BLUE),
        ("Heading 3", 12, DARK_BLUE),
    ]:
        style = styles[style_name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
        style._element.rPr.rFonts.set(qn("w:cs"), "Arial")
        style.font.size = Pt(size)
        style.font.color.rgb = color

    header = section.header.paragraphs[0]
    header.text = "דוח אבני דרך | אדמה ירוקה"
    set_paragraph_rtl(header)
    set_run_font(header.runs[0], size=9, color=MUTED)
    footer = section.footer.paragraphs[0]
    footer.text = "מעבדת בנין, בר-אילן"
    footer.alignment = WD_ALIGN_PARAGRAPH.LEFT
    set_run_font(footer.runs[0], size=9, color=MUTED)


def main():
    metrics = json.loads(METRICS.read_text(encoding="utf-8"))
    doc = Document()
    setup_doc(doc)

    # Title block / memo masthead.
    add_para(doc, "דוח אבני דרך", size=23, color=INK, bold=True, after=4)
    add_para(doc, "בנין - דירוג ראשוני של פרומוטורים משובטים", size=15, color=MUTED, bold=True, after=12)
    meta = doc.add_table(rows=4, cols=2)
    meta.style = "Table Grid"
    set_table_bidi(meta)
    meta_rows = [
        ("פרויקט", "אדמה ירוקה - רכיב החישה / דטקטורים"),
        ("אבן דרך", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי ו/או פעילות ביולוגית"),
        ("תאריך סטטוס", "9 באוגוסט 2026"),
        ("מקורות נתונים", "קובץ yossi_20260610.xlsx; גרפי pvdA/glnK; עדכוני סטטוס מהמעבדה"),
    ]
    for idx, (label, value) in enumerate(meta_rows):
        set_cell_shading(meta.cell(idx, 1), LIGHT_BLUE)
        set_cell_text(meta.cell(idx, 1), label, bold=True, color=DARK_BLUE)
        set_cell_text(meta.cell(idx, 0), value)
    set_table_width(meta, [4.85, 1.65])
    add_para(doc, "", after=8)

    add_callout(
        doc,
        "תקציר מנהלים",
        "נכון לעכשיו קיימות תוצאות כמותיות חזקות לשני פרומוטורים פעילים: pvdA בתנאי הרעבה לברזל ו-glnK בתנאי הרעבה לחנקן. שני הפרומוטורים מציגים יחס אות/רעש מעל 3:1 ועברו גם למערכת מבוססת לוציפראז. עם זאת, אבן הדרך הכוללת עדיין לא הושלמה במלואה, משום שעדיין אין דירוג של לפחות ארבעה פרומוטורים, שני פרומוטורים נוספים לפוספט נמצאים בבנייה, וקונסטרקט האלקנים עדיין אינו יציב.",
        fill=LIGHT_GREEN,
        color=GREEN,
    )

    add_heading(doc, "1. הגדרת אבן הדרך והמדדים", 1)
    add_para(doc, "אבן הדרך עוסקת בדירוג ראשוני של פרומוטורים משובטים בתנאי שייק פלאסק, באמצעות ביטוי אנזימטי ו/או פעילות ביולוגית, לצורך הערכה כמותית ודירוג עוצמת הפרומוטור.")
    add_bullet(doc, "מדד כמותי 1: לכל הפחות 80% מהקונסטרוקטים יציגו פעילות נמדדת.")
    add_bullet(doc, "מדד כמותי 2: דירוג ברור של לפחות 4 פרומוטורים.")
    add_bullet(doc, "מדד כמותי 3: יחס אות/רעש גדול מ-3:1 עבור הפרומוטורים המדורגים.")
    add_para(doc, "הדוח הנוכחי מסכם את כל התוצאות הרלוונטיות הזמינות עד כה. במקומות שבהם קונסטרוקטים עדיין בבנייה או אינם יציבים, הסטטוס מוצג כפער להשלמה ולא כתוצאה כמותית סופית.")

    add_heading(doc, "2. סטטוס עמידה במדדי אבן הדרך", 1)
    add_status_table(doc)

    add_heading(doc, "3. תוצאות כמותיות זמינות", 1)
    add_para(doc, "מדידות ההרעבה הזמינות נותחו על בסיס ביטוי מנורמל לאחר חיסור בקרת דטקטור. נקודת הזמן המרכזית להשוואה היא 13.3 שעות, בהתאם לגרף הסיכום בקובץ התוצאות.")
    add_quant_table(doc, metrics)

    add_heading(doc, "4. דירוג ראשוני של הפרומוטורים הפעילים", 1)
    ranking = [
        ("1", "glnK", f"{metrics['glnK_ratio']:.1f}:1", "פרומוטור פעיל להרעבה לחנקן; תגובה חזקה וברורה עם ירידת ריכוז החנקן."),
        ("2", "pvdA", f"{metrics['pvdA_ratio']:.1f}:1", "פרומוטור פעיל להרעבה לברזל; תגובה מדורגת עם ירידת זמינות הברזל."),
        ("3", "פוספט", "לא נקבע", "שני פרומוטורים נוספים עדיין בבנייה; אין עדיין דירוג כמותי תקף."),
        ("4", "אלקנים", "לא נקבע", "עדיין יש קושי ביצירת קונסטרקט יציב; אין עדיין מדידת פעילות שניתן לדרג."),
    ]
    table = doc.add_table(rows=1 + len(ranking), cols=4)
    table.style = "Table Grid"
    set_table_bidi(table)
    headers = ["דירוג זמני", "פרומוטור / יעד חישה", "יחס אות/רעש", "פירוש"]
    for c, h in enumerate(headers):
        set_cell_shading(table.cell(0, c), LIGHT_BLUE)
        set_cell_text(table.cell(0, c), h, bold=True, color=DARK_BLUE, size=9.5)
    for r_idx, row in enumerate(ranking, 1):
        for c_idx, val in enumerate(row):
            set_cell_text(table.cell(r_idx, c_idx), val, size=9.0, align=WD_ALIGN_PARAGRAPH.CENTER if c_idx < 3 else WD_ALIGN_PARAGRAPH.RIGHT)
            if c_idx == 2:
                set_cell_shading(table.cell(r_idx, c_idx), LIGHT_GREEN if ":1" in val else LIGHT_ORANGE)
    set_table_width(table, [0.8, 1.45, 1.1, 3.15])
    add_para(doc, "מסקנה: הדירוג הכמותי הנוכחי כולל שני פרומוטורים בלבד. כדי לעמוד באבן הדרך במלואה יש להשלים לפחות שני פרומוטורים מדורגים נוספים.", size=10.5, color=INK, bold=True, after=8)

    add_heading(doc, "5. פירוט תוצאות לפי דטקטור", 1)
    add_heading(doc, "5.1 pvdA - תגובה להרעבה לברזל", 2)
    add_para(doc, f"פרומוטור pvdA הראה תגובת מינון ברורה בתנאי ברזל. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מ-{metrics['pvdA_baseline']['mean']:,.0f} בתנאי 20 mM Fe ל-{metrics['pvdA_signal']['mean']:,.0f} בתנאי -Fe. יחס האות/רעש המחושב הוא {metrics['pvdA_ratio']:.1f}:1, מעל סף 3:1.")
    add_heading(doc, "5.2 glnK - תגובה להרעבה לחנקן", 2)
    add_para(doc, f"פרומוטור glnK הראה תגובה חזקה לירידת זמינות חנקן. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מ-{metrics['glnK_baseline']['mean']:,.0f} בתנאי 10 mM N ל-{metrics['glnK_signal']['mean']:,.0f} בתנאי 2 mM N. יחס האות/רעש המחושב הוא {metrics['glnK_ratio']:.1f}:1, מעל סף 3:1.")
    add_heading(doc, "5.3 פוספט ואלקנים", 2)
    add_para(doc, "בדטקטורי פוספט, שני פרומוטורים קודמים לא סיפקו תגובה ספציפית מספקת, ושני פרומוטורים נוספים להרעבה של פוספט עדיין בבנייה. בדטקטור האלקנים, קיימת עדיין בעיית יציבות בקונסטרקט, ולכן אין עדיין מדידה כמותית תקפה לדירוג.")

    add_heading(doc, "6. נתוני 13.3 שעות - טבלת סיכום", 1)
    add_endpoint_table(doc, metrics)

    add_heading(doc, "7. גרפים תומכים", 1)
    add_picture_if_exists(doc, CHARTS / "pvdA_Fe_response.png", "איור 1. תגובת pvdA לתנאי ברזל לאורך זמן. האות עולה עם ירידת זמינות הברזל.")
    add_picture_if_exists(doc, CHARTS / "glnK_N_response.png", "איור 2. תגובת glnK לתנאי חנקן לאורך זמן. האות עולה עם ירידת ריכוז החנקן.")
    add_picture_if_exists(doc, CHARTS / "normalized_expression_13_3h.png", "איור 3. השוואת ביטוי מנורמל בנקודת זמן 13.3 שעות עבור תנאי pvdA ו-glnK.")

    add_heading(doc, "8. פערים להשלמת אבן הדרך", 1)
    add_bullet(doc, "להשלים בנייה ובדיקה של שני פרומוטורים נוספים להרעבה של פוספט.")
    add_bullet(doc, "לייצב את קונסטרקט דטקטור האלקנים לפני מדידה כמותית ודירוג.")
    add_bullet(doc, "להרחיב את הדירוג הכמותי לפחות לארבעה פרומוטורים פעילים עם יחס אות/רעש מעל 3:1.")
    add_bullet(doc, "לאמת את מדד 80% פעילות נמדדת לאחר שכל הקונסטרוקטים המתוכננים יהיו יציבים ויעברו מדידה באותו פורמט.")
    add_bullet(doc, "לשמור הפרדה בדיווח בין תוצאות GFP/פעילות ביולוגית קיימות לבין תוצאות לוציפראז עתידיות לאחר העברה לראמז.")

    add_heading(doc, "9. מסקנה", 1)
    add_para(doc, "הנתונים הקיימים תומכים בהתקדמות משמעותית באבן הדרך: שני פרומוטורים משובטים מציגים פעילות ביולוגית נמדדת, תגובת מינון ברורה ויחס אות/רעש גבוה מהסף הנדרש. עם זאת, אבן הדרך עדיין נמצאת בסטטוס חלקי, משום שנדרש דירוג של לפחות ארבעה פרומוטורים והוכחת פעילות עבור לפחות 80% מהקונסטרוקטים לאחר השלמת הבנייה והייצוב של יתר המערכות.")

    add_heading(doc, "נספח: מקורות נתונים והנחות עיבוד", 1)
    add_para(doc, "מקורות: yossi_20260610.xlsx, גיליונות Averages ו-Charts; קובצי הגרפים שיוצאו מהגיליון; עדכוני סטטוס שנמסרו על ידי המעבדה.")
    add_para(doc, "הנחת עיבוד: יחס אות/רעש חושב כאות ממוצע בתנאי אינדוקציה/מחסור החזק ביותר חלקי אות ממוצע בתנאי בסיס מתאים באותה סדרת מדידה. בקרות הדטקטור שימשו לנרמול וחיסור רקע לפי README של קובץ האקסל.")

    doc.save(OUT)
    print(str(OUT).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
