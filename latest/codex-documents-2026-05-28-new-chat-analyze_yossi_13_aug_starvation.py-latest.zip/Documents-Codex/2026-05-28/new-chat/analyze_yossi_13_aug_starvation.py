from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean, stdev

from openpyxl import load_workbook


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
OUT_JSON = Path("yossi_13_aug_normalized_analysis.json")


@dataclass
class WellRecord:
    read: int
    elapsed_h: float
    growth_time: str
    fluorescence_time: str
    condition: str
    construct: str
    replicate: str
    sample_well: str
    control_well: str
    growth_raw: float
    growth_control: float
    growth_subtracted: float
    fluorescence_raw: float
    fluorescence_control: float
    fluorescence_subtracted: float
    normalized_fluorescence_per_growth: float | None
    denominator_flag: str


def excel_time_to_hours(value) -> float:
    if hasattr(value, "hour"):
        return value.hour + value.minute / 60 + value.second / 3600
    if isinstance(value, (int, float)):
        return float(value) * 24
    raise TypeError(f"Unsupported time value: {value!r}")


def excel_time_to_text(value) -> str:
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    if isinstance(value, (int, float)):
        total_seconds = round(float(value) * 24 * 3600)
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    return str(value)


def read_measurement_block(ws, header_row: int, first_data_row: int, last_data_row: int) -> tuple[list[str], list[dict[str, float]]]:
    raw_rows = list(ws.iter_rows(min_row=header_row, max_row=last_data_row, values_only=True))
    headers = list(raw_rows[0])
    header_map = {str(name): idx for idx, name in enumerate(headers) if name}
    wells = [h for h in header_map if len(h) in (2, 3) and h[0] in "ABCDEFGH" and h[1:].isdigit()]
    rows: list[dict[str, float]] = []
    for row in raw_rows[first_data_row - header_row :]:
        rec: dict[str, float] = {
            "_time": row[1],
        }
        for well in wells:
            value = row[header_map[well]]
            if isinstance(value, (int, float)):
                rec[well] = float(value)
        rows.append(rec)
    return wells, rows


def build_well_map() -> list[dict[str, str]]:
    groups = [
        ("M9", 1, "pupxA", 3),
        ("M9", 2, "pupxB", 3),
        ("M9 0.5P", 4, "pupxA", 6),
        ("M9 0.5P", 5, "pupxB", 6),
        ("M9 -P", 7, "pupxA", 9),
        ("M9 -P", 8, "pupxB", 9),
    ]
    records = []
    for row in "BCDEFG":
        for condition, sample_col, construct, control_col in groups:
            records.append(
                {
                    "condition": condition,
                    "construct": construct,
                    "replicate": row,
                    "sample_well": f"{row}{sample_col}",
                    "control_well": f"{row}{control_col}",
                }
            )
    return records


def safe_mean(values: list[float | None]) -> float | None:
    nums = [v for v in values if v is not None and math.isfinite(v)]
    return mean(nums) if nums else None


def safe_sd(values: list[float | None]) -> float | None:
    nums = [v for v in values if v is not None and math.isfinite(v)]
    return stdev(nums) if len(nums) > 1 else None


def main() -> None:
    source = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE_NAME
    wb = load_workbook(source, data_only=True, read_only=True)
    ws = wb["Plate 1 - Sheet1"]

    growth_wells, growth_rows = read_measurement_block(ws, 51, 52, 69)
    fluor_wells, fluor_rows = read_measurement_block(ws, 87, 88, 105)
    if len(growth_rows) != len(fluor_rows):
        raise RuntimeError("Growth and fluorescence blocks have different read counts.")

    well_map = build_well_map()
    normalized_records: list[WellRecord] = []
    for read_idx, (g_row, f_row) in enumerate(zip(growth_rows, fluor_rows), start=1):
        elapsed = excel_time_to_hours(g_row["_time"])
        for item in well_map:
            sample = item["sample_well"]
            control = item["control_well"]
            growth_raw = g_row[sample]
            growth_control = g_row[control]
            fluorescence_raw = f_row[sample]
            fluorescence_control = f_row[control]
            growth_sub = growth_raw - growth_control
            fluor_sub = fluorescence_raw - fluorescence_control
            flag = ""
            normalized = None
            if abs(growth_sub) < 1e-9:
                flag = "zero growth denominator"
            else:
                normalized = fluor_sub / growth_sub
                if growth_sub < 0:
                    flag = "negative growth denominator"
            normalized_records.append(
                WellRecord(
                    read=read_idx,
                    elapsed_h=elapsed,
                    growth_time=excel_time_to_text(g_row["_time"]),
                    fluorescence_time=excel_time_to_text(f_row["_time"]),
                    condition=item["condition"],
                    construct=item["construct"],
                    replicate=item["replicate"],
                    sample_well=sample,
                    control_well=control,
                    growth_raw=growth_raw,
                    growth_control=growth_control,
                    growth_subtracted=growth_sub,
                    fluorescence_raw=fluorescence_raw,
                    fluorescence_control=fluorescence_control,
                    fluorescence_subtracted=fluor_sub,
                    normalized_fluorescence_per_growth=normalized,
                    denominator_flag=flag,
                )
            )

    summary_rows: list[dict[str, float | str | int | None]] = []
    for read_idx in range(1, len(growth_rows) + 1):
        read_records = [r for r in normalized_records if r.read == read_idx]
        elapsed = read_records[0].elapsed_h
        gtime = read_records[0].growth_time
        ftime = read_records[0].fluorescence_time
        for condition in ["M9", "M9 0.5P", "M9 -P"]:
            for construct in ["pupxA", "pupxB"]:
                records = [r for r in read_records if r.condition == condition and r.construct == construct]
                vals = [r.normalized_fluorescence_per_growth for r in records]
                growth_vals = [r.growth_subtracted for r in records]
                fluor_vals = [r.fluorescence_subtracted for r in records]
                valid = [v for v in vals if v is not None and math.isfinite(v)]
                summary_rows.append(
                    {
                        "read": read_idx,
                        "elapsed_h": elapsed,
                        "growth_time": gtime,
                        "fluorescence_time": ftime,
                        "condition": condition,
                        "construct": construct,
                        "n_total": len(records),
                        "n_valid": len(valid),
                        "mean_growth_subtracted": safe_mean(growth_vals),
                        "sd_growth_subtracted": safe_sd(growth_vals),
                        "mean_fluorescence_subtracted": safe_mean(fluor_vals),
                        "sd_fluorescence_subtracted": safe_sd(fluor_vals),
                        "mean_normalized": safe_mean(vals),
                        "sd_normalized": safe_sd(vals),
                        "negative_denominators": sum(1 for r in records if r.growth_subtracted < 0),
                    }
                )

    endpoint_rows = [r for r in summary_rows if r["read"] == len(growth_rows)]
    output = {
        "source": str(source),
        "sheet": ws.title,
        "normalization": "(GFP_sample - GFP_control_same_condition_same_row) / (OD595_sample - OD595_control_same_condition_same_row)",
        "well_map": well_map,
        "normalized_records": [asdict(r) for r in normalized_records],
        "summary_rows": summary_rows,
        "endpoint_rows": endpoint_rows,
    }
    OUT_JSON.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT_JSON.resolve())
    print("records", len(normalized_records), "summary", len(summary_rows))
    print("endpoint")
    for row in endpoint_rows:
        print(row)


if __name__ == "__main__":
    main()
