from __future__ import annotations

import re
import shutil
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


LRM = "\u200e"
RLM = "\u200f"
HEBREW_RE = re.compile(r"[\u0590-\u05ff]")
LTR_TOKEN_RE = re.compile(
    r"(?<!\u200e)("
    r"-?[A-Za-z][A-Za-z0-9_./-]*"
    r"|[0-9]+(?:[.,][0-9]+)?(?:%|:[0-9]+)?"
    r"|[<>]=?"
    r")(?!\u200e)"
)


def find_target_docx() -> Path:
    root = Path.home() / ".codex"
    matches: list[Path] = []
    for path in root.rglob("*.docx"):
        if "backup before bidi fix" in path.name:
            continue
        try:
            doc = Document(path)
        except Exception:
            continue
        text = "\n".join(p.text for p in doc.paragraphs)
        if "pvdA" in text and "glnK" in text and "3:1" in text:
            matches.append(path)
    if not matches:
        raise FileNotFoundError("Could not find the promoter milestone DOCX.")
    return max(matches, key=lambda p: p.stat().st_mtime)


def ensure_child(parent, tag: str) -> OxmlElement:
    child = parent.find(qn(tag))
    if child is None:
        child = OxmlElement(tag)
        parent.append(child)
    return child


def set_paragraph_rtl(paragraph) -> None:
    if paragraph.alignment is None:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_pr = paragraph._p.get_or_add_pPr()
    ensure_child(p_pr, "w:bidi")


def set_run_bidi(run) -> None:
    r_pr = run._element.get_or_add_rPr()
    fonts = ensure_child(r_pr, "w:rFonts")
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        fonts.set(qn(attr), "Arial")
    lang = ensure_child(r_pr, "w:lang")
    lang.set(qn("w:bidi"), "he-IL")
    if HEBREW_RE.search(run.text or ""):
        ensure_child(r_pr, "w:rtl")


def protect_mixed_direction_text(text: str) -> str:
    if not text:
        return text
    cleaned = text.replace(LRM, "").replace(RLM, "")
    return LTR_TOKEN_RE.sub(lambda match: f"{LRM}{match.group(1)}{LRM}", cleaned)


def patch_paragraph(paragraph) -> None:
    set_paragraph_rtl(paragraph)
    for run in paragraph.runs:
        if run.text:
            fixed = protect_mixed_direction_text(run.text)
            if fixed != run.text:
                run.text = fixed
        set_run_bidi(run)


def patch_table(table) -> None:
    tbl_pr = table._tbl.tblPr
    ensure_child(tbl_pr, "w:bidiVisual")
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                patch_paragraph(paragraph)
            for nested in cell.tables:
                patch_table(nested)


def patch_styles(doc: Document) -> None:
    for name in ("Normal", "Heading 1", "Heading 2", "Heading 3", "List Bullet"):
        if name not in doc.styles:
            continue
        style = doc.styles[name]
        if not hasattr(style, "_element"):
            continue
        p_pr = style._element.get_or_add_pPr()
        ensure_child(p_pr, "w:bidi")
        r_pr = style._element.get_or_add_rPr()
        fonts = ensure_child(r_pr, "w:rFonts")
        for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            fonts.set(qn(attr), "Arial")
        lang = ensure_child(r_pr, "w:lang")
        lang.set(qn("w:bidi"), "he-IL")


def patch_settings(doc: Document) -> None:
    settings = doc._part.settings.element
    lang = ensure_child(settings, "w:themeFontLang")
    lang.set(qn("w:val"), "en-US")
    lang.set(qn("w:eastAsia"), "he-IL")
    lang.set(qn("w:bidi"), "he-IL")


def main() -> None:
    target = find_target_docx()
    backup = target.with_name(target.stem + " - backup before bidi fix.docx")
    if not backup.exists():
        shutil.copy2(target, backup)

    doc = Document(target)
    patch_settings(doc)
    patch_styles(doc)

    for paragraph in doc.paragraphs:
        patch_paragraph(paragraph)
    for section in doc.sections:
        for paragraph in section.header.paragraphs:
            patch_paragraph(paragraph)
        for paragraph in section.footer.paragraphs:
            patch_paragraph(paragraph)
    for table in doc.tables:
        patch_table(table)

    doc.save(target)
    print(str(target).encode("unicode_escape").decode("ascii"))
    print(str(backup).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
