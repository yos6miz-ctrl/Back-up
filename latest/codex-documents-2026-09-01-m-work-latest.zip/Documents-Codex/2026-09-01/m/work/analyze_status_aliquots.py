from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m")
LIVE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
VERSIONS = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Excel file editor\deta\Final Known and Unknown merged.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\דוח כמין\Final Known and Unknown merged.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Excel file editor\Final Known and Unknown merged.xlsx"),
    ROOT / r"outputs\onedrive_synced_20260902\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\consistent_measurement_marking_20260902\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\classifier_decisions_20260902\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\final_layout_warning_update_20260903\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\repeat_logic_update_20260903\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\two_measurement_conflict_repeat_20260903\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\final_decision_color_fix_20260903\Final Known and Unknown merged.xlsx",
    ROOT / r"outputs\new_repeat_files_20260903\Final Known and Unknown merged.xlsx",
    LIVE,
]
ALIQUOT_FILES = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Excel file editor\deta\aliqauts 20250112.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Old sampels\Stool aliquots updated.xlsx"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Old sampels\All Stool aliquots updated 10.8.23.xlsx"),
]


def text(v):
    return "" if v is None else str(v).strip()


def norm(v):
    return re.sub(r"[^A-Z0-9]", "", text(v).upper())


def argb(color):
    if color is None:
        return None
    if getattr(color, "type", None) == "rgb":
        return color.rgb
    if getattr(color, "type", None) == "indexed":
        return f"indexed:{color.indexed}"
    if getattr(color, "type", None) == "theme":
        return f"theme:{color.theme}:{color.tint}"
    return str(color.type)


def row_key(ws, r):
    return (text(ws.cell(r, 1).value), text(ws.cell(r, 2).value))


def sample_label(ws, r):
    a, b = row_key(ws, r)
    return f"{a} | {b}" if b else a


def find_header_row(values):
    for r, row in enumerate(values[:20], start=1):
        vals = [text(v).lower() for v in row]
        if any("primary" in v or "sample" in v or "ראש" in v for v in vals) and sum(bool(v) for v in vals) >= 3:
            return r
    return 1


def summarize_version(path):
    wb = load_workbook(path, data_only=False, read_only=True)
    record = {"path": str(path), "sheets": [], "not_tested": []}
    for ws in wb.worksheets:
        max_col = min(ws.max_column or 1, 35)
        values = list(ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, 1000), max_col=max_col, values_only=True))
        hdr = find_header_row(values)
        headers = [text(v) for v in values[hdr - 1]] if values else []
        counts_c = Counter()
        counts_e = Counter()
        for r, raw_row in enumerate(values[hdr:], start=hdr + 1):
            vals = [text(v) for v in raw_row]
            if not any(vals):
                continue
            cval = vals[2] if len(vals) >= 3 else ""
            eval_ = vals[4] if len(vals) >= 5 else ""
            counts_c[cval] += 1
            counts_e[eval_] += 1
            if cval == "לא נבדק" or eval_ == "לא נבדק" or any(v == "לא נבדק" for v in vals):
                record["not_tested"].append({
                    "sheet": ws.title,
                    "row": r,
                    "A": vals[0] if vals else "",
                    "B": vals[1] if len(vals) >= 2 else "",
                    "C": cval,
                    "E": eval_,
                })
        record["sheets"].append({
            "name": ws.title,
            "dimensions": f"{ws.max_row}x{ws.max_column}",
            "header_row": hdr,
            "headers": headers,
            "status_C": counts_c,
            "decision_E": counts_e,
        })
    wb.close()
    return record


def current_detail(path):
    wb = load_workbook(path, data_only=False, read_only=False)
    result = {"rows": [], "ct606": None}
    for ws in wb.worksheets:
        for r in range(2, min(ws.max_row, 1000) + 1):
            a, b = row_key(ws, r)
            cval = text(ws.cell(r, 3).value)
            yellow_cells = []
            for col in list(range(8, 16)) + list(range(17, 23)):
                cell = ws.cell(r, col)
                fill = argb(cell.fill.fgColor)
                if fill and fill.upper().endswith("FFD966"):
                    yellow_cells.append(cell.coordinate)
            if cval == "missing" or yellow_cells:
                result["rows"].append({
                    "sheet": ws.title,
                    "row": r,
                    "A": a,
                    "B": b,
                    "status": cval,
                    "status_fill": argb(ws.cell(r, 3).fill.fgColor),
                    "yellow_measurements": yellow_cells,
                })
            if norm(a) == "CT606" or norm(b) in {"CT606", "HS606"}:
                fonts = {}
                for col in range(1, 28):
                    cell = ws.cell(r, col)
                    fonts[cell.coordinate] = {
                        "value": text(cell.value),
                        "style_id": cell.style_id,
                        "name": cell.font.name,
                        "size": cell.font.sz,
                        "bold": cell.font.b,
                        "italic": cell.font.i,
                        "color": argb(cell.font.color),
                        "fill": argb(cell.fill.fgColor),
                    }
                result["ct606"] = {"sheet": ws.title, "row": r, "fonts": fonts}
    wb.close()
    return result


def aliquot_summary(path):
    wb = load_workbook(path, data_only=True, read_only=True)
    rec = {"path": str(path), "sheets": []}
    for ws in wb.worksheets:
        max_col = min(ws.max_column or 1, 25)
        values = list(ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, 1000), max_col=max_col, values_only=True))
        rows = []
        for raw_row in values[:12]:
            rows.append([text(v) for v in raw_row[:20]])
        ct606 = []
        for r, raw_row in enumerate(values, start=1):
            vals = [text(v) for v in raw_row]
            joined = "|".join(norm(v) for v in vals)
            if "CT606" in joined or "HS606" in joined:
                ct606.append({"row": r, "values": vals})
        rec["sheets"].append({"name": ws.title, "dimensions": f"{ws.max_row}x{ws.max_column}", "first_rows": rows, "ct606": ct606})
    wb.close()
    return rec


out = {
    "versions": [summarize_version(p) for p in VERSIONS if p.exists()],
    "current": current_detail(LIVE),
    "aliquot_files": [aliquot_summary(p) for p in ALIQUOT_FILES if p.exists()],
}
out_path = ROOT / r"work\status_aliquot_analysis.json"
out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2, default=lambda x: dict(x)), encoding="utf-8")
print(out_path)
