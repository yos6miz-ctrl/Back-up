import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "file:///C:/Users/Popovtzer%20lab/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs";

const workbookPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/aliquot_status_and_font_fix_20260903/Final Known and Unknown merged.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/aliquot_status_after";
await fs.mkdir(previewDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));

const styles = [];
for (const [sheetId, range] of [
  ["Older samples - before 2021", "A168:E190"],
  ["2021 onward", "A140:E158"],
]) {
  const result = await workbook.inspect({ kind: "computedStyle", sheetId, range, maxChars: 12000 });
  styles.push({ sheetId, range, ndjson: result.ndjson });
}
await fs.writeFile(`${previewDir}/computed_styles.json`, JSON.stringify(styles, null, 2));

const formulaScan = await workbook.inspect({ kind: "formula", maxChars: 8000, options: { maxResults: 200 } });
await fs.writeFile(`${previewDir}/formula_scan.ndjson`, formulaScan.ndjson ?? "");

for (const [sheetName, range, fileName] of [
  ["Older samples - before 2021", "A163:H190", "older_missing_and_ct606.png"],
  ["Older samples - before 2021", "A25:C45", "older_empty_statuses_1.png"],
  ["Older samples - before 2021", "A88:C145", "older_empty_statuses_2.png"],
  ["2021 onward", "A15:C50", "onward_empty_statuses.png"],
  ["2021 onward", "A138:E158", "onward_missing_and_not_tested.png"],
]) {
  const blob = await workbook.render({ sheetName, range, scale: 1.8, format: "png" });
  await fs.writeFile(`${previewDir}/${fileName}`, new Uint8Array(await blob.arrayBuffer()));
}

console.log(JSON.stringify({ previewDir, formulaScanChars: (formulaScan.ndjson ?? "").length }, null, 2));
