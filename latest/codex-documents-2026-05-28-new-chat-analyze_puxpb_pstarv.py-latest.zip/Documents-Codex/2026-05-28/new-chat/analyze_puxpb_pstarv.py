from pathlib import Path

import numpy as np
import pandas as pd


PATH = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה\03_חישה ודטקטורים\YOSSI  P starv  18.8.xlsx")
df = pd.read_excel(PATH, sheet_name="Sheet1", header=None)

conditions = [str(x).strip() for x in df.iloc[0, 1:12].tolist()]
time_labels = list(range(18))

records = []
for t in range(18):
    start = t * 8
    g = df.iloc[start + 1 : start + 7, 1:12].astype(float).to_numpy()
    f_start = 144 + t * 8
    fl = df.iloc[f_start + 1 : f_start + 7, 1:12].astype(float).to_numpy()

    growth_control = g[:, -1]
    fl_control = fl[:, -1]
    for idx, cond in enumerate(conditions[:-1]):
        growth = g[:, idx] - growth_control
        signal = fl[:, idx] - fl_control
        norm = signal / growth
        records.append(
            {
                "time_index": t,
                "condition": cond,
                "mean": float(np.nanmean(norm)),
                "sd": float(np.nanstd(norm, ddof=1)),
                "n": int(np.sum(np.isfinite(norm))),
            }
        )

out = pd.DataFrame(records)
puxpb = out[out["condition"].str.startswith("puxpB")].copy()
baseline = puxpb[puxpb["condition"].eq("puxpB M9")][["time_index", "mean", "sd"]].rename(
    columns={"mean": "baseline_mean", "sd": "baseline_sd"}
)
puxpb = puxpb.merge(baseline, on="time_index", how="left")
puxpb["fold_vs_m9"] = puxpb["mean"] / puxpb["baseline_mean"]
print(puxpb.to_string(index=False, float_format=lambda x: f"{x:,.2f}"))
print("\nBest fold:")
print(puxpb.sort_values("fold_vs_m9", ascending=False).head(12).to_string(index=False, float_format=lambda x: f"{x:,.2f}"))
