from __future__ import annotations

import json
import math
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as XLImage
from PIL import Image, ImageDraw, ImageFont


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
ANALYSIS_JSON = Path("yossi_13_aug_normalized_analysis.json")
OUT_DIR = Path.home() / ".codex" / PROJECT / "starvation"
OUT_XLSX = OUT_DIR / "YOSSI 13.8.26 normalized analysis.xlsx"
NORM_PNG = OUT_DIR / "YOSSI 13.8.26 normalized curves.png"
RAW_PNG = OUT_DIR / "YOSSI 13.8.26 control subtracted curves.png"

BLUE = "1F4E79"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREEN = "E2F0D9"
LIGHT_ORANGE = "FCE4D6"
GRAY = "F2F2F2"
WHITE = "FFFFFF"
BORDER = Side(style="thin", color="D9E2F3")


def clean_sheet_name(name: str) -> str:
    return name[:31]


def finite(value) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(value)


def write_table(ws, start_row: int, start_col: int, headers: list[str], rows: list[list], title: str | None = None) -> int:
    row_idx = start_row
    if title:
        ws.cell(row_idx, start_col, title)
        ws.cell(row_idx, start_col).font = Font(bold=True, size=13, color=BLUE)
        row_idx += 1
    for c, header in enumerate(headers, start_col):
        cell = ws.cell(row_idx, c, header)
        cell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
        cell.font = Font(bold=True, color=BLUE)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=BORDER)
    for r_offset, row in enumerate(rows, row_idx + 1):
        for c, value in enumerate(row, start_col):
            cell = ws.cell(r_offset, c, value)
            cell.alignment = Alignment(vertical="center", wrap_text=False)
            if isinstance(value, float):
                cell.number_format = "0.000"
            if value == "negative growth denominator" or value == "zero growth denominator":
                cell.fill = PatternFill("solid", fgColor=LIGHT_ORANGE)
    return row_idx + len(rows)


def autofit(ws, min_width=9, max_width=32) -> None:
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        max_len = 0
        for cell in col:
            value = "" if cell.value is None else str(cell.value)
            max_len = max(max_len, len(value))
        ws.column_dimensions[letter].width = min(max(max_len + 2, min_width), max_width)


def build_chart_data(summary_rows: list[dict]) -> tuple[list[str], list[str], list[list]]:
    times = sorted({round(r["elapsed_h"], 6) for r in summary_rows})
    series = []
    for condition in ["M9", "M9 0.5P", "M9 -P"]:
        for construct in ["pupxA", "pupxB"]:
            series.append(f"{condition} | {construct}")
    lookup = {
        (round(r["elapsed_h"], 6), f"{r['condition']} | {r['construct']}"): r
        for r in summary_rows
    }
    rows = []
    for t in times:
        row = [t]
        for s in series:
            row.append(lookup[(t, s)]["mean_normalized"])
        rows.append(row)
    return ["Elapsed h"] + series, series, rows


def build_measurement_chart_data(summary_rows: list[dict], field: str) -> tuple[list[str], list[list]]:
    times = sorted({round(r["elapsed_h"], 6) for r in summary_rows})
    series = []
    for condition in ["M9", "M9 0.5P", "M9 -P"]:
        for construct in ["pupxA", "pupxB"]:
            series.append(f"{condition} | {construct}")
    lookup = {
        (round(r["elapsed_h"], 6), f"{r['condition']} | {r['construct']}"): r
        for r in summary_rows
    }
    rows = []
    for t in times:
        rows.append([t] + [lookup[(t, s)][field] for s in series])
    return ["Elapsed h"] + series, rows


def add_line_chart(ws, anchor: str, title: str, data_min_row: int, data_max_row: int, data_min_col: int, data_max_col: int, y_title: str) -> None:
    chart = LineChart()
    chart.title = title
    chart.style = 13
    chart.y_axis.title = y_title
    chart.x_axis.title = "Elapsed time (h)"
    chart.height = 10
    chart.width = 22
    data = Reference(ws, min_col=data_min_col + 1, max_col=data_max_col, min_row=data_min_row, max_row=data_max_row)
    cats = Reference(ws, min_col=data_min_col, min_row=data_min_row + 1, max_row=data_max_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.legend.position = "r"
    ws.add_chart(chart, anchor)


def plot_pngs(summary_rows: list[dict]) -> None:
    colors = {
        "M9 | pupxA": "#1f77b4",
        "M9 | pupxB": "#ff7f0e",
        "M9 0.5P | pupxA": "#2ca02c",
        "M9 0.5P | pupxB": "#d62728",
        "M9 -P | pupxA": "#9467bd",
        "M9 -P | pupxB": "#8c564b",
    }
    def font(size: int, bold: bool = False):
        candidates = [
            "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
        ]
        for candidate in candidates:
            try:
                return ImageFont.truetype(candidate, size)
            except OSError:
                pass
        return ImageFont.load_default()

    def draw_chart(path: Path, field: str, title: str, y_label: str, size=(1500, 850)) -> None:
        img = Image.new("RGB", size, "white")
        draw = ImageDraw.Draw(img)
        title_font = font(34, True)
        axis_font = font(20)
        tick_font = font(17)
        legend_font = font(19)
        left, top, right, bottom = 125, 125, size[0] - 365, size[1] - 105
        draw.text((left, 24), title, fill="#1F4E79", font=title_font)
        times = sorted({float(r["elapsed_h"]) for r in summary_rows})
        series_rows = {}
        values = []
        for condition in ["M9", "M9 0.5P", "M9 -P"]:
            for construct in ["pupxA", "pupxB"]:
                label = f"{condition} | {construct}"
                rows = sorted([r for r in summary_rows if r["condition"] == condition and r["construct"] == construct], key=lambda r: r["elapsed_h"])
                vals = [(float(r["elapsed_h"]), r[field]) for r in rows if finite(r[field])]
                series_rows[label] = vals
                values.extend(v for _, v in vals)
        y_min = min(values)
        y_max = max(values)
        if y_min == y_max:
            y_min -= 1
            y_max += 1
        pad = (y_max - y_min) * 0.08
        y_min -= pad
        y_max += pad
        x_min, x_max = min(times), max(times)

        def xmap(x):
            return left + (x - x_min) / (x_max - x_min) * (right - left)

        def ymap(y):
            return bottom - (y - y_min) / (y_max - y_min) * (bottom - top)

        for i in range(6):
            y = top + i * (bottom - top) / 5
            draw.line((left, y, right, y), fill="#E5E7EB", width=1)
            value = y_max - i * (y_max - y_min) / 5
            draw.text((20, y - 10), f"{value:,.0f}" if abs(value) >= 100 else f"{value:.2f}", fill="#374151", font=tick_font)
        for i in range(0, len(times), max(1, len(times) // 8)):
            x = xmap(times[i])
            draw.line((x, bottom, x, bottom + 6), fill="#374151", width=1)
            draw.text((x - 20, bottom + 12), f"{times[i]:.1f}", fill="#374151", font=tick_font)
        draw.rectangle((left, top, right, bottom), outline="#374151", width=2)
        draw.text(((left + right) / 2 - 70, size[1] - 48), "Elapsed time (h)", fill="#111827", font=axis_font)
        draw.text((left, 72), y_label, fill="#111827", font=axis_font)

        for idx, (label, vals) in enumerate(series_rows.items()):
            pts = [(xmap(x), ymap(y)) for x, y in vals]
            if len(pts) > 1:
                draw.line(pts, fill=colors[label], width=4)
            for x, y in pts:
                draw.ellipse((x - 4, y - 4, x + 4, y + 4), fill=colors[label], outline="white", width=1)
            lx, ly = right + 32, top + idx * 42
            draw.line((lx, ly + 12, lx + 28, ly + 12), fill=colors[label], width=5)
            draw.text((lx + 40, ly), label, fill="#111827", font=legend_font)
        img.save(path)

    draw_chart(NORM_PNG, "mean_normalized", "Normalized promoter response curves", "GFP/OD595")
    draw_chart(RAW_PNG, "mean_fluorescence_subtracted", "Control-subtracted GFP curves", "GFP RFU")


def main() -> None:
    data = json.loads(ANALYSIS_JSON.read_text(encoding="utf-8"))
    well_map = data["well_map"]
    records = data["normalized_records"]
    summary_rows = data["summary_rows"]
    endpoint_rows = data["endpoint_rows"]
    plot_pngs(summary_rows)

    wb = Workbook()
    ws = wb.active
    ws.title = "README"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "YOSSI 13.8.26 normalized analysis"
    ws["A1"].font = Font(bold=True, size=16, color=BLUE)
    ws["A3"] = "Source"
    ws["B3"] = data["source"]
    ws["A4"] = "Sheet"
    ws["B4"] = data["sheet"]
    ws["A5"] = "Normalization"
    ws["B5"] = data["normalization"]
    ws["A6"] = "Control pairing"
    ws["B6"] = "Each sample well is paired to the Control well in the same plate row and medium condition."
    ws["A7"] = "Important caveat"
    ws["B7"] = "Some control-subtracted OD595 denominators are negative or close to zero; see denominator_flag and negative_denominators."
    for cell in ws["A3:A7"]:
        cell[0].font = Font(bold=True, color=BLUE)
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 110

    map_ws = wb.create_sheet("Well map")
    map_ws.sheet_view.showGridLines = False
    map_headers = ["condition", "construct", "replicate", "sample_well", "control_well"]
    map_rows = [[r[h] for h in map_headers] for r in well_map]
    write_table(map_ws, 1, 1, map_headers, map_rows, "Parsed well map")
    autofit(map_ws)
    map_ws.freeze_panes = "A3"

    norm_ws = wb.create_sheet("Normalized wells")
    norm_ws.sheet_view.showGridLines = False
    norm_headers = [
        "read", "elapsed_h", "growth_time", "fluorescence_time", "condition", "construct", "replicate",
        "sample_well", "control_well", "growth_raw", "growth_control", "growth_subtracted",
        "fluorescence_raw", "fluorescence_control", "fluorescence_subtracted",
        "normalized_fluorescence_per_growth", "denominator_flag",
    ]
    norm_rows = [[r.get(h) for h in norm_headers] for r in records]
    write_table(norm_ws, 1, 1, norm_headers, norm_rows, "Per-well normalized values")
    autofit(norm_ws, max_width=26)
    norm_ws.freeze_panes = "A3"

    summary_ws = wb.create_sheet("Mean curves")
    summary_ws.sheet_view.showGridLines = False
    summary_headers = [
        "read", "elapsed_h", "growth_time", "fluorescence_time", "condition", "construct",
        "n_total", "n_valid", "mean_growth_subtracted", "sd_growth_subtracted",
        "mean_fluorescence_subtracted", "sd_fluorescence_subtracted",
        "mean_normalized", "sd_normalized", "negative_denominators",
    ]
    summary_table_rows = [[r.get(h) for h in summary_headers] for r in summary_rows]
    write_table(summary_ws, 1, 1, summary_headers, summary_table_rows, "Mean curves by condition and construct")
    autofit(summary_ws, max_width=28)
    summary_ws.freeze_panes = "A3"

    endpoint_ws = wb.create_sheet("Endpoint")
    endpoint_ws.sheet_view.showGridLines = False
    endpoint_rows_values = [[r.get(h) for h in summary_headers] for r in endpoint_rows]
    write_table(endpoint_ws, 1, 1, summary_headers, endpoint_rows_values, "Endpoint summary at final read")
    autofit(endpoint_ws, max_width=28)

    chart_ws = wb.create_sheet("Charts")
    chart_ws.sheet_view.showGridLines = False
    chart_ws["A1"] = "Chart data and curves"
    chart_ws["A1"].font = Font(bold=True, size=15, color=BLUE)

    norm_headers2, series, norm_curve_rows = build_chart_data(summary_rows)
    norm_start = 3
    write_table(chart_ws, norm_start, 1, norm_headers2, norm_curve_rows, "Normalized mean curves")
    norm_data_header_row = norm_start + 1
    norm_data_max_row = norm_start + len(norm_curve_rows) + 1
    add_line_chart(chart_ws, "J3", "Normalized response curves", norm_data_header_row, norm_data_max_row, 1, len(norm_headers2), "GFP/OD595")

    growth_headers, growth_rows = build_measurement_chart_data(summary_rows, "mean_growth_subtracted")
    growth_start = norm_data_max_row + 4
    write_table(chart_ws, growth_start, 1, growth_headers, growth_rows, "Control-subtracted OD595")
    growth_header_row = growth_start + 1
    growth_max_row = growth_start + len(growth_rows) + 1
    add_line_chart(chart_ws, f"J{growth_start}", "Control-subtracted OD595 curves", growth_header_row, growth_max_row, 1, len(growth_headers), "OD595")

    fluor_headers, fluor_rows = build_measurement_chart_data(summary_rows, "mean_fluorescence_subtracted")
    fluor_start = growth_max_row + 4
    write_table(chart_ws, fluor_start, 1, fluor_headers, fluor_rows, "Control-subtracted GFP")
    fluor_header_row = fluor_start + 1
    fluor_max_row = fluor_start + len(fluor_rows) + 1
    add_line_chart(chart_ws, f"J{fluor_start}", "Control-subtracted GFP curves", fluor_header_row, fluor_max_row, 1, len(fluor_headers), "GFP RFU")
    autofit(chart_ws, max_width=22)

    figures_ws = wb.create_sheet("Figure exports")
    figures_ws.sheet_view.showGridLines = False
    figures_ws["A1"] = "Exported PNG figures"
    figures_ws["A1"].font = Font(bold=True, size=15, color=BLUE)
    figures_ws.add_image(XLImage(str(NORM_PNG)), "A3")
    figures_ws.add_image(XLImage(str(RAW_PNG)), "A34")
    figures_ws.column_dimensions["A"].width = 18

    for ws2 in wb.worksheets:
        for row in ws2.iter_rows():
            for cell in row:
                if isinstance(cell.value, float):
                    cell.number_format = "0.000"

    wb.save(OUT_XLSX)
    print(str(OUT_XLSX).encode("unicode_escape").decode("ascii"))
    print(str(NORM_PNG).encode("unicode_escape").decode("ascii"))
    print(str(RAW_PNG).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
