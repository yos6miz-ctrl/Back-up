$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$base = Join-Path $env:USERPROFILE ".codex\אדמה ירוקה"
$source = Join-Path $base "דוח טכנולוגי.doc"
$output = Join-Path $base "דוח טכנולוגי - טיוטה ממולאת.doc"

function Set-CellText {
    param(
        [Parameter(Mandatory=$true)] $Table,
        [Parameter(Mandatory=$true)] [int] $Row,
        [Parameter(Mandatory=$true)] [int] $Column,
        [Parameter(Mandatory=$true)] [string] $Text
    )
    $range = $Table.Cell($Row, $Column).Range
    $range.End = $range.End - 1
    $range.Text = $Text
    $range.ParagraphFormat.ReadingOrder = 1
    $range.ParagraphFormat.Alignment = 2
    $range.Font.NameBi = "Arial"
    $range.Font.Name = "Arial"
}

function Add-DataRow {
    param(
        [Parameter(Mandatory=$true)] $Table
    )
    [void]$Table.Rows.Add()
}

$companyName = "מעבדת בנין, אוניברסיטת בר-אילן"

$tasks = @(
    @{
        Name = "קבוצה 1 - התאמת UPO19 לביטוי והפרשה ב-Pseudomonas putida"
        Status = "כ-55% - התקבלו הזנים מליאנט, הפלסמידים רוצפו, זוהה חסם התאמה לביטוי ב-P. putida, ונבנה רצף UPO19 מותאם קודונים עם SP ו-His-tag. הקונסטרקטים נשלחו לריצוף."
    },
    @{
        Name = "קבוצה 1 - בניית מערכת ביטוי קונסטיטוטיבית ואינדוסבילית"
        Status = "כ-50% - הרצף הוחדר לשני וקטורים: pBBR1mcs-2 לביטוי קונסטיטוטיבי ו-pJN105 לביטוי אינדוסבילי תחת פרומוטור ארבינוז. ממתינים לאישור ריצוף לפני מעבר לביטוי ואפיון."
    },
    @{
        Name = "קבוצה 3 - פיתוח דטקטורי הרעבה לחנקן, ברזל ופוספט"
        Status = "כ-70% - נבנו דטקטורים מגיבי הרעבה לחנקן ולברזל ונמדדה תגובת GFP. עבור פוספט נבדקו שני פרומוטורים ללא תגובה ספציפית מספקת; קונסטרקט שלישי נמצא בבנייה."
    },
    @{
        Name = "קבוצה 3 - פיתוח דטקטור אלקנים והתאמת קריאות"
        Status = "כ-35% - הפלסמידים הסביבתיים הרלוונטיים בידינו, והדטקטור עם רצפטור וגן דיווח נמצא בבנייה. במקביל מועברים זנים עובדים למערכות קריאה אלקטרוכימית ולומינסנטית."
    }
)

$details = @(
    @{
        Activity = "התאמת UPO19 לביטוי והפרשה"
        Partner = "ליאנט"
        Products = "ריצוף פלסמידים; רצף UPO19 מותאם קודונים ל-P. putida; הוספת SP ו-His-tag; בניית קונסטרקטים."
        Transfer = "המשך ריצוף, ביטוי ב-P. putida, בדיקת הפרשה וניקוי האנזים."
        Description = "לאחר קבלת הזנים והפלסמידים מליאנט בוצע ריצוף לפלסמידים שנמצאו ב-E. coli. נמצא כי רצפי המקור בעלי אחוז GC נמוך, סביב 30%, ולכן אינם אופטימליים לביטוי ב-P. putida. בהתאם לכך סונתז רצף חדש השומר על רצף החלבון של UPO19 אך מותאם קודונים ל-P. putida, עם signal peptide לעידוד הפרשה חוץ-תאית ו-His-tag לניקוי בשלבי ההמשך."
    },
    @{
        Activity = "בניית וקטורי ביטוי ל-UPO19"
        Partner = "ליאנט"
        Products = "שני וקטורי ביטוי: pBBR1mcs-2 קונסטיטוטיבי ו-pJN105 אינדוסבילי."
        Transfer = "אישור ריצוף ולאחריו ביטוי, הפרשה ואפיון פעילות."
        Description = "הרצף האופטימלי הוחדר לשני פלסמידים משלימים: pBBR1mcs-2 לביטוי קונסטיטוטיבי ו-pJN105 לביטוי אינדוסבילי תחת פרומוטור ארבינוז. הקונסטרקטים נבנו ונשלחו לריצוף, וכעת ממתינים לתוצאות לאישור תקינות הרצף והמסגרת."
    },
    @{
        Activity = "דטקטורי הרעבה לחנקן, ברזל ופוספט"
        Partner = "הדר; ראמז"
        Products = "זני P. putida עם GFP; דטקטורים פעילים לחנקן ולברזל; נתוני מדידה קינטיים בניסוי הרעבה."
        Transfer = "המערכת האלקטרוכימית במעבדה של הדר; מערכת לומינסנטית במעבדה של ראמז."
        Description = "נבנו ונבדקו דטקטורים ב-P. putida לתגובת הרעבה. במדידות GFP קינטיות התקבלה תגובה ברורה לתנאי מחסור בברזל ולתנאי מחסור בחנקן. עבור פוספט נבחנו שני פרומוטורים שונים, אך עד כה לא התקבלה תגובה ספציפית מספקת; לכן נבנה כעת קונסטרקט שלישי."
    },
    @{
        Activity = "דטקטור אלקנים"
        Partner = "הדר; ראמז"
        Products = "פלסמידים סביבתיים רלוונטיים בידינו; דטקטור בתכנון ובנייה עם רצפטור וגן דיווח."
        Transfer = "המשך בנייה ואפיון, ובהמשך התאמה לקריאות אלקטרוכימיות ולומינסנטיות."
        Description = "דטקטור האלקנים מורכב יותר משום שהגנים הרלוונטיים אינם גנים נטיביים של P. putida, אלא נמצאים על פלסמידים בזנים סביבתיים. הפלסמידים הדרושים כבר נמצאים בידינו, והמערכת נבנית כך שתכלול רכיב רצפטור וגן דיווח."
    }
)

$milestones = @(
    @{
        Name = "בנין - דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי ו/או פעילות ביולוגית, לצורך הערכה כמותית ודירוג עוצמת הפרומוטור. מדד כמותי: לכל הפחות 80% מהקונסטרוקטים יציגו פעילות נמדדת, דירוג ברור של לפחות 4 פרומוטורים עם יחס אות/רעש הגדול מ-3:1"
        Planned = "31.8.2026"
        Status = "בביצוע. התקבלו דטקטורים פעילים לתנאי הרעבה לחנקן ולברזל, עם תגובת GFP מדידה. עבור פוספט נבדקו שני פרומוטורים ללא ספציפיות מספקת, וקונסטרקט שלישי נמצא בבנייה. מועד אבן הדרך טרם הגיע."
    },
    @{
        Name = "בנין - הצגת שיבוט מטריצת אותות הפרשה מסוג Sec/Tat, Sec, Tat, Type I היברידי שישובטו לקונסטרוקטים ויוערכו מבחינת יעילות ההפרשה החוץ תאית. מדד כמותי: לפחות 12 שילובי אות-אנזים ייבדקו כשמתוכם ייבחרו שלושה שילובים מובילים עם יעילות הפרשה חוץ תאית מעל 30% ביחס לחלבון הכולל"
        Planned = "28.2.2027"
        Status = "בביצוע מוקדם. נבחר האנזים UPO19, תוכנן רצף מותאם קודונים ל-P. putida, נוספו SP להפרשה ו-His-tag לניקוי, ונבנו קונסטרקטים בשני וקטורי ביטוי. הקונסטרקטים נשלחו לריצוף לפני מעבר לבדיקות ביטוי והפרשה."
    }
)

$achievements = @"
במהלך התקופה התקדמו שני צירי הפיתוח המרכזיים של מעבדת בנין במסגרת מאגד אדמה ירוקה.

בקבוצה 1, התקבלו מליאנט כל הזנים והפלסמידים הרלוונטיים. בוצע ריצוף לפלסמידים שנמצאו ב-E. coli, ובעקבותיו זוהה כי רצפי המקור אינם מתאימים לביטוי מיטבי ב-Pseudomonas putida עקב אחוז GC נמוך מאוד, סביב 30%, בעוד שב-P. putida נדרש רצף בעל התאמת קודונים והרכב GC קרוב יותר לכ-60%. כמענה לכך תוכנן וסונתז רצף חדש לאנזים UPO19, על פי המלצת ליאנט, תוך שמירה על רצף החלבון המקורי וביצוע התאמת קודונים ל-P. putida. לרצף נוספו signal peptide לעידוד הפרשה חוץ-תאית ו-His-tag לצורך ניקוי האנזים בהמשך. הרצף הוכנס לשני וקטורים: pBBR1mcs-2 לביטוי קונסטיטוטיבי ו-pJN105 לביטוי אינדוסבילי תחת פרומוטור ארבינוז. הקונסטרקטים נבנו ונשלחו לריצוף.

בקבוצה 3, נבנו דטקטורים מבוססי P. putida לתגובת הרעבה. נבנו ונבחנו זנים עם GFP, ובמדידות קינטיות של GFP ו-OD595 התקבלה תגובה ברורה לתנאי מחסור בברזל ולתנאי מחסור בחנקן. עבור דטקטור הרעבה לפוספט נבחנו שני פרומוטורים שונים, אולם נכון למועד הדיווח אף אחד מהם לא נתן תגובה ספציפית מספקת, ולכן נבנה כעת קונסטרקט שלישי. בנוסף, החל פיתוח דטקטור לזיהוי אלקנים כמייצגי זיהום דלקים בקרקע. מאחר שהגנים הרלוונטיים אינם נטיביים ל-P. putida אלא מצויים על פלסמידים בזנים סביבתיים, פיתוח זה דורש בניית מערכת הכוללת רצפטור וגן דיווח; הפלסמידים הרלוונטיים כבר נמצאים בידינו והדטקטור בבנייה.

במקביל, הזנים העובדים מועברים להתאמה למערכת אלקטרוכימית עבור מדידות במעבדה של הדר, ונבנה סט נוסף עם אנזים לומינסנטי לשימוש במעבדה של ראמז. בכך התוצרים הביולוגיים מתחילים לעבור ממדידות GFP מעבדתיות למערכות קריאה המתאימות יותר לשימושי המשך במאגד.
"@

$collaboration = @"
הפעילות בתקופה כללה ממשקי עבודה עם מספר שותפים במאגד. בקבוצה 1 העבודה התבססה על קבלת זנים, פלסמידים והמלצה אנזימטית מליאנט, ובוצע תכנון מחודש של מערכת הביטוי בהתאם להתאמה הנדרשת ל-P. putida. בקבוצה 3 התוצרים שנמצאו פעילים במערכת GFP מועברים להמשך התאמה למערכת אלקטרוכימית במעבדה של הדר. במקביל נבנית מערכת דיווח נוספת המבוססת על אנזים לומינסנטי, כדי לאפשר שימוש במעבדה של ראמז. שיתופי פעולה אלה מיועדים לאפשר מעבר ממדידות ביולוגיות בסיסיות למערכות קריאה יישומיות יותר במסגרת יעדי המאגד.
"@

$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    Copy-Item -LiteralPath $source -Destination $output -Force
    $doc = $word.Documents.Open($output, $false, $false, $false)

    Set-CellText $doc.Tables.Item(3) 1 1 $companyName

    $taskTable = $doc.Tables.Item(7)
    for ($i = 0; $i -lt $tasks.Count; $i++) {
        $row = 3 + $i
        Set-CellText $taskTable $row 2 $tasks[$i].Name
        Set-CellText $taskTable $row 11 $tasks[$i].Status
    }

    $detailTable = $doc.Tables.Item(8)
    for ($i = 0; $i -lt $details.Count; $i++) {
        $row = 2 + $i
        Set-CellText $detailTable $row 2 $details[$i].Activity
        Set-CellText $detailTable $row 3 $details[$i].Partner
        Set-CellText $detailTable $row 4 $details[$i].Products
        Set-CellText $detailTable $row 5 $details[$i].Transfer
        Set-CellText $detailTable $row 6 $details[$i].Description
    }

    $milestoneTable = $doc.Tables.Item(10)
    for ($i = 0; $i -lt $milestones.Count; $i++) {
        $row = 2 + $i
        Set-CellText $milestoneTable $row 1 $milestones[$i].Name
        Set-CellText $milestoneTable $row 2 $milestones[$i].Planned
        Set-CellText $milestoneTable $row 4 $milestones[$i].Status
    }

    Set-CellText $doc.Tables.Item(11) 1 1 $achievements

    $riskTable = $doc.Tables.Item(13)
    Add-DataRow $riskTable
    Set-CellText $riskTable 2 1 "אי התאמת רצפי המקור לביטוי ב-P. putida עקב אחוז GC נמוך"
    Set-CellText $riskTable 2 2 "בוצעה אופטימיזציית קודונים ל-P. putida וסונתז רצף UPO19 חדש הכולל SP ו-His-tag."
    Set-CellText $riskTable 2 3 "הקונסטרקטים נבנו ונשלחו לריצוף."
    Set-CellText $riskTable 3 1 "דטקטור פוספט לא נתן תגובה ספציפית בשני פרומוטורים שנבדקו"
    Set-CellText $riskTable 3 2 "נבנה קונסטרקט שלישי, שייבחן מול תנאי הרעבה מבוקרים לפוספט ובהשוואה לתנאי ביקורת."
    Set-CellText $riskTable 3 3 "בתהליך."
    Set-CellText $riskTable 4 1 "דטקטור אלקנים מבוסס על גנים שאינם נטיביים ל-P. putida"
    Set-CellText $riskTable 4 2 "שימוש בפלסמידים סביבתיים שכבר נמצאים בידינו ובנייה הדרגתית של מערכת רצפטור וגן דיווח."
    Set-CellText $riskTable 4 3 "בתהליך בנייה."

    Set-CellText $doc.Tables.Item(15) 1 1 $collaboration

    $doc.Save()
    $doc.Close($false)
    $word.Quit()
    Write-Output $output
}
finally {
    if ($doc) { [Runtime.InteropServices.Marshal]::ReleaseComObject($doc) | Out-Null }
    if ($word) { [Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null }
}
