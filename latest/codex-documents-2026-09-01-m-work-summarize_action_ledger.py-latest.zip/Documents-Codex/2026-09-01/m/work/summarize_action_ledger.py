import json
from pathlib import Path

d = json.loads(Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\aliquot_action_ledger.json").read_text(encoding="utf-8"))
for action in ["highlight_missing_status", "measured_and_empty", "none"]:
    print("\nACTION", action)
    for r in d["flagged_rows"]:
        if r["action"] != action:
            continue
        m = "; ".join(f'{x["sheet"]}!{x["row"]} qty={x["quantity_raw"]}' for x in r["matches"])
        print(f'{r["sheet"]}!{r["row"]} {r["primary"]} | {r["secondary"]} status={r["status"]} yellow={",".join(r["yellow_measurements"])} method={r["match_method"]} matches={m}')

print("\nNOT TESTED TRACE")
for x in d["not_tested_trace"]:
    print(x)

print("\nMISSING TRANSITIONS")
for x in d["missing_trace"]:
    cur = x["current"]
    if not cur or cur["status"] != "missing":
        print(x)

matched_missing_locations = {
    (x["current"]["sheet"], x["current"]["row"])
    for x in d["missing_trace"]
    if x["current"] and x["current"]["status"] == "missing"
}
print("\nCURRENT MISSING NOT MATCHED TO ORIGINAL MISSING")
for r in d["flagged_rows"]:
    if r["status"] == "missing" and (r["sheet"], r["row"]) not in matched_missing_locations:
        print(r["sheet"], r["row"], r["primary"], r["secondary"])
