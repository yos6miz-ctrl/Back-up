from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
BASE_DIR = (
    Path.home()
    / "OneDrive - Bar Ilan University (1)"
    / "Banin Lab Files"
    / "Lab members"
    / "Yosi"
    / "sensor"
    / PROJECT
    / "Detectors"
    / "starvation"
)
SOURCE = BASE_DIR / "M9 5.docx"
OUTPUT = BASE_DIR / "M9 5 - revised phosphate protocol.docx"


BLUE = "1F4E79"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREEN = "E2F0D9"
LIGHT_ORANGE = "FCE4D6"
LIGHT_GRAY = "F2F2F2"


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_width(cell, width_twips: int) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width_twips))
    tc_w.set(qn("w:type"), "dxa")


def set_table_width(table, widths_twips: list[int]) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_twips)))
    tbl_w.set(qn("w:type"), "dxa")

    grid = tbl.find(qn("w:tblGrid"))
    if grid is not None:
        tbl.remove(grid)
    grid = OxmlElement("w:tblGrid")
    for width in widths_twips:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)
    tbl.insert(0, grid)

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            set_cell_width(cell, widths_twips[idx])


def style_table(table, widths_twips: list[int], header_rows: int = 1) -> None:
    table.style = "Table Grid"
    table.autofit = False
    set_table_width(table, widths_twips)
    for r_idx, row in enumerate(table.rows):
        for cell in row.cells:
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(0)
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size = Pt(9)
            if r_idx < header_rows:
                set_cell_shading(cell, LIGHT_BLUE)
                for para in cell.paragraphs:
                    for run in para.runs:
                        run.bold = True
                        run.font.color.rgb = RGBColor(31, 78, 121)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[int]) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    for idx, header in enumerate(headers):
        table.rows[0].cells[idx].text = header
    for row_values in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row_values):
            cells[idx].text = value
    style_table(table, widths)


def add_note(doc: Document, text: str, fill: str = LIGHT_ORANGE) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    cell = table.cell(0, 0)
    cell.text = text
    set_cell_shading(cell, fill)
    set_table_width(table, [9000])
    for para in cell.paragraphs:
        para.paragraph_format.space_after = Pt(0)
        for run in para.runs:
            run.font.size = Pt(9.5)


def add_heading(doc: Document, text: str, level: int) -> None:
    para = doc.add_heading(text, level=level)
    for run in para.runs:
        run.font.color.rgb = RGBColor(31, 78, 121)


def add_bullet(doc: Document, text: str) -> None:
    para = doc.add_paragraph(style="List Bullet")
    para.add_run(text)
    para.paragraph_format.space_after = Pt(2)


def build_doc() -> None:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.6)
    section.bottom_margin = Inches(0.6)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)

    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("M9 5x Media for Pseudomonas putida KT2440")
    run.bold = True
    run.font.size = Pt(18)
    run.font.color.rgb = RGBColor(31, 78, 121)
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run("Revised phosphate-starvation protocol").italic = True

    add_note(
        doc,
        "Key change: for phosphate-starvation assays, do not include Na2HPO4 or KH2PO4 in the base medium. "
        "Prepare a phosphate-free MOPS-M9 base, then add phosphate separately from a defined phosphate stock.",
    )

    add_heading(doc, "Phosphate-Free MOPS-M9 5x Base - 250 mL", 1)
    add_table(
        doc,
        ["Component", "MW (g/mol)", "Final conc. in 5x", "Amount for 250 mL"],
        [
            ["NH4Cl", "53.491", "100 mM", "1.34 g"],
            ["NaCl", "58.44", "43 mM", "0.63 g"],
            ["KCl", "74.55", "99 mM", "1.85 g"],
            ["MOPS", "209.26", "250 mM", "13.08 g"],
            ["Dextrose / Glucose", "180.16", "55 mM", "2.48 g"],
        ],
        [2200, 1800, 2100, 2500],
    )
    add_bullet(doc, "Dissolve components in about 200 mL ddH2O.")
    add_bullet(doc, "Adjust pH to 7.0-7.2 after MOPS is dissolved, before bringing to final volume.")
    add_bullet(doc, "Bring to 250 mL with ddH2O.")
    add_bullet(doc, "Sterilize by filtration or autoclave. If glucose is autoclaved separately in your lab, add it as sterile glucose stock instead.")
    add_bullet(doc, "Do not add Na2HPO4 or KH2PO4 to this base.")

    add_heading(doc, "Phosphate Stock Preparation", 1)
    add_heading(doc, "100 mM total phosphate stock - 10 mL", 2)
    add_table(
        doc,
        ["Component", "MW (g/mol)", "Final conc. in stock", "Amount for 10 mL"],
        [
            ["Na2HPO4", "141.96", "35.3 mM", "50.1 mg"],
            ["KH2PO4", "136.08", "64.7 mM", "88.0 mg"],
        ],
        [2200, 1800, 2300, 2200],
    )
    add_bullet(doc, "This combines both phosphate sources while keeping phosphate separate from the base medium.")
    add_bullet(doc, "Dissolve in about 8 mL ddH2O, adjust pH to 7.0-7.2 if needed, bring to 10 mL, and sterile-filter.")

    add_heading(doc, "10 mM phosphate working stock - 10 mL", 2)
    add_table(
        doc,
        ["Component", "Amount"],
        [
            ["100 mM phosphate stock", "1.0 mL"],
            ["Sterile ddH2O", "9.0 mL"],
        ],
        [4200, 4200],
    )
    add_bullet(doc, "Use the 10 mM working stock for the phosphate titration below; it gives practical pipetting volumes for 10 mL condition media.")

    add_heading(doc, "Added Separately After Dilution To 1x", 1)
    add_table(
        doc,
        ["Component", "Stock", "Final conc. in 1x", "Add per 10 mL final 1x"],
        [
            ["MgSO4", "1 M", "1 mM", "10 uL"],
            ["CaCl2", "100 mM", "0.1 mM", "10 uL"],
            ["FeSO4", "10 mM fresh", "10 uM", "10 uL"],
            ["Phosphate stock", "10 mM or 100 mM", "Variable", "See tables below"],
        ],
        [1900, 2100, 2300, 2600],
    )
    add_bullet(doc, "For Fe-limited conditions, omit FeSO4 only.")
    add_bullet(doc, "For P assays, phosphate is added only from the phosphate stock.")

    doc.add_section(WD_SECTION_START.NEW_PAGE)
    add_heading(doc, "P-Starvation Detector Assay: 2x Phosphate Condition Media", 1)
    add_note(
        doc,
        "Use these 2x media when the plate setup is 1:1, for example 100 uL washed cells + 100 uL 2x condition medium. "
        "The final phosphate in the well will be half of the 2x medium concentration.",
        LIGHT_GREEN,
    )
    add_heading(doc, "Base mix for each 10 mL of 2x condition medium", 2)
    add_table(
        doc,
        ["Component", "Stock", "Conc. in 2x medium", "Add per 10 mL 2x medium"],
        [
            ["Phosphate-free MOPS-M9 base", "5x", "2x", "4.00 mL"],
            ["MgSO4", "1 M", "2 mM", "20 uL"],
            ["CaCl2", "100 mM", "0.2 mM", "20 uL"],
            ["FeSO4", "10 mM fresh", "20 uM", "20 uL"],
            ["10 mM phosphate working stock", "10 mM", "Variable", "See titration table"],
            ["Sterile ddH2O", "-", "-", "To 10.00 mL"],
        ],
        [2400, 1800, 2200, 2500],
    )

    add_heading(doc, "Five 2x phosphate conditions", 2)
    add_table(
        doc,
        [
            "Final P in assay well after 1:1 mix",
            "P in 2x condition medium",
            "Add 10 mM P stock to 10 mL 2x medium",
            "Sterile ddH2O to add",
        ],
        [
            ["10 uM", "20 uM", "20 uL", "5.920 mL"],
            ["25 uM", "50 uM", "50 uL", "5.890 mL"],
            ["50 uM", "100 uM", "100 uL", "5.840 mL"],
            ["100 uM", "200 uM", "200 uL", "5.740 mL"],
            ["250 uM", "500 uM", "500 uL", "5.440 mL"],
        ],
        [2500, 2200, 2600, 1900],
    )
    add_bullet(doc, "The water values assume the base mix above: 4.00 mL 5x base + 20 uL MgSO4 + 20 uL CaCl2 + 20 uL FeSO4.")
    add_bullet(doc, "Recommended first readout: OD595 and GFP over time. If 10 uM blocks growth too strongly, focus on 50-250 uM.")

    add_heading(doc, "Optional controls", 2)
    add_table(
        doc,
        [
            "Final P in assay well",
            "P in 2x medium",
            "Stock to use",
            "Add stock to 10 mL 2x medium",
            "Sterile ddH2O to add",
        ],
        [
            ["0 uM", "0 uM", "-", "0 uL", "5.940 mL"],
            ["1 mM", "2 mM", "100 mM P stock", "200 uL", "5.740 mL"],
            ["3.4 mM", "6.8 mM", "100 mM P stock", "680 uL", "5.260 mL"],
        ],
        [1700, 1700, 2200, 2500, 1700],
    )
    add_bullet(doc, "Use 1 mM or 3.4 mM phosphate as P-replete controls. The 3.4 mM condition matches the previous low-P recipe's total phosphate.")

    add_heading(doc, "Cell preparation for P assay", 1)
    add_bullet(doc, "Grow cells in non-inducing/replete medium.")
    add_bullet(doc, "Wash cells 2-3 times in phosphate-free 1x MOPS-M9 without added phosphate to remove phosphate carryover.")
    add_bullet(doc, "Resuspend cells in phosphate-free 1x MOPS-M9 without added phosphate.")
    add_bullet(doc, "Mix cells 1:1 with each 2x phosphate condition medium in the plate.")
    add_bullet(doc, "Include promoterless/GFP background control if available.")

    doc.add_page_break()
    add_heading(doc, "Chemical Locations", 1)
    add_table(
        doc,
        ["Chemical", "Lab number"],
        [
            ["NH4Cl", "1 (shelf 4)"],
            ["Na2HPO4", "51 (shelf 4)"],
            ["KH2PO4", "32 (shelf 4)"],
            ["NaCl", "38 (shelf 4)"],
            ["Dextrose / Glucose", "14 (shelf 4)"],
            ["KCl", "29 (shelf 1)"],
            ["MOPS", "25 (shelf 1)"],
            ["FeSO4", "347 (shelf 2)"],
            ["CaCl2", "8a (shelf 1)"],
            ["MgSO4", "23 (shelf 4)"],
        ],
        [4500, 4200],
    )

    doc.save(OUTPUT)


if __name__ == "__main__":
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)
    build_doc()
    print(str(OUTPUT).encode("unicode_escape").decode("ascii"))
