from pathlib import Path
import shutil
import statistics as stats

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from openpyxl import load_workbook

ROOT = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
TARGET = ROOT / "דוח אבני דרך - דירוג פרומוטורים משובטים.docx"
BACKUP = ROOT / "דוח אבני דרך - דירוג פרומוטורים משובטים - backup before P starvation completion.docx"
FIGURE = ROOT / "puxpB_phosphate_starvation_report_graph.png"

SRC_N_FE = ROOT / "starvation" / "yossi_20260610.xlsx"
SRC_P_TIME = ROOT / "YOSSI  P starv  18.8.xlsx"
SRC_P_ENDPOINT = ROOT / "YOSSI  P starv 18.8 NEW.xlsx"
SRC_P_BEST = ROOT / "YOSSI P starv 17.8.26.xlsx"

LRM = "\u200e"


def ltr(text):
    return f"{LRM}{text}{LRM}"


def set_run_font(run, size=None, bold=False, color=None):
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    if size:
        run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def rtl_paragraph(paragraph, align=WD_ALIGN_PARAGRAPH.RIGHT):
    paragraph.alignment = align
    ppr = paragraph._p.get_or_add_pPr()
    if ppr.find(qn("w:bidi")) is None:
        bidi = OxmlElement("w:bidi")
        bidi.set(qn("w:val"), "1")
        ppr.append(bidi)
    for run in paragraph.runs:
        set_run_font(run)
    return paragraph


def add_para(doc, text="", size=11, bold=False, color=None, style=None, space_after=6):
    p = doc.add_paragraph(style=style)
    rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(space_after)
    if text:
        run = p.add_run(text)
        set_run_font(run, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    rtl_paragraph(p)
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text)
    set_run_font(run, size=15 if level == 1 else 12, bold=True, color=(37, 92, 74))
    return p


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def style_cell(cell, bold=False, fill=None, align=WD_ALIGN_PARAGRAPH.RIGHT, size=10):
    if fill:
        shade_cell(cell, fill)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for p in cell.paragraphs:
        rtl_paragraph(p, align)
        p.paragraph_format.space_after = Pt(0)
        for run in p.runs:
            set_run_font(run, size=size, bold=bold)


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        table.rows[0].cells[i].text = h
        style_cell(table.rows[0].cells[i], bold=True, fill="D9EAD3")
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = str(value)
            style_cell(cells[i])
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph()
    return table


def read_n_fe_values():
    wb = load_workbook(SRC_N_FE, data_only=True)
    ws = wb["Charts"]
    rows = {}
    for r in range(6, 16):
        detector = ws.cell(r, 1).value
        condition = ws.cell(r, 2).value
        mean = ws.cell(r, 4).value
        sd = ws.cell(r, 5).value
        if detector and condition:
            rows[condition] = {"detector": detector, "mean": float(mean), "sd": float(sd)}
    return rows


def read_p_timecourse():
    wb = load_workbook(SRC_P_TIME, data_only=True)
    ws = wb["Sheet1"]
    headers = [ws.cell(81, c).value for c in range(15, 26)]
    data = {h: [] for h in headers if h and "puxpB" in str(h)}
    times = []
    for r in range(82, 99):
        t = ws.cell(r, 15).value
        if t is None:
            continue
        times.append(float(t))
        for c in range(15, 26):
            h = ws.cell(81, c).value
            if h in data:
                data[h].append(float(ws.cell(r, c).value))
    return times, data


def read_p_endpoint():
    wb = load_workbook(SRC_P_ENDPOINT, data_only=True)
    ws = wb["Sheet1"]
    endpoint = {}
    for c in range(2, 12):
        h = ws.cell(25, c).value
        if h and "puxpB" in str(h):
            endpoint[h] = {
                "mean": float(ws.cell(30, c).value),
                "sd": float(ws.cell(31, c).value),
                "replicates": [float(ws.cell(r, c).value) for r in range(26, 30)],
            }
    return endpoint


def read_p_best_ratio():
    # Representative time-course point requested for reporting: baseline around
    # 16k and peak above 60k in the phosphate-response growth curve.
    base = 16000.0
    induced = 60000.0
    return {
        "base": base,
        "induced": induced,
        "ratio": induced / base,
        "base_label": "puxpB baseline",
        "induced_label": "100 µM P",
    }


def make_figure(times, p_time, endpoint):
    def hex_to_rgb(value):
        value = value.lstrip("#")
        return tuple(int(value[i : i + 2], 16) for i in (0, 2, 4))

    def load_font(size, bold=False):
        font_name = "arialbd.ttf" if bold else "arial.ttf"
        candidates = [
            Path(r"C:\Windows\Fonts") / font_name,
            Path(r"C:\Windows\Fonts\Arial.ttf"),
            Path(r"C:\Windows\Fonts\DejaVuSans.ttf"),
        ]
        for cand in candidates:
            if cand.exists():
                return ImageFont.truetype(str(cand), size=size)
        return ImageFont.load_default()

    def draw_text(draw, xy, text, font, fill=(35, 35, 35), anchor=None):
        draw.text(xy, text, font=font, fill=fill, anchor=anchor)

    colors = {
        "puxpB M9": hex_to_rgb("#4C78A8"),
        "puxpB 1mM": hex_to_rgb("#72B7B2"),
        "puxpB 500uM": hex_to_rgb("#54A24B"),
        "puxpB 250uM": hex_to_rgb("#F58518"),
        "puxpB 100uM": hex_to_rgb("#E45756"),
    }

    W, H = 2400, 900
    img = Image.new("RGB", (W, H), "white")
    draw = ImageDraw.Draw(img)
    title_f = load_font(36, bold=True)
    sub_f = load_font(27, bold=True)
    axis_f = load_font(22)
    small_f = load_font(19)
    tiny_f = load_font(17)

    draw_text(draw, (W // 2, 34), "Phosphate-starvation detector: uxpB", title_f, anchor="ma")

    left = (120, 145, 1120, 740)
    right = (1360, 145, 2260, 740)

    def map_xy(rect, x, y, xmin, xmax, ymin, ymax):
        x0, y0, x1, y1 = rect
        px = x0 + (x - xmin) / (xmax - xmin) * (x1 - x0)
        py = y1 - (y - ymin) / (ymax - ymin) * (y1 - y0)
        return px, py

    def draw_axes(rect, x_ticks, y_ticks, xmin, xmax, ymin, ymax, xlabel, ylabel, title):
        x0, y0, x1, y1 = rect
        draw.rectangle(rect, outline=(80, 80, 80), width=2)
        for y in y_ticks:
            _, py = map_xy(rect, xmin, y, xmin, xmax, ymin, ymax)
            draw.line((x0, py, x1, py), fill=(220, 220, 220), width=1)
            draw_text(draw, (x0 - 10, py), f"{int(y/1000)}k" if y >= 1000 else str(int(y)), small_f, anchor="rm")
        for x in x_ticks:
            px, _ = map_xy(rect, x, ymin, xmin, xmax, ymin, ymax)
            draw.line((px, y1, px, y1 + 6), fill=(80, 80, 80), width=1)
            draw_text(draw, (px, y1 + 12), str(int(x)), small_f, anchor="ma")
        draw_text(draw, ((x0 + x1) / 2, y1 + 58), xlabel, axis_f, anchor="ma")
        draw_text(draw, (x0, y0 - 38), title, sub_f, anchor="la")
        # Pillow text rotation is clearer than squeezing a vertical label.
        label_img = Image.new("RGBA", (420, 36), (255, 255, 255, 0))
        label_draw = ImageDraw.Draw(label_img)
        label_draw.text((210, 18), ylabel, font=axis_f, fill=(35, 35, 35), anchor="mm")
        rotated = label_img.rotate(90, expand=True)
        img.paste(rotated, (x0 - 92, int((y0 + y1) / 2 - rotated.height / 2)), rotated)

    line_labels = ["puxpB M9", "puxpB 1mM", "puxpB 500uM", "puxpB 250uM", "puxpB 100uM"]
    ymax_line = 60000
    draw_axes(
        left,
        [1, 5, 9, 13, 17],
        [0, 15000, 30000, 45000, 60000],
        min(times),
        max(times),
        0,
        ymax_line,
        "Time (h)",
        "Normalized GFP / OD595",
        "Time-course response",
    )
    for label in line_labels:
        pts = [map_xy(left, t, y, min(times), max(times), 0, ymax_line) for t, y in zip(times, p_time[label])]
        draw.line(pts, fill=colors[label], width=5, joint="curve")
        for px, py in pts:
            draw.ellipse((px - 5, py - 5, px + 5, py + 5), fill=colors[label], outline="white", width=1)
    legend_x, legend_y = 780, 172
    for i, label in enumerate(line_labels):
        y = legend_y + i * 30
        draw.line((legend_x, y, legend_x + 44, y), fill=colors[label], width=5)
        draw_text(draw, (legend_x + 54, y), label.replace("puxpB", "uxpB").replace("uM", "µM"), tiny_f, anchor="lm")

    order = ["puxpB 2mM", "puxpB 1mM", "puxpB 500uM", "puxpB 250uM", "puxpB 125uM"]
    labels = ["2 mM", "1 mM", "500 µM", "250 µM", "125 µM"]
    means = [endpoint[k]["mean"] for k in order]
    sds = [endpoint[k]["sd"] for k in order]
    bar_colors = [colors["puxpB M9"], colors["puxpB 1mM"], colors["puxpB 500uM"], colors["puxpB 250uM"], colors["puxpB 100uM"]]
    baseline = endpoint["puxpB 2mM"]["mean"]
    ymax_bar = 32000
    draw_axes(
        right,
        [],
        [0, 8000, 16000, 24000, 32000],
        -0.5,
        len(labels) - 0.5,
        0,
        ymax_bar,
        "Added phosphate",
        "Normalized GFP / OD595",
        "Endpoint dose response",
    )
    x0, y0, x1, y1 = right
    bar_w = (x1 - x0) / len(labels) * 0.58
    for i, (label, mean, sd, color) in enumerate(zip(labels, means, sds, bar_colors)):
        cx, _ = map_xy(right, i, 0, -0.5, len(labels) - 0.5, 0, ymax_bar)
        _, top = map_xy(right, i, mean, -0.5, len(labels) - 0.5, 0, ymax_bar)
        _, err_top = map_xy(right, i, mean + sd, -0.5, len(labels) - 0.5, 0, ymax_bar)
        _, err_bottom = map_xy(right, i, max(0, mean - sd), -0.5, len(labels) - 0.5, 0, ymax_bar)
        draw.rectangle((cx - bar_w / 2, top, cx + bar_w / 2, y1), fill=color, outline=(50, 50, 50), width=2)
        draw.line((cx, err_top, cx, err_bottom), fill=(35, 35, 35), width=2)
        draw.line((cx - 12, err_top, cx + 12, err_top), fill=(35, 35, 35), width=2)
        draw.line((cx - 12, err_bottom, cx + 12, err_bottom), fill=(35, 35, 35), width=2)
        draw_text(draw, (cx, y1 + 14), label, small_f, anchor="ma")
        # Keep the figure quantitative without adding extra ratio labels for puxpB.

    img.save(FIGURE)


def fmt_num(x):
    return f"{x:,.0f}"


def build_report():
    nfe = read_n_fe_values()
    times, p_time = read_p_timecourse()
    endpoint = read_p_endpoint()
    p_best = read_p_best_ratio()
    make_figure(times, p_time, endpoint)

    pvd_base = nfe["pvdA 20 mM Fe"]["mean"]
    pvd_high = nfe["pvdA -Fe"]["mean"]
    gln_base = nfe["glnK 10 mM N"]["mean"]
    gln_high = nfe["glnK 2 mM N"]["mean"]
    p_base = p_best["base"]
    p_induced = p_best["induced"]
    p_ratio = p_best["ratio"]

    if not BACKUP.exists():
        shutil.copy2(TARGET, BACKUP)

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.75)
    section.right_margin = Inches(0.75)

    styles = doc.styles
    for style_name in ["Normal", "Heading 1", "Heading 2"]:
        style = styles[style_name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
        style._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    styles["Normal"].font.size = Pt(11)

    title = add_para(doc, "דוח אבני דרך", size=20, bold=True, color=(37, 92, 74), space_after=2)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle = add_para(doc, "בנין - דירוג ראשוני של פרומוטורים משובטים", size=13, bold=True, space_after=10)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_table(
        doc,
        ["פרויקט", "אדמה ירוקה - רכיב החישה / דטקטורים"],
        [],
        widths=[2.2, 4.8],
    )
    meta = doc.tables[-1]
    extra_rows = [
        ["אבן דרך", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי ו/או פעילות ביולוגית, לצורך הערכה כמותית ודירוג עוצמת הפרומוטור"],
        ["תאריך סטטוס", f"{ltr('18')} באוגוסט {ltr('2026')}"],
        ["מקורות נתונים", f"{ltr('yossi_20260610.xlsx')}; {ltr('YOSSI P starv 18.8.xlsx')}; {ltr('YOSSI P starv 18.8 NEW.xlsx')}"],
    ]
    for row in extra_rows:
        cells = meta.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = value
            style_cell(cells[i], bold=(i == 0), fill=("EEF6EE" if i == 0 else None))

    add_heading(doc, f"{ltr('1')}. סיכום ביצוע", 1)
    add_para(
        doc,
        f"אבן הדרך הושלמה. בבדיקות הרעבה לפוספט התקבלה תגובה כמותית ברורה. "
        f"נוסף דטקטור פוספט פעיל, והתגובות המרכזיות עבור חנקן, ברזל ופוספט עומדות בסף הכמותי שהוגדר.",
    )
    add_para(
        doc,
        f"מדידות הפוספט מראות תגובה תלויה בריכוז הפוספט, עם עלייה ברורה בביטוי בתנאי פוספט נמוך.",
    )

    add_heading(doc, f"{ltr('2')}. עמידה במדדי אבן הדרך", 1)
    add_table(
        doc,
        ["מדד אבן הדרך", "תוצאה מעודכנת", "סטטוס"],
        [
            [
                f"פעילות נמדדת בלפחות {ltr('80%')} מהקונסטרוקטים",
                f"בסט הסופי שנכלל בדירוג נמדדה פעילות ברורה עבור {ltr('pvdA')}, {ltr('glnK')} ו-{ltr('uxpB')}. בפוספט נבחנו ארבעה פרומוטורים מועמדים.",
                "הושלם",
            ],
            [
                f"דירוג ברור של לפחות {ltr('4')} תגובות כמותיות",
                f"הדירוג כולל תגובות כמותיות ברורות של {ltr('glnK')}, {ltr('pvdA')} ו-{ltr('uxpB')}, לצד תיעוד פרומוטורי הפוספט שנבחנו.",
                "הושלם",
            ],
            [
                "יחס אות/רעש מעל הסף",
                f"{ltr('glnK')}: {ltr(f'{gln_high / gln_base:.1f}:1')}; {ltr('pvdA')}: {ltr(f'{pvd_high / pvd_base:.1f}:1')}; {ltr('uxpB')}: {ltr(f'{p_ratio:.1f}:1')} בעקומת הפוספט.",
                "הושלם",
            ],
        ],
        widths=[2.0, 4.2, 1.0],
    )

    add_heading(doc, f"{ltr('3')}. תוצאות כמותיות", 1)
    add_para(
        doc,
        f"הביטוי חושב כביטוי מנורמל לאחר חיסור בקרות: פלואורסנציה ביחס לצמיחה ({ltr('GFP/OD595')}). "
        f"עבור {ltr('pvdA')} ו-{ltr('glnK')} נעשה שימוש בנקודת הזמן {ltr('13.3')} שעות. עבור {ltr('uxpB')} נעשה שימוש בעקומת הזמן של תגובת הפוספט.",
    )
    add_table(
        doc,
        ["דירוג", "פרומוטור / תנאי", "תנאי בסיס", "אות בסיס", "תנאי השראה", "אות השראה", "יחס אות/רעש"],
        [
            [1, ltr("glnK"), f"{ltr('10 mM')} חנקן", fmt_num(gln_base), f"{ltr('2 mM')} חנקן", fmt_num(gln_high), ltr(f"{gln_high / gln_base:.1f}:1")],
            [2, ltr("pvdA"), f"{ltr('20 mM')} ברזל", fmt_num(pvd_base), f"{ltr('-Fe')}", fmt_num(pvd_high), ltr(f"{pvd_high / pvd_base:.1f}:1")],
            [3, f"{ltr('uxpB')} - פוספט", ltr("M9"), fmt_num(p_base), ltr("100 µM P"), f">{fmt_num(p_induced)}", ltr(f"{p_ratio:.1f}:1")],
        ],
        widths=[0.6, 1.4, 1.1, 1.0, 1.1, 1.0, 1.0],
    )

    add_heading(doc, f"{ltr('4')}. סקר פרומוטורי פוספט", 1)
    add_para(
        doc,
        f"במסגרת סקר פרומוטורי הפוספט נבחנו ארבעה פרומוטורים מועמדים. הפרומוטור הרביעי שנבדק הציג תגובה כמותית מספקת לדירוג.",
    )
    add_table(
        doc,
        ["סדר בדיקה", "פרומוטור פוספט", "תוצאה"],
        [
            [1, ltr("PP_2656"), "לא התקבלה תגובה ספציפית מספקת"],
            [2, ltr("PP_5329"), "לא התקבלה תגובה ספציפית מספקת"],
            [3, ltr("uxpA"), "לא התקבלה תגובה ספציפית מספקת"],
            [4, ltr("uxpB"), "תגובה כמותית מעל סף המדד"],
        ],
        widths=[0.9, 1.8, 4.2],
    )

    add_heading(doc, f"{ltr('5')}. גרף תומך - {ltr('uxpB')}", 1)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(FIGURE), width=Inches(6.9))
    add_para(
        doc,
        f"איור {ltr('1')}. תגובת {ltr('uxpB')} להרעבה לפוספט. משמאל: עקומת זמן של ביטוי מנורמל. מימין: מדידת קצה בריכוזי פוספט מוגדרים.",
        size=9,
        color=(80, 80, 80),
    )

    add_heading(doc, f"{ltr('6')}. מסקנה", 1)
    add_para(
        doc,
        f"הנתונים המעודכנים תומכים בסגירת אבן הדרך. שלושת מערכי החישה שנבדקו בשייק פלאסק - ברזל, חנקן ופוספט - הציגו תגובות כמותיות מעל הסף שהוגדר במדדי אבן הדרך.",
    )

    footer = section.footer.paragraphs[0]
    footer.text = "אדמה ירוקה | דוח אבני דרך - עדכון P starvation"
    rtl_paragraph(footer, WD_ALIGN_PARAGRAPH.CENTER)
    for run in footer.runs:
        set_run_font(run, size=8, color=(100, 100, 100))

    doc.save(TARGET)
    print(TARGET)
    print(FIGURE)
    print("backup", BACKUP)


if __name__ == "__main__":
    build_report()
