from __future__ import annotations

from pathlib import Path

from docx import Document


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
REPORT = "\u05d3\u05d5\u05d7 \u05d0\u05d1\u05e0\u05d9 \u05d3\u05e8\u05da - \u05d3\u05d9\u05e8\u05d5\u05d2 \u05e4\u05e8\u05d5\u05de\u05d5\u05d8\u05d5\u05e8\u05d9\u05dd \u05de\u05e9\u05d5\u05d1\u05d8\u05d9\u05dd.docx"
PHOSPHATE = "\u05e4\u05d5\u05e1\u05e4\u05d8"
LRM = "\u200e"
RLM = "\u200f"


def plain(text: str) -> str:
    return text.replace(LRM, "").replace(RLM, "")


def emit(label: str, text: str) -> None:
    print(label, plain(text).encode("unicode_escape").decode("ascii"))


def main() -> None:
    p = Path.home() / ".codex" / PROJECT / REPORT
    doc = Document(p)
    print("PARAGRAPHS")
    for i, para in enumerate(doc.paragraphs, 1):
        if PHOSPHATE in plain(para.text) or "PP_" in para.text:
            emit(str(i), para.text)
    print("TABLES")
    for ti, table in enumerate(doc.tables, 1):
        for ri, row in enumerate(table.rows, 1):
            for ci, cell in enumerate(row.cells, 1):
                if PHOSPHATE in plain(cell.text) or "PP_" in cell.text:
                    emit(f"table {ti} row {ri} cell {ci}", cell.text)


if __name__ == "__main__":
    main()
