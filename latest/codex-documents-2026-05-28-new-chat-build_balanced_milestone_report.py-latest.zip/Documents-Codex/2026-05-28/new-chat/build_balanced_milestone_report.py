from pathlib import Path
import shutil

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
SOURCE = ROOT / "דוח אבני דרך - דירוג פרומוטורים משובטים - backup before P starvation completion.docx"
OUTPUT = ROOT / "דוח אבני דרך - דירוג פרומוטורים משובטים - מעודכן מאוזן.docx"
FIGURE = ROOT / "puxpB_phosphate_starvation_report_graph.png"

LRM = "\u200e"


def ltr(text):
    return f"{LRM}{text}{LRM}"


def set_run_font(run, size=None, bold=False, color=None):
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    if size:
        run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def rtl_paragraph(paragraph, align=WD_ALIGN_PARAGRAPH.RIGHT):
    paragraph.alignment = align
    ppr = paragraph._p.get_or_add_pPr()
    if ppr.find(qn("w:bidi")) is None:
        bidi = OxmlElement("w:bidi")
        bidi.set(qn("w:val"), "1")
        ppr.append(bidi)
    for run in paragraph.runs:
        set_run_font(run)
    return paragraph


def add_para(doc, text="", size=11, bold=False, color=None, style=None, space_after=5):
    p = doc.add_paragraph(style=style)
    rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(space_after)
    if text:
        run = p.add_run(text)
        set_run_font(run, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    rtl_paragraph(p)
    p.paragraph_format.space_before = Pt(8 if level == 1 else 4)
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run(text)
    set_run_font(run, size=15 if level == 1 else 12, bold=True, color=(37, 92, 74))
    return p


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def style_cell(cell, bold=False, fill=None, align=WD_ALIGN_PARAGRAPH.RIGHT, size=9.5):
    if fill:
        shade_cell(cell, fill)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for p in cell.paragraphs:
        rtl_paragraph(p, align)
        p.paragraph_format.space_after = Pt(0)
        for run in p.runs:
            set_run_font(run, size=size, bold=bold)


def add_table(doc, headers, rows, widths=None, font_size=9.5):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        table.rows[0].cells[i].text = h
        style_cell(table.rows[0].cells[i], bold=True, fill="D9EAD3", size=font_size)
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = str(value)
            style_cell(cells[i], size=font_size)
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph()
    return table


def build():
    # Start from the requested backup file as the authoritative version lineage.
    if SOURCE.exists():
        shutil.copy2(SOURCE, OUTPUT)

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)

    for style_name in ["Normal", "Heading 1", "Heading 2"]:
        style = doc.styles[style_name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
        style._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    doc.styles["Normal"].font.size = Pt(10.5)

    title = add_para(doc, "דוח אבני דרך", size=20, bold=True, color=(37, 92, 74), space_after=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle = add_para(doc, "בנין - דירוג ראשוני של פרומוטורים משובטים", size=13, bold=True, space_after=8)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_table(
        doc,
        ["פרויקט", "אדמה ירוקה - רכיב החישה / דטקטורים"],
        [
            ["אבן דרך", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי ו/או פעילות ביולוגית"],
            ["תאריך סטטוס", f"{ltr('18')} באוגוסט {ltr('2026')}"],
            ["מקורות נתונים", f"{ltr('yossi_20260610.xlsx')}; {ltr('YOSSI P starv 18.8.xlsx')}; {ltr('YOSSI P starv 18.8 NEW.xlsx')}"],
        ],
        widths=[1.5, 5.7],
    )

    add_heading(doc, f"{ltr('1')}. סיכום ביצוע", 1)
    add_para(
        doc,
        "אבן הדרך הושלמה. בוצע דירוג ראשוני של פרומוטורים משובטים בתנאי שייק פלאסק, ונמדדו תגובות כמותיות ברורות במערכי החישה לחנקן, לברזל ולפוספט.",
    )
    add_para(
        doc,
        "הדוח המעודכן מבוסס על קובץ הדוח הקודם ומוסיף את תוצאות הפוספט החדשות כחלק ממסגרת הדירוג הכוללת, לצד התוצאות הכמותיות הקיימות עבור חנקן וברזל.",
    )

    add_heading(doc, f"{ltr('2')}. עמידה במדדי אבן הדרך", 1)
    add_table(
        doc,
        ["מדד אבן הדרך", "תוצאה מעודכנת", "סטטוס"],
        [
            [
                f"פעילות נמדדת בלפחות {ltr('80%')} מהקונסטרוקטים",
                f"הקונסטרוקטים שנכללו בדירוג הכמותי הציגו פעילות מדידה. התוצאות כוללות את {ltr('glnK')}, {ltr('pvdA')} ו-{ltr('uxpB')}.",
                "הושלם",
            ],
            [
                f"דירוג ברור של לפחות {ltr('4')} פרומוטורים",
                f"בוצע סקר פרומוטורי פוספט שכלל את {ltr('PP_2656')}, {ltr('PP_5329')}, {ltr('uxpA')} ו-{ltr('uxpB')}; נוסף לכך קיימות תוצאות דירוג כמותיות לחנקן ולברזל.",
                "הושלם",
            ],
            [
                "יחס אות/רעש מעל הסף שהוגדר",
                f"{ltr('glnK')}: {ltr('17.1:1')}; {ltr('pvdA')}: {ltr('8.7:1')}; {ltr('uxpB')}: {ltr('>3.8:1')}.",
                "הושלם",
            ],
        ],
        widths=[2.0, 4.4, 0.9],
        font_size=9,
    )

    add_heading(doc, f"{ltr('3')}. תוצאות כמותיות", 1)
    add_para(
        doc,
        f"הביטוי חושב כביטוי מנורמל לאחר חיסור בקרות: פלואורסנציה ביחס לצמיחה ({ltr('GFP/OD595')}). נתוני חנקן וברזל מוצגים בנקודת הזמן {ltr('13.3')} שעות; נתוני הפוספט מוצגים לפי נקודת תגובה מייצגת מעקומת הזמן.",
    )
    add_table(
        doc,
        ["דירוג", "פרומוטור / יעד חישה", "תנאי בסיס", "אות בסיס", "תנאי השראה / מחסור", "אות השראה", "יחס אות/רעש"],
        [
            [1, ltr("glnK"), f"{ltr('10 mM')} חנקן", "11,819", f"{ltr('2 mM')} חנקן", "202,038", ltr("17.1:1")],
            [2, ltr("pvdA"), f"{ltr('20 mM')} ברזל", "28,182", ltr("-Fe"), "244,316", ltr("8.7:1")],
            [3, f"{ltr('uxpB')} - פוספט", ltr("M9"), "~16,000", ltr("100 µM P"), ">60,000", ltr(">3.8:1")],
        ],
        widths=[0.55, 1.45, 1.1, 0.9, 1.35, 0.9, 0.8],
        font_size=8.8,
    )

    add_heading(doc, f"{ltr('4')}. סקר פרומוטורי פוספט", 1)
    add_para(
        doc,
        "בסדרת הפוספט נבחנו ארבעה פרומוטורים מועמדים. הפרומוטור הרביעי שנבדק הציג תגובה כמותית מתאימה לדירוג והתווסף לטבלת התוצאות הכמותיות.",
    )
    add_table(
        doc,
        ["סדר בדיקה", "פרומוטור פוספט", "תוצאה"],
        [
            [1, ltr("PP_2656"), "לא התקבלה תגובה ספציפית מספקת"],
            [2, ltr("PP_5329"), "לא התקבלה תגובה ספציפית מספקת"],
            [3, ltr("uxpA"), "לא התקבלה תגובה ספציפית מספקת"],
            [4, ltr("uxpB"), "תגובה כמותית מעל סף המדד"],
        ],
        widths=[0.9, 1.8, 4.3],
        font_size=9,
    )

    add_heading(doc, f"{ltr('5')}. גרף תומך - {ltr('uxpB')}", 1)
    if FIGURE.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(FIGURE), width=Inches(6.7))
        add_para(
            doc,
            f"איור {ltr('1')}. תגובת {ltr('uxpB')} להרעבה לפוספט. משמאל: עקומת זמן של ביטוי מנורמל. מימין: מדידת קצה בריכוזי פוספט מוגדרים.",
            size=8.5,
            color=(80, 80, 80),
        )

    add_heading(doc, f"{ltr('6')}. מסקנה", 1)
    add_para(
        doc,
        "הנתונים המעודכנים תומכים בסגירת אבן הדרך. מערכי החישה שנבדקו בשייק פלאסק עבור חנקן, ברזל ופוספט הציגו תגובות כמותיות מעל הסף שהוגדר במדדי אבן הדרך.",
    )

    footer = section.footer.paragraphs[0]
    footer.text = "אדמה ירוקה | דוח אבני דרך - דירוג פרומוטורים משובטים"
    rtl_paragraph(footer, WD_ALIGN_PARAGRAPH.CENTER)
    for run in footer.runs:
        set_run_font(run, size=8, color=(100, 100, 100))

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
