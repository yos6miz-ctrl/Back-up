from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
OUT_NAME = "YOSSI 13.8.26 plates only labeled.xlsx"
FALLBACK_OUT_NAME = "YOSSI 13.8.26 plates only labeled updated.xlsx"
ROWS = list("BCDEFG")
COLS = list(range(1, 10))

BLUE = "1F4E79"
GREEN = "548235"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREEN = "E2F0D9"
LIGHT_ORANGE = "FCE4D6"
LIGHT_GRAY = "F2F2F2"
WHITE = "FFFFFF"
BORDER = Side(style="thin", color="C7D2E4")


def excel_time_to_text(value) -> str:
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    if isinstance(value, (int, float)):
        total_seconds = round(float(value) * 24 * 3600)
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    return str(value)


def read_block(ws, header_row: int, first_data_row: int, last_data_row: int) -> list[dict]:
    raw_rows = list(ws.iter_rows(min_row=header_row, max_row=last_data_row, values_only=True))
    headers = list(raw_rows[0])
    idx = {str(v): i for i, v in enumerate(headers) if v}
    output = []
    for read_no, row in enumerate(raw_rows[first_data_row - header_row :], start=1):
        rec = {"read": read_no, "time_text": excel_time_to_text(row[1]), "temp": row[2]}
        for plate_row in ROWS:
            for plate_col in COLS:
                well = f"{plate_row}{plate_col}"
                rec[well] = row[idx[well]]
        output.append(rec)
    return output


def build_label_map() -> dict[str, str]:
    labels = {}
    groups = [
        ("M9", 1, "pupxA"),
        ("M9", 2, "pupxB"),
        ("M9", 3, "Control"),
        ("M9 0.5P", 4, "pupxA"),
        ("M9 0.5P", 5, "pupxB"),
        ("M9 0.5P", 6, "Control"),
        ("M9 -P", 7, "pupxA"),
        ("M9 -P", 8, "pupxB"),
        ("M9 -P", 9, "Control"),
    ]
    for row in ROWS:
        for condition, col, construct in groups:
            labels[f"{row}{col}"] = f"{condition} | {construct}"
    return labels


def set_block_dimensions(ws) -> None:
    ws.column_dimensions["A"].width = 9
    for col in range(2, 11):
        ws.column_dimensions[get_column_letter(col)].width = 14


def style_grid(ws, min_row: int, max_row: int, min_col: int, max_col: int) -> None:
    for row in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(left=BORDER, right=BORDER, top=BORDER, bottom=BORDER)
            if cell.row == min_row or cell.column == min_col:
                cell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
                cell.font = Font(bold=True, color=BLUE)


def add_plate_header(ws, start_row: int, title: str, fill: str) -> None:
    ws.merge_cells(start_row=start_row, start_column=1, end_row=start_row, end_column=10)
    cell = ws.cell(start_row, 1, title)
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(bold=True, color=WHITE, size=13)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[start_row].height = 26


def add_value_plate(ws, start_row: int, record: dict, channel: str, fill: str, number_format: str) -> int:
    add_plate_header(ws, start_row, f"Read {record['read']:02d} | {record['time_text']} | raw {channel}", fill)

    # Compact header matching the source plate map: medium condition, then construct/control.
    condition_row = start_row + 1
    construct_row = start_row + 2
    first_value_row = start_row + 3
    ws.cell(condition_row, 1, "")
    ws.merge_cells(start_row=condition_row, start_column=2, end_row=condition_row, end_column=4)
    ws.cell(condition_row, 2, "M9")
    ws.merge_cells(start_row=condition_row, start_column=5, end_row=condition_row, end_column=7)
    ws.cell(condition_row, 5, "M9 0.5P")
    ws.merge_cells(start_row=condition_row, start_column=8, end_row=condition_row, end_column=10)
    ws.cell(condition_row, 8, "M9 -P")

    constructs = ["", "pupxA", "pupxB", "Control", "pupxA", "pupxB", "Control", "pupxA", "pupxB", "Control"]
    for c, value in enumerate(constructs, start=1):
        ws.cell(construct_row, c, value)

    for i, row_name in enumerate(ROWS, start=first_value_row):
        ws.cell(i, 1, row_name)
        for j, plate_col in enumerate(COLS, start=2):
            well = f"{row_name}{plate_col}"
            cell = ws.cell(i, j, record[well])
            cell.number_format = number_format

    header_fill_by_col = {
        2: LIGHT_GREEN,
        3: LIGHT_GRAY,
        4: LIGHT_GREEN,
        5: LIGHT_GREEN,
        6: LIGHT_GRAY,
        7: LIGHT_GREEN,
        8: LIGHT_GREEN,
        9: LIGHT_GRAY,
        10: LIGHT_GRAY,
    }
    for row in range(condition_row, construct_row + 1):
        for col in range(1, 11):
            cell = ws.cell(row, col)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(left=BORDER, right=BORDER, top=BORDER, bottom=BORDER)
            cell.font = Font(bold=True, color=BLUE if row != construct_row else "333333")
            cell.fill = PatternFill("solid", fgColor=header_fill_by_col.get(col, LIGHT_BLUE))
    style_grid(ws, first_value_row, first_value_row + len(ROWS) - 1, 1, 10)
    data_range = f"B{first_value_row}:J{first_value_row + len(ROWS) - 1}"
    ws.conditional_formatting.add(
        data_range,
        ColorScaleRule(start_type="min", start_color="F7FBFF", mid_type="percentile", mid_value=50, mid_color="9ECAE1", end_type="max", end_color="08519C"),
    )
    for row in range(condition_row, first_value_row + len(ROWS)):
        ws.row_dimensions[row].height = 22
    ws.row_dimensions[construct_row].height = 30
    return start_row + len(ROWS) + 5


def build_sheet(wb: Workbook, name: str, rows: list[dict], labels: dict[str, str], channel: str, fill: str, number_format: str) -> None:
    ws = wb.create_sheet(name)
    ws.sheet_view.showGridLines = False
    set_block_dimensions(ws)
    next_row = 1
    for record in rows:
        next_row = add_value_plate(ws, next_row, record, channel, fill, number_format)
    ws.freeze_panes = "A1"


def main() -> None:
    source = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE_NAME
    out = Path.home() / ".codex" / PROJECT / "starvation" / OUT_NAME
    src_wb = load_workbook(source, data_only=True, read_only=True)
    src_ws = src_wb["Plate 1 - Sheet1"]
    od_rows = read_block(src_ws, 51, 52, 69)
    gfp_rows = read_block(src_ws, 87, 88, 105)
    labels = build_label_map()

    wb = Workbook()
    wb.remove(wb.active)
    build_sheet(wb, "OD595 plates", od_rows, labels, "OD595", BLUE, "0.000")
    build_sheet(wb, "GFP plates", gfp_rows, labels, "GFP 488/528", GREEN, "#,##0")
    try:
        wb.save(out)
    except PermissionError:
        out = Path.home() / ".codex" / PROJECT / "starvation" / FALLBACK_OUT_NAME
        wb.save(out)
    print(str(out).encode("unicode_escape").decode("ascii"))
    print("sheets", wb.sheetnames)
    print("od_reads", len(od_rows), "gfp_reads", len(gfp_rows))


if __name__ == "__main__":
    main()
