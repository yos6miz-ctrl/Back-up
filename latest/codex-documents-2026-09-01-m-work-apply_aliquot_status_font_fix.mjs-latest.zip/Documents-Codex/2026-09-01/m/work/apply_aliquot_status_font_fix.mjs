import fs from "node:fs/promises";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "file:///C:/Users/Popovtzer%20lab/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs";

const inputPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const ledgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/aliquot_action_ledger.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/aliquot_status_and_font_fix_20260903";
const outputPath = `${outputDir}/Final Known and Unknown merged.xlsx`;
const auditPath = `${outputDir}/edit_audit.json`;
const expectedInputHash = "B2F9725E42715B4C5C12AD9D2A8B3A11A5B964CC703B27DAA7D4A69B99309811";

const YELLOW = "#FFD966";
const BLACK = "#000000";
const LAVENDER_TEXT = "#4C3868";

function sha256(bytes) {
  return crypto.createHash("sha256").update(bytes).digest("hex").toUpperCase();
}

function norm(value) {
  return String(value ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

const inputBytes = await fs.readFile(inputPath);
const inputHash = sha256(inputBytes);
if (inputHash !== expectedInputHash) {
  throw new Error(`Live workbook changed after analysis. Expected ${expectedInputHash}, found ${inputHash}.`);
}

const ledger = JSON.parse(await fs.readFile(ledgerPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(inputPath));

const edited = [];
for (const rec of ledger.flagged_rows) {
  if (rec.action !== "highlight_missing_status" && rec.action !== "measured_and_empty") continue;
  const sheet = workbook.worksheets.getItem(rec.sheet);
  const rowValues = sheet.getRange(`A${rec.row}:C${rec.row}`).values?.[0] ?? [];
  if (norm(rowValues[0]) !== norm(rec.primary) || norm(rowValues[1]) !== norm(rec.secondary)) {
    throw new Error(`Row identity mismatch at ${rec.sheet}!${rec.row}: ${JSON.stringify(rowValues)}`);
  }
  const statusCell = sheet.getRange(`C${rec.row}`);
  const before = statusCell.values?.[0]?.[0] ?? null;
  if (rec.action === "measured_and_empty") {
    if (String(before) !== "measured") {
      throw new Error(`Expected measured at ${rec.sheet}!C${rec.row}, found ${String(before)}`);
    }
    statusCell.values = [["measured and empty"]];
  } else if (String(before) !== "missing") {
    throw new Error(`Expected missing at ${rec.sheet}!C${rec.row}, found ${String(before)}`);
  }
  statusCell.format.fill = YELLOW;
  statusCell.format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
  edited.push({
    sheet: rec.sheet,
    row: rec.row,
    primary: rec.primary,
    secondary: rec.secondary,
    action: rec.action,
    before,
    after: rec.action === "measured_and_empty" ? "measured and empty" : "missing",
    aliquotMatches: rec.matches.map((m) => ({ sheet: m.sheet, row: m.row, quantity: m.quantity })),
  });
}

// CT-606 was appended with the workbook default font. Standardize its entire row
// to the body font while preserving the intended decision emphasis in column E.
const older = workbook.worksheets.getItem("Older samples - before 2021");
const used = older.getUsedRange(true);
const values = used?.values ?? [];
let ct606Row = null;
for (let i = 1; i < values.length; i += 1) {
  if (norm(values[i]?.[0]) === "CT606" || norm(values[i]?.[1]) === "HS606") {
    ct606Row = i + 1;
    break;
  }
}
if (!ct606Row) throw new Error("CT-606 row not found.");
older.getRange(`A${ct606Row}:D${ct606Row}`).format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
older.getRange(`F${ct606Row}:AA${ct606Row}`).format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
older.getRange(`E${ct606Row}`).format.font = { name: "Calibri", size: 10, color: LAVENDER_TEXT, bold: true };

if (edited.filter((x) => x.action === "highlight_missing_status").length !== 20) {
  throw new Error("Unexpected count of highlighted missing-status rows.");
}
if (edited.filter((x) => x.action === "measured_and_empty").length !== 15) {
  throw new Error("Unexpected count of measured-and-empty rows.");
}

await fs.mkdir(outputDir, { recursive: true });
const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);
const outputBytes = await fs.readFile(outputPath);
const outputHash = sha256(outputBytes);
await fs.writeFile(auditPath, JSON.stringify({
  inputPath,
  inputHash,
  outputPath,
  outputHash,
  ct606Row,
  highlightedMissingRows: edited.filter((x) => x.action === "highlight_missing_status").length,
  measuredAndEmptyRows: edited.filter((x) => x.action === "measured_and_empty").length,
  edited,
}, null, 2));

console.log(JSON.stringify({ outputPath, outputHash, ct606Row, editedCount: edited.length }, null, 2));
