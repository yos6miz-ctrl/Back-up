from __future__ import annotations

import sys
from pathlib import Path

from docx import Document


def emit_paragraphs(lines: list[str], prefix: str, paragraphs) -> None:
    for idx, paragraph in enumerate(paragraphs):
        text = paragraph.text.strip()
        if text:
            lines.append(f"{prefix}.P{idx:03d}\t{text}")


def emit_table(lines: list[str], prefix: str, table) -> None:
    for row_idx, row in enumerate(table.rows):
        for cell_idx, cell in enumerate(row.cells):
            emit_paragraphs(lines, f"{prefix}.R{row_idx:02d}.C{cell_idx:02d}", cell.paragraphs)
            for nested_idx, nested in enumerate(cell.tables):
                emit_table(lines, f"{prefix}.R{row_idx:02d}.C{cell_idx:02d}.T{nested_idx:02d}", nested)


def main() -> None:
    source = Path(sys.argv[1])
    output = Path(sys.argv[2])
    doc = Document(source)
    lines: list[str] = []
    emit_paragraphs(lines, "BODY", doc.paragraphs)
    for table_idx, table in enumerate(doc.tables):
        emit_table(lines, f"T{table_idx:02d}", table)
    for section_idx, section in enumerate(doc.sections):
        emit_paragraphs(lines, f"S{section_idx:02d}.HEADER", section.header.paragraphs)
        emit_paragraphs(lines, f"S{section_idx:02d}.FOOTER", section.footer.paragraphs)
    output.write_text("\n".join(lines), encoding="utf-8")
    print(f"{len(lines)} text items -> {output}")


if __name__ == "__main__":
    main()
