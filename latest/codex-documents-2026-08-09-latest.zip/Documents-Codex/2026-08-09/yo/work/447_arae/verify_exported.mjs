import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const files = [
  "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae/Final 447.xlsx",
  "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_araE/Final araE.xlsx".replace("447_araE", "447_arae"),
];
const renderDir = "./reimport_previews";
await fs.mkdir(renderDir, { recursive: true });

for (const file of files) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
  const sheets = await workbook.inspect({ kind: "sheet", include: "id,name", maxChars: 4000 });
  const resultsName = workbook.worksheets.getItemAt(0).name;
  const resultTable = await workbook.inspect({
    kind: "table",
    range: `${resultsName}!A1:K56`,
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 13,
    maxChars: 30000,
  });
  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 300 },
    summary: "exported workbook formula error scan",
  });
  const diagnosisLeak = await workbook.inspect({
    kind: "match",
    searchTerm: "Diagnosis|diagnosis|CDf|CDr|Healthy",
    options: { useRegex: true, maxResults: 100 },
    summary: "removed diagnosis field scan",
  });
  for (const sheet of workbook.worksheets.items) {
    const range = sheet.name === "Sample Log" ? "A1:M59" : sheet.name === "Follow-up Pairs" ? "A1:I7" : "A1:N60";
    const preview = await workbook.render({ sheetName: sheet.name, range, scale: 0.7, format: "png" });
    const safe = `${path.basename(file, ".xlsx")}_${sheet.name}`.replace(/[^A-Za-z0-9._-]+/g, "_");
    await fs.writeFile(path.join(renderDir, `${safe}.png`), new Uint8Array(await preview.arrayBuffer()));
  }
  const resultSummary = JSON.parse(resultTable.ndjson);
  process.stdout.write(`${path.basename(file)} sheets=${workbook.worksheets.items.length} resultRows=${resultSummary.rows} resultCols=${resultSummary.cols}\nERRORS ${errors.ndjson}\nDIAGNOSIS_SCAN ${diagnosisLeak.ndjson}\n`);
}
