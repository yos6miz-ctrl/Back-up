import fs from "node:fs/promises";

const read = async (p) => JSON.parse(await fs.readFile(p, "utf8"));
const merged = (await read("./inspect_merged/01.json")).sheets[0].values.slice(1);
const shipment = (await read("./inspect/07.json")).sheets[0].values.slice(1).map((r) => r[4]).filter(Boolean);

function prefix(v) {
  const s = String(v ?? "").toUpperCase().replace(/^\s*UN\s*/, "").replace(/[^A-Z0-9]/g, "").replace(/^F/, "");
  return (s.match(/^[A-Z]+/) ?? [""])[0];
}

for (const candidate of shipment) {
  const p = prefix(candidate);
  const hits = merged
    .map((r, i) => ({ row: i + 2, primary: r[0], secondary: r[1], diagnosis: r[3], decision: r[4], p1: prefix(r[0]), p2: prefix(r[1]) }))
    .filter((r) => p && (r.p1 === p || r.p2 === p))
    .slice(0, 20);
  process.stdout.write(`\n${candidate}\t${p}\n`);
  for (const hit of hits) process.stdout.write(`  ${hit.row}\t${hit.primary}\t${hit.secondary}\t${hit.diagnosis || "?"}\t${hit.decision || "?"}\n`);
}
