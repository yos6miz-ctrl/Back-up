import fs from "node:fs/promises";

const read = async (p) => JSON.parse(await fs.readFile(p, "utf8"));
const merged = (await read("./inspect_merged/01.json")).sheets[0].values;
const shipment = (await read("./inspect/07.json")).sheets[0].values.slice(1).map((r) => ({ source: "Shipment Bar Ilan 7.26 Blinded", name: r[4], row: r }));
const july = (await read("./inspect/08.json")).sheets[0].values.slice(1).map((r) => ({ source: "Bar Ilan July 25 blinded", name: r[1], row: r }));
const candidates = [...shipment, ...july].filter((x) => String(x.name ?? "").trim());

function norm(v) {
  return String(v ?? "")
    .toUpperCase()
    .replace(/^\s*UN\s*/, "")
    .replace(/[^A-Z0-9]/g, "")
    .replace(/^F/, "");
}

const records = merged.slice(1).map((r, index) => ({
  row: index + 2,
  primary: r[0],
  secondary: r[1],
  status: r[2],
  diagnosis: r[3],
  decision: r[4],
  pa447: [r[7], r[8], r[9]].filter((v) => typeof v === "number"),
  araE: [r[11], r[12], r[13]].filter((v) => typeof v === "number"),
  source: r[16],
}));

for (const c of candidates) {
  const n = norm(c.name);
  const matches = records.filter((r) => norm(r.primary) === n || norm(r.secondary) === n);
  const summary = matches.map((m) => `${m.row}:${m.diagnosis || "?"}/${m.decision || "?"};447=${m.pa447.join(",")};araE=${m.araE.join(",")}`).join(" || ");
  process.stdout.write(`${c.source}\t${c.name}\t${n}\t${summary || "NO EXACT MATCH"}\n`);
}
