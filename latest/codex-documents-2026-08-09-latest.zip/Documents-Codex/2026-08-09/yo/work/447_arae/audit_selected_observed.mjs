import fs from "node:fs/promises";

function canonical(v) {
  return String(v ?? "").toUpperCase().trim().replace(/^(?:IBS|CDF|CDR|CD|HS|UN)\s*/g, "").replace(/[^A-Z0-9]/g, "").replace(/^F/, "");
}

const merged = JSON.parse(await fs.readFile("./inspect_merged/01.json", "utf8")).sheets[0].values.slice(1);
const records = merged.map((r) => ({
  primary: r[0], secondary: r[1], diagnosis: r[3], final: r[4], d447: r[10], daraE: r[14],
}));

function findRecord(name) {
  const key = canonical(name);
  return records.find((r) => canonical(r.primary) === key || canonical(r.secondary) === key);
}

for (const detector of ["447", "araE"]) {
  const verification = JSON.parse(await fs.readFile(`./previews/verify_${detector}.json`, "utf8"));
  const table = JSON.parse(verification.logInspect).values.slice(1);
  const observed = table.filter((row) => row[4] === "Observed");
  const results = observed.map((row) => {
    const record = findRecord(row[1]);
    const diagnosis = row[13];
    const expected = diagnosis === "CDf" || diagnosis === "CDr" ? "IBD" : "IBS";
    const detectorDecision = detector === "447" ? record?.d447 : record?.daraE;
    const detectorBinary = detectorDecision === "Pos" ? "IBD" : detectorDecision === "Neg" ? "IBS" : "inconclusive";
    return { sample: row[1], group: row[0], diagnosis, expected, final: record?.final, detectorDecision, detectorBinary, finalError: record?.final !== expected, detectorError: detectorBinary !== expected };
  });
  process.stdout.write(`\n${detector} observed n=${results.length} final errors=${results.filter((r) => r.finalError).length} detector errors incl Int=${results.filter((r) => r.detectorError).length}\n`);
  for (const result of results.filter((r) => r.finalError || r.detectorError)) process.stdout.write(`${JSON.stringify(result)}\n`);
}
