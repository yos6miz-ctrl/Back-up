import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outDir = process.argv[2];
const files = process.argv.slice(3);
if (!outDir || files.length === 0) {
  throw new Error("Usage: node inspect_workbooks.mjs OUT_DIR FILE...");
}
await fs.mkdir(outDir, { recursive: true });

for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
  const file = files[fileIndex];
  const input = await FileBlob.load(file);
  const workbook = await SpreadsheetFile.importXlsx(input);
  const sheets = [];
  for (let i = 0; i < workbook.worksheets.items.length; i += 1) {
    const sheet = workbook.worksheets.getItemAt(i);
    const used = sheet.getUsedRange();
    sheets.push({
      name: sheet.name,
      usedAddress: used?.address ?? null,
      values: used ? used.values : [],
      formulas: used ? used.formulas : [],
      displayFormulas: used ? used.displayFormulas : [],
    });
    if (fileIndex < 5) {
      const rendered = await workbook.render({
        sheetName: sheet.name,
        range: "A1:Z60",
        scale: 1,
        format: "png",
      });
      const safeBase = path.basename(file).replace(/[^A-Za-z0-9._-]+/g, "_");
      const safeSheet = sheet.name.replace(/[^A-Za-z0-9._-]+/g, "_");
      await fs.writeFile(path.join(outDir, `${String(fileIndex + 1).padStart(2, "0")}_${safeBase}_${safeSheet}.png`), new Uint8Array(await rendered.arrayBuffer()));
    }
  }
  const overview = await workbook.inspect({
    kind: "workbook,sheet,table,drawing,definedName",
    maxChars: 12000,
    tableMaxRows: 10,
    tableMaxCols: 12,
    tableMaxCellChars: 120,
  });
  const styles = sheets.length
    ? await workbook.inspect({
        kind: "computedStyle",
        sheetId: sheets[0].name,
        range: "A1:Z20",
        maxChars: 6000,
      })
    : { ndjson: "" };
  const payload = {
    file,
    overview: overview.ndjson,
    styles: styles.ndjson,
    sheets,
  };
  await fs.writeFile(path.join(outDir, `${String(fileIndex + 1).padStart(2, "0")}.json`), JSON.stringify(payload, null, 2));
  process.stdout.write(`${fileIndex + 1}/${files.length} ${file}\n`);
}
