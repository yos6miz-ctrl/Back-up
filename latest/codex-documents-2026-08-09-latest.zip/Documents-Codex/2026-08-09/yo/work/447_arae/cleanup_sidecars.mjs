import fs from "node:fs/promises";
import path from "node:path";

const allowedRoots = [
  "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE",
].map((p) => path.resolve(p));

const targets = allowedRoots.flatMap((root) => [
  path.resolve(root, "Final 447.xlsx.inspect.ndjson"),
  path.resolve(root, "Final araE.xlsx.inspect.ndjson"),
]);

for (const target of targets) {
  if (!allowedRoots.some((root) => target.startsWith(`${root}${path.sep}`))) {
    throw new Error(`Refusing target outside allowed roots: ${target}`);
  }
  try {
    await fs.unlink(target);
    process.stdout.write(`Removed generated sidecar: ${target}\n`);
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
}
