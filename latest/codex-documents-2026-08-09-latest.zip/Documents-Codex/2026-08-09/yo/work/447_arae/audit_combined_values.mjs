import fs from "node:fs/promises";

function readLog(detector) {
  return fs.readFile(`./previews/verify_${detector}.json`, "utf8")
    .then((text) => JSON.parse(text))
    .then((json) => JSON.parse(json.logInspect).values.slice(1));
}

const [rows447, rowsAraE] = await Promise.all([readLog("447"), readLog("araE")]);
const merged = JSON.parse(await fs.readFile("./inspect_merged/01.json", "utf8")).sheets[0].values.slice(1);
const shipmentRows = JSON.parse(await fs.readFile("./inspect_diagnosis/01.json", "utf8")).sheets[0].values.slice(1);

function canonical(v) {
  return String(v ?? "").toUpperCase().trim().replace(/^(?:IBS|CDF|CDR|CD|HS|UN)\s*/g, "").replace(/[^A-Z0-9]/g, "").replace(/^F/, "");
}

const shipmentDiagnoses = new Map(shipmentRows.filter((r) => r[1] && r[2]).map((r) => [canonical(r[1]), r[2]]));
function diagnosisFor(row) {
  const key = canonical(row[1]);
  const record = merged.find((r) => canonical(r[0]) === key || canonical(r[1]) === key);
  return shipmentDiagnoses.get(key) ?? record?.[3] ?? (row[0] === "HS" ? "Healthy" : row[0] === "CD" ? "CDr" : "IBS");
}

const araEByName = new Map(rowsAraE.map((row) => [row[1], row]));
const audited = rows447.map((row447) => {
  const rowAraE = araEByName.get(row447[1]);
  const diagnosis = diagnosisFor(row447);
  const expectedIbd = diagnosis === "CDf" || diagnosis === "CDr";
  const value447 = Number(row447[10]);
  const valueAraE = Number(rowAraE?.[10]);
  const predictedIbd = value447 >= 0.22 || valueAraE >= 0.14;
  return {
    group: row447[0], sample: row447[1], origin447: row447[4], originAraE: rowAraE?.[4], diagnosis,
    value447, valueAraE, expectedIbd, predictedIbd, error: expectedIbd !== predictedIbd,
    errorType: expectedIbd && !predictedIbd ? "FN CD" : !expectedIbd && predictedIbd ? "FP non-CD" : "correct",
  };
});
const errors = audited.filter((row) => row.error);
process.stdout.write(`total=${audited.length} errors=${errors.length} rate=${(errors.length / audited.length * 100).toFixed(1)}%\n`);
process.stdout.write(`base=${audited.filter((row) => row.group !== "Follow-up").length} baseErrors=${errors.filter((row) => row.group !== "Follow-up").length}\n`);
for (const row of errors) process.stdout.write(`${JSON.stringify(row)}\n`);
