import fs from "node:fs/promises";

const read = async (p) => JSON.parse(await fs.readFile(p, "utf8"));
const sourceFiles = [await read("./inspect/07.json"), await read("./inspect/08.json")];
const repeatFiles = [await read("./inspect/03.json"), await read("./inspect/04.json"), await read("./inspect/05.json")];

function canon(v) {
  let s = String(v ?? "").toUpperCase().trim();
  s = s.replace(/^(?:IBS|CDF|CDR|CD|HS|UN)\s*/g, "");
  s = s.replace(/[^A-Z0-9]/g, "");
  s = s.replace(/^F/, "");
  return s;
}

const candidates = [];
for (const [i, f] of sourceFiles.entries()) {
  const values = f.sheets[0].values.slice(1);
  for (const row of values) {
    const name = i === 0 ? row[4] : row[1];
    if (String(name ?? "").trim()) candidates.push({ source: i === 0 ? "shipment" : "july", name });
  }
}

const repeatCells = [];
for (const file of repeatFiles) {
  for (const sheet of file.sheets) {
    for (let r = 0; r < sheet.values.length; r += 1) {
      for (let c = 0; c < sheet.values[r].length; c += 1) {
        const value = sheet.values[r][c];
        if (typeof value === "string" && value.trim()) repeatCells.push({ file: file.file, sheet: sheet.name, row: r + 1, col: c + 1, value, canon: canon(value) });
      }
    }
  }
}

for (const candidate of candidates) {
  const key = canon(candidate.name);
  const hits = repeatCells.filter((x) => x.canon === key);
  if (hits.length) process.stdout.write(`${candidate.name}\t${hits.map((h) => `${h.row}:${h.col}:${h.value}`).join(" || ")}\n`);
}
