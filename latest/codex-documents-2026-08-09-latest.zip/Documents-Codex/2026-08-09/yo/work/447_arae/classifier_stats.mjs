import fs from "node:fs/promises";

const merged = JSON.parse(await fs.readFile("./inspect_merged/01.json", "utf8")).sheets[0].values.slice(1);
const mean = (xs) => xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null;
const quantile = (xs, q) => {
  const a = xs.slice().sort((x, y) => x - y);
  if (!a.length) return null;
  const p = (a.length - 1) * q;
  const lo = Math.floor(p), hi = Math.ceil(p);
  return lo === hi ? a[lo] : a[lo] + (a[hi] - a[lo]) * (p - lo);
};
for (const detector of ["447", "araE"]) {
  for (const diagnosis of ["CDf", "CDr", "IBS", "Healthy"]) {
    for (const correctlyClassified of [false, true]) {
      const expected = diagnosis === "CDf" || diagnosis === "CDr" ? "IBD" : diagnosis === "IBS" ? "IBS" : null;
      const values = merged
        .filter((r) => r[2] === "measured" && r[3] === diagnosis && (!correctlyClassified || !expected || r[4] === expected))
        .map((r) => mean((detector === "447" ? [r[7], r[8], r[9]] : [r[11], r[12], r[13]]).filter((v) => typeof v === "number")))
        .filter((v) => typeof v === "number");
      process.stdout.write(`${detector}\t${diagnosis}\t${correctlyClassified ? "classifier-match" : "all"}\tn=${values.length}\tq25=${quantile(values, .25)}\tmedian=${quantile(values, .5)}\tq75=${quantile(values, .75)}\n`);
    }
  }
}
