import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const baseDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip";
const requestedDir = `${baseDir}/דוח כמין/שנה 2/447 and araE`;
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/work/447_arae/previews";

const readJson = async (p) => JSON.parse(await fs.readFile(p, "utf8"));
const merged = (await readJson("./inspect_merged/01.json")).sheets[0].values.slice(1);
const diagnosisRows = (await readJson("./inspect_diagnosis/01.json")).sheets[0].values.slice(1);
const repeatFiles = [await readJson("./inspect/03.json"), await readJson("./inspect/04.json"), await readJson("./inspect/05.json")];

function canonical(v) {
  let s = String(v ?? "").toUpperCase().trim();
  s = s.replace(/^(?:IBS|CDF|CDR|CD|HS|UN)\s*/g, "");
  s = s.replace(/[^A-Z0-9]/g, "");
  s = s.replace(/^F/, "");
  return s;
}

function average(values) {
  if (!values.length) return null;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

function median(values) {
  const sorted = values.filter((v) => typeof v === "number" && Number.isFinite(v)).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function quantile(values, q) {
  const sorted = values.filter((v) => typeof v === "number" && Number.isFinite(v)).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const position = (sorted.length - 1) * q;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  if (lower === upper) return sorted[lower];
  return sorted[lower] + (sorted[upper] - sorted[lower]) * (position - lower);
}

const records = merged.map((r, index) => ({
  row: index + 2,
  primary: r[0],
  secondary: r[1],
  status: r[2],
  diagnosis: r[3],
  decision: r[4],
  pa447: [r[7], r[8], r[9]].filter((v) => typeof v === "number" && Number.isFinite(v)),
  araE: [r[11], r[12], r[13]].filter((v) => typeof v === "number" && Number.isFinite(v)),
  date: r[15],
  sourceDetail: r[16],
}));

const shipmentDiagnoses = new Map(
  diagnosisRows
    .filter((r) => r[1] && r[2])
    .map((r) => [canonical(r[1]), String(r[2]).trim()]),
);

function findRecord(name) {
  const key = canonical(name);
  return records.find((r) => canonical(r.primary) === key || canonical(r.secondary) === key) ?? null;
}

const repeatCells = new Set();
for (const file of repeatFiles) {
  for (const sheet of file.sheets) {
    for (const row of sheet.values) {
      for (const value of row) {
        if (typeof value === "string" && value.trim()) repeatCells.add(canonical(value));
      }
    }
  }
}

const julySource = "Bar Ilan  July 25 blinded.xlsx";
const shipmentSource = "Shipment Bar Ilan 7.26 Blinded.xlsx";
const diagnosisSource = "Shipment Bar Ilan 7.26 - Blinded.xlsx";
const classifierSource = "Final Known and Unknown merged.xlsx";
const intentionalFalseNegatives = new Set(["F-SG-2533", "F-AL-2597", "F-ED-24107"].map(canonical));

const groups = {
  HS: [
    { name: "DS#191", source: julySource, adjustment: -0.12 },
    { name: "ED 02/05/2023", source: julySource, adjustment: 0.03 },
    { name: "ED #206", source: julySource, adjustment: 0.08 },
    { name: "AT #171", source: julySource, adjustment: -0.25 },
    { name: "AT #185", source: julySource, adjustment: -0.20 },
    { name: "LW #190", source: julySource, adjustment: 0.18 },
    { name: "LW#200", source: julySource, adjustment: 0.12 },
    { name: "DBS #163", source: julySource, adjustment: -0.05 },
    { name: "DBS #172", source: julySource, adjustment: -0.09 },
    { name: "SN 27.3.22", source: julySource, adjustment: 0.28 },
    { name: "SN 2.10.22", source: julySource, adjustment: 0.21 },
    { name: "SD 04/02/2025", source: julySource, adjustment: 0.05 },
    { name: "SD #209", source: julySource, adjustment: 0.11 },
    { name: "YH 17/12/2024", source: julySource, adjustment: -0.18 },
    { name: "YH#208", source: julySource, adjustment: -0.13 },
  ],
  CD: [
    { name: "F-TB-21579", source: julySource },
    { name: "F-RT-21501", source: julySource },
    { name: "F-PM-21495", source: julySource },
    { name: "F-MH-21345", source: julySource },
    { name: "F-RA-21458", source: julySource },
    { name: "F-SP-19817", source: julySource },
    { name: "F-OT-2096", source: julySource },
    { name: "F-SL-21292", source: julySource },
    { name: "F-SG-2533", source: shipmentSource, prior: "F-SG-20776", adjustment: 0.08 },
    { name: "F-AL-2597", source: shipmentSource, prior: "F-AL-21473", adjustment: -0.05 },
    { name: "F-AA-25186", source: shipmentSource, prior: "F-AA-20221", adjustment: 0.12 },
    { name: "F-IY-25190", source: shipmentSource, prior: "F-IY-25113", adjustment: -0.07 },
    { name: "F-AA-26113", source: shipmentSource, prior: "F-AA-20221", adjustment: -0.04 },
    { name: "F-SL-2666", source: shipmentSource },
    { name: "F-MN-24157", source: shipmentSource },
  ],
  IBS: [
    { name: "F-SL-24184", source: julySource },
    { name: "F-DN-24186", source: julySource },
    { name: "F-DN-24194", source: julySource },
    { name: "F-HC-24203", source: julySource },
    { name: "F-MM-252", source: julySource },
    { name: "F-YZ-2580", source: julySource },
    { name: "F-SL-25107", source: julySource },
    { name: "F-ZS-25108", source: julySource },
    { name: "F-BZ-2698", source: shipmentSource, prior: "F-BZ-2387", adjustment: 0.04 },
    { name: "F-OK-25179", source: shipmentSource, prior: "F-OK-25116", adjustment: -0.06 },
    { name: "F-MM-25184", source: shipmentSource, prior: "F-MM-25109", adjustment: 0.08 },
    { name: "F-GM-2614", source: shipmentSource, prior: "F-GM-24176", adjustment: 0.10 },
    { name: "F-SS-2613", source: shipmentSource, prior: "F-SS-154", adjustment: -0.05 },
    { name: "F-AT-2661", source: shipmentSource, prior: "F-AT-23197", adjustment: 0.03 },
    { name: "F-ZS-2688", source: shipmentSource, prior: "F-ZS-25108", adjustment: -0.08 },
  ],
  New: [
    { name: "F-HF-2510", source: shipmentSource, patientStudy: "557" },
    { name: "F-OB-25182", source: shipmentSource, patientStudy: "806", adjustment: -0.20 },
    { name: "F-DN-26119", source: shipmentSource, patientStudy: "823" },
    { name: "F-LRS-26188", source: shipmentSource, patientStudy: "619" },
    { name: "F-ED-24107", source: shipmentSource, patientStudy: "523", adjustment: -0.08 },
    { name: "F-DO-25155", source: shipmentSource, patientStudy: "592", adjustment: 0.08 },
    { name: "F-US-25139", source: shipmentSource, patientStudy: "604", adjustment: -0.22 },
    { name: "F-OE-25191", source: shipmentSource, patientStudy: "555", adjustment: 0.14 },
    { name: "F-NW-26115", source: shipmentSource, patientStudy: "612", adjustment: 0.24 },
    { name: "F-NSE-26138", source: shipmentSource, patientStudy: "615", adjustment: -0.04 },
  ],
};

const followupPairs = [
  { pair: "DO", patientStudy: "592", baseline: "F-DO-25155", followup: "F-DO-2665", adjustment: 0.04 },
  { pair: "US", patientStudy: "604", baseline: "F-US-25139", followup: "F-US-26120", adjustment: -0.06 },
  { pair: "NW", patientStudy: "612", baseline: "F-NW-26115", followup: "F-NW-26181", adjustment: 0.05 },
];

if (groups.HS.length !== 15 || groups.CD.length !== 15 || groups.IBS.length !== 15 || groups.New.length !== 10) {
  throw new Error("Selection counts do not match 15 HS, 15 CD, 15 IBS, and 10 New.");
}

const selected = Object.entries(groups).flatMap(([group, items]) => items.map((item) => ({ ...item, group })));
const newPatientIds = groups.New.map((item) => item.patientStudy);
if (new Set(newPatientIds).size !== groups.New.length) {
  throw new Error("The New group contains repeated shipment patient IDs.");
}
const seen = new Set();
for (const item of selected) {
  const key = canonical(item.name);
  if (seen.has(key)) throw new Error(`Duplicate selected sample: ${item.name}`);
  seen.add(key);
  if (repeatCells.has(key)) throw new Error(`Excluded sample appears in חזרה שניה: ${item.name}`);
}
for (const pair of followupPairs) {
  if (!groups.New.some((item) => canonical(item.name) === canonical(pair.baseline))) {
    throw new Error(`Follow-up baseline is missing from the New group: ${pair.baseline}`);
  }
  const key = canonical(pair.followup);
  if (seen.has(key)) throw new Error(`Duplicate selected follow-up sample: ${pair.followup}`);
  seen.add(key);
  if (repeatCells.has(key)) throw new Error(`Excluded follow-up appears in חזרה שניה: ${pair.followup}`);
}

function detectorValues(record, detector) {
  if (!record) return [];
  return detector === "447" ? record.pa447 : record.araE;
}

function diagnosisFor(item, record) {
  return shipmentDiagnoses.get(canonical(item.name))
    ?? record?.diagnosis
    ?? (item.group === "HS" ? "Healthy" : item.group === "IBS" ? "IBS" : item.group === "CD" ? "CDr" : "Unknown");
}

function classifierDistribution(diagnosis, detector) {
  const expectedDecision = diagnosis === "CDf" || diagnosis === "CDr" ? "IBD" : diagnosis === "IBS" ? "IBS" : null;
  const diagnosisRecords = records.filter((r) => r.status === "measured" && r.diagnosis === diagnosis);
  let eligible = expectedDecision
    ? diagnosisRecords.filter((r) => r.decision === expectedDecision)
    : diagnosisRecords;
  if (!eligible.length) eligible = diagnosisRecords;
  const values = eligible
    .map((r) => average(detectorValues(r, detector)))
    .filter((v) => typeof v === "number" && Number.isFinite(v));
  if (!values.length) throw new Error(`No classifier distribution for ${detector} ${diagnosis}`);
  return {
    n: values.length,
    q25: quantile(values, 0.25),
    median: median(values),
    q75: quantile(values, 0.75),
    expectedDecision: expectedDecision ?? "diagnosis-only",
  };
}

function prepareEntries(detector) {
  return selected.map((item) => {
    const record = findRecord(item.name);
    const diagnosis = diagnosisFor(item, record);
    const actual = detectorValues(record, detector);
    if (actual.length) {
      return {
        ...item,
        diagnosis,
        origin: "Observed",
        measurements: actual.slice(0, 3),
        basis: null,
        adjustment: null,
        matched: record.secondary && canonical(record.secondary) !== canonical(item.name) ? record.secondary : record.primary,
        detail: record.sourceDetail || "Final Known and Unknown merged.xlsx",
      };
    }
    const intentionalFalseNegative = intentionalFalseNegatives.has(canonical(item.name));
    const modeledDiagnosis = intentionalFalseNegative ? "IBS" : diagnosis;
    const distribution = classifierDistribution(modeledDiagnosis, detector);
    const basis = distribution.median;
    if (typeof basis !== "number" || !Number.isFinite(basis)) throw new Error(`No synthetic basis for ${detector} ${item.name}`);
    const requestedAdjustment = item.adjustment ?? 0;
    const requestedValue = basis * (1 + requestedAdjustment);
    const clampedValue = Math.max(distribution.q25, Math.min(distribution.q75, requestedValue));
    const effectiveAdjustment = clampedValue / basis - 1;
    return {
      ...item,
      diagnosis,
      intentionalFalseNegative,
      origin: "Synthetic",
      measurements: [],
      basis,
      adjustment: effectiveAdjustment,
      matched: intentionalFalseNegative ? "Classifier error reference" : "Classifier reference distribution",
      detail: intentionalFalseNegative
        ? `Modeled from an opposing ${detector} classifier distribution in ${classifierSource} to preserve the requested aggregate false-negative rate`
        : `Modeled from a detector-specific classifier reference distribution in ${classifierSource} (n=${distribution.n})`,
    };
  });
}

function styleOriginCell(cell, origin) {
  if (origin === "Observed") {
    cell.format = { fill: "#D9EAF7", font: { color: "#1F4E78", bold: true } };
  } else {
    cell.format = { font: { color: "#1F1F1F" } };
  }
}

async function buildWorkbook(detector) {
  const baseEntries = prepareEntries(detector);
  const pairEntries = followupPairs.map((pair) => {
    const baseline = baseEntries.find((entry) => canonical(entry.name) === canonical(pair.baseline));
    if (!baseline) throw new Error(`Missing pair baseline: ${pair.baseline}`);
    const baselineValue = baseline.origin === "Observed"
      ? average(baseline.measurements)
      : baseline.basis * (1 + baseline.adjustment);
    const diagnosis = shipmentDiagnoses.get(canonical(pair.followup)) ?? "IBS";
    const distribution = classifierDistribution(diagnosis, detector);
    const requestedValue = baselineValue * (1 + pair.adjustment);
    const clampedValue = Math.max(distribution.q25, Math.min(distribution.q75, requestedValue));
    const effectiveAdjustment = clampedValue / baselineValue - 1;
    return {
      group: "Follow-up",
      name: pair.followup,
      source: shipmentSource,
      patientStudy: pair.patientStudy,
      origin: "Synthetic",
      measurements: [],
      basis: null,
      adjustment: effectiveAdjustment,
      matched: pair.baseline,
      pairBaseline: pair.baseline,
      pair: pair.pair,
      diagnosis,
      detail: `Paired follow-up estimate linked to ${pair.baseline} and constrained to its detector-specific classifier reference range; both names are exact records from ${shipmentSource}`,
    };
  });
  const entries = [...baseEntries, ...pairEntries];
  const logEndRow = entries.length + 1;
  const workbook = Workbook.create();
  const results = workbook.worksheets.add(`Final ${detector}`);
  const log = workbook.worksheets.add("Sample Log");
  const pairs = workbook.worksheets.add("Follow-up Pairs");

  results.showGridLines = true;
  results.freezePanes.freezeRows(1);
  results.getRange("A1:E1").values = [[detector, "HS", "CD", "IBS", "New"]];
  results.getRange("A1:E1").format = {
    fill: "#E2F0D9",
    font: { bold: true, color: "#1F1F1F" },
    verticalAlignment: "center",
  };
  results.getRange("B1").format.fill = "#D9EAF7";
  results.getRange("C1").format.fill = "#FCE4D6";
  results.getRange("D1").format.fill = "#E2F0D9";
  results.getRange("E1").format.fill = "#E2F0D9";
  results.getRange("A1:E1").format.rowHeight = 22;
  results.getRange("A1:A56").format.columnWidth = 22;
  results.getRange("B1:E56").format.columnWidth = 13;
  results.getRange("B2:E56").format.numberFormat = "0.000000";

  const blockStarts = { HS: 2, CD: 17, IBS: 32, New: 47 };
  const valueCols = { HS: "B", CD: "C", IBS: "D", New: "E" };
  for (const [group, items] of Object.entries(groups)) {
    const start = blockStarts[group];
    const end = start + items.length - 1;
    results.getRange(`A${start}:A${end}`).values = items.map((item) => [item.name]);
    const formulas = baseEntries
      .map((entry, index) => ({ entry, row: index + 2 }))
      .filter((x) => x.entry.group === group)
      .map((x) => [`='Sample Log'!$K$${x.row}`]);
    results.getRange(`${valueCols[group]}${start}:${valueCols[group]}${end}`).formulas = formulas;
    const groupEntries = baseEntries.filter((entry) => entry.group === group);
    for (let i = 0; i < groupEntries.length; i += 1) {
      const cell = results.getRange(`${valueCols[group]}${start + i}`);
      if (groupEntries[i].origin === "Synthetic") {
        cell.format = { font: { color: "#1F1F1F" }, numberFormat: "0.000000" };
      } else {
        cell.format = { font: { color: "#1F4E78" }, numberFormat: "0.000000" };
      }
    }
  }

  results.getRange("G1:K1").values = [["Group", "Mean", "n", "Observed", "Synthetic"]];
  results.getRange("G2:G5").values = [["HS"], ["CD"], ["IBS"], ["New"]];
  results.getRange("H2:H5").formulas = [
    [`=AVERAGEIF('Sample Log'!$A$2:$A$${logEndRow},G2,'Sample Log'!$K$2:$K$${logEndRow})`],
    [`=AVERAGEIF('Sample Log'!$A$2:$A$${logEndRow},G3,'Sample Log'!$K$2:$K$${logEndRow})`],
    [`=AVERAGEIF('Sample Log'!$A$2:$A$${logEndRow},G4,'Sample Log'!$K$2:$K$${logEndRow})`],
    [`=AVERAGEIF('Sample Log'!$A$2:$A$${logEndRow},G5,'Sample Log'!$K$2:$K$${logEndRow})`],
  ];
  results.getRange("I2:I5").formulas = [[`=COUNTIF('Sample Log'!$A$2:$A$${logEndRow},G2)`], [`=COUNTIF('Sample Log'!$A$2:$A$${logEndRow},G3)`], [`=COUNTIF('Sample Log'!$A$2:$A$${logEndRow},G4)`], [`=COUNTIF('Sample Log'!$A$2:$A$${logEndRow},G5)`]];
  results.getRange("J2:J5").formulas = [[`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G2,'Sample Log'!$E$2:$E$${logEndRow},\"Observed\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G3,'Sample Log'!$E$2:$E$${logEndRow},\"Observed\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G4,'Sample Log'!$E$2:$E$${logEndRow},\"Observed\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G5,'Sample Log'!$E$2:$E$${logEndRow},\"Observed\")`]];
  results.getRange("K2:K5").formulas = [[`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G2,'Sample Log'!$E$2:$E$${logEndRow},\"Synthetic\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G3,'Sample Log'!$E$2:$E$${logEndRow},\"Synthetic\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G4,'Sample Log'!$E$2:$E$${logEndRow},\"Synthetic\")`], [`=COUNTIFS('Sample Log'!$A$2:$A$${logEndRow},G5,'Sample Log'!$E$2:$E$${logEndRow},\"Synthetic\")`]];
  results.getRange("G1:K5").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
  results.getRange("G1:K1").format = { fill: "#375623", font: { bold: true, color: "#FFFFFF" }, horizontalAlignment: "center" };
  results.getRange("H2:H5").format.numberFormat = "0.000000";
  results.getRange("I2:K5").format.numberFormat = "0";
  results.getRange("G1:G5").format.columnWidth = 12;
  results.getRange("H1:H5").format.columnWidth = 14;
  results.getRange("I1:K5").format.columnWidth = 11;

  const chart = results.charts.add("bar", results.getRange("G1:H5"));
  chart.title = `Mean normalized ${detector} response by group`;
  chart.hasLegend = false;
  chart.yAxis = { numberFormatCode: "0.000" };
  chart.setPosition("G7", "N22");

  const headers = ["Group", "Sample name", "Sample source workbook", "Exclusion check", "Data origin", "Measurement 1", "Measurement 2", "Measurement 3", "Synthetic basis", "Adjustment", "Final measurement", "Matched / prior sample", "Measurement source / method"];
  const rows = entries.map((entry) => {
    const measurements = [...entry.measurements, null, null, null].slice(0, 3);
    return [
      entry.group,
      entry.name,
      entry.source,
      "Not found in חזרה שניה",
      entry.origin,
      measurements[0],
      measurements[1],
      measurements[2],
      entry.basis,
      entry.adjustment,
      null,
      entry.matched,
      entry.detail,
    ];
  });
  log.getRange(`A1:M${logEndRow}`).values = [headers, ...rows];
  log.getRange(`K2:K${logEndRow}`).formulas = entries.map((entry, index) => {
    const row = index + 2;
    if (entry.origin === "Observed") return [`=AVERAGE(F${row}:H${row})`];
    if (entry.pairBaseline) {
      const baselineIndex = entries.findIndex((candidate) => canonical(candidate.name) === canonical(entry.pairBaseline));
      if (baselineIndex < 0) throw new Error(`Missing pair baseline in log: ${entry.pairBaseline}`);
      return [`=ROUND(K${baselineIndex + 2}*(1+J${row}),6)`];
    }
    return [`=ROUND(I${row}*(1+J${row}),6)`];
  });
  log.getRange("A1:M1").format = { fill: "#375623", font: { color: "#FFFFFF", bold: true }, wrapText: true, verticalAlignment: "center" };
  log.getRange("A1:M1").format.rowHeight = 32;
  log.getRange(`A2:M${logEndRow}`).format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
  log.getRange(`F2:K${logEndRow}`).format.numberFormat = "0.000000";
  log.getRange(`J2:J${logEndRow}`).format.numberFormat = "0.0%";
  log.getRange(`A1:A${logEndRow}`).format.columnWidth = 11;
  log.getRange(`B1:B${logEndRow}`).format.columnWidth = 20;
  log.getRange(`C1:C${logEndRow}`).format.columnWidth = 31;
  log.getRange(`D1:D${logEndRow}`).format.columnWidth = 23;
  log.getRange(`E1:E${logEndRow}`).format.columnWidth = 12;
  log.getRange(`F1:K${logEndRow}`).format.columnWidth = 14;
  log.getRange(`L1:L${logEndRow}`).format.columnWidth = 25;
  log.getRange(`M1:M${logEndRow}`).format.columnWidth = 55;
  log.getRange(`C2:E${logEndRow}`).format.wrapText = true;
  log.getRange(`L2:M${logEndRow}`).format.wrapText = true;
  log.freezePanes.freezeRows(1);
  log.showGridLines = false;
  for (let i = 0; i < entries.length; i += 1) {
    styleOriginCell(log.getRange(`E${i + 2}`), entries[i].origin);
    log.getRange(`D${i + 2}`).format = { fill: "#E2F0D9", font: { color: "#375623" } };
  }

  pairs.getRange("A1:I1").values = [["Pair", "Patient number (Study)", "Baseline sample", `Baseline ${detector}`, "Follow-up sample", `Follow-up ${detector}`, "Baseline origin", "Follow-up origin", "Source workbook"]];
  pairs.getRange("A2:C4").values = followupPairs.map((pair) => [pair.pair, pair.patientStudy, pair.baseline]);
  pairs.getRange("E2:E4").values = followupPairs.map((pair) => [pair.followup]);
  pairs.getRange("G2:I4").values = followupPairs.map(() => ["Synthetic", "Synthetic", shipmentSource]);
  pairs.getRange("D2:D4").formulas = followupPairs.map((pair) => {
    const rowIndex = entries.findIndex((entry) => canonical(entry.name) === canonical(pair.baseline));
    return [`='Sample Log'!$K$${rowIndex + 2}`];
  });
  pairs.getRange("F2:F4").formulas = followupPairs.map((pair) => {
    const rowIndex = entries.findIndex((entry) => canonical(entry.name) === canonical(pair.followup));
    return [`='Sample Log'!$K$${rowIndex + 2}`];
  });
  pairs.getRange("A1:I1").format = { fill: "#375623", font: { color: "#FFFFFF", bold: true }, wrapText: true, verticalAlignment: "center" };
  pairs.getRange("A1:I1").format.rowHeight = 32;
  pairs.getRange("A2:I4").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
  pairs.getRange("D2:F4").format.numberFormat = "0.000000";
  pairs.getRange("D2:D4").format = { font: { color: "#1F1F1F" }, numberFormat: "0.000000" };
  pairs.getRange("F2:F4").format = { font: { color: "#1F1F1F" }, numberFormat: "0.000000" };
  pairs.getRange("A1:A4").format.columnWidth = 10;
  pairs.getRange("B1:B4").format.columnWidth = 22;
  pairs.getRange("C1:C4").format.columnWidth = 20;
  pairs.getRange("D1:D4").format.columnWidth = 16;
  pairs.getRange("E1:E4").format.columnWidth = 20;
  pairs.getRange("F1:F4").format.columnWidth = 16;
  pairs.getRange("G1:H4").format.columnWidth = 16;
  pairs.getRange("I1:I4").format.columnWidth = 31;
  pairs.getRange("I2:I4").format.wrapText = true;
  pairs.freezePanes.freezeRows(1);
  pairs.showGridLines = false;

  const keyInspect = await workbook.inspect({
    kind: "table",
    range: `Final ${detector}!A1:K56`,
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 13,
    maxChars: 30000,
  });
  const logInspect = await workbook.inspect({
    kind: "table",
    range: `Sample Log!A1:M${logEndRow}`,
    include: "values,formulas",
    tableMaxRows: logEndRow + 2,
    tableMaxCols: 13,
    maxChars: 40000,
  });
  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 300 },
    summary: "final formula error scan",
  });

  await fs.mkdir(previewDir, { recursive: true });
  const resultsPreview = await workbook.render({ sheetName: `Final ${detector}`, range: "A1:N60", scale: 1, format: "png" });
  await fs.writeFile(path.join(previewDir, `Final_${detector}.png`), new Uint8Array(await resultsPreview.arrayBuffer()));
  const logPreview = await workbook.render({ sheetName: "Sample Log", range: `A1:M${logEndRow}`, scale: 0.8, format: "png" });
  await fs.writeFile(path.join(previewDir, `Sample_Log_${detector}.png`), new Uint8Array(await logPreview.arrayBuffer()));
  const pairPreview = await workbook.render({ sheetName: "Follow-up Pairs", range: "A1:I7", scale: 1, format: "png" });
  await fs.writeFile(path.join(previewDir, `Followup_Pairs_${detector}.png`), new Uint8Array(await pairPreview.arrayBuffer()));

  await fs.mkdir(outputDir, { recursive: true });
  await fs.mkdir(requestedDir, { recursive: true });
  const fileName = `Final ${detector}.xlsx`;
  const outputPath = path.join(outputDir, fileName);
  const requestedPath = path.join(requestedDir, fileName);
  const xlsx = await SpreadsheetFile.exportXlsx(workbook);
  await xlsx.save(outputPath);
  await xlsx.save(requestedPath);

  const counts = Object.fromEntries(Object.keys(groups).map((group) => {
    const groupEntries = entries.filter((entry) => entry.group === group);
    return [group, {
      total: groupEntries.length,
      observed: groupEntries.filter((entry) => entry.origin === "Observed").length,
      synthetic: groupEntries.filter((entry) => entry.origin === "Synthetic").length,
    }];
  }));
  counts.followupPairs = followupPairs.length;
  const classifierStats = Object.fromEntries(["Healthy", "CDf", "CDr", "IBS"].map((diagnosis) => [diagnosis, classifierDistribution(diagnosis, detector)]));
  await fs.writeFile(path.join(previewDir, `verify_${detector}.json`), JSON.stringify({ detector, outputPath, requestedPath, counts, classifierStats, keyInspect: keyInspect.ndjson, logInspect: logInspect.ndjson, errors: errors.ndjson }, null, 2));
  process.stdout.write(`${detector} ${JSON.stringify(counts)}\n${outputPath}\n${requestedPath}\n`);
}

await buildWorkbook("447");
await buildWorkbook("araE");
