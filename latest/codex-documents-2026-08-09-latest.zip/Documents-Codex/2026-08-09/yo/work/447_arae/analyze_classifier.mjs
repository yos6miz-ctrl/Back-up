import fs from "node:fs/promises";

const values = JSON.parse(await fs.readFile("./inspect_merged/01.json", "utf8")).sheets[0].values;
const rows = values.slice(1).filter((r) => r[2] === "measured");

function average(items) {
  const nums = items.filter((v) => typeof v === "number" && Number.isFinite(v));
  return nums.length ? nums.reduce((sum, value) => sum + value, 0) / nums.length : null;
}

function keyCount(items, keyFn) {
  const counts = new Map();
  for (const item of items) {
    const key = keyFn(item);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return Object.fromEntries([...counts.entries()].sort());
}

for (const detector of ["447", "araE"]) {
  const measurementCols = detector === "447" ? [7, 8, 9] : [11, 12, 13];
  const decisionCol = detector === "447" ? 10 : 14;
  const usable = rows
    .map((r) => ({
      name: r[0],
      diagnosis: r[3],
      final: r[4],
      detectorDecision: r[decisionCol],
      value: average(measurementCols.map((index) => r[index])),
    }))
    .filter((r) => r.value !== null);
  process.stdout.write(`\n${detector} n=${usable.length}\n`);
  process.stdout.write(`diagnosis x detector decision ${JSON.stringify(keyCount(usable, (r) => `${r.diagnosis}|${r.detectorDecision}`))}\n`);
  process.stdout.write(`diagnosis x final ${JSON.stringify(keyCount(usable, (r) => `${r.diagnosis}|${r.final}`))}\n`);
  for (const decision of [...new Set(usable.map((r) => r.detectorDecision))].sort()) {
    const subset = usable.filter((r) => r.detectorDecision === decision).map((r) => r.value).sort((a, b) => a - b);
    process.stdout.write(`${decision}: n=${subset.length} min=${subset[0]} max=${subset.at(-1)}\n`);
  }
  const labeled = usable.filter((r) => ["CDf", "CDr", "UCf", "IBS", "Healthy"].includes(r.diagnosis));
  const thresholds = [...new Set(labeled.map((r) => r.value))].sort((a, b) => a - b);
  let bestAccuracy = null;
  let bestBalanced = null;
  for (const threshold of thresholds) {
    let tp = 0; let fn = 0; let tn = 0; let fp = 0;
    for (const row of labeled) {
      const positive = ["CDf", "CDr", "UCf"].includes(row.diagnosis);
      const predicted = row.value >= threshold;
      if (positive && predicted) tp += 1;
      else if (positive) fn += 1;
      else if (predicted) fp += 1;
      else tn += 1;
    }
    const accuracy = (tp + tn) / labeled.length;
    const sensitivity = tp / (tp + fn);
    const specificity = tn / (tn + fp);
    const balanced = (sensitivity + specificity) / 2;
    const candidate = { threshold, tp, fn, tn, fp, accuracy, sensitivity, specificity, balanced };
    if (!bestAccuracy || candidate.accuracy > bestAccuracy.accuracy) bestAccuracy = candidate;
    if (!bestBalanced || candidate.balanced > bestBalanced.balanced) bestBalanced = candidate;
  }
  process.stdout.write(`best accuracy threshold ${JSON.stringify(bestAccuracy)}\n`);
  process.stdout.write(`best balanced threshold ${JSON.stringify(bestBalanced)}\n`);
}
