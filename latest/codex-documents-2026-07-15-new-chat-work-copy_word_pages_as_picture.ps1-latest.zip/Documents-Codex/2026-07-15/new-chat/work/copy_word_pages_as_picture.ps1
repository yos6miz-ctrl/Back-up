$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$docPath = (Resolve-Path 'outputs\Teads_TA_Interview_Assignment.docx').Path
$qaDir = (Resolve-Path 'work\qa_review_comments_20260715').Path
$targets = @(
    @{ Text = 'FIVE-MINUTE READER PATH'; File = 'picture-page1.png' },
    @{ Text = 'Modular LinkedIn Recruiter searches'; File = 'picture-page2.png' },
    @{ Text = 'Exploratory adjacent-pool prospect'; File = 'picture-page5.png' },
    @{ Text = 'ChatGPT Enterprise'; File = 'picture-page6.png' },
    @{ Text = 'Branching sequence'; File = 'picture-page7.png' },
    @{ Text = 'LOCATION DROP-OFF HEATMAP'; File = 'picture-page8.png' }
)

$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($docPath, $false, $true)
    $doc.Repaginate()
    foreach ($item in $targets) {
        $range = $doc.Content.Duplicate
        $find = $range.Find
        $find.ClearFormatting()
        $find.Text = $item.Text
        $find.MatchCase = $true
        $find.Forward = $true
        $find.Wrap = 0
        if (-not $find.Execute()) { throw "Could not find target: $($item.Text)" }
        $range.Select()
        $pageRange = $word.Selection.Bookmarks.Item('\Page').Range
        $pageRange.Select()
        [System.Windows.Forms.Clipboard]::Clear()
        $word.Selection.CopyAsPicture()
        Start-Sleep -Milliseconds 700
        $image = [System.Windows.Forms.Clipboard]::GetImage()
        if ($null -eq $image) { throw "Word did not place an image on the clipboard for: $($item.Text)" }
        try {
            $image.Save((Join-Path $qaDir $item.File), [System.Drawing.Imaging.ImageFormat]::Png)
        }
        finally {
            $image.Dispose()
        }
    }
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
