$ErrorActionPreference = 'Stop'
$docPath = (Resolve-Path 'outputs\Teads_TA_Interview_Assignment.docx').Path
$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($docPath, $false, $true)
    $doc.Repaginate()
    "TOTAL_PAGES=$($doc.ComputeStatistics(2))"
    foreach ($target in @(
        'FIVE-MINUTE READER PATH',
        'Modular LinkedIn Recruiter searches',
        'Five prospects to validate',
        'Exploratory adjacent-pool prospect',
        'AI-assisted hidden talent-pool discovery prompt',
        'ChatGPT Enterprise',
        'Branching sequence',
        'STAKEHOLDER ONE-PAGER',
        'Forecast: 5.8 accepts against a target of 6',
        'LOCATION DROP-OFF HEATMAP',
        'In plain English: each active candidate is counted once',
        'Each target-state cohort back-solves from three accepts',
        'Teads Israel: current status and action plan',
        'Short-term, low-cost actions and long-term plays',
        'Event participation, return rate and NPS are leading indicators'
    )) {
        $range = $doc.Content.Duplicate
        $find = $range.Find
        $find.ClearFormatting()
        $find.Text = $target
        $find.MatchCase = $true
        $find.Forward = $true
        $find.Wrap = 0
        if ($find.Execute()) {
            "$target=$($range.Information(3))"
        }
        else {
            "$target=NOT_FOUND"
        }
    }
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
