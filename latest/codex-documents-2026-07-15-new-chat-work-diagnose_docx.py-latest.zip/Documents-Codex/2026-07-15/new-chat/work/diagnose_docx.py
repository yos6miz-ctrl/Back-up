from copy import deepcopy
from pathlib import Path

from docx import Document


source = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-07-15\new-chat\outputs\Teads_Lead_Technical_TA_Interview_Assignment.docx")
out_dir = source.parent.parent / "work" / "diagnostic_cuts"
out_dir.mkdir(parents=True, exist_ok=True)

for cutoff in (60, 108, 118, 160, 190, 208, 223):
    doc = Document(source)
    body = doc._element.body
    sect_pr = deepcopy(body[-1])
    for element in list(body)[cutoff:]:
        body.remove(element)
    if len(body) == 0 or body[-1].tag.split("}")[-1] != "sectPr":
        body.append(sect_pr)
    doc.save(out_dir / f"cut_{cutoff}.docx")

print(out_dir)
