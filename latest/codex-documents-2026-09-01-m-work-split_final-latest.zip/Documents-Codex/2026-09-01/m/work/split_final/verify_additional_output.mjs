import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outputPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_additions_20260902/Final Known and Unknown - additional raw measurements.xlsx";
const workDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final";

const input = await FileBlob.load(outputPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const summary = await workbook.inspect({
  kind: "workbook,sheet",
  include: "id,name",
  maxChars: 3000,
});
const olderCheck = await workbook.inspect({
  kind: "region",
  sheetId: "Older samples - before 2021",
  range: "A185:AA190",
  maxChars: 4500,
});
const onwardCheck = await workbook.inspect({
  kind: "region",
  sheetId: "2021 onward",
  range: "A14:AA36",
  maxChars: 4500,
});
const cdrCheck = await workbook.inspect({
  kind: "region",
  sheetId: "2021 onward",
  range: "A132:AA135",
  maxChars: 3000,
});
const diagnostics = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "exported workbook formula error scan",
});

console.log("SUMMARY");
console.log(summary.ndjson);
console.log("OLDER_CHECK");
console.log(olderCheck.ndjson);
console.log("ONWARD_CHECK");
console.log(onwardCheck.ndjson);
console.log("CDR_CHECK");
console.log(cdrCheck.ndjson);
console.log("DIAGNOSTICS");
console.log(diagnostics.ndjson);

const renders = [
  ["Older samples - before 2021", "A1:AA24", "final_additions_older.png", 1],
  ["2021 onward", "A1:AA24", "final_additions_onward.png", 1],
  ["Older samples - before 2021", "A185:AA190", "final_additions_new_sample.png", 1.5],
  ["2021 onward", "A14:AA36", "final_additions_aliases.png", 1],
];
for (const [sheetName, range, fileName, scale] of renders) {
  const blob = await workbook.render({ sheetName, range, scale, format: "png" });
  await fs.writeFile(`${workDir}/${fileName}`, new Uint8Array(await blob.arrayBuffer()));
}

const older = workbook.worksheets.getItem("Older samples - before 2021").getUsedRange();
const onward = workbook.worksheets.getItem("2021 onward").getUsedRange();
if (older.rowCount !== 190 || onward.rowCount !== 159) {
  throw new Error(`Unexpected exported row counts: older=${older.rowCount}, onward=${onward.rowCount}`);
}
console.log(JSON.stringify({
  olderRows: older.rowCount - 1,
  onwardRows: onward.rowCount - 1,
  totalRows: older.rowCount + onward.rowCount - 2,
}, null, 2));
