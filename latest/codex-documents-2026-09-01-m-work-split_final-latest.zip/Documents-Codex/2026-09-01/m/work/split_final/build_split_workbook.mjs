import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const ledgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additional_measurements_ledger.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_additions_20260902";
const outputPath = `${outputDir}/Final Known and Unknown - additional raw measurements.xlsx`;
const previewOlderPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additions_older_top.png";
const previewOnwardPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additions_onward_top.png";
const previewNewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additions_new_sample.png";
const previewAliasesPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additions_aliases.png";

const ledger = JSON.parse(await fs.readFile(ledgerPath, "utf8"));
const input = await FileBlob.load(ledger.input);
const workbook = await SpreadsheetFile.importXlsx(input);

const categoryStyles = {
  diagnosis: {
    CDf: { fill: "#E06666", font: "#000000" },
    Healthy: { fill: "#CFE2F3", font: "#000000" },
    CDr: { fill: "#F4CCCC", font: "#000000" },
    IBS: { fill: "#3C78D8", font: "#000000" },
    UCf: { fill: "#F6B26B", font: "#000000" },
    UCr: { fill: "#FCE5CD", font: "#000000" },
  },
  classification: {
    IBD: { fill: "#C00000", font: "#FFFFFF" },
    inconclusive: { fill: "#D9D2E9", font: "#4C3868" },
    IBS: { fill: "#003399", font: "#FFFFFF" },
    missing: { fill: "#E7E6E6", font: "#666666" },
    "לא נבדק": { fill: "#D9D2E9", font: "#4C3868" },
  },
  decision: {
    Neg: { fill: "#CFE2F3", font: "#17365D" },
    Pos: { fill: "#F4C7C3", font: "#5A1212" },
    Int: { fill: "#FFF2CC", font: "#7F6000" },
  },
};

const detectorMeasurementColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};

function dateValue(value) {
  return value ? new Date(`${value}T00:00:00Z`) : null;
}

function setCellStyle(cell, style, bold = false) {
  cell.format.fill = style.fill;
  cell.format.font = { name: "Calibri", size: 10, color: style.font, bold };
}

function resetCellStyle(cell) {
  cell.format.fill = "#FFFFFF";
  cell.format.font = { name: "Calibri", size: 10, color: "#000000", bold: false };
}

function styleDetectorMeasurements(sheet, outputRow, detector, result) {
  const columns = detectorMeasurementColumns[detector];
  for (const column of columns) {
    const cell = sheet.getRange(`${column}${outputRow}`);
    resetCellStyle(cell);
    cell.format.numberFormat = "0.000";
    cell.format.horizontalAlignment = "center";
  }
  if (!result || Object.keys(result).length === 0) return;
  const used = new Set(result.used_indices ?? []);
  const problems = new Set(result.problem_indices ?? []);
  const repeats = new Set(result.needs_repeat_indices ?? []);
  columns.forEach((column, index) => {
    const cell = sheet.getRange(`${column}${outputRow}`);
    if (used.has(index)) cell.format.font = { name: "Calibri", size: 10, bold: true, color: "#000000" };
    if (problems.has(index)) cell.format.fill = "#FFF2CC";
    if (repeats.has(index)) cell.format.fill = "#FCE4D6";
  });
}

function styleCategoricalCell(sheet, address, styleMap, value, bold = false) {
  const cell = sheet.getRange(address);
  const style = styleMap[value];
  if (style) setCellStyle(cell, style, bold);
  else resetCellStyle(cell);
}

function styleUpdatedRow(sheet, outputRow, record) {
  const values = record.values;
  styleCategoricalCell(sheet, `D${outputRow}`, categoryStyles.diagnosis, values[3]);
  styleCategoricalCell(sheet, `E${outputRow}`, categoryStyles.classification, values[4], true);
  styleCategoricalCell(sheet, `R${outputRow}`, categoryStyles.decision, values[17], true);
  styleCategoricalCell(sheet, `Y${outputRow}`, categoryStyles.decision, values[24], true);
  styleDetectorMeasurements(sheet, outputRow, "PA447", record.detector_results?.PA447);
  styleDetectorMeasurements(sheet, outputRow, "araE", record.detector_results?.araE);
  sheet.getRange(`Z${outputRow}`).format.numberFormat = "yyyy-mm-dd";
  sheet.getRange(`AA${outputRow}`).format.wrapText = true;
  sheet.getRange(`AA${outputRow}`).format.horizontalAlignment = "left";
}

for (const update of ledger.existing_row_updates) {
  const sheet = workbook.worksheets.getItem(update.sheet);
  const values = [...update.values];
  values[25] = dateValue(update.date);
  sheet.getRange(`A${update.output_row}:AA${update.output_row}`).values = [values];
  styleUpdatedRow(sheet, update.output_row, { ...update, values });
}

const appendedRows = [];
for (const record of ledger.new_rows) {
  const sheetName = record.split === "Before 2021" ? "Older samples - before 2021" : "2021 onward";
  const sheet = workbook.worksheets.getItem(sheetName);
  const currentUsed = sheet.getUsedRange();
  const outputRow = currentUsed.rowCount + 1;
  const previousRow = outputRow - 1;
  sheet.getRange(`A${outputRow}:AA${outputRow}`).copyFrom(sheet.getRange(`A${previousRow}:AA${previousRow}`), "all");
  const values = [...record.values];
  values[25] = dateValue(record.date);
  sheet.getRange(`A${outputRow}:AA${outputRow}`).values = [values];
  styleUpdatedRow(sheet, outputRow, { ...record, values });
  appendedRows.push({ sample: values[0], sheet: sheetName, outputRow, date: record.date });
}

const olderSheet = workbook.worksheets.getItem("Older samples - before 2021");
const onwardSheet = workbook.worksheets.getItem("2021 onward");
const olderUsed = olderSheet.getUsedRange();
const onwardUsed = onwardSheet.getUsedRange();

const olderPreview = await workbook.render({
  sheetName: "Older samples - before 2021",
  range: "A1:AA24",
  scale: 1,
  format: "png",
});
await fs.writeFile(previewOlderPath, new Uint8Array(await olderPreview.arrayBuffer()));

const onwardPreview = await workbook.render({
  sheetName: "2021 onward",
  range: "A1:AA24",
  scale: 1,
  format: "png",
});
await fs.writeFile(previewOnwardPath, new Uint8Array(await onwardPreview.arrayBuffer()));

const newRow = appendedRows[0];
const newPreview = await workbook.render({
  sheetName: newRow.sheet,
  range: `A${Math.max(1, newRow.outputRow - 5)}:AA${newRow.outputRow}`,
  scale: 1.5,
  format: "png",
});
await fs.writeFile(previewNewPath, new Uint8Array(await newPreview.arrayBuffer()));

const aliasesPreview = await workbook.render({
  sheetName: "2021 onward",
  range: "A14:AA36",
  scale: 1,
  format: "png",
});
await fs.writeFile(previewAliasesPath, new Uint8Array(await aliasesPreview.arrayBuffer()));

const inspectOlder = await workbook.inspect({
  kind: "region",
  sheetId: "Older samples - before 2021",
  range: `A${Math.max(1, olderUsed.rowCount - 5)}:AA${olderUsed.rowCount}`,
  maxChars: 3500,
});
const inspectOnward = await workbook.inspect({
  kind: "region",
  sheetId: "2021 onward",
  range: "A14:AA36",
  maxChars: 3500,
});
const diagnostics = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "final formula error scan",
});
console.log("OLDER_CHECK");
console.log(inspectOlder.ndjson);
console.log("ONWARD_CHECK");
console.log(inspectOnward.ndjson);
console.log("DIAGNOSTICS");
console.log(diagnostics.ndjson);

await fs.mkdir(outputDir, { recursive: true });
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

console.log(JSON.stringify({
  outputPath,
  existingRowsUpdated: ledger.existing_samples_updated,
  newRowsAdded: ledger.new_samples_added,
  measurementsAdded: ledger.measurements_added,
  existingMeasurementLinkedWithoutDuplication: ledger.existing_measurements_linked_without_duplication,
  excludedLabels: ledger.excluded_labels,
  decisionChanges: ledger.decision_changes.length,
  classificationChanges: ledger.classification_changes.length,
  olderRows: olderUsed.rowCount - 1,
  onwardRows: onwardUsed.rowCount - 1,
  totalRows: olderUsed.rowCount + onwardUsed.rowCount - 2,
  appendedRows,
}, null, 2));
