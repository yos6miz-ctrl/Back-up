from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import sys
import zipfile

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final")
FINAL = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\verified_raw_split_20260901"
    r"\Final Known and Unknown - verified raw measurements.xlsx"
)
RAW_AUDIT_SCRIPT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure"
    r"\audit_final_measurements_without_source.py"
)
ROOTS = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\p447\447- new"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\p447\447-old"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\KPS new detectors\araE"),
]
OUTPUT = WORK / "reverse_raw_coverage.json"
TOLERANCE = 5e-7


sys.path.insert(0, str(RAW_AUDIT_SCRIPT.parent))
spec = spec_from_file_location("reverse_raw_audit", RAW_AUDIT_SCRIPT)
raw_audit = module_from_spec(spec)
spec.loader.exec_module(raw_audit)


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def detector_columns(headers, detector):
    columns = []
    index = 1
    while f"{detector} measurement {index}" in headers:
        columns.append(headers[f"{detector} measurement {index}"])
        index += 1
    return columns


def load_final_rows():
    workbook = load_workbook(FINAL, data_only=True, read_only=False)
    rows = []
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        headers = {cell.value: cell.column for cell in sheet[1]}
        detector_cols = {
            detector: detector_columns(headers, detector)
            for detector in ("PA447", "araE")
        }
        for row_number in range(2, sheet.max_row + 1):
            primary = sheet.cell(row_number, headers["Primary name"]).value
            secondary = sheet.cell(row_number, headers["Secondary / other name"]).value
            exact_names = {
                raw_audit.norm(value)
                for value in (primary, secondary)
                if raw_audit.norm(value)
            }
            rows.append(
                {
                    "row_id": f"{sheet_name}!{row_number}",
                    "sheet": sheet_name,
                    "row": row_number,
                    "primary": primary,
                    "secondary": secondary,
                    "exact_names": exact_names,
                    "keys": raw_audit.expand_manual_aliases(raw_audit.variants(primary, secondary)),
                    "values": {
                        detector: [
                            float(sheet.cell(row_number, col).value)
                            for col in detector_cols[detector]
                            if is_numeric(sheet.cell(row_number, col).value)
                        ]
                        for detector in ("PA447", "araE")
                    },
                }
            )
    workbook.close()
    return rows


def candidates_for(record, final_rows):
    sample_norm = raw_audit.norm(record["sample"])
    exact = [row for row in final_rows if sample_norm and sample_norm in row["exact_names"]]
    if exact:
        return exact, "exact_name"
    scored = []
    for row in final_rows:
        shared = set(record["keys"]) & row["keys"]
        if shared:
            scored.append((max(len(key) for key in shared), row))
    best_score = max((score for score, _row in scored), default=0)
    broad = [row for score, row in scored if score == best_score]
    return broad, "alias_keys" if broad else "none"


def value_present(record, row):
    return any(
        abs(float(record["value"]) - final_value) <= TOLERANCE
        for final_value in row["values"][record["detector"]]
    )


def root_name(path):
    lower = str(path).lower()
    for root in ROOTS:
        if lower.startswith(str(root).lower()):
            return str(root)
    return "unknown"


def main():
    final_rows = load_final_rows()
    files = sorted(
        {
            path
            for root in ROOTS
            for path in root.rglob("*.xlsx")
            if not path.name.startswith("~$")
        },
        key=lambda path: str(path).lower(),
    )

    file_audit = []
    raw_records = []
    for path in files:
        try:
            with zipfile.ZipFile(path) as handle:
                handle.getinfo("xl/workbook.xml")
            opened = True
            open_error = None
        except Exception as exc:
            opened = False
            open_error = f"{type(exc).__name__}: {exc}"
        records = raw_audit.extract_formula_records(path) if opened else []
        raw_records.extend(records)
        file_audit.append(
            {
                "path": str(path),
                "root": root_name(path),
                "opened": opened,
                "open_error": open_error,
                "records_extracted": len(records),
            }
        )

    occurrence_classes = Counter()
    occurrence_by_detector = defaultdict(Counter)
    occurrence_by_root = defaultdict(Counter)
    unique_groups = defaultdict(dict)
    ambiguous_occurrences = []

    for record in raw_records:
        candidates, match_method = candidates_for(record, final_rows)
        matching_rows = [row for row in candidates if value_present(record, row)]
        if matching_rows:
            classification = "present_in_final"
            identity = tuple(sorted(row["row_id"] for row in matching_rows))
        elif candidates:
            classification = "sample_present_value_absent"
            identity = tuple(sorted(row["row_id"] for row in candidates))
        else:
            classification = "sample_absent"
            identity = raw_audit.norm(record["sample"])

        if len(candidates) > 1:
            ambiguous_occurrences.append(
                {
                    "sample": record["sample"],
                    "detector": record["detector"],
                    "value": record["value"],
                    "source_file": record["source_file"],
                    "candidate_rows": [row["row_id"] for row in candidates],
                    "matching_rows": [row["row_id"] for row in matching_rows],
                }
            )

        occurrence_classes[classification] += 1
        occurrence_by_detector[record["detector"]][classification] += 1
        occurrence_by_root[root_name(Path(record["path"]))][classification] += 1

        group_key = (classification, str(identity), record["detector"], round(float(record["value"]), 9))
        group = unique_groups[classification].setdefault(
            group_key,
            {
                "classification": classification,
                "sample": record["sample"],
                "detector": record["detector"],
                "value": float(record["value"]),
                "matched_final_rows": list(identity) if isinstance(identity, tuple) else [],
                "source_files": set(),
                "source_cells": [],
                "paths": set(),
                "occurrences": 0,
                "match_method": match_method,
            },
        )
        group["source_files"].add(record["source_file"])
        group["paths"].add(record["path"])
        if len(group["source_cells"]) < 12:
            group["source_cells"].append(record["source_cell"])
        group["occurrences"] += 1

    serializable_groups = {}
    for classification, groups in unique_groups.items():
        values = []
        for group in groups.values():
            group["source_files"] = sorted(group["source_files"], key=str.lower)
            group["paths"] = sorted(group["paths"], key=str.lower)
            values.append(group)
        serializable_groups[classification] = sorted(
            values,
            key=lambda item: (str(item["sample"]).lower(), item["detector"], item["value"]),
        )

    extra_groups = (
        serializable_groups.get("sample_present_value_absent", [])
        + serializable_groups.get("sample_absent", [])
    )
    samples_with_extra_values_in_final = sorted(
        {
            row_id
            for group in serializable_groups.get("sample_present_value_absent", [])
            for row_id in group["matched_final_rows"]
        }
    )
    absent_raw_sample_labels = sorted(
        {group["sample"] for group in serializable_groups.get("sample_absent", [])},
        key=lambda value: str(value).lower(),
    )

    result = {
        "final_file": str(FINAL),
        "raw_roots": [str(root) for root in ROOTS],
        "xlsx_files_scanned": len(files),
        "xlsx_files_opened": sum(item["opened"] for item in file_audit),
        "xlsx_files_unreadable": sum(not item["opened"] for item in file_audit),
        "files_with_normalized_records": sum(item["records_extracted"] > 0 for item in file_audit),
        "files_without_normalized_records": sum(item["records_extracted"] == 0 for item in file_audit),
        "raw_record_occurrences": len(raw_records),
        "final_measurement_occurrences": sum(
            len(row["values"][detector])
            for row in final_rows
            for detector in ("PA447", "araE")
        ),
        "occurrence_class_counts": dict(occurrence_classes),
        "occurrence_class_counts_by_detector": {
            detector: dict(counts) for detector, counts in occurrence_by_detector.items()
        },
        "occurrence_class_counts_by_root": {
            root: dict(counts) for root, counts in occurrence_by_root.items()
        },
        "unique_group_counts": {
            classification: len(groups) for classification, groups in serializable_groups.items()
        },
        "unique_extra_raw_measurements": len(extra_groups),
        "samples_in_final_with_extra_raw_values": len(samples_with_extra_values_in_final),
        "raw_sample_labels_absent_from_final": len(absent_raw_sample_labels),
        "ambiguous_raw_occurrences": len(ambiguous_occurrences),
        "file_audit": file_audit,
        "unique_groups": serializable_groups,
        "samples_with_extra_values_in_final": samples_with_extra_values_in_final,
        "absent_raw_sample_labels": absent_raw_sample_labels,
        "ambiguous_examples": ambiguous_occurrences[:100],
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {key: value for key, value in result.items() if key not in {
        "file_audit", "unique_groups", "samples_with_extra_values_in_final",
        "absent_raw_sample_labels", "ambiguous_examples", "occurrence_class_counts_by_root",
    }}
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
