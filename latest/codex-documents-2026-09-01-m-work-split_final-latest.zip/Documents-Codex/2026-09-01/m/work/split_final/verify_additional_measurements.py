from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
import json
import math
import re
import zipfile

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final")
LEDGER = WORK / "additional_measurements_ledger.json"
INPUT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\verified_raw_split_20260901"
    r"\Final Known and Unknown - verified raw measurements.xlsx"
)
OUTPUT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\verified_raw_additions_20260902"
    r"\Final Known and Unknown - additional raw measurements.xlsx"
)


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def normalized(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if value in (None, ""):
        return None
    return value


def equal(left, right):
    left = normalized(left)
    right = normalized(right)
    if is_numeric(left) and is_numeric(right):
        return abs(float(left) - float(right)) <= 1e-10
    return left == right


ledger = json.loads(LEDGER.read_text(encoding="utf-8"))
input_wb = load_workbook(INPUT, data_only=False, read_only=False)
output_wb = load_workbook(OUTPUT, data_only=False, read_only=False)

expected_sheets = ["Older samples - before 2021", "2021 onward"]
assert input_wb.sheetnames == output_wb.sheetnames == expected_sheets
assert output_wb["Older samples - before 2021"].max_row == 190
assert output_wb["2021 onward"].max_row == 159

updates = {item["row_id"]: item for item in ledger["existing_row_updates"]}
mismatches = []
unaffected_rows_checked = 0
updated_rows_checked = 0
for sheet_name in expected_sheets:
    input_ws = input_wb[sheet_name]
    output_ws = output_wb[sheet_name]
    for row in range(2, input_ws.max_row + 1):
        row_id = f"{sheet_name}!{row}"
        actual = [output_ws.cell(row, col).value for col in range(1, 28)]
        if row_id in updates:
            expected = updates[row_id]["values"]
            updated_rows_checked += 1
        else:
            expected = [input_ws.cell(row, col).value for col in range(1, 28)]
            unaffected_rows_checked += 1
        for col, (actual_value, expected_value) in enumerate(zip(actual, expected), start=1):
            if not equal(actual_value, expected_value):
                mismatches.append(
                    {
                        "sheet": sheet_name,
                        "row": row,
                        "col": col,
                        "primary": actual[0],
                        "actual": str(actual_value),
                        "expected": str(expected_value),
                    }
                )

new_expected = ledger["new_rows"][0]
new_ws = output_wb["Older samples - before 2021"]
new_row_number = 190
new_actual = [new_ws.cell(new_row_number, col).value for col in range(1, 28)]
for col, (actual_value, expected_value) in enumerate(zip(new_actual, new_expected["values"]), start=1):
    if not equal(actual_value, expected_value):
        mismatches.append(
            {
                "sheet": "Older samples - before 2021",
                "row": new_row_number,
                "col": col,
                "primary": new_actual[0],
                "actual": str(actual_value),
                "expected": str(expected_value),
            }
        )

measurement_indexes = list(range(9, 17)) + list(range(18, 24))
input_measurements = sum(
    is_numeric(ws.cell(row, index + 1).value)
    for ws in input_wb.worksheets
    for row in range(2, ws.max_row + 1)
    for index in measurement_indexes
)
output_measurements = sum(
    is_numeric(ws.cell(row, index + 1).value)
    for ws in output_wb.worksheets
    for row in range(2, ws.max_row + 1)
    for index in measurement_indexes
)

assignment_failures = []
citation_failures = []
for proof in ledger["assignment_proofs"]:
    if proof["target_row"] is None:
        sheet_name = "Older samples - before 2021"
        row = new_row_number
    else:
        sheet_name = proof["target_sheet"]
        row = proof["target_row"]
    ws = output_wb[sheet_name]
    actual_value = ws.cell(row, proof["target_column"]).value
    if not equal(actual_value, proof["value"]):
        assignment_failures.append(
            {
                "sample": proof["target_primary"],
                "sheet": sheet_name,
                "row": row,
                "column": proof["target_column"],
                "actual": actual_value,
                "expected": proof["value"],
            }
        )
    source_text = str(ws.cell(row, 27).value or "")
    for file_name in proof["source_files"]:
        if file_name not in source_text:
            citation_failures.append(
                {"sample": proof["target_primary"], "file": file_name, "sheet": sheet_name, "row": row}
            )

identity_link_failures = []
for link in ledger["identity_links"]:
    ws = output_wb[link["target_sheet"]]
    linked_value = ws.cell(link["target_row"], link["target_column"]).value
    if not (
        is_numeric(linked_value)
        and abs(float(linked_value) - float(link["value"])) <= 5e-7
    ):
        identity_link_failures.append({"kind": "value", "link": link})
    secondary = str(ws.cell(link["target_row"], 2).value or "")
    if link["raw_sample"] not in secondary:
        identity_link_failures.append({"kind": "alias", "link": link})
    source_text = str(ws.cell(link["target_row"], 27).value or "")
    for file_name in link["source_files"]:
        if file_name not in source_text:
            identity_link_failures.append({"kind": "citation", "file": file_name, "link": link})

primary_locations = {}
all_names = []
for ws in output_wb.worksheets:
    for row in range(2, ws.max_row + 1):
        primary = str(ws.cell(row, 1).value or "")
        secondary = str(ws.cell(row, 2).value or "")
        primary_locations.setdefault(primary, []).append((ws.title, row))
        all_names.append(f"{primary} {secondary}".lower())

assert len(primary_locations["CT-606"]) == 1
assert new_ws.cell(190, 2).value == "HS 606"
assert normalized(new_ws.cell(190, 26).value) == "2020-01-27"
assert "UN FZK58" in str(output_wb["2021 onward"].cell(16, 2).value)
assert "UNFNS98" in str(output_wb["2021 onward"].cell(34, 2).value)
assert "CDr 179" in str(output_wb["2021 onward"].cell(134, 2).value)
assert "CDr 615" in str(output_wb["Older samples - before 2021"].cell(157, 2).value)
for excluded in ("IBS P4 w0", "IBS P6", "IBS P7"):
    assert not any(excluded.lower() in names for names in all_names)

older_dates = [
    normalized(output_wb["Older samples - before 2021"].cell(row, 26).value)
    for row in range(2, output_wb["Older samples - before 2021"].max_row + 1)
]
onward_dates = [
    normalized(output_wb["2021 onward"].cell(row, 26).value)
    for row in range(2, output_wb["2021 onward"].max_row + 1)
]
invalid_older_dates = [value for value in older_dates if value is not None and str(value)[:4] >= "2021"]
invalid_onward_dates = [value for value in onward_dates if value is None or str(value)[:4] < "2021"]

obsolete_sources = []
empty_detector_sources = []
for ws in output_wb.worksheets:
    for row in range(2, ws.max_row + 1):
        source_text = str(ws.cell(row, 27).value or "")
        if "unknowns trial 6.26.xlsx" in source_text.lower():
            obsolete_sources.append((ws.title, row))
        pa_values = [ws.cell(row, col).value for col in range(10, 18)]
        ara_values = [ws.cell(row, col).value for col in range(19, 25)]
        if not any(is_numeric(value) for value in pa_values) and re.search(r"PA447:\s*[^;]+", source_text, flags=re.I):
            empty_detector_sources.append((ws.title, row, "PA447"))
        if not any(is_numeric(value) for value in ara_values) and re.search(r"araE:\s*[^;]+", source_text, flags=re.I):
            empty_detector_sources.append((ws.title, row, "araE"))

formula_cells = [
    (ws.title, cell.coordinate)
    for ws in output_wb.worksheets
    for row in ws.iter_rows()
    for cell in row
    if isinstance(cell.value, str) and cell.value.startswith("=")
]

bad_zip_member = None
with zipfile.ZipFile(OUTPUT) as handle:
    bad_zip_member = handle.testzip()

summary = {
    "sheet_names": output_wb.sheetnames,
    "older_rows": output_wb["Older samples - before 2021"].max_row - 1,
    "onward_rows": output_wb["2021 onward"].max_row - 1,
    "total_rows": sum(ws.max_row - 1 for ws in output_wb.worksheets),
    "input_measurements": input_measurements,
    "output_measurements": output_measurements,
    "measurements_added": output_measurements - input_measurements,
    "updated_rows_checked": updated_rows_checked,
    "unaffected_rows_checked": unaffected_rows_checked,
    "cell_mismatch_count": len(mismatches),
    "assignment_failure_count": len(assignment_failures),
    "citation_failure_count": len(citation_failures),
    "identity_link_failure_count": len(identity_link_failures),
    "invalid_older_date_count": len(invalid_older_dates),
    "invalid_onward_date_count": len(invalid_onward_dates),
    "obsolete_source_count": len(obsolete_sources),
    "empty_detector_source_count": len(empty_detector_sources),
    "formula_cell_count": len(formula_cells),
    "bad_zip_member": bad_zip_member,
    "decision_change_count": len(ledger["decision_changes"]),
    "classification_change_count": len(ledger["classification_changes"]),
}
print(json.dumps(summary, ensure_ascii=False, indent=2))
if mismatches:
    print(json.dumps({"mismatches": mismatches[:50]}, ensure_ascii=False, indent=2))
if assignment_failures or citation_failures or identity_link_failures:
    print(
        json.dumps(
            {
                "assignment_failures": assignment_failures,
                "citation_failures": citation_failures,
                "identity_link_failures": identity_link_failures,
            },
            ensure_ascii=False,
            indent=2,
        )
    )

assert input_measurements == 938
assert output_measurements == 1042
assert output_measurements - input_measurements == ledger["measurements_added"] == 104
assert updated_rows_checked == ledger["existing_samples_updated"] == 77
assert unaffected_rows_checked == 269
assert not mismatches
assert not assignment_failures
assert not citation_failures
assert not identity_link_failures
assert not invalid_older_dates
assert not invalid_onward_dates
assert not obsolete_sources
assert not empty_detector_sources
assert not formula_cells
assert bad_zip_member is None
