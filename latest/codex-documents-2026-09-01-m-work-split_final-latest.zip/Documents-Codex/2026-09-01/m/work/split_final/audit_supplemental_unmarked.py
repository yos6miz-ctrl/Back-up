from __future__ import annotations

from collections import Counter
from pathlib import Path
import json
import zipfile

import audit_reverse_raw_coverage as reverse


BASE_REPORT = reverse.WORK / "reverse_raw_coverage.json"
OUTPUT = reverse.WORK / "supplemental_unmarked_coverage.json"


def has_division_formula(path):
    with zipfile.ZipFile(path) as handle:
        for name in handle.namelist():
            if not name.startswith("xl/worksheets/sheet") or not name.endswith(".xml"):
                continue
            payload = handle.read(name)
            if b"<f" in payload and b"/" in payload:
                return True
    return False


def group_signature(classification, identity, detector, value):
    return (classification, str(identity), detector, round(float(value), 9))


def main():
    base = json.loads(BASE_REPORT.read_text(encoding="utf-8"))
    final_rows = reverse.load_final_rows()
    old_root = str(reverse.ROOTS[1]).lower()
    candidates = [
        Path(item["path"])
        for item in base["file_audit"]
        if not item["records_extracted"]
        and not str(item["path"]).lower().startswith(old_root)
        and has_division_formula(Path(item["path"]))
    ]

    original_marker = reverse.raw_audit.has_marker
    reverse.raw_audit.has_marker = lambda _grids, _detector: True
    records = []
    try:
        for path in candidates:
            records.extend(reverse.raw_audit.extract_formula_records(path))
    finally:
        reverse.raw_audit.has_marker = original_marker

    existing_signatures = set()
    for classification, groups in base["unique_groups"].items():
        for group in groups:
            identity = (
                tuple(group["matched_final_rows"])
                if group["matched_final_rows"]
                else reverse.raw_audit.norm(group["sample"])
            )
            existing_signatures.add(
                group_signature(classification, identity, group["detector"], group["value"])
            )

    groups = {}
    class_counts = Counter()
    for record in records:
        candidates_for_sample, method = reverse.candidates_for(record, final_rows)
        matching_rows = [row for row in candidates_for_sample if reverse.value_present(record, row)]
        if matching_rows:
            classification = "present_in_final"
            identity = tuple(sorted(row["row_id"] for row in matching_rows))
        elif candidates_for_sample:
            classification = "sample_present_value_absent"
            identity = tuple(sorted(row["row_id"] for row in candidates_for_sample))
        else:
            classification = "sample_absent"
            identity = reverse.raw_audit.norm(record["sample"])
        signature = group_signature(classification, identity, record["detector"], record["value"])
        group = groups.setdefault(
            signature,
            {
                "classification": classification,
                "sample": record["sample"],
                "detector": record["detector"],
                "value": float(record["value"]),
                "matched_final_rows": list(identity) if isinstance(identity, tuple) else [],
                "source_files": set(),
                "paths": set(),
                "occurrences": 0,
                "match_method": method,
                "already_in_base_report": signature in existing_signatures,
            },
        )
        group["source_files"].add(record["source_file"])
        group["paths"].add(record["path"])
        group["occurrences"] += 1
        class_counts[classification] += 1

    serializable = []
    for group in groups.values():
        group["source_files"] = sorted(group["source_files"], key=str.lower)
        group["paths"] = sorted(group["paths"], key=str.lower)
        serializable.append(group)
    serializable.sort(key=lambda item: (str(item["sample"]).lower(), item["detector"], item["value"]))

    new_groups = [group for group in serializable if not group["already_in_base_report"]]
    new_extra = [
        group for group in new_groups
        if group["classification"] in {"sample_present_value_absent", "sample_absent"}
    ]
    result = {
        "candidate_files": [str(path) for path in candidates],
        "candidate_file_count": len(candidates),
        "supplemental_raw_occurrences": len(records),
        "supplemental_occurrence_classes": dict(class_counts),
        "supplemental_unique_groups": len(serializable),
        "new_unique_groups_not_in_base": len(new_groups),
        "new_unique_extra_measurements": len(new_extra),
        "new_unique_extra_by_class": dict(Counter(group["classification"] for group in new_extra)),
        "new_unique_extra_by_detector": dict(Counter(group["detector"] for group in new_extra)),
        "groups": serializable,
        "new_extra_groups": new_extra,
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key not in {"groups", "new_extra_groups"}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
