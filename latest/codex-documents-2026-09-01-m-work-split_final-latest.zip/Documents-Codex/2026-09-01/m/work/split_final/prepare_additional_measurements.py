from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path
import json
import math

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

import prepare_requested_edits as previous


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final")
CURRENT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\verified_raw_split_20260901"
    r"\Final Known and Unknown - verified raw measurements.xlsx"
)
BASE_REPORT = WORK / "reverse_raw_coverage.json"
SUPPLEMENTAL_REPORT = WORK / "supplemental_unmarked_coverage.json"
OUTPUT = WORK / "additional_measurements_ledger.json"
TOLERANCE = 5e-7


NEW_SAMPLE_METADATA = {
    "HS 606": {
        "primary": "CT-606",
        "secondary": "HS 606",
        "diagnosis": "Healthy",
        "date": "2020-01-27",
        "date_source": r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx | Healthy!row 53",
        "split": "Before 2021",
    },
}


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def date_iso(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if value in (None, ""):
        return None
    text = str(value).strip()
    return text[:10]


def source_sort_key(group):
    paths = group.get("paths") or []
    return (min(paths, default="").lower(), min(group.get("source_files") or [""]).lower(), float(group["value"]))


def find_row_id_by_primary(records, primary):
    matches = [row_id for row_id, record in records.items() if str(record["values"][0]).strip() == primary]
    if len(matches) != 1:
        raise AssertionError(f"Expected one row for {primary}, found {matches}")
    return matches[0]


def addition_from_group(group, target_row_id=None, new_sample_label=None, category=None, alias_only=False):
    return {
        "target_row_id": target_row_id,
        "new_sample_label": new_sample_label,
        "raw_sample": group["sample"],
        "detector": group["detector"],
        "value": float(group["value"]),
        "source_files": list(group.get("source_files") or []),
        "source_paths": list(group.get("paths") or []),
        "raw_occurrences": int(group.get("occurrences") or 1),
        "category": category,
        "alias_only": alias_only,
    }


def append_secondary_alias(value, alias):
    parts = [part.strip() for part in str(value or "").split(";") if part.strip()]
    if alias and alias not in parts:
        parts.append(alias)
    return "; ".join(parts)


def main():
    base = json.loads(BASE_REPORT.read_text(encoding="utf-8"))
    supplemental = json.loads(SUPPLEMENTAL_REPORT.read_text(encoding="utf-8"))

    workbook = load_workbook(CURRENT, data_only=True, read_only=False)
    records = {}
    headers = None
    for sheet_name in workbook.sheetnames:
        ws = workbook[sheet_name]
        sheet_headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
        if headers is None:
            headers = sheet_headers
        else:
            assert sheet_headers == headers
        for row in range(2, ws.max_row + 1):
            values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
            values[25] = date_iso(values[25])
            row_id = f"{sheet_name}!{row}"
            records[row_id] = {
                "row_id": row_id,
                "sheet": sheet_name,
                "output_row": row,
                "split": "Before 2021" if sheet_name == "Older samples - before 2021" else "2021 onward",
                "date": values[25],
                "values": values,
            }
    workbook.close()

    header_index = {value: index for index, value in enumerate(headers)}
    detector_indexes = {
        "PA447": [header_index[f"PA447 measurement {index}"] for index in range(1, 9)],
        "araE": [header_index[f"araE measurement {index}"] for index in range(1, 7)],
    }
    decision_index = {
        "PA447": header_index["PA447 decision"],
        "araE": header_index["araE decision"],
    }
    final_index = header_index["Final classification / decision"]
    source_index = header_index["Measurement/source file"]

    additions = []
    existing_extra_groups = base["unique_groups"]["sample_present_value_absent"]
    assert len(existing_extra_groups) == 76
    for group in existing_extra_groups:
        if group["sample"] == "CDf DY-247":
            target = "2021 onward!2"
        else:
            targets = group["matched_final_rows"]
            if len(targets) != 1:
                raise AssertionError(f"Ambiguous existing target: {group['sample']} -> {targets}")
            target = targets[0]
        additions.append(addition_from_group(group, target_row_id=target, category="existing sample raw value"))

    supplemental_existing = [
        group for group in supplemental["new_extra_groups"]
        if group["classification"] == "sample_present_value_absent"
    ]
    assert len(supplemental_existing) == 23
    for group in supplemental_existing:
        targets = group["matched_final_rows"]
        if len(targets) != 1:
            raise AssertionError(f"Ambiguous supplemental target: {group['sample']} -> {targets}")
        additions.append(addition_from_group(group, target_row_id=targets[0], category="existing sample raw value"))

    alias_targets = {
        "UN FZK58": find_row_id_by_primary(records, "F-ZK-2158"),
        "UNFNS98": find_row_id_by_primary(records, "F-NS-2398"),
    }
    aliquot_confirmed_targets = {
        "CDr 179": find_row_id_by_primary(records, "F-NK-21179"),
        "CDr 615": find_row_id_by_primary(records, "F-EA-19615"),
    }
    excluded_labels = {"IBS P4 w0", "IBS P6", "IBS P7"}
    for group in base["unique_groups"]["sample_absent"]:
        label = group["sample"]
        if label in excluded_labels:
            continue
        if label not in alias_targets:
            raise AssertionError(f"Unexpected unmatched base label: {label}")
        additions.append(
            addition_from_group(
                group,
                target_row_id=alias_targets[label],
                category="user-confirmed shortened alias",
            )
        )

    new_groups = [
        group for group in supplemental["new_extra_groups"]
        if group["classification"] == "sample_absent"
    ]
    assert {group["sample"] for group in new_groups} == set(NEW_SAMPLE_METADATA) | set(aliquot_confirmed_targets)
    for group in new_groups:
        if group["sample"] in aliquot_confirmed_targets:
            additions.append(
                addition_from_group(
                    group,
                    target_row_id=aliquot_confirmed_targets[group["sample"]],
                    category="aliquot-confirmed full-name match",
                    alias_only=group["sample"] == "CDr 179",
                )
            )
        else:
            additions.append(
                addition_from_group(
                    group,
                    new_sample_label=group["sample"],
                    category="new sample row requested by user",
                )
            )

    assert len([item for item in additions if item["category"] == "existing sample raw value"]) == 99
    assert len([item for item in additions if item["category"] == "user-confirmed shortened alias"]) == 3
    assert len([item for item in additions if item["category"] == "aliquot-confirmed full-name match"]) == 2
    assert len([item for item in additions if item["category"] == "new sample row requested by user"]) == 1
    assert len(additions) == 105
    assert sum(not item["alias_only"] for item in additions) == 104

    additions_by_target = defaultdict(list)
    additions_by_new_sample = defaultdict(list)
    for item in additions:
        if item["target_row_id"]:
            additions_by_target[item["target_row_id"]].append(item)
        else:
            additions_by_new_sample[item["new_sample_label"]].append(item)

    training, feature_cols, _fill_values, _sources = previous.importer.classifier.load_training()
    bars = previous.importer.classifier.learn_detector_bars(training, feature_cols)

    updates = []
    assignment_proofs = []
    identity_links = []
    capacity_errors = []
    decision_changes = []
    classification_changes = []

    for row_id, row_additions in sorted(additions_by_target.items()):
        record = records[row_id]
        values = list(record["values"])
        old_values = list(values)
        detector_results = {}
        citation_additions = defaultdict(list)
        added_measurements = []
        for item in row_additions:
            if item["category"] in {"user-confirmed shortened alias", "aliquot-confirmed full-name match"}:
                values[1] = append_secondary_alias(values[1], item["raw_sample"])
        for detector in ("PA447", "araE"):
            current = [float(values[index]) for index in detector_indexes[detector] if is_numeric(values[index])]
            detector_items = sorted(
                [item for item in row_additions if item["detector"] == detector],
                key=lambda item: (min(item["source_paths"], default="").lower(), item["value"]),
            )
            for item in detector_items:
                for file_name in item["source_files"]:
                    if file_name not in citation_additions[detector]:
                        citation_additions[detector].append(file_name)
                if item["alias_only"]:
                    matching_position = next(
                        (position for position, existing in enumerate(current) if abs(existing - item["value"]) <= TOLERANCE),
                        None,
                    )
                    if matching_position is None:
                        raise AssertionError(f"Alias-only value is not already present for {row_id}: {item['value']}")
                    identity_links.append(
                        {
                            **item,
                            "target_primary": values[0],
                            "target_sheet": record["sheet"],
                            "target_row": record["output_row"],
                            "target_column": detector_indexes[detector][matching_position] + 1,
                            "target_cell": f"{get_column_letter(detector_indexes[detector][matching_position] + 1)}{record['output_row']}",
                        }
                    )
            detector_additions = [item for item in detector_items if not item["alias_only"]]
            for item in detector_additions:
                if any(abs(existing - item["value"]) <= TOLERANCE for existing in current):
                    raise AssertionError(f"Duplicate addition for {row_id} {detector}: {item['value']}")
                current.append(item["value"])
            if len(current) > len(detector_indexes[detector]):
                capacity_errors.append(
                    {
                        "row_id": row_id,
                        "primary": values[0],
                        "detector": detector,
                        "needed": len(current),
                        "capacity": len(detector_indexes[detector]),
                    }
                )
                continue
            for index, value in zip(detector_indexes[detector], current + [None] * (len(detector_indexes[detector]) - len(current))):
                values[index] = value
            result = previous.expand.detector_consensus_with_used(current, bars[detector]["bar"])
            detector_results[detector] = result
            old_decision = old_values[decision_index[detector]]
            values[decision_index[detector]] = result["decision"]
            if old_decision != result["decision"]:
                decision_changes.append(
                    {
                        "row_id": row_id,
                        "primary": values[0],
                        "detector": detector,
                        "old": old_decision,
                        "new": result["decision"],
                    }
                )
            start_position = len(current) - len(detector_additions)
            for offset, item in enumerate(detector_additions):
                column_index = detector_indexes[detector][start_position + offset]
                proof = {
                    **item,
                    "target_primary": values[0],
                    "target_sheet": record["sheet"],
                    "target_row": record["output_row"],
                    "target_column": column_index + 1,
                    "target_cell": f"{get_column_letter(column_index + 1)}{record['output_row']}",
                }
                added_measurements.append(proof)
                assignment_proofs.append(proof)

        if capacity_errors:
            continue
        old_final = old_values[final_index]
        calls = [
            detector_results[detector]["call"]
            for detector in ("PA447", "araE")
            if detector_results[detector].get("call")
        ]
        new_final = previous.importer.classifier.final_classification(calls) if calls else "missing"
        values[final_index] = new_final
        if old_final != new_final:
            classification_changes.append(
                {"row_id": row_id, "primary": values[0], "old": old_final, "new": new_final}
            )
        values[source_index] = previous.clean_and_append_sources(
            values[source_index], citation_additions, values,
            {detector: [index + 1 for index in indexes] for detector, indexes in detector_indexes.items()},
        )
        updates.append(
            {
                **record,
                "values": values,
                "old_values": old_values,
                "detector_results": detector_results,
                "citation_additions": dict(citation_additions),
                "added_measurements": added_measurements,
            }
        )

    if capacity_errors:
        raise AssertionError(f"Measurement capacity exceeded: {capacity_errors}")

    new_rows = []
    for label, metadata in NEW_SAMPLE_METADATA.items():
        row_additions = additions_by_new_sample[label]
        values = [None] * len(headers)
        values[0] = metadata["primary"]
        values[1] = metadata["secondary"]
        values[2] = "measured"
        values[3] = metadata["diagnosis"]
        values[7] = 0
        values[25] = metadata["date"]
        detector_results = {}
        citation_additions = defaultdict(list)
        added_measurements = []
        for detector in ("PA447", "araE"):
            detector_additions = sorted(
                [item for item in row_additions if item["detector"] == detector],
                key=lambda item: (min(item["source_paths"], default="").lower(), item["value"]),
            )
            current = [item["value"] for item in detector_additions]
            for index, value in zip(detector_indexes[detector], current):
                values[index] = value
            result = previous.expand.detector_consensus_with_used(current, bars[detector]["bar"])
            detector_results[detector] = result
            values[decision_index[detector]] = result["decision"]
            for offset, item in enumerate(detector_additions):
                for file_name in item["source_files"]:
                    if file_name not in citation_additions[detector]:
                        citation_additions[detector].append(file_name)
                proof = {
                    **item,
                    "target_primary": metadata["primary"],
                    "target_sheet": "Older samples - before 2021" if metadata["split"] == "Before 2021" else "2021 onward",
                    "target_row": None,
                    "target_column": detector_indexes[detector][offset] + 1,
                    "target_cell": None,
                }
                added_measurements.append(proof)
                assignment_proofs.append(proof)
        calls = [
            detector_results[detector]["call"]
            for detector in ("PA447", "araE")
            if detector_results[detector].get("call")
        ]
        values[final_index] = previous.importer.classifier.final_classification(calls) if calls else "missing"
        values[source_index] = previous.clean_and_append_sources(
            None, citation_additions, values,
            {detector: [index + 1 for index in indexes] for detector, indexes in detector_indexes.items()},
        )
        new_rows.append(
            {
                "new_sample_label": label,
                "primary": metadata["primary"],
                "split": metadata["split"],
                "date": metadata["date"],
                "date_source": metadata["date_source"],
                "values": values,
                "detector_results": detector_results,
                "citation_additions": dict(citation_additions),
                "added_measurements": added_measurements,
            }
        )

    assert len(updates) == len(additions_by_target)
    assert len(new_rows) == 1
    assert len(assignment_proofs) == 104
    assert len(identity_links) == 1
    assert Counter(item["detector"] for item in assignment_proofs) == {"PA447": 75, "araE": 29}
    assert sum(len(item["added_measurements"]) for item in updates) == 103
    assert sum(len(item["added_measurements"]) for item in new_rows) == 1

    max_after = {"PA447": 0, "araE": 0}
    for update in updates:
        for detector, indexes in detector_indexes.items():
            max_after[detector] = max(max_after[detector], sum(is_numeric(update["values"][index]) for index in indexes))
    for row in new_rows:
        for detector, indexes in detector_indexes.items():
            max_after[detector] = max(max_after[detector], sum(is_numeric(row["values"][index]) for index in indexes))

    result = {
        "input": str(CURRENT),
        "headers": headers,
        "existing_row_updates": updates,
        "new_rows": new_rows,
        "assignment_proofs": assignment_proofs,
        "identity_links": identity_links,
        "raw_measurement_requests_processed": 105,
        "measurements_added": 104,
        "measurements_added_to_existing_samples": 103,
        "existing_measurements_linked_without_duplication": 1,
        "raw_extra_measurements_for_original_75_samples": 99,
        "measurements_added_via_confirmed_aliases": 3,
        "measurements_added_via_aliquot_identity_matches": 1,
        "measurements_added_with_new_rows": 1,
        "existing_samples_updated": len(additions_by_target),
        "new_samples_added": 1,
        "excluded_labels": sorted(excluded_labels),
        "decision_changes": decision_changes,
        "classification_changes": classification_changes,
        "max_measurements_after": max_after,
        "current_older_rows": sum(record["split"] == "Before 2021" for record in records.values()),
        "current_onward_rows": sum(record["split"] == "2021 onward" for record in records.values()),
        "new_older_rows": sum(row["split"] == "Before 2021" for row in new_rows),
        "new_onward_rows": sum(row["split"] == "2021 onward" for row in new_rows),
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key not in {"headers", "existing_row_updates", "new_rows", "assignment_proofs", "identity_links", "decision_changes", "classification_changes"}}, ensure_ascii=False, indent=2))
    print(json.dumps({"decision_change_count": len(decision_changes), "classification_change_count": len(classification_changes)}, ensure_ascii=False, indent=2))
    print(json.dumps({"decision_changes": decision_changes, "classification_changes": classification_changes}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
