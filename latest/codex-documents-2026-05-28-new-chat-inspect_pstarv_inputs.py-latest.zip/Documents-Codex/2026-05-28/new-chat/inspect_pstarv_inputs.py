from pathlib import Path
import json

from docx import Document
from openpyxl import load_workbook

ROOT = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")


def used_bounds(ws):
    min_row = min_col = None
    max_row = max_col = 0
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None:
                min_row = cell.row if min_row is None else min(min_row, cell.row)
                min_col = cell.column if min_col is None else min(min_col, cell.column)
                max_row = max(max_row, cell.row)
                max_col = max(max_col, cell.column)
    return min_row, min_col, max_row, max_col


def preview_sheet(ws, max_rows=12, max_cols=12):
    min_row, min_col, max_row, max_col = used_bounds(ws)
    if min_row is None:
        return []
    rows = []
    for r in range(min_row, min(max_row, min_row + max_rows - 1) + 1):
        vals = []
        for c in range(min_col, min(max_col, min_col + max_cols - 1) + 1):
            vals.append(ws.cell(r, c).value)
        rows.append(vals)
    return rows


print("ROOT", ROOT)
print("\nDOCX FILES")
for p in sorted(ROOT.glob("*.docx"), key=lambda x: x.stat().st_mtime, reverse=True):
    print(p.name, p.stat().st_size)
    if "דוח אבני דרך" in p.name and "backup" not in p.name:
        doc = Document(p)
        print("  paragraphs:")
        for i, para in enumerate(doc.paragraphs[:30]):
            text = para.text.strip()
            if text:
                print(f"    P{i}: {text[:220]}")
        print("  tables:", len(doc.tables))
        for ti, table in enumerate(doc.tables[:5]):
            print(f"    T{ti}: {len(table.rows)}x{len(table.columns)}")
            for row in table.rows[:4]:
                print("      ", [cell.text.replace("\n", " | ")[:80] for cell in row.cells[:6]])

print("\nP STARV WORKBOOKS")
for p in sorted(ROOT.glob("*P starv*.xlsx"), key=lambda x: x.stat().st_mtime, reverse=True):
    print("\n", p.name, p.stat().st_size)
    wb = load_workbook(p, data_only=True)
    print("  sheets:", wb.sheetnames)
    for s in wb.sheetnames:
        ws = wb[s]
        print("  sheet", s, "bounds", used_bounds(ws), "charts", len(ws._charts), "images", len(ws._images))
        for row in preview_sheet(ws, 10, 10):
            print("    ", json.dumps(row, ensure_ascii=False, default=str))
