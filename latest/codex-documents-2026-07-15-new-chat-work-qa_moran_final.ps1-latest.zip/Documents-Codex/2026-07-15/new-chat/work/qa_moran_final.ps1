$ErrorActionPreference = 'Stop'

$docPath = (Resolve-Path 'outputs\Teads_TA_Interview_Assignment_clean.docx').Path
$pdfPath = Join-Path (Resolve-Path 'work').Path 'Teads_TA_Interview_Assignment_clean_qa.pdf'
$stagePath = Join-Path (Resolve-Path 'work').Path 'qa_moran_stage.txt'
$word = $null
$doc = $null
try {
    Set-Content -LiteralPath $stagePath -Value 'starting Word'
    $word = New-Object -ComObject Word.Application
    Set-Content -LiteralPath $stagePath -Value 'Word started'
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($docPath, $false, $true)
    Set-Content -LiteralPath $stagePath -Value 'document opened'
    $doc.Repaginate()
    Set-Content -LiteralPath $stagePath -Value 'document repaginated'
    $totalPages = $doc.ComputeStatistics(2)
    Set-Content -LiteralPath $stagePath -Value "TOTAL_PAGES=$totalPages"
    "TOTAL_PAGES=$totalPages"
    $doc.SaveAs2($pdfPath, 17)
    Set-Content -LiteralPath $stagePath -Value 'PDF exported'
    "PDF=$pdfPath"
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
