from __future__ import annotations

import json
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m")
INPUT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
OUTPUT = ROOT / r"outputs\aliquot_status_and_font_fix_20260903\Final Known and Unknown merged.xlsx"
LEDGER = ROOT / r"work\aliquot_action_ledger.json"
REPORT = ROOT / r"outputs\aliquot_status_and_font_fix_20260903\verification.json"


def text(v):
    return "" if v is None else str(v).strip()


def color_value(color):
    if color.type == "rgb" and color.rgb:
        return color.rgb.upper()
    return ""


ledger = json.loads(LEDGER.read_text(encoding="utf-8"))
expected_value_changes = {
    (r["sheet"], r["row"], 3): ("measured", "measured and empty")
    for r in ledger["flagged_rows"] if r["action"] == "measured_and_empty"
}
expected_yellow_status = {
    (r["sheet"], r["row"])
    for r in ledger["flagged_rows"] if r["action"] in {"highlight_missing_status", "measured_and_empty"}
}

wb_in = load_workbook(INPUT, data_only=False, read_only=False)
wb_out = load_workbook(OUTPUT, data_only=False, read_only=False)

value_diffs = []
formula_diffs = []
formula_errors = []
yellow_measurement_in = 0
yellow_measurement_out = 0
not_tested_out = []
status_yellow_failures = []

assert wb_in.sheetnames == wb_out.sheetnames, (wb_in.sheetnames, wb_out.sheetnames)
for sname in wb_in.sheetnames:
    a = wb_in[sname]
    b = wb_out[sname]
    max_row = max(a.max_row, b.max_row)
    max_col = max(a.max_column, b.max_column)
    for r in range(1, max_row + 1):
        if text(b.cell(r, 3).value) == "לא נבדק":
            not_tested_out.append({"sheet": sname, "row": r, "sample": text(b.cell(r, 1).value)})
        for c in range(1, max_col + 1):
            va, vb = a.cell(r, c).value, b.cell(r, c).value
            if va != vb:
                value_diffs.append({"sheet": sname, "row": r, "col": c, "before": va, "after": vb})
            fa = va if isinstance(va, str) and va.startswith("=") else None
            fb = vb if isinstance(vb, str) and vb.startswith("=") else None
            if fa != fb:
                formula_diffs.append({"sheet": sname, "row": r, "col": c, "before": fa, "after": fb})
            if isinstance(vb, str) and any(err in vb for err in ("#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A")):
                formula_errors.append({"sheet": sname, "cell": b.cell(r, c).coordinate, "value": vb})
        for c in list(range(8, 16)) + list(range(17, 23)):
            if color_value(a.cell(r, c).fill.fgColor).endswith("FFD966"):
                yellow_measurement_in += 1
            if color_value(b.cell(r, c).fill.fgColor).endswith("FFD966"):
                yellow_measurement_out += 1

for sname, row in expected_yellow_status:
    cell = wb_out[sname].cell(row, 3)
    if not color_value(cell.fill.fgColor).endswith("FFD966"):
        status_yellow_failures.append(f"{sname}!C{row}")

actual_value_changes = {
    (d["sheet"], d["row"], d["col"]): (d["before"], d["after"])
    for d in value_diffs
}

ct_sheet = wb_out["Older samples - before 2021"]
ct_row = next(r for r in range(2, ct_sheet.max_row + 1) if text(ct_sheet.cell(r, 1).value) == "CT-606")
ct_font_failures = []
for c in range(1, 28):
    f = ct_sheet.cell(ct_row, c).font
    if f.name != "Calibri" or float(f.sz or 0) != 10.0:
        ct_font_failures.append(ct_sheet.cell(ct_row, c).coordinate)

report = {
    "sheet_names_match": wb_in.sheetnames == wb_out.sheetnames,
    "value_diff_count": len(value_diffs),
    "value_diffs_match_expected": actual_value_changes == expected_value_changes,
    "formula_diff_count": len(formula_diffs),
    "formula_error_count": len(formula_errors),
    "yellow_measurement_cells_before": yellow_measurement_in,
    "yellow_measurement_cells_after": yellow_measurement_out,
    "yellow_measurement_cells_unchanged": yellow_measurement_in == yellow_measurement_out,
    "expected_yellow_status_cells": len(expected_yellow_status),
    "status_yellow_failures": status_yellow_failures,
    "not_tested_count": len(not_tested_out),
    "not_tested_rows": not_tested_out,
    "ct606_row": ct_row,
    "ct606_font_failures": ct_font_failures,
    "value_diffs": value_diffs,
    "formula_diffs": formula_diffs,
    "formula_errors": formula_errors,
}
REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

assert report["value_diffs_match_expected"], value_diffs
assert report["formula_diff_count"] == 0, formula_diffs
assert report["formula_error_count"] == 0, formula_errors
assert report["yellow_measurement_cells_unchanged"], (yellow_measurement_in, yellow_measurement_out)
assert not status_yellow_failures, status_yellow_failures
assert report["not_tested_count"] == 17, not_tested_out
assert not ct_font_failures, ct_font_failures

print(json.dumps({k: v for k, v in report.items() if k not in {"not_tested_rows", "value_diffs", "formula_diffs", "formula_errors"}}, ensure_ascii=False, indent=2))
