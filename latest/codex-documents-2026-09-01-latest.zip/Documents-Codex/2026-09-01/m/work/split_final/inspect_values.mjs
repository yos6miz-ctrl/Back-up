import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const input = await FileBlob.load("C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx");
const wb = await SpreadsheetFile.importXlsx(input);
const sheet = wb.worksheets.getItem("Final");
const values = sheet.getRange("A1:AA5").values;
console.log(JSON.stringify(values, null, 2));
