from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
import json
import math
import re
import zipfile

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final")
LEDGER = WORK / "requested_edit_ledger.json"
SOURCE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
OUTPUT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\verified_raw_split_20260901"
    r"\Final Known and Unknown - verified raw measurements.xlsx"
)


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def normalized(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return value


def equal(left, right):
    left = normalized(left)
    right = normalized(right)
    if left in (None, "") and right in (None, ""):
        return True
    if is_numeric(left) and is_numeric(right):
        return abs(float(left) - float(right)) <= 1e-10
    return left == right


ledger = json.loads(LEDGER.read_text(encoding="utf-8"))
source_wb = load_workbook(SOURCE, data_only=True, read_only=False)
output_wb = load_workbook(OUTPUT, data_only=False, read_only=False)

assert output_wb.sheetnames == ["Older samples - before 2021", "2021 onward"]
older_ws = output_wb["Older samples - before 2021"]
onward_ws = output_wb["2021 onward"]
actual_older = [[cell.value for cell in row] for row in older_ws.iter_rows(min_row=2, max_col=27)]
actual_onward = [[cell.value for cell in row] for row in onward_ws.iter_rows(min_row=2, max_col=27)]
expected_older = [row for row in ledger["rows"] if row["split"] == "Before 2021"]
expected_onward = [row for row in ledger["rows"] if row["split"] == "2021 onward"]

assert len(actual_older) == len(expected_older) == 188
assert len(actual_onward) == len(expected_onward) == 158

mismatches = []
for sheet_name, actual_rows, expected_rows in (
    ("Older samples - before 2021", actual_older, expected_older),
    ("2021 onward", actual_onward, expected_onward),
):
    for output_row, (actual, expected) in enumerate(zip(actual_rows, expected_rows), start=2):
        expected_values = expected["values"]
        for col, (actual_value, expected_value) in enumerate(zip(actual, expected_values), start=1):
            if not equal(actual_value, expected_value):
                mismatches.append(
                    {
                        "sheet": sheet_name,
                        "row": output_row,
                        "col": col,
                        "primary": expected["primary"],
                        "actual": str(actual_value),
                        "expected": str(expected_value),
                    }
                )

measurement_indexes = list(range(9, 17)) + list(range(18, 24))
source_ws = source_wb["Final"]
source_measurement_count = sum(
    is_numeric(source_ws.cell(row, col + 1).value)
    for row in range(2, source_ws.max_row + 1)
    for col in measurement_indexes
)
output_measurement_count = sum(
    is_numeric(row[col])
    for row in actual_older + actual_onward
    for col in measurement_indexes
)

older_dates = [row[25] for row in actual_older]
onward_dates = [row[25] for row in actual_onward]
undated_older = sum(value is None for value in older_dates)
invalid_older_dates = [value for value in older_dates if value is not None and normalized(value)[:4] >= "2021"]
invalid_onward_dates = [value for value in onward_dates if value is None or normalized(value)[:4] < "2021"]

all_actual_by_source_row = {}
for actual, expected in zip(actual_older, expected_older):
    all_actual_by_source_row[expected["source_row"]] = actual
for actual, expected in zip(actual_onward, expected_onward):
    all_actual_by_source_row[expected["source_row"]] = actual

citation_failures = []
for row in ledger["rows"]:
    if not row["citation_additions"]:
        continue
    source_text = str(all_actual_by_source_row[row["source_row"]][26] or "")
    for detector, file_names in row["citation_additions"].items():
        for file_name in file_names:
            if file_name not in source_text:
                citation_failures.append(
                    {"source_row": row["source_row"], "primary": row["primary"], "detector": detector, "file": file_name}
                )

obsolete_aggregate_sources = []
empty_detector_source_segments = []
for expected in ledger["rows"]:
    actual = all_actual_by_source_row[expected["source_row"]]
    source_text = str(actual[26] or "")
    if "unknowns trial 6.26.xlsx" in source_text.lower():
        obsolete_aggregate_sources.append({"source_row": expected["source_row"], "primary": expected["primary"]})
    pa_values = actual[9:17]
    ara_values = actual[18:24]
    if not any(is_numeric(value) for value in pa_values) and re.search(r"PA447:\s*[^;]+", source_text, flags=re.I):
        empty_detector_source_segments.append({"source_row": expected["source_row"], "primary": expected["primary"], "detector": "PA447"})
    if not any(is_numeric(value) for value in ara_values) and re.search(r"araE:\s*[^;]+", source_text, flags=re.I):
        empty_detector_source_segments.append({"source_row": expected["source_row"], "primary": expected["primary"], "detector": "araE"})

formula_cells = []
for ws in output_wb.worksheets:
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith("="):
                formula_cells.append(f"{ws.title}!{cell.coordinate}")

with zipfile.ZipFile(OUTPUT) as archive:
    bad_zip_member = archive.testzip()

result = {
    "sheet_names": output_wb.sheetnames,
    "older_rows": len(actual_older),
    "onward_rows": len(actual_onward),
    "total_rows": len(actual_older) + len(actual_onward),
    "undated_in_older_tab": undated_older,
    "invalid_older_date_count": len(invalid_older_dates),
    "invalid_onward_date_count": len(invalid_onward_dates),
    "source_measurement_count": source_measurement_count,
    "output_measurement_count": output_measurement_count,
    "removed_measurement_count": source_measurement_count - output_measurement_count,
    "cell_mismatch_count_against_ledger": len(mismatches),
    "citation_failure_count": len(citation_failures),
    "obsolete_aggregate_source_count": len(obsolete_aggregate_sources),
    "empty_detector_source_segment_count": len(empty_detector_source_segments),
    "decision_changes_expected": len(ledger["decision_changes"]),
    "classification_changes_expected": len(ledger["classification_changes"]),
    "formula_cell_count": len(formula_cells),
    "bad_zip_member": bad_zip_member,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
if mismatches:
    print(json.dumps({"mismatches": mismatches[:20]}, ensure_ascii=False, indent=2))
if citation_failures:
    print(json.dumps({"citation_failures": citation_failures[:20]}, ensure_ascii=False, indent=2))

assert source_measurement_count == 1039
assert output_measurement_count == 938
assert source_measurement_count - output_measurement_count == 101
assert undated_older == 8
assert not invalid_older_dates
assert not invalid_onward_dates
assert not mismatches
assert not citation_failures
assert not obsolete_aggregate_sources
assert not empty_detector_source_segments
assert not formula_cells
assert bad_zip_member is None

source_wb.close()
output_wb.close()
