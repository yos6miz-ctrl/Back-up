import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const outputPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_split_20260901/Final Known and Unknown - verified raw measurements.xlsx";
const olderPreviewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/verified_export_older.png";
const onwardPreviewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/verified_export_onward.png";
const undatedPreviewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/verified_export_undated.png";

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
const olderSheet = workbook.worksheets.getItem("Older samples - before 2021");
const onwardSheet = workbook.worksheets.getItem("2021 onward");
const olderValues = olderSheet.getRange("A1:AA189").values;
const onwardValues = onwardSheet.getRange("A1:AA159").values;

const summary = await workbook.inspect({
  kind: "workbook,sheet",
  maxChars: 5000,
});
console.log("SUMMARY");
console.log(summary.ndjson);

for (const [sheetId, range] of [
  ["Older samples - before 2021", "A1:AA8"],
  ["2021 onward", "A1:AA8"],
]) {
  const region = await workbook.inspect({ kind: "region", sheetId, range, maxChars: 8000 });
  console.log(`REGION ${sheetId}`);
  console.log(region.ndjson);
}

const diagnostics = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "reopened final formula error scan",
});
console.log("DIAGNOSTICS");
console.log(diagnostics.ndjson);

const olderPreview = await workbook.render({
  sheetName: "Older samples - before 2021",
  range: "A1:AA24",
  scale: 1,
  format: "png",
});
await fs.writeFile(olderPreviewPath, new Uint8Array(await olderPreview.arrayBuffer()));

const onwardPreview = await workbook.render({
  sheetName: "2021 onward",
  range: "A1:AA24",
  scale: 1,
  format: "png",
});
await fs.writeFile(onwardPreviewPath, new Uint8Array(await onwardPreview.arrayBuffer()));

const undatedPreview = await workbook.render({
  sheetName: "Older samples - before 2021",
  range: "A170:AA189",
  scale: 1,
  format: "png",
});
await fs.writeFile(undatedPreviewPath, new Uint8Array(await undatedPreview.arrayBuffer()));

const result = {
  sheetNames: [olderSheet.name, onwardSheet.name],
  olderRows: olderValues.length - 1,
  onwardRows: onwardValues.length - 1,
  totalRows: olderValues.length + onwardValues.length - 2,
  diagnostics: diagnostics.ndjson,
};
console.log(JSON.stringify(result, null, 2));

if (
  result.olderRows !== 188 ||
  result.onwardRows !== 158 ||
  result.totalRows !== 346 ||
  result.sheetNames.join("|") !== "Older samples - before 2021|2021 onward"
) {
  throw new Error("Artifact-tool workbook structure verification failed.");
}
