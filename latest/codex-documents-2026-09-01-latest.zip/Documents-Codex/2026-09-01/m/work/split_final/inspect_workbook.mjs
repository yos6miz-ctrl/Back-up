import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const inputPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const previewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/current_final_preview.png";

const input = await FileBlob.load(inputPath);
const workbook = await SpreadsheetFile.importXlsx(input);

const summary = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 9000,
  tableMaxRows: 8,
  tableMaxCols: 12,
  tableMaxCellChars: 100,
});
console.log("SUMMARY");
console.log(summary.ndjson);

const values = await workbook.inspect({
  kind: "region",
  sheetId: "Final",
  range: "A1:AA12",
  maxChars: 12000,
});
console.log("VALUES");
console.log(values.ndjson);

const styles = await workbook.inspect({
  kind: "computedStyle",
  sheetId: "Final",
  range: "A1:AA5",
  maxChars: 10000,
});
console.log("STYLES");
console.log(styles.ndjson);

const preview = await workbook.render({
  sheetName: "Final",
  range: "A1:AA25",
  scale: 1.4,
  format: "png",
});
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
console.log(JSON.stringify({ previewPath }));
