import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const outputPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/final_split_20260901/Final Known and Unknown merged - split by sample date.xlsx";
const bottomPreviewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/output_undated_rows.png";

const sourceWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const outputWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
const sourceValues = sourceWorkbook.worksheets.getItem("Final").getRange("A1:AA347").values;
const beforeSheet = outputWorkbook.worksheets.getItem("Before 2021");
const onwardSheet = outputWorkbook.worksheets.getItem("2021 onward + undated");
const beforeValues = beforeSheet.getRange("A1:AA181").values;
const onwardValues = onwardSheet.getRange("A1:AA167").values;

function dateYear(value) {
  if (value === null || value === "") return null;
  if (value instanceof Date) return value.getUTCFullYear();
  const match = String(value).match(/^(\d{4})/);
  if (!match) throw new Error(`Unexpected date value: ${value}`);
  return Number(match[1]);
}

const beforeDates = beforeValues.slice(1).map((row) => dateYear(row[25]));
const onwardDates = onwardValues.slice(1).map((row) => dateYear(row[25]));
const beforeInvalid = beforeDates.filter((year) => year === null || year >= 2021).length;
const onwardInvalid = onwardDates.filter((year) => year !== null && year < 2021).length;
const undatedCount = onwardDates.filter((year) => year === null).length;

const sourceNonDate = sourceValues.slice(1).map((row) => JSON.stringify([...row.slice(0, 25), row[26]])).sort();
const outputNonDate = [...beforeValues.slice(1), ...onwardValues.slice(1)]
  .map((row) => JSON.stringify([...row.slice(0, 25), row[26]]))
  .sort();
const nonDateDataPreserved = JSON.stringify(sourceNonDate) === JSON.stringify(outputNonDate);

const oldMeteringSourceBlanks = sourceValues.slice(1)
  .filter((row) => row[2] === "old metering system" && (row[26] === null || row[26] === "")).length;
const oldMeteringOutputBlanks = [...beforeValues.slice(1), ...onwardValues.slice(1)]
  .filter((row) => row[2] === "old metering system" && (row[26] === null || row[26] === "")).length;

const expectedRecovered = new Map([
  ["CT-163", "2021-03-10"],
  ["CT-229", "2021-04-12"],
  ["CT-258", "2019-04-14"],
]);
const recoveredChecks = {};
for (const [name, expectedDate] of expectedRecovered.entries()) {
  const row = [...beforeValues.slice(1), ...onwardValues.slice(1)].find((values) => values[0] === name);
  recoveredChecks[name] = row ? String(row[25]).slice(0, 10) === expectedDate : false;
}

const diagnostics = await outputWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "reopened output formula error scan",
});

const bottomPreview = await outputWorkbook.render({
  sheetName: "2021 onward + undated",
  range: "A155:AA167",
  scale: 1,
  format: "png",
});
await fs.writeFile(bottomPreviewPath, new Uint8Array(await bottomPreview.arrayBuffer()));

const result = {
  sheetNames: [beforeSheet.name, onwardSheet.name],
  beforeRows: beforeValues.length - 1,
  onwardAndUndatedRows: onwardValues.length - 1,
  totalRows: beforeValues.length + onwardValues.length - 2,
  beforeInvalid,
  onwardInvalid,
  undatedCount,
  undatedAreLastEight: onwardDates.slice(-8).every((year) => year === null),
  nonDateDataPreserved,
  oldMeteringSourceBlanks,
  oldMeteringOutputBlanks,
  recoveredChecks,
  diagnostics: diagnostics.ndjson,
};

console.log(JSON.stringify(result, null, 2));

if (
  result.beforeRows !== 180 ||
  result.onwardAndUndatedRows !== 166 ||
  result.totalRows !== 346 ||
  beforeInvalid !== 0 ||
  onwardInvalid !== 0 ||
  undatedCount !== 8 ||
  !result.undatedAreLastEight ||
  !nonDateDataPreserved ||
  oldMeteringSourceBlanks !== oldMeteringOutputBlanks ||
  Object.values(recoveredChecks).some((ok) => !ok)
) {
  throw new Error("Workbook verification failed.");
}
