import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const requests = [
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Old sampels/All Stool aliquots updated 10.8.23.xlsx",
    sheet: "UC",
    range: "A1:F10",
  },
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Old sampels/samples for weizmann PAO1.xlsx",
    sheet: "BOX Layout",
    range: "A1:G11",
  },
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Old sampels/ישן-new stool inventory.xlsx",
    sheet: "old samples",
    range: "A1:D10",
  },
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx",
    sheet: "Final",
    range: "A1:AA12",
  },
];

for (const request of requests) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(request.path));
  const result = await workbook.inspect({
    kind: "region",
    sheetId: request.sheet,
    range: request.range,
    maxChars: 12000,
  });
  console.log(JSON.stringify({ path: request.path, sheet: request.sheet, range: request.range }));
  console.log(result.ndjson);
}
