from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path
import json
import math
import sys

from openpyxl import load_workbook


AUDIT_SCRIPT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure"
    r"\audit_final_measurements_without_source.py"
)
OUTPUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final\raw_measurement_coverage_enhanced.json")


sys.path.insert(0, str(AUDIT_SCRIPT.parent))
spec = spec_from_file_location("raw_audit", AUDIT_SCRIPT)
audit = module_from_spec(spec)
spec.loader.exec_module(audit)


def average_match(value, candidates, tolerance=1e-6):
    unique = []
    seen = set()
    for item in candidates:
        key = round(item["value"], 12)
        if key not in seen:
            seen.add(key)
            unique.append(item)
    for size in (2, 3, 4):
        if len(unique) > 18:
            break
        for group in combinations(unique, size):
            mean = sum(item["value"] for item in group) / size
            if abs(mean - value) <= tolerance:
                return {
                    "size": size,
                    "mean": mean,
                    "items": [
                        {
                            "value": item["value"],
                            "source_file": item["source_file"],
                            "source_cell": item["source_cell"],
                            "sample": item["sample"],
                        }
                        for item in group
                    ],
                }
    return None


def candidate_summary(item):
    return {
        "value": item["value"],
        "sample": item["sample"],
        "source_file": item["source_file"],
        "source_cell": item["source_cell"],
        "path": item["path"],
    }


def main():
    measurements, needed_files = audit.read_final()
    sources_by_name = audit.locate_sources(needed_files)
    source_records = []
    for _name, paths in sorted(sources_by_name.items()):
        for path in paths:
            source_records.extend(audit.extract_formula_records(path))

    final_wb = load_workbook(audit.FINAL_PATH, data_only=True, read_only=False)
    final_ws = final_wb["Final"]
    headers = {final_ws.cell(1, col).value: col for col in range(1, final_ws.max_column + 1)}
    source_text_by_row = {
        row: str(final_ws.cell(row, headers["Measurement/source file"]).value or "")
        for row in range(2, final_ws.max_row + 1)
    }
    final_wb.close()

    records_by_detector = defaultdict(list)
    records_by_file_detector = defaultdict(list)
    for record in source_records:
        records_by_detector[record["detector"]].append(record)
        records_by_file_detector[(record["source_file"], record["detector"])].append(record)

    classified = []
    for measurement in measurements:
        detector = measurement["detector"]
        keys = measurement["keys"]
        value = measurement["value"]
        listed = []
        for file_name in measurement["listed_files"]:
            listed.extend(
                record
                for record in records_by_file_detector.get((file_name, detector), [])
                if keys & record["keys"]
            )
        anywhere = [record for record in records_by_detector[detector] if keys & record["keys"]]
        exact_listed = [record for record in listed if abs(record["value"] - value) <= 5e-7]
        exact_anywhere = [record for record in anywhere if abs(record["value"] - value) <= 5e-7]
        average = average_match(value, listed) or average_match(value, anywhere)
        source_text = source_text_by_row[measurement["row"]]
        legacy_marker = any(token in source_text.lower() for token in ("ibd ibs old", "447 and arae all"))

        if measurement["status"] == "old metering system":
            category = "accepted_old_metering_status"
        elif exact_listed:
            category = "exact_raw_value_in_listed_file"
        elif exact_anywhere:
            category = "exact_raw_value_in_unlisted_file"
        elif average:
            category = "reproducible_average_of_raw_values"
        elif anywhere:
            category = "raw_sample_detector_exists_but_value_not_reproduced"
        elif legacy_marker:
            category = "accepted_legacy_source_marker_no_raw_match"
        else:
            category = "no_raw_record_for_sample_detector"

        closest = sorted(anywhere, key=lambda record: abs(record["value"] - value))[:5]
        classified.append(
            {
                **measurement,
                "category": category,
                "source_text": source_text,
                "legacy_marker": legacy_marker,
                "listed_same_sample_candidates": len(listed),
                "anywhere_same_sample_candidates": len(anywhere),
                "exact_listed": [candidate_summary(item) for item in exact_listed[:5]],
                "exact_anywhere": [candidate_summary(item) for item in exact_anywhere[:5]],
                "average_match": average,
                "closest_same_sample": [candidate_summary(item) for item in closest],
            }
        )

    category_counts = Counter(item["category"] for item in classified)
    non_legacy = [
        item for item in classified
        if item["category"] not in {
            "accepted_old_metering_status",
            "accepted_legacy_source_marker_no_raw_match",
        }
    ]
    non_legacy_covered = [
        item for item in non_legacy
        if item["category"] in {
            "exact_raw_value_in_listed_file",
            "exact_raw_value_in_unlisted_file",
            "reproducible_average_of_raw_values",
        }
    ]
    unresolved = [
        item for item in non_legacy
        if item["category"] in {
            "raw_sample_detector_exists_but_value_not_reproduced",
            "no_raw_record_for_sample_detector",
        }
    ]

    result = {
        "measurements_checked": len(classified),
        "source_records_extracted": len(source_records),
        "source_files_located": len(sources_by_name),
        "category_counts": dict(category_counts),
        "non_legacy_measurements": len(non_legacy),
        "non_legacy_reproduced_from_raw": len(non_legacy_covered),
        "non_legacy_unresolved": len(unresolved),
        "non_legacy_unresolved_rows": len({item["row"] for item in unresolved}),
        "non_legacy_unresolved_by_detector": dict(Counter(item["detector"] for item in unresolved)),
        "unresolved": unresolved,
        "classified": classified,
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=list), encoding="utf-8")
    print(
        json.dumps(
            {key: result[key] for key in result if key not in {"unresolved", "classified"}},
            ensure_ascii=False,
            indent=2,
        )
    )
    print(json.dumps({"unresolved_rows": sorted({(item["row"], item["primary"]) for item in unresolved})}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
