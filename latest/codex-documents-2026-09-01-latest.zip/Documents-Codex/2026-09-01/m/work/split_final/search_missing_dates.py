from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json
import re
import zipfile
import xml.etree.ElementTree as ET

import analyze_sources_dates as base


TARGETS = {
    "CT621": {"CT621", "HS621"},
    "CT167": {"CT167", "HS167"},
    "CT187": {"CT187", "HS187"},
    "CT229": {"CT229", "HS229"},
    "CT270": {"CT270", "HS270"},
    "CT222": {"CT222", "HS222"},
    "CT241": {"CT241", "HS241"},
    "CT245": {"CT245", "HS245"},
    "CT247": {"CT247", "HS247"},
    "CT258": {"CT258", "HS258"},
}
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final\missing_date_search.json")


def target_for(value):
    key = base.norm(value)
    if not re.search(r"[A-Z]", key):
        return None
    for target, aliases in TARGETS.items():
        if key in aliases:
            return target
    return None


def search_file(path):
    hits = []
    try:
        with zipfile.ZipFile(path) as zf:
            strings = base.shared_strings(zf)
            if not any(target_for(value) for value in strings):
                # Inline strings are uncommon in these inventories; parse only files whose XML text contains CT/HS IDs.
                raw_probe = b"".join(
                    zf.read(sheet_path)
                    for _sheet, sheet_path in base.sheet_paths(zf)
                    if sheet_path in zf.namelist()
                )
                if not any(alias.encode("ascii") in raw_probe.upper() for aliases in TARGETS.values() for alias in aliases):
                    return hits
            for sheet_name, sheet_path in base.sheet_paths(zf):
                root = ET.fromstring(zf.read(sheet_path))
                for row in root.findall(f".//{{{base.NS_MAIN}}}row"):
                    row_values = []
                    row_hits = []
                    for cell in row.findall(f"{{{base.NS_MAIN}}}c"):
                        value = base.cell_value(cell, strings)
                        if value not in (None, ""):
                            row_values.append({"cell": cell.attrib.get("r"), "value": value})
                            target = target_for(value)
                            if target:
                                row_hits.append({"target": target, "cell": cell.attrib.get("r"), "label": str(value)})
                    for hit in row_hits:
                        hits.append(
                            {
                                "target": hit["target"],
                                "path": str(path),
                                "sheet": sheet_name,
                                "row": int(row.attrib.get("r", "0") or 0),
                                "cell": hit["cell"],
                                "label": hit["label"],
                                "row_values": row_values[:40],
                            }
                        )
    except Exception:
        pass
    return hits


def main():
    paths = [path for path in base.ROOT.rglob("*.xlsx") if not path.name.startswith("~$")]
    hits = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(search_file, path) for path in paths]
        for future in as_completed(futures):
            hits.extend(future.result())
    grouped = {target: [hit for hit in hits if hit["target"] == target] for target in TARGETS}
    OUT.write_text(json.dumps(grouped, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({target: len(items) for target, items in grouped.items()}, ensure_ascii=False, indent=2))
    for target, items in grouped.items():
        if items:
            print(target)
            print(json.dumps(items[:12], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
