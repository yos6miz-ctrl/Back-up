import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const ledgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/requested_edit_ledger.json";
const outputPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_split_20260901/Final Known and Unknown - verified raw measurements.xlsx";
const previewBeforePath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/verified_older_samples.png";
const previewAfterPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/verified_2021_onward.png";

const ledger = JSON.parse(await fs.readFile(ledgerPath, "utf8"));

const headers = [...ledger.headers];
const preparedRows = ledger.rows.map((record) => {
  const values = [...record.values];
  values[25] = record.date ? new Date(`${record.date}T00:00:00Z`) : null;
  return { ...record, values };
});

const beforeRows = preparedRows.filter((row) => row.split === "Before 2021");
const onwardRows = preparedRows.filter((row) => row.split === "2021 onward");
const undatedRows = beforeRows.filter((row) => row.date === null);

if (beforeRows.length + onwardRows.length !== ledger.rows.length) {
  throw new Error("Row accounting failed while splitting the source workbook.");
}

const workbook = Workbook.create();
const beforeSheet = workbook.worksheets.add("Older samples - before 2021");
const onwardSheet = workbook.worksheets.add("2021 onward");

const categoryStyles = {
  diagnosis: {
    CDf: { fill: "#E06666", font: "#000000" },
    Healthy: { fill: "#CFE2F3", font: "#000000" },
    CDr: { fill: "#F4CCCC", font: "#000000" },
    IBS: { fill: "#3C78D8", font: "#000000" },
    UCf: { fill: "#F6B26B", font: "#000000" },
    UCr: { fill: "#FCE5CD", font: "#000000" },
  },
  classification: {
    IBD: { fill: "#C00000", font: "#FFFFFF" },
    inconclusive: { fill: "#D9D2E9", font: "#4C3868" },
    IBS: { fill: "#003399", font: "#FFFFFF" },
    missing: { fill: "#E7E6E6", font: "#666666" },
    "לא נבדק": { fill: "#D9D2E9", font: "#4C3868" },
  },
  decision: {
    Neg: { fill: "#CFE2F3", font: "#17365D" },
    Pos: { fill: "#F4C7C3", font: "#5A1212" },
    Int: { fill: "#FFF2CC", font: "#7F6000" },
  },
};

function setCellStyle(cell, style, bold = false) {
  cell.format.fill = style.fill;
  cell.format.font = { color: style.font, bold };
}

const detectorMeasurementColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};

function styleDetectorMeasurements(sheet, outputRow, detector, result) {
  if (!result || Object.keys(result).length === 0) return;
  const used = new Set(result.used_indices ?? []);
  const problems = new Set(result.problem_indices ?? []);
  const repeats = new Set(result.needs_repeat_indices ?? []);
  detectorMeasurementColumns[detector].forEach((column, index) => {
    const cell = sheet.getRange(`${column}${outputRow}`);
    if (used.has(index)) cell.format.font = { bold: true, color: "#000000" };
    if (problems.has(index)) cell.format.fill = "#FFF2CC";
    if (repeats.has(index)) cell.format.fill = "#FCE4D6";
  });
}

function buildSheet(sheet, rows) {
  const matrix = [headers, ...rows.map((row) => row.values)];
  const lastRow = matrix.length;
  const used = sheet.getRange(`A1:AA${lastRow}`);
  used.values = matrix;

  used.format.font = { name: "Calibri", size: 10, color: "#000000" };
  used.format.verticalAlignment = "center";
  used.format.borders = { preset: "all", style: "thin", color: "#D9D9D9" };

  const header = sheet.getRange("A1:AA1");
  header.format.fill = "#D9D9D9";
  header.format.font = { name: "Calibri", size: 11, bold: true, color: "#000000" };
  header.format.horizontalAlignment = "center";
  header.format.verticalAlignment = "center";
  header.format.wrapText = true;
  header.format.rowHeight = 38;
  header.format.borders = {
    bottom: { style: "thin", color: "#808080" },
  };

  if (lastRow > 1) {
    sheet.getRange(`A2:Z${lastRow}`).format.horizontalAlignment = "center";
    sheet.getRange(`D2:I${lastRow}`).format.wrapText = true;
    sheet.getRange(`AA2:AA${lastRow}`).format.wrapText = true;
    sheet.getRange(`AA2:AA${lastRow}`).format.horizontalAlignment = "left";
    sheet.getRange(`F2:F${lastRow}`).format.numberFormat = "0.##";
    sheet.getRange(`H2:H${lastRow}`).format.numberFormat = "0";
    sheet.getRange(`J2:Q${lastRow}`).format.numberFormat = "0.000";
    sheet.getRange(`S2:X${lastRow}`).format.numberFormat = "0.000";
    sheet.getRange(`Z2:Z${lastRow}`).format.numberFormat = "yyyy-mm-dd";
  }

  const widths = {
    A: 14, B: 18, C: 17, D: 11, E: 21, F: 14, G: 16, H: 14, I: 16,
    J: 13, K: 13, L: 13, M: 13, N: 13, O: 13, P: 13, Q: 13, R: 12,
    S: 13, T: 13, U: 13, V: 13, W: 13, X: 13, Y: 12, Z: 13, AA: 55,
  };
  for (const [column, width] of Object.entries(widths)) {
    sheet.getRange(`${column}:${column}`).format.columnWidth = width;
  }

  for (let index = 0; index < rows.length; index += 1) {
    const outputRow = index + 2;
    const values = rows[index].values;

    if (values[2] === "old metering system") {
      setCellStyle(sheet.getRange(`C${outputRow}`), { fill: "#FFE599", font: "#7F6000" });
    }

    const diagnosisStyle = categoryStyles.diagnosis[values[3]];
    if (diagnosisStyle) setCellStyle(sheet.getRange(`D${outputRow}`), diagnosisStyle);

    const classificationStyle = categoryStyles.classification[values[4]];
    if (classificationStyle) setCellStyle(sheet.getRange(`E${outputRow}`), classificationStyle, true);

    const paStyle = categoryStyles.decision[values[17]];
    if (paStyle) setCellStyle(sheet.getRange(`R${outputRow}`), paStyle, true);

    const araStyle = categoryStyles.decision[values[24]];
    if (araStyle) setCellStyle(sheet.getRange(`Y${outputRow}`), araStyle, true);

    styleDetectorMeasurements(sheet, outputRow, "PA447", rows[index].detector_results?.PA447);
    styleDetectorMeasurements(sheet, outputRow, "araE", rows[index].detector_results?.araE);

    if (rows[index].date === null) {
      setCellStyle(sheet.getRange(`Z${outputRow}`), { fill: "#FFF2CC", font: "#7F6000" }, true);
    }
  }

  sheet.freezePanes.freezeRows(1);
  sheet.freezePanes.freezeColumns(2);
  sheet.showGridLines = false;
}

buildSheet(beforeSheet, beforeRows);
buildSheet(onwardSheet, onwardRows);

const beforePreview = await workbook.render({
  sheetName: "Older samples - before 2021",
  range: `A1:AA${Math.min(beforeRows.length + 1, 24)}`,
  scale: 1,
  format: "png",
});
await fs.writeFile(previewBeforePath, new Uint8Array(await beforePreview.arrayBuffer()));

const onwardPreview = await workbook.render({
  sheetName: "2021 onward",
  range: `A1:AA${Math.min(onwardRows.length + 1, 24)}`,
  scale: 1,
  format: "png",
});
await fs.writeFile(previewAfterPath, new Uint8Array(await onwardPreview.arrayBuffer()));

const diagnostics = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "final formula error scan",
});
console.log("DIAGNOSTICS");
console.log(diagnostics.ndjson);

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

console.log(JSON.stringify({
  outputPath,
  olderSamples: beforeRows.length,
  onward2021: onwardRows.length,
  undatedAssumedOld: undatedRows.length,
  totalRows: beforeRows.length + onwardRows.length,
  removedMeasurementCells: ledger.removed_measurement_cells,
  correctedCitationMeasurements: ledger.citation_measurements_corrected,
  correctedCitationRows: ledger.citation_rows_corrected,
  decisionChanges: ledger.decision_changes.length,
  classificationChanges: ledger.classification_changes.length,
}, null, 2));
