from collections import Counter
from datetime import date, datetime
from pathlib import Path
import json

from openpyxl import load_workbook


SOURCE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
OUTPUT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\outputs\final_split_20260901"
    r"\Final Known and Unknown merged - split by sample date.xlsx"
)


def signature(row):
    values = [cell.value for cell in row]
    return json.dumps(values[:25] + values[26:], ensure_ascii=False, default=str)


source_wb = load_workbook(SOURCE, data_only=False, read_only=False)
output_wb = load_workbook(OUTPUT, data_only=False, read_only=False)
source_ws = source_wb["Final"]
before_ws = output_wb["Before 2021"]
onward_ws = output_wb["2021 onward + undated"]

source_rows = list(source_ws.iter_rows(min_row=2, max_col=27))
before_rows = list(before_ws.iter_rows(min_row=2, max_col=27))
onward_rows = list(onward_ws.iter_rows(min_row=2, max_col=27))

before_dates = [row[25].value for row in before_rows]
onward_dates = [row[25].value for row in onward_rows]
before_invalid = [value for value in before_dates if not isinstance(value, (date, datetime)) or value.year >= 2021]
onward_invalid = [value for value in onward_dates if value is not None and (not isinstance(value, (date, datetime)) or value.year < 2021)]
undated_positions = [index + 2 for index, value in enumerate(onward_dates) if value is None]

source_signatures = Counter(signature(row) for row in source_rows)
output_signatures = Counter(signature(row) for row in before_rows + onward_rows)

all_output_rows = before_rows + onward_rows
date_by_name = {row[0].value: row[25].value for row in all_output_rows}
expected_recovered = {
    "CT-163": datetime(2021, 3, 10),
    "CT-229": datetime(2021, 4, 12),
    "CT-258": datetime(2019, 4, 14),
}
recovered_checks = {name: date_by_name.get(name) == expected for name, expected in expected_recovered.items()}

result = {
    "sheet_names": output_wb.sheetnames,
    "before_rows": len(before_rows),
    "onward_rows_with_undated": len(onward_rows),
    "total_rows": len(before_rows) + len(onward_rows),
    "before_invalid_count": len(before_invalid),
    "onward_invalid_count": len(onward_invalid),
    "undated_positions": undated_positions,
    "all_non_date_data_preserved": source_signatures == output_signatures,
    "recovered_checks": recovered_checks,
}
print(json.dumps(result, ensure_ascii=False, indent=2, default=str))

assert output_wb.sheetnames == ["Before 2021", "2021 onward + undated"]
assert len(before_rows) == 180
assert len(onward_rows) == 166
assert len(before_rows) + len(onward_rows) == 346
assert not before_invalid
assert not onward_invalid
assert undated_positions == list(range(160, 168))
assert source_signatures == output_signatures
assert all(recovered_checks.values())

source_wb.close()
output_wb.close()
