from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from pathlib import Path
import json
import re

from openpyxl import load_workbook

import analyze_sources_dates as base


OLD_ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Old sampels")
OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final\old_samples_date_audit.json")
TARGETS = {
    "CT621": {"CT621", "HS621", "621"},
    "CT167": {"CT167", "HS167", "167"},
    "CT187": {"CT187", "HS187", "187"},
    "CT270": {"CT270", "HS270", "270"},
    "CT222": {"CT222", "HS222", "222"},
    "CT241": {"CT241", "HS241", "241"},
    "CT245": {"CT245", "HS245", "245"},
    "CT247": {"CT247", "HS247", "247"},
}


def clean(value):
    if value is None:
        return None
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ").strip()) or None


def norm(value):
    text = (clean(value) or "").upper()
    return re.sub(r"[^A-Z0-9א-ת]+", "", text)


def target_for(value, allow_numeric=True):
    key = norm(value)
    if not key:
        return None
    for target, aliases in TARGETS.items():
        if key in aliases and (allow_numeric or not key.isdigit()):
            return target
    return None


def header_text(ws, row, col):
    for header_row in range(row - 1, max(0, row - 25), -1):
        value = clean(ws.cell(header_row, col).value)
        if value:
            return value, header_row
    return None, None


def is_sample_identifier_header(value):
    text = (clean(value) or "").lower()
    tokens = (
        "sample", "patient", "code", "number", "name", "id", "uid",
        "דגימה", "מטופל", "מספר", "שם",
    )
    return any(token in text for token in tokens)


def is_collection_date_header(value):
    text = (clean(value) or "").lower()
    if not text:
        return False
    positive = (
        "sample date", "date of sample", "collection date", "collected",
        "visit date", "date taken", "stool date", "תאריך דגימה", "תאריך ביקור",
    )
    negative = ("sent", "shipment", "received", "run date", "measurement", "assay", "משלוח")
    return any(token in text for token in positive) and not any(token in text for token in negative)


def date_cells_for_row(ws, row):
    cells = []
    for col in range(1, ws.max_column + 1):
        raw = ws.cell(row, col).value
        parsed = base.normalize_date(raw)
        if not parsed:
            continue
        header, header_row = header_text(ws, row, col)
        cells.append(
            {
                "cell": ws.cell(row, col).coordinate,
                "raw": str(raw),
                "date": parsed.isoformat(),
                "header": header,
                "header_row": header_row,
                "collection_date_header": is_collection_date_header(header),
            }
        )
    return cells


def row_snapshot(ws, row):
    values = []
    for col in range(1, ws.max_column + 1):
        value = ws.cell(row, col).value
        if value not in (None, ""):
            values.append({"cell": ws.cell(row, col).coordinate, "value": str(value)})
    return values[:80]


def main():
    files = sorted(path for path in OLD_ROOT.rglob("*.xlsx") if not path.name.startswith("~$"))
    result = {
        "root": str(OLD_ROOT),
        "files_detected": len(files),
        "files_opened": 0,
        "errors": [],
        "targets": {target: [] for target in TARGETS},
        "trustworthy_collection_dates": defaultdict(list),
    }

    for path in files:
        try:
            workbook = load_workbook(path, data_only=False, read_only=False)
            values_workbook = load_workbook(path, data_only=True, read_only=False)
            result["files_opened"] += 1
        except Exception as exc:
            result["errors"].append({"file": str(path), "error": f"{type(exc).__name__}: {exc}"})
            continue

        for ws in workbook.worksheets:
            values_ws = values_workbook[ws.title]
            for row in range(1, ws.max_row + 1):
                row_hits = []
                for col in range(1, ws.max_column + 1):
                    raw_value = values_ws.cell(row, col).value
                    target = target_for(raw_value, allow_numeric=False)
                    if not target and norm(raw_value).isdigit():
                        header, _ = header_text(values_ws, row, col)
                        if is_sample_identifier_header(header):
                            target = target_for(raw_value, allow_numeric=True)
                    if target:
                        row_hits.append((target, values_ws.cell(row, col).coordinate, str(raw_value)))

                if not row_hits:
                    continue
                dates = date_cells_for_row(values_ws, row)
                context = {
                    "file": str(path),
                    "sheet": ws.title,
                    "sheet_state": ws.sheet_state,
                    "row": row,
                    "row_hidden": bool(ws.row_dimensions[row].hidden),
                    "row_values": row_snapshot(values_ws, row),
                    "nearby_rows": [
                        {"row": nearby, "values": row_snapshot(values_ws, nearby)}
                        for nearby in range(max(1, row - 2), min(values_ws.max_row, row + 2) + 1)
                        if nearby != row
                    ],
                    "date_cells": dates,
                }
                for target, cell, label in row_hits:
                    hit = {**context, "matched_cell": cell, "matched_label": label}
                    result["targets"][target].append(hit)
                    for date_cell in dates:
                        if date_cell["collection_date_header"]:
                            result["trustworthy_collection_dates"][target].append(
                                {
                                    "date": date_cell["date"],
                                    "file": str(path),
                                    "sheet": ws.title,
                                    "row": row,
                                    "cell": date_cell["cell"],
                                    "header": date_cell["header"],
                                }
                            )
        workbook.close()
        values_workbook.close()

    result["trustworthy_collection_dates"] = dict(result["trustworthy_collection_dates"])
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        "files_detected": result["files_detected"],
        "files_opened": result["files_opened"],
        "error_count": len(result["errors"]),
        "hit_counts": {target: len(hits) for target, hits in result["targets"].items()},
        "trustworthy_collection_dates": result["trustworthy_collection_dates"],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
