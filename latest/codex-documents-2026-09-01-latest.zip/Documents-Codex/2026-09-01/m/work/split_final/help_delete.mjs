import { Workbook } from "@oai/artifact-tool";

const wb = Workbook.create();
for (const query of ["table.delete", "worksheet.tables.delete", "worksheet.tables.deleteAll"]) {
  const result = await wb.help(query, { include: "index,examples,notes", max_chars: 5000 });
  console.log(`QUERY ${query}`);
  console.log(JSON.stringify(result, null, 2));
}
