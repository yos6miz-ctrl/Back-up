from __future__ import annotations

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta
from pathlib import Path
import importlib.util
import json
import math
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
FINAL = ROOT / "Final Known and Unknown merged.xlsx"
PRIMARY_ALIQUOTS = ROOT / "aliqauts 20260801.xlsx"
ALIQUOT_SOURCES = [
    PRIMARY_ALIQUOTS,
    ROOT / "Old sampels" / "Stool aliquots updated.xlsx",
    ROOT / "Old sampels" / "All Stool aliquots updated 10.8.23.xlsx",
    ROOT / "Excel file editor" / "deta" / "aliqauts 20250112.xlsx",
    ROOT / "Old sampels" / "CD to Bar Ilan Feb 23 clinical data.xlsx",
    ROOT / "Old sampels" / "Stools  to Bar ilan UID 7.2.23.xlsx",
    ROOT / "Old sampels" / "ישן-new stool inventory.xlsx",
    ROOT / "Old sampels" / "samples for weizmann PAO1.xlsx",
    ROOT / "Excel file editor" / "deta" / "Final Known and Unknown merged.xlsx",
]
REPORT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final\analysis.json")
BUILDER_PATH = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure\build_accounted_known_unknown.py")

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def load_builder():
    spec = importlib.util.spec_from_file_location("date_builder", BUILDER_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


BUILDER = load_builder()


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\xa0", " ").strip()
    return re.sub(r"\s+", " ", text) or None


def norm(value):
    text = (clean(value) or "").upper()
    text = re.sub(r"^UN[\s_-]*", "", text)
    return re.sub(r"[^A-Z0-9א-ת]+", "", text)


def strict_keys(*values):
    keys = set()
    for value in values:
        if not value:
            continue
        for part in re.split(r"[;,\n]+", str(value)):
            part = clean(part)
            if not part:
                continue
            key = norm(part)
            if key:
                keys.add(key)
            keys.update(BUILDER.strict_identifier_variants(part))
    return {key for key in keys if key}


def expanded_keys(*values):
    keys = strict_keys(*values)
    for value in values:
        if not value:
            continue
        for part in re.split(r"[;,\n]+", str(value)):
            keys.update(BUILDER.identifier_variants(part))
    for aliases in BUILDER.MANUAL_SAMPLE_ALIASES:
        alias_keys = set()
        for alias in aliases:
            alias_keys.update(BUILDER.identifier_variants(alias))
            alias_keys.update(BUILDER.strict_identifier_variants(alias))
        if keys & alias_keys:
            keys.update(alias_keys)
    return {key for key in keys if key}


def excel_serial_date(number):
    try:
        value = float(number)
    except Exception:
        return None
    if not math.isfinite(value) or not 20000 <= value <= 60000:
        return None
    return (datetime(1899, 12, 30) + timedelta(days=value)).date()


def normalize_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)):
        return excel_serial_date(value)
    text = clean(value)
    if not text:
        return None
    serial = excel_serial_date(text)
    if serial:
        return serial
    text = re.sub(r"\s+00:00:00$", "", text)
    text = text.strip(" .")

    year_first = re.fullmatch(r"(\d{4})[./-](\d{1,2})[./-](\d{1,2})", text)
    if year_first:
        year, month, day = map(int, year_first.groups())
        try:
            return date(year, month, day)
        except ValueError:
            return None

    numeric = re.fullmatch(r"(\d{1,2})[./-](\d{1,2})[./-](\d{2}|\d{4})", text)
    if numeric:
        first, second, raw_year = numeric.groups()
        first, second, year = int(first), int(second), int(raw_year)
        if year < 100:
            year += 2000 if year <= 68 else 1900
        # Israeli lab records are day-first unless the values make month-first unavoidable.
        if first > 12:
            day, month = first, second
        elif second > 12:
            month, day = first, second
        else:
            day, month = first, second
        try:
            return date(year, month, day)
        except ValueError:
            return None

    for fmt in ("%d %b %Y", "%d %B %Y", "%b %d %Y", "%B %d %Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def shared_strings(zf):
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    return ["".join(node.text or "" for node in si.findall(f".//{{{NS_MAIN}}}t")) for si in root.findall(f"{{{NS_MAIN}}}si")]


def sheet_paths(zf):
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_by_id = {
        rel.attrib["Id"]: rel.attrib["Target"]
        for rel in rels.findall(f"{{{NS_PKG_REL}}}Relationship")
    }
    paths = []
    for sheet in workbook.findall(f".//{{{NS_MAIN}}}sheet"):
        rel_id = sheet.attrib.get(f"{{{NS_REL}}}id")
        target = rel_by_id.get(rel_id)
        if not target:
            continue
        path = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
        paths.append((sheet.attrib.get("name"), path))
    return paths


def cell_value(cell, strings):
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        return "".join(node.text or "" for node in cell.findall(f".//{{{NS_MAIN}}}t"))
    node = cell.find(f"{{{NS_MAIN}}}v")
    if node is None or node.text is None:
        return None
    if cell_type == "s":
        try:
            return strings[int(node.text)]
        except Exception:
            return None
    try:
        return float(node.text)
    except ValueError:
        return node.text


def inspect_excel_file(path):
    result = {
        "path": str(path),
        "opened": False,
        "raw_measurement": False,
        "detectors": [],
        "error": None,
    }
    try:
        with zipfile.ZipFile(path) as zf:
            strings = shared_strings(zf)
            numeric_count = 0
            formula_count = 0
            text_bits = []
            for _sheet_name, sheet_path in sheet_paths(zf):
                root = ET.fromstring(zf.read(sheet_path))
                for row in root.findall(f".//{{{NS_MAIN}}}row"):
                    row_number = int(row.attrib.get("r", "0") or 0)
                    if row_number > 12:
                        continue
                    for cell in row.findall(f"{{{NS_MAIN}}}c"):
                        value = cell_value(cell, strings)
                        formula = cell.find(f"{{{NS_MAIN}}}f")
                        if formula is not None:
                            formula_count += 1
                        if isinstance(value, (int, float)):
                            numeric_count += 1
                        elif value not in (None, ""):
                            text_bits.append(str(value))
            joined = " ".join(text_bits).lower()
            has_glutaric = "glutaric" in joined or re.search(r"\bga\b", joined) is not None
            has_arabinose = "arabinose" in joined or re.search(r"\barae?\b", joined) is not None
            has_time_current_layout = ("µa" in joined or "ua" in joined) and re.search(r"(^|\s)s($|\s)", joined) is not None
            result["opened"] = True
            result["detectors"] = [name for name, present in (("PA447", has_glutaric), ("araE", has_arabinose)) if present]
            result["raw_measurement"] = bool(
                numeric_count >= 10
                and (has_glutaric or has_arabinose)
                and (has_time_current_layout or formula_count > 0)
            )
            result["numeric_cells_first_12_rows"] = numeric_count
            result["formula_cells_first_12_rows"] = formula_count
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def find_header_row_and_columns(ws):
    for header_row in range(1, min(ws.max_row, 20) + 1):
        headers = [clean(ws.cell(header_row, col).value) for col in range(1, ws.max_column + 1)]
        lowered = [(value or "").lower() for value in headers]
        date_cols = [
            index + 1
            for index, header in enumerate(lowered)
            if header == "date"
            or "sample date" in header
            or "date of sample" in header
            or "תאריך ביקור" in header
            or "תאריך דגימה" in header
        ]
        name_cols = [
            index + 1
            for index, header in enumerate(lowered)
            if "sample name" in header
            or "sample #" in header
            or "sample code" in header
            or header == "sample"
            or "patient number" in header
            or "מספר מטופל" in header
            or header == "name"
            or header == "primary name"
            or header.startswith("secondary")
        ]
        if name_cols and date_cols:
            return header_row, name_cols, date_cols[0]
    return None, [], None


def aliquot_records(path, priority):
    records = []
    errors = []
    if not path.exists():
        return records, [{"file": str(path), "error": "missing"}]
    try:
        workbook = load_workbook(path, data_only=True, read_only=False)
    except Exception as exc:
        return records, [{"file": str(path), "error": f"{type(exc).__name__}: {exc}"}]
    for ws in workbook.worksheets:
        header_row, name_cols, date_col = find_header_row_and_columns(ws)
        if not header_row:
            continue
        for row in range(header_row + 1, ws.max_row + 1):
            names = [clean(ws.cell(row, col).value) for col in name_cols]
            names = [name for name in names if name and name not in {"1", "N/A"}]
            if not names:
                continue
            raw_date = ws.cell(row, date_col).value
            parsed = normalize_date(raw_date)
            if not parsed:
                continue
            record = {
                "file": str(path),
                "priority": priority,
                "sheet": ws.title,
                "row": row,
                "names": names,
                "strict_keys": sorted(strict_keys(*names)),
                "expanded_keys": sorted(expanded_keys(*names)),
                "date": parsed.isoformat(),
                "date_raw": str(raw_date),
            }
            records.append(record)
    workbook.close()
    return records, errors


def choose_date(final_row, records):
    final_strict = set(final_row["strict_keys"])
    final_expanded = set(final_row["expanded_keys"])
    strict_matches = [record for record in records if final_strict & set(record["strict_keys"])]
    matches = strict_matches or [record for record in records if final_expanded & set(record["expanded_keys"])]
    if not matches:
        return None, [], "not found"
    best_priority = min(record["priority"] for record in matches)
    matches = [record for record in matches if record["priority"] == best_priority]
    dates = sorted({record["date"] for record in matches})
    if len(dates) == 1:
        selected = next(record for record in matches if record["date"] == dates[0])
        return dates[0], matches, f"unique date at priority {best_priority}"

    primary_norm = norm(final_row["primary"])
    exact_primary = [record for record in matches if primary_norm and primary_norm in {norm(name) for name in record["names"]}]
    primary_dates = sorted({record["date"] for record in exact_primary})
    if len(primary_dates) == 1:
        selected_date = primary_dates[0]
        return selected_date, exact_primary, f"unique exact-primary date at priority {best_priority}"
    return None, matches, f"ambiguous dates: {dates}"


def analyze_dates():
    source_records = []
    source_errors = []
    for priority, path in enumerate(ALIQUOT_SOURCES):
        records, errors = aliquot_records(path, priority)
        source_records.extend(records)
        source_errors.extend(errors)

    workbook = load_workbook(FINAL, data_only=True, read_only=False)
    ws = workbook["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    final_rows = []
    recovered = []
    unresolved = []
    unparseable_existing = []
    for row in range(2, ws.max_row + 1):
        primary = clean(ws.cell(row, headers["Primary name"]).value)
        secondary = clean(ws.cell(row, headers["Secondary / other name"]).value)
        raw_date = ws.cell(row, headers["Sample date"]).value
        parsed = normalize_date(raw_date)
        record = {
            "row": row,
            "primary": primary,
            "secondary": secondary,
            "strict_keys": sorted(strict_keys(primary, secondary)),
            "expanded_keys": sorted(expanded_keys(primary, secondary)),
            "original_date": str(raw_date) if raw_date not in (None, "") else None,
            "date": parsed.isoformat() if parsed else None,
            "date_source": "Final" if parsed else None,
        }
        if raw_date not in (None, "") and not parsed:
            unparseable_existing.append({"row": row, "primary": primary, "value": str(raw_date)})
        if not parsed:
            selected_date, matches, reason = choose_date(record, source_records)
            if selected_date:
                record["date"] = selected_date
                source = next(match for match in matches if match["date"] == selected_date)
                record["date_source"] = f"{source['file']} | {source['sheet']}!row {source['row']}"
                recovered.append(
                    {
                        "row": row,
                        "primary": primary,
                        "secondary": secondary,
                        "date": selected_date,
                        "source": record["date_source"],
                        "reason": reason,
                    }
                )
            else:
                unresolved.append(
                    {
                        "row": row,
                        "primary": primary,
                        "secondary": secondary,
                        "reason": reason,
                        "candidate_dates": sorted({match["date"] for match in matches}),
                        "candidate_sources": [
                            f"{match['file']} | {match['sheet']}!row {match['row']}"
                            for match in matches[:10]
                        ],
                    }
                )
        if record["date"]:
            year = int(record["date"][:4])
            record["split"] = "Before 2021" if year < 2021 else "2021 onward"
        else:
            record["split"] = None
        final_rows.append(record)
    workbook.close()
    return {
        "aliquot_source_files": [str(path) for path in ALIQUOT_SOURCES],
        "aliquot_source_records": len(source_records),
        "aliquot_source_errors": source_errors,
        "recovered_dates": recovered,
        "unresolved_dates": unresolved,
        "unparseable_existing_dates": unparseable_existing,
        "rows": final_rows,
    }


def main():
    paths = sorted(path for path in ROOT.rglob("*.xlsx") if not path.name.startswith("~$"))
    inventory = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(inspect_excel_file, path): path for path in paths}
        for index, future in enumerate(as_completed(futures), start=1):
            inventory.append(future.result())
            if index % 150 == 0:
                print(f"inspected {index}/{len(paths)}", flush=True)

    opened = [item for item in inventory if item["opened"]]
    raw_files = [item for item in inventory if item["raw_measurement"]]
    errors = [item for item in inventory if not item["opened"]]
    detector_counts = defaultdict(int)
    for item in raw_files:
        for detector in item["detectors"]:
            detector_counts[detector] += 1

    dates = analyze_dates()
    report = {
        "root": str(ROOT),
        "excel_files_detected": len(paths),
        "excel_files_opened": len(opened),
        "excel_open_errors": errors,
        "raw_measurement_files_detected": len(raw_files),
        "raw_measurement_files_opened": sum(1 for item in raw_files if item["opened"]),
        "raw_measurement_detector_counts": dict(detector_counts),
        "raw_measurement_files": raw_files,
        "dates": dates,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        "excel_files_detected": report["excel_files_detected"],
        "excel_files_opened": report["excel_files_opened"],
        "excel_open_error_count": len(report["excel_open_errors"]),
        "raw_measurement_files_detected": report["raw_measurement_files_detected"],
        "raw_measurement_files_opened": report["raw_measurement_files_opened"],
        "raw_measurement_detector_counts": report["raw_measurement_detector_counts"],
        "date_rows": len(dates["rows"]),
        "dates_recovered": len(dates["recovered_dates"]),
        "dates_unresolved": len(dates["unresolved_dates"]),
        "existing_dates_unparseable": len(dates["unparseable_existing_dates"]),
        "before_2021_rows": sum(row["split"] == "Before 2021" for row in dates["rows"]),
        "on_or_after_2021_rows": sum(row["split"] == "2021 onward" for row in dates["rows"]),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    if dates["unresolved_dates"]:
        print(json.dumps({"unresolved_dates": dates["unresolved_dates"]}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
