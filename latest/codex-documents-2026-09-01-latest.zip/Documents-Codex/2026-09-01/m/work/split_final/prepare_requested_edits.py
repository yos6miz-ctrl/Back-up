from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import re
import sys

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\split_final")
SOURCE = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
TRACE = WORK / "raw_measurement_coverage_enhanced.json"
DATES = WORK / "dates.json"
OUT = WORK / "requested_edit_ledger.json"
LEGACY_CODE = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
RAW_AUDIT_SCRIPT = LEGACY_CODE / "audit_final_measurements_without_source.py"
EXPAND_SCRIPT = LEGACY_CODE / "expand_measurement_columns_and_show_all.py"
AUTHORITATIVE_ROOTS = [
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\p447\447- new"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\p447\447-old"),
    Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\KPS new detectors\araE"),
]


sys.path.insert(0, str(LEGACY_CODE))


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


raw_audit = load_module("raw_audit_for_edit", RAW_AUDIT_SCRIPT)
expand = load_module("expand_for_edit", EXPAND_SCRIPT)
import import_2026_measurements as importer


def is_numeric(value):
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def source_parts(value):
    text = str(value or "")
    result = {"PA447": [], "araE": []}
    for detector in result:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if match:
            result[detector] = [part.strip() for part in match.group(1).split(",") if part.strip()]
    return result


def clean_and_append_sources(value, additions, row_values, detector_cols):
    parts = source_parts(value)
    for detector in ("PA447", "araE"):
        parts[detector] = [
            file_name
            for file_name in parts[detector]
            if file_name.lower() != "unknowns trial 6.26.xlsx"
        ]
        if not any(is_numeric(row_values[col - 1]) for col in detector_cols[detector]):
            parts[detector] = []
        for file_name in additions.get(detector, []):
            if file_name not in parts[detector]:
                parts[detector].append(file_name)
    segments = [f"{detector}: {', '.join(parts[detector])}" for detector in ("PA447", "araE") if parts[detector]]
    return "; ".join(segments)


def authoritative_file_index():
    index = defaultdict(list)
    for priority, root in enumerate(AUTHORITATIVE_ROOTS):
        for path in root.rglob("*.xlsx"):
            if not path.name.startswith("~$"):
                index[path.name].append((priority, path))
    return index


def main():
    trace = json.loads(TRACE.read_text(encoding="utf-8"))
    dates = json.loads(DATES.read_text(encoding="utf-8"))
    date_by_row = {item["row"]: item for item in dates["rows"]}

    remove_entries = []
    citation_entries = []
    for item in trace["classified"]:
        if item["category"] == "reproducible_average_of_raw_values":
            remove_entries.append({**item, "removal_reason": "reproducible average removed by user"})
        elif item["category"] == "raw_sample_detector_exists_but_value_not_reproduced" and not item["legacy_marker"]:
            remove_entries.append({**item, "removal_reason": "final value does not reproduce from normalized raw data"})
        elif item["category"] == "no_raw_record_for_sample_detector":
            remove_entries.append({**item, "removal_reason": "no normalized raw record found"})
        if item["category"] == "exact_raw_value_in_unlisted_file":
            citation_entries.append(item)

    removal_counts = Counter(item["removal_reason"] for item in remove_entries)
    assert len(remove_entries) == 101, len(remove_entries)
    assert removal_counts["reproducible average removed by user"] == 21
    assert removal_counts["final value does not reproduce from normalized raw data"] == 73
    assert removal_counts["no normalized raw record found"] == 7
    assert len(citation_entries) == 136

    authoritative_index = authoritative_file_index()
    needed_names = {
        candidate["source_file"]
        for item in citation_entries
        for candidate in item["exact_anywhere"]
        if candidate["source_file"] in authoritative_index
    }
    authoritative_records = []
    opened_authoritative_paths = set()
    for file_name in sorted(needed_names):
        for _priority, path in sorted(authoritative_index[file_name], key=lambda pair: (pair[0], str(pair[1]).lower())):
            key = str(path).lower()
            if key in opened_authoritative_paths:
                continue
            opened_authoritative_paths.add(key)
            authoritative_records.extend(raw_audit.extract_formula_records(path))

    records_by_detector_file = defaultdict(list)
    for record in authoritative_records:
        records_by_detector_file[(record["detector"], record["source_file"])].append(record)

    citation_additions = defaultdict(lambda: defaultdict(list))
    citation_proofs = []
    for item in citation_entries:
        item_keys = set(item["keys"])
        matches = []
        candidate_names = {candidate["source_file"] for candidate in item["exact_anywhere"]}
        for file_name in sorted(candidate_names):
            for record in records_by_detector_file.get((item["detector"], file_name), []):
                if item_keys & set(record["keys"]) and abs(float(record["value"]) - float(item["value"])) <= 5e-7:
                    matches.append(record)
        if not matches:
            raise AssertionError(f"No authoritative raw proof for {item['cell']} {item['primary']}")
        selected_names = []
        for record in sorted(matches, key=lambda record: (record["source_file"].lower(), record["path"].lower())):
            if record["source_file"] not in selected_names:
                selected_names.append(record["source_file"])
        for file_name in selected_names:
            if file_name not in citation_additions[item["row"]][item["detector"]]:
                citation_additions[item["row"]][item["detector"]].append(file_name)
        citation_proofs.append(
            {
                "row": item["row"],
                "cell": item["cell"],
                "primary": item["primary"],
                "detector": item["detector"],
                "value": item["value"],
                "source_files_added": selected_names,
                "proof_cells": [
                    {"file": record["source_file"], "path": record["path"], "cell": record["source_cell"]}
                    for record in matches[:10]
                ],
            }
        )

    training, feature_cols, _fill_values, _sources = importer.classifier.load_training()
    bars = importer.classifier.learn_detector_bars(training, feature_cols)

    workbook = load_workbook(SOURCE, data_only=True, read_only=False)
    ws = workbook["Final"]
    headers = {ws.cell(1, col).value: col for col in range(1, ws.max_column + 1)}
    header_values = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
    detector_cols = {
        "PA447": [headers[f"PA447 measurement {index}"] for index in range(1, 9)],
        "araE": [headers[f"araE measurement {index}"] for index in range(1, 7)],
    }
    decision_cols = {"PA447": headers["PA447 decision"], "araE": headers["araE decision"]}
    removed_cells_by_row = defaultdict(set)
    remove_details_by_row = defaultdict(list)
    for item in remove_entries:
        col_letters = re.match(r"([A-Z]+)", item["cell"]).group(1)
        col = 0
        for char in col_letters:
            col = col * 26 + ord(char) - 64
        removed_cells_by_row[item["row"]].add(col)
        remove_details_by_row[item["row"]].append(
            {
                "cell": item["cell"],
                "detector": item["detector"],
                "value": item["value"],
                "reason": item["removal_reason"],
            }
        )

    original_decision_mismatches = []
    for row in range(2, ws.max_row + 1):
        status = str(ws.cell(row, headers["Measurement status"]).value or "").strip()
        if status in {"missing", "לא נבדק", "old metering system"}:
            continue
        for detector in ("PA447", "araE"):
            values = [ws.cell(row, col).value if is_numeric(ws.cell(row, col).value) else None for col in detector_cols[detector]]
            result = expand.detector_consensus_with_used(values, bars[detector]["bar"])
            existing = ws.cell(row, decision_cols[detector]).value
            if result["decision"] != existing:
                original_decision_mismatches.append(
                    {"row": row, "primary": ws.cell(row, 1).value, "detector": detector, "existing": existing, "recomputed": result["decision"]}
                )

    rows = []
    decision_changes = []
    classification_changes = []
    rows_without_measurements_after = []
    removed_numeric_count = 0
    for row in range(2, ws.max_row + 1):
        values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
        original_values = list(values)
        detector_results = {}
        if row in removed_cells_by_row:
            for col in removed_cells_by_row[row]:
                if is_numeric(values[col - 1]):
                    removed_numeric_count += 1
                values[col - 1] = None

            for detector in ("PA447", "araE"):
                cols = detector_cols[detector]
                compacted = [values[col - 1] for col in cols if is_numeric(values[col - 1])]
                compacted += [None] * (len(cols) - len(compacted))
                for col, value in zip(cols, compacted):
                    values[col - 1] = value
                result = expand.detector_consensus_with_used(compacted, bars[detector]["bar"])
                detector_results[detector] = result
                old_decision = original_values[decision_cols[detector] - 1]
                values[decision_cols[detector] - 1] = result["decision"]
                if old_decision != result["decision"]:
                    decision_changes.append(
                        {
                            "row": row,
                            "primary": values[0],
                            "detector": detector,
                            "old": old_decision,
                            "new": result["decision"],
                        }
                    )

            old_final = original_values[headers["Final classification / decision"] - 1]
            calls = [detector_results[detector]["call"] for detector in ("PA447", "araE") if detector_results[detector]["call"]]
            new_final = importer.classifier.final_classification(calls) if calls else "missing"
            values[headers["Final classification / decision"] - 1] = new_final
            if old_final != new_final:
                classification_changes.append(
                    {"row": row, "primary": values[0], "old": old_final, "new": new_final}
                )

        additions = citation_additions.get(row, {})
        values[headers["Measurement/source file"] - 1] = clean_and_append_sources(
            values[headers["Measurement/source file"] - 1], additions, values, detector_cols
        )

        date_record = date_by_row[row]
        values[headers["Sample date"] - 1] = date_record["date"]
        split = "Before 2021" if date_record["date"] is None or int(date_record["date"][:4]) < 2021 else "2021 onward"
        if not any(is_numeric(values[col - 1]) for detector in detector_cols for col in detector_cols[detector]):
            rows_without_measurements_after.append({"row": row, "primary": values[0], "status": values[2]})

        rows.append(
            {
                "source_row": row,
                "primary": values[0],
                "split": split,
                "date": date_record["date"],
                "values": values,
                "removed": remove_details_by_row.get(row, []),
                "detector_results": detector_results,
                "citation_additions": additions,
            }
        )

    workbook.close()
    assert removed_numeric_count == 101, removed_numeric_count
    assert sum(item["split"] == "Before 2021" for item in rows) == 188
    assert sum(item["split"] == "2021 onward" for item in rows) == 158

    result = {
        "source": str(SOURCE),
        "headers": header_values,
        "authoritative_roots": [str(path) for path in AUTHORITATIVE_ROOTS],
        "authoritative_files_opened": len(opened_authoritative_paths),
        "authoritative_raw_records_extracted": len(authoritative_records),
        "removal_counts": dict(removal_counts),
        "removed_measurement_cells": len(remove_entries),
        "citation_measurements_corrected": len(citation_entries),
        "citation_rows_corrected": len(citation_additions),
        "citation_proofs": citation_proofs,
        "original_decision_mismatch_count": len(original_decision_mismatches),
        "original_decision_mismatches": original_decision_mismatches,
        "decision_changes": decision_changes,
        "classification_changes": classification_changes,
        "rows_without_measurements_after": rows_without_measurements_after,
        "before_2021_rows_including_undated": 188,
        "onward_2021_rows": 158,
        "undated_rows_moved_to_before_2021": [
            {"row": item["source_row"], "primary": item["primary"]}
            for item in rows if item["date"] is None
        ],
        "rows": rows,
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    summary = {key: value for key, value in result.items() if key not in {"headers", "citation_proofs", "original_decision_mismatches", "decision_changes", "classification_changes", "rows_without_measurements_after", "rows"}}
    summary["decision_change_count"] = len(decision_changes)
    summary["classification_change_count"] = len(classification_changes)
    summary["rows_without_measurements_after_count"] = len(rows_without_measurements_after)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(json.dumps({"original_decision_mismatches": original_decision_mismatches[:30]}, ensure_ascii=False, indent=2))
    print(json.dumps({"decision_changes": decision_changes, "classification_changes": classification_changes}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
