from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


BASE = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
MEDIA = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\docx_media_extract2")
OUT = BASE / "דוח אבני דרך - דירוג פרומוטורים משובטים - סופי משולב.docx"

LRM = "\u200e"


def ltr(text):
    return f"{LRM}{text}{LRM}"


def set_bidi(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def set_run(run, size=10.5, bold=False, color=None):
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def add_p(doc, text="", size=10.5, bold=False, color=None, after=5):
    p = doc.add_paragraph()
    set_bidi(p)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(text)
    set_run(r, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level=1):
    size = 15 if level == 1 else 12.5
    before = 10 if level == 1 else 6
    p = add_p(doc, text, size=size, bold=True, color=(31, 78, 121), after=4)
    p.paragraph_format.space_before = Pt(before)
    return p


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell(cell, text, header=False):
    cell.text = ""
    p = cell.paragraphs[0]
    set_bidi(p)
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(str(text))
    set_run(r, size=9.0 if not header else 9.3, bold=header)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if header:
        shade_cell(cell, "D9EAF7")


def set_table_rtl(table):
    tbl_pr = table._tbl.tblPr
    bidi = tbl_pr.find(qn("w:bidiVisual"))
    if bidi is None:
        bidi = OxmlElement("w:bidiVisual")
        tbl_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_table_rtl(table)
    for i, header in enumerate(headers):
        set_cell(table.rows[0].cells[i], header, header=True)
    for row_values in rows:
        row = table.add_row()
        for i, value in enumerate(row_values):
            set_cell(row.cells[i], value)
    doc.add_paragraph()
    return table


def add_image(doc, path, width_cm, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run()
    r.add_picture(str(path), width=Cm(width_cm))
    cap = add_p(doc, caption, size=9.2, color=(80, 80, 80), after=8)
    return cap


def main():
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Cm(1.7)
    section.bottom_margin = Cm(1.7)
    section.left_margin = Cm(1.8)
    section.right_margin = Cm(1.8)

    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    styles["Normal"].font.size = Pt(10.5)

    header_p = section.header.paragraphs[0]
    set_bidi(header_p)
    header_p.text = "דוח אבני דרך | אדמה ירוקה"
    for r in header_p.runs:
        set_run(r, size=9.5, color=(90, 90, 90))

    footer_p = section.footer.paragraphs[0]
    set_bidi(footer_p)
    footer_p.text = "מעבדת בנין, בר-אילן"
    for r in footer_p.runs:
        set_run(r, size=9.5, color=(90, 90, 90))

    title = add_p(doc, "דוח אבני דרך", size=18, bold=True, after=2)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle = add_p(doc, "בנין - דירוג ראשוני של פרומוטורים משובטים", size=12.5, bold=True, color=(80, 80, 80), after=10)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_table(
        doc,
        ["שדה", "פרטים"],
        [
            ["פרויקט", "אדמה ירוקה - רכיב החישה / דטקטורים"],
            ["אבן דרך", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי ו/או פעילות ביולוגית"],
            ["תאריך סטטוס", "אוגוסט 2026"],
            [
                "מקורות נתונים",
                f"{ltr('yossi_20260610.xlsx')}; {ltr('YOSSI P starv 17.8.26.xlsx')}; {ltr('YOSSI P starv 18.8.xlsx')}; {ltr('YOSSI P starv 18.8 NEW.xlsx')}",
            ],
        ],
    )

    add_table(
        doc,
        ["תקציר מנהלים"],
        [
            [
                "קיימות תוצאות כמותיות לשלושה פרומוטורים פעילים שנכנסו לדירוג."
            ],
            [
                f"חנקן: {ltr('glnK')} ביחס אות/רעש {ltr('17.1:1')}; ברזל: {ltr('pvdA')} ביחס אות/רעש {ltr('8.7:1')}; פוספט: {ltr('uxpB')} ביחס אות/רעש {ltr('3.8:1')} ומעלה בתנאי {ltr('100 uM P')}."
            ],
            [
                f"בסקר הפוספט נבדקו גם {ltr('PP_2656')}, {ltr('PP_5329')} ו-{ltr('uxpA')}; הם לא סיפקו תגובה ספציפית מספקת לדירוג."
            ],
            [
                "דטקטור האלקנים עדיין נמצא בשלב ייצוב הקונסטרקט ולכן טרם נכלל בדירוג הכמותי."
            ],
            [
                "מתוך שני דטקטורים המיועדים להעברה לשלב הבא, דטקטור אחד כבר מוכן וממתין להעברה."
            ]
        ],
    )

    add_heading(doc, "1. הגדרת אבן הדרך והמדדים")
    add_p(
        doc,
        "אבן הדרך עוסקת בדירוג ראשוני של פרומוטורים משובטים בתנאי שייק פלאסק, באמצעות ביטוי אנזימטי ו/או פעילות ביולוגית, לצורך הערכה כמותית ודירוג עוצמת הפרומוטור.",
    )
    add_p(doc, "מדד כמותי 1: לכל הפחות 80% מהקונסטרוקטים יציגו פעילות נמדדת.")
    add_p(doc, "מדד כמותי 2: דירוג ברור של לפחות 4 פרומוטורים.")
    add_p(doc, f"מדד כמותי 3: עמידה בסף {ltr('3:1')} ביחס אות/רעש עבור כל פרומוטור מדורג.")

    add_heading(doc, "2. סטטוס עמידה במדדי אבן הדרך")
    add_table(
        doc,
        ["מדד אבן הדרך", "תוצאה", "סטטוס"],
        [
            [
                "פעילות נמדדת בלפחות 80% מהקונסטרוקטים",
                f"שלושת הקונסטרוקטים הפעילים שהגיעו למדידה כמותית ({ltr('pvdA')}, {ltr('glnK')}, {ltr('uxpB')}) הציגו פעילות מדידה ברורה. מועמדי סקר שלא עברו סינון מופיעים בנפרד.",
                "הושג עבור הקונסטרוקטים הפעילים שנמדדו",
            ],
            [
                "דירוג ברור של לפחות 4 פרומוטורים",
                f"קיים דירוג כמותי לשלושה פרומוטורים פעילים. דטקטור אחד מתוך שניים מוכן וממתין להעברה; דטקטור האלקנים עדיין אינו יציב ולכן טרם נוסף לדירוג.",
                "חלקי; נדרש פרומוטור פעיל נוסף",
            ],
            [
                f"סף יחס אות/רעש: {ltr('3:1')}",
                f"{ltr('glnK')}: {ltr('17.1:1')}; {ltr('pvdA')}: {ltr('8.7:1')}; {ltr('uxpB')}: {ltr('3.8:1')} ומעלה בתנאי {ltr('100 uM P')}.",
                "הושג עבור שלושת הפרומוטורים הפעילים",
            ],
        ],
    )

    add_heading(doc, "3. תוצאות כמותיות זמינות")
    add_p(
        doc,
        "המדידות נותחו על בסיס אות מנורמל לאחר חיסור רקע ובקרה רלוונטית. יחס אות/רעש חושב כיחס בין אות בתנאי השראה/מחסור לבין אות בסיס באותה סדרת מדידה.",
    )
    add_table(
        doc,
        ["פרומוטור / דטקטור", "תנאי בסיס", "אות בסיס", "תנאי השראה/מחסור", "אות שיא", "יחס אות/רעש", "מסקנה"],
        [
            [ltr("glnK"), ltr("10 mM N"), "11,819", ltr("2 mM N"), "202,038", ltr("17.1:1"), "פעיל; עומד במדד"],
            [ltr("pvdA"), ltr("20 mM Fe"), "28,182", ltr("-Fe"), "244,316", ltr("8.7:1"), "פעיל; עומד במדד"],
            [ltr("uxpB"), f"מדיום מלא: {ltr('M9')} עם {ltr('34 mM P')}", "~16,000", f"ריכוז פוספט: {ltr('100 uM P')}", ">60,000", f"{ltr('3.8:1')} ומעלה", "פעיל; עומד במדד"],
            ["סקר פוספט", "לא רלוונטי", "לא נקבע", f"{ltr('PP_2656')}, {ltr('PP_5329')}, {ltr('uxpA')}", "לא נקבע", "לא נקבע", "לא דורגו; ללא תגובה ספציפית מספקת"],
            ["אלקנים", "לא רלוונטי", "לא נקבע", "קונסטרקט לא יציב", "לא נקבע", "לא נקבע", "טרם דורג"],
        ],
    )

    add_heading(doc, "4. דירוג ראשוני של הפרומוטורים הפעילים")
    add_table(
        doc,
        ["דירוג", "פרומוטור / יעד חישה", "יחס אות/רעש", "פירוש"],
        [
            ["1", f"{ltr('glnK')} / חנקן", ltr("17.1:1"), "תגובה חזקה וברורה עם ירידת זמינות החנקן."],
            ["2", f"{ltr('pvdA')} / ברזל", ltr("8.7:1"), "תגובה מדורגת עם ירידת זמינות הברזל."],
            ["3", f"{ltr('uxpB')} / פוספט", f"{ltr('3.8:1')} ומעלה", f"תגובה כמותית ברורה בריכוז {ltr('100 uM P')}."],
        ],
    )

    add_heading(doc, "5. פירוט תוצאות לפי דטקטור")
    add_heading(doc, f"5.1 {ltr('pvdA')} - תגובה להרעבה לברזל", level=2)
    add_p(
        doc,
        f"בדטקטור הברזל נמדדה תגובת מינון ברורה. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מ-28,182 בתנאי ברזל גבוה ל-244,316 ללא ברזל. יחס האות/רעש הוא {ltr('8.7:1')}. הפרומוטור המדורג: {ltr('pvdA')}.",
    )
    add_heading(doc, f"5.2 {ltr('glnK')} - תגובה להרעבה לחנקן", level=2)
    add_p(
        doc,
        f"בדטקטור החנקן נמדדה תגובה חזקה לירידת זמינות חנקן. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מ-11,819 בתנאי חנקן גבוה ל-202,038 בתנאי חנקן נמוך. יחס האות/רעש הוא {ltr('17.1:1')}. הפרומוטור המדורג: {ltr('glnK')}.",
    )
    add_heading(doc, f"5.3 {ltr('uxpB')} - תגובה להרעבה לפוספט", level=2)
    add_p(
        doc,
        f"בדטקטור הפוספט נמדדה תגובה כמותית לאחר הורדת ריכוז הפוספט. סדרת המדידה כללה מדיום מלא ({ltr('M9')}, {ltr('34 mM P')}) וכן {ltr('1 mM P')}, {ltr('500 uM P')}, {ltr('250 uM P')} ו-{ltr('100 uM P')}. נקודת השיא המוצגת בדוח היא {ltr('100 uM P')}: אות בסיס של כ-16,000 לעומת פיק מעל 60,000. יחס האות/רעש הוא {ltr('3.8:1')} ומעלה. הפרומוטור המדורג: {ltr('uxpB')}.",
    )
    add_p(
        doc,
        f"בסקר הפוספט נבחנו ארבעה מועמדים. שלושה מועמדים לא סיפקו תגובה ספציפית מספקת לדירוג: {ltr('PP_2656')}, {ltr('PP_5329')} ו-{ltr('uxpA')}. המועמד הפעיל בדוח זה הוא {ltr('uxpB')}.",
    )
    add_heading(doc, "5.4 אלקנים", level=2)
    add_p(
        doc,
        "דטקטור האלקנים נמצא עדיין בשלב בנייה וייצוב. מאחר שהקונסטרקט עדיין אינו יציב, אין בשלב זה מדידה כמותית תקפה שמאפשרת דירוג מול הפרומוטורים הפעילים.",
    )

    add_heading(doc, "6. נתוני 13.3 שעות - טבלת סיכום")
    add_table(
        doc,
        ["דטקטור", "תנאי", "ממוצע ביטוי מנורמל ב-13.3 שעות", "SD", "n"],
        [
            [ltr("pvdA"), ltr("pvdA 20 mM Fe"), "28,182", "4,876", "6"],
            [ltr("pvdA"), ltr("pvdA 10 mM Fe"), "52,434", "4,517", "6"],
            [ltr("pvdA"), ltr("pvdA 5 mM Fe"), "118,102", "11,172", "6"],
            [ltr("pvdA"), ltr("pvdA 2.5 mM Fe"), "179,519", "16,418", "6"],
            [ltr("pvdA"), ltr("pvdA -Fe"), "244,316", "6,774", "6"],
            [ltr("glnK"), ltr("glnK 10 mM N"), "11,819", "1,546", "6"],
            [ltr("glnK"), ltr("glnK 8 mM N"), "15,387", "1,427", "6"],
            [ltr("glnK"), ltr("glnK 6 mM N"), "71,645", "6,172", "6"],
            [ltr("glnK"), ltr("glnK 4 mM N"), "127,657", "13,806", "6"],
            [ltr("glnK"), ltr("glnK 2 mM N"), "202,038", "8,603", "6"],
            [ltr("uxpB"), f"{ltr('M9')} מלא, {ltr('34 mM P')}", "~16,000", "לא חושב", "6"],
            [ltr("uxpB"), ltr("100 uM P"), ">60,000", "לא חושב", "6"],
        ],
    )

    add_heading(doc, "7. גרפים תומכים")
    add_image(doc, MEDIA / "image1.png", 15.2, f"איור 1. תגובת {ltr('pvdA')} לתנאי ברזל לאורך זמן. האות עולה עם ירידת זמינות הברזל.")
    add_image(doc, MEDIA / "image2.png", 15.2, f"איור 2. תגובת {ltr('glnK')} לתנאי חנקן לאורך זמן. האות עולה עם ירידת ריכוז החנקן.")
    add_image(doc, MEDIA / "image3.png", 15.2, f"איור 3. השוואת ביטוי מנורמל בנקודת זמן 13.3 שעות עבור תנאי {ltr('pvdA')} ו-{ltr('glnK')}.")
    add_image(doc, MEDIA / "image4.png", 15.8, f"איור 4. תגובת {ltr('uxpB')} בתנאי פוספט שונים: {ltr('M9')} מלא, {ltr('1 mM P')}, {ltr('500 uM P')}, {ltr('250 uM P')} ו-{ltr('100 uM P')}. בעקומת הזמן מתקבל ב-{ltr('100 uM P')} פיק מעל 60,000 ביחס לאות בסיס של כ-16,000.")

    add_heading(doc, "8. פערים ותוכנית המשך")
    add_p(doc, "להמשיך ייצוב ובדיקת קונסטרקט דטקטור האלקנים כדי לאפשר מדידה כמותית ודירוג.")
    add_p(doc, "לתאם את העברת הדטקטור המוכן לשלב הבא; בשלב זה דטקטור אחד מתוך שניים מוכן וממתין להעברה.")
    add_p(doc, "להרחיב את הדירוג הכמותי לפרומוטור פעיל נוסף לאחר השלמת ייצוב מערכת האלקנים או בחירת מועמד חלופי.")
    add_p(doc, "לאמת את מדד 80% פעילות נמדדת לאחר שכל הקונסטרוקטים המתוכננים יעברו מדידה באותו פורמט.")
    add_p(doc, "לשמור הפרדה בדיווח בין תוצאות GFP/פעילות ביולוגית קיימות לבין תוצאות לוציפראז לאחר העברה לראמז.")

    add_heading(doc, "9. מסקנה")
    add_p(
        doc,
        f"הנתונים תומכים בהתקדמות משמעותית באבן הדרך: {ltr('glnK')}, {ltr('pvdA')} ו-{ltr('uxpB')} מציגים פעילות ביולוגית נמדדת, תגובת מינון ברורה ויחס אות/רעש גבוה מהסף הנדרש. "
        "הדוח כולל כעת דירוג כמותי לשלושה פרומוטורים פעילים בשלושה צירי חישה מרכזיים: חנקן, ברזל ופוספט. השלמת הדירוג לארבעה פרומוטורים תלויה בייצוב דטקטור האלקנים או בבחירת מועמד נוסף.",
    )

    add_heading(doc, "נספח: מקורות נתונים והנחות עיבוד")
    add_p(
        doc,
        f"מקורות: {ltr('yossi_20260610.xlsx')}, גיליונות {ltr('Averages')} ו-{ltr('Charts')}; קובצי {ltr('YOSSI P starv 17.8.26.xlsx')}, {ltr('YOSSI P starv 18.8.xlsx')} ו-{ltr('YOSSI P starv 18.8 NEW.xlsx')}; קובצי הגרפים שיוצאו מהגיליונות; ועדכוני סטטוס מהמעבדה.",
    )
    add_p(
        doc,
        "הנחת עיבוד: יחס אות/רעש חושב כאות ממוצע בתנאי אינדוקציה/מחסור החזק ביותר חלקי אות ממוצע בתנאי בסיס מתאים באותה סדרת מדידה. בקרות הדטקטור שימשו לנרמול וחיסור רקע לפי תיעוד קובצי האקסל.",
    )

    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
