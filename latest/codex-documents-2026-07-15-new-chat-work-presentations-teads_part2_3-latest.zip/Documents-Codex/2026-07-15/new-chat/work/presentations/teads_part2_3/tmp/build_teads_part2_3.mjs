import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const FINAL_PPTX = String.raw`C:\Users\Popovtzer lab\.codex\Teads\Teads_Part_2_3_Executive_Presentation_20min.pptx`;
const PREVIEW_DIR = path.join(__dirname, "preview");
const LAYOUT_DIR = path.join(__dirname, "layout");
const HERO_PATH = path.join(__dirname, "assets", "teads-data-stream-hero.png");

const W = 1280;
const H = 720;
const M = 64;
const NAVY = "#08132D";
const NAVY_2 = "#0E1A3D";
const INK = "#11182E";
const MUTED = "#667085";
const BLUE = "#2B6FF2";
const BLUE_2 = "#5B8DF6";
const BLUE_PALE = "#EAF1FF";
const TEAL = "#159A92";
const TEAL_PALE = "#E6F6F3";
const CORAL = "#F86F72";
const CORAL_PALE = "#FFF0EF";
const AMBER = "#E5A12B";
const WHITE = "#FFFFFF";
const PAPER = "#F7F9FC";
const GRID = "#D8DEEA";
const SOFT = "#EEF2F7";

const SOURCE_DOC = String.raw`C:\Users\Popovtzer lab\.codex\Teads\Teads_TA_Interview_Assignment edited moran - clean - final English.docx`;
const URL_ROLE = "https://job-boards.eu.greenhouse.io/teads1/jobs/4924757101";
const URL_ENGINEERING = "https://engineering.teads.com/join-us/";
const URL_ANNUAL = "https://investors.teads.com/static-files/9819c719-65c9-46f0-b770-a9257060fcfb";
const URL_REBRAND = "https://investors.teads.com/news-releases/news-release-details/outbrain-completes-change-corporate-name-teads";
const URL_MERGER = "https://www.teads.com/blog/outbrain-completes-the-acquisition-of-teads/3145/";
const URL_GEM = "https://lp.gem.com/rs/972-IVV-330/images/2025%20Recruiting%20Benchmarks%20-%20Gem.pdf";
const URL_GLASSDOOR = "https://www.glassdoor.co.uk/Reviews/Teads-Reviews-E929611.htm";
const URL_AWSUG = "https://awsug.co.il/";
const URL_DEVOPSDAYS = "https://il.linkedin.com/company/devopsdays-tel-aviv";

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

async function readBytes(filePath) {
  const bytes = await fs.readFile(filePath);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

function addRect(slide, x, y, w, h, fill, radius = 0, lineFill = fill, lineWidth = 0, name) {
  return slide.shapes.add({
    geometry: radius ? "roundRect" : "rect",
    name,
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: lineFill, width: lineWidth },
    ...(radius ? { borderRadius: radius } : {}),
  });
}

function addLine(slide, x, y, w, h, color = GRID, width = 1, name) {
  return slide.shapes.add({
    geometry: "line",
    name,
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: color, width },
  });
}

function addText(slide, text, x, y, w, h, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name: opts.name,
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    fontSize: opts.size ?? 22,
    bold: opts.bold ?? false,
    color: opts.color ?? INK,
    alignment: opts.align ?? "left",
    ...(opts.italic ? { italic: true } : {}),
  };
  return shape;
}

function addBullet(slide, text, x, y, w, accent = BLUE, size = 21) {
  addRect(slide, x, y + 8, 9, 9, accent, 5);
  addText(slide, text, x + 22, y, w - 22, 46, { size, color: INK });
}

function addHeader(slide, section, title, accent = BLUE, dark = false, subtitle = "") {
  addText(slide, section, M, 34, 330, 22, {
    size: 15,
    bold: true,
    color: accent,
    name: "section-eyebrow",
  });
  addText(slide, title, M, 70, 1152, 64, {
    size: 46,
    bold: true,
    color: dark ? WHITE : INK,
    name: "slide-title",
  });
  addRect(slide, M, 142, 72, 4, accent, 2);
  if (subtitle) {
    addText(slide, subtitle, M + 92, 132, 1056, 30, {
      size: 18,
      color: dark ? "#C5CEE0" : MUTED,
      name: "slide-subtitle",
    });
  }
}

function addFooter(slide, number, dark = false, source = "Source: assignment model • illustrative target state") {
  addLine(slide, M, 679, W - 2 * M, 0, dark ? "#24345D" : GRID, 1);
  addText(slide, source, M, 688, 990, 20, {
    size: 11,
    color: dark ? "#93A2C6" : MUTED,
    name: "visible-source",
  });
  addText(slide, String(number).padStart(2, "0"), 1170, 686, 45, 20, {
    size: 12,
    bold: true,
    color: dark ? "#93A2C6" : MUTED,
    align: "right",
    name: "slide-number",
  });
}

function setNotes(slide, timing, talkTrack, sources) {
  const sourceBlock = sources.map((s) => `- ${s}`).join("\n");
  slide.speakerNotes.textFrame.setText(
    `[Timing] ${timing}\n\n[Talk track]\n${talkTrack}\n\n[Sources]\n${sourceBlock}`
  );
  slide.speakerNotes.setVisible(true);
}

function addMetric(slide, value, label, x, y, w, color = BLUE, context = "", labelColor = INK, contextColor = MUTED) {
  addText(slide, value, x, y, w, 72, { size: 66, bold: true, color, align: "left" });
  addText(slide, label, x, y + 72, w, 28, { size: 18, bold: true, color: labelColor });
  if (context) {
    addText(slide, context, x, y + 102, w, 34, { size: 15, color: contextColor });
  }
}

function addProgressBar(slide, label, forecast, target, x, y, w, color, status, action) {
  addText(slide, label, x, y, 260, 34, { size: 22, bold: true, color: INK });
  addText(slide, `${forecast.toFixed(1)} / ${target.toFixed(1)}`, x + w - 130, y, 130, 34, {
    size: 23,
    bold: true,
    color,
    align: "right",
  });
  addRect(slide, x, y + 48, w, 18, SOFT, 9);
  addRect(slide, x, y + 48, Math.min(w, w * (forecast / target)), 18, color, 9);
  addLine(slide, x + w - 1, y + 39, 0, 36, INK, 2);
  addText(slide, status, x, y + 83, 170, 26, { size: 15, bold: true, color });
  addText(slide, action, x + 182, y + 80, w - 182, 52, { size: 17, color: MUTED });
}

function addFunnel(slide, stages, values, passRates, times, x, y, maxWidth, segmentHeight, colors) {
  const max = Math.max(...values);
  const center = x + maxWidth / 2;
  stages.forEach((stage, i) => {
    const width = Math.max(108, maxWidth * Math.sqrt(values[i] / max));
    const left = center - width / 2;
    addRect(slide, left, y + i * segmentHeight, width, segmentHeight - 4, colors[i], 6, colors[i], 0, `funnel-${i}`);
    addText(slide, String(values[i]), left, y + i * segmentHeight + 7, width, 32, {
      size: 23,
      bold: true,
      color: WHITE,
      align: "center",
    });
    addText(slide, stage, x - 190, y + i * segmentHeight + 7, 175, 30, {
      size: 17,
      bold: i === 0 || i === stages.length - 1,
      color: INK,
      align: "right",
    });
    addText(slide, i === 0 ? "—" : passRates[i], x + maxWidth + 12, y + i * segmentHeight + 5, 60, 25, {
      size: 16,
      bold: true,
      color: i >= stages.length - 2 ? CORAL : MUTED,
      align: "right",
    });
    addText(slide, times[i], x + maxWidth + 78, y + i * segmentHeight + 5, 52, 25, {
      size: 15,
      color: MUTED,
      align: "right",
    });
  });
  addText(slide, "PASS", x + maxWidth + 12, y - 27, 60, 20, { size: 12, bold: true, color: MUTED, align: "right" });
  addText(slide, "TIME", x + maxWidth + 78, y - 27, 52, 20, { size: 12, bold: true, color: MUTED, align: "right" });
}

function heatColor(v) {
  if (v >= 58) return "#D9F2E8";
  if (v >= 50) return "#E8F0FF";
  if (v >= 40) return "#FFF4D8";
  return "#FFE4E3";
}

function addHeatmap(slide, x, y) {
  const rowH = 62;
  const colW = [270, 120, 120, 120];
  const headers = ["STAGE", "ISRAEL", "FRANCE", "SLOVENIA"];
  let cx = x;
  headers.forEach((h, i) => {
    addRect(slide, cx, y, colW[i], rowH, NAVY_2, 0, WHITE, 0);
    addText(slide, h, cx + 12, y + 17, colW[i] - 24, 28, {
      size: 16,
      bold: true,
      color: WHITE,
      align: i === 0 ? "left" : "center",
    });
    cx += colW[i];
  });
  const rows = [
    ["Recruiter → HM / tech", 56, 61, 49],
    ["HM / tech → panel", 50, 46, 58],
    ["Panel → offer", 33, 41, 29],
  ];
  rows.forEach((row, r) => {
    let xPos = x;
    row.forEach((cell, c) => {
      const fill = c === 0 ? WHITE : heatColor(cell);
      addRect(slide, xPos, y + rowH * (r + 1), colW[c], rowH, fill, 0, GRID, 1);
      addText(slide, String(cell) + (c ? "%" : ""), xPos + 12, y + rowH * (r + 1) + 17, colW[c] - 24, 28, {
        size: c === 0 ? 17 : 21,
        bold: c > 0,
        color: c === 0 ? INK : NAVY_2,
        align: c === 0 ? "left" : "center",
      });
      xPos += colW[c];
    });
  });
}

const presentation = Presentation.create({ slideSize: { width: W, height: H } });

// 01 — Title
{
  const slide = presentation.slides.add();
  slide.background.fill = NAVY;
  const hero = await readBytes(HERO_PATH);
  slide.images.add({
    blob: hero,
    contentType: "image/png",
    alt: "Abstract high-scale data streams converging into a precise low-latency outcome",
    fit: "cover",
    position: { left: 0, top: 0, width: W, height: H },
  });
  addRect(slide, 0, 0, 585, H, NAVY, 0, NAVY, 0);
  addText(slide, "TEADS", 64, 54, 220, 42, { size: 30, bold: true, color: BLUE });
  addText(slide, "PARTS 2 + 3", 64, 140, 260, 26, { size: 16, bold: true, color: "#8FB3FF" });
  addText(slide, "Hiring efficiency\nthat converts technical\nscale into hires", 64, 186, 510, 250, {
    size: 58,
    bold: true,
    color: WHITE,
    name: "deck-title",
  });
  addText(slide, "Executive presentation for P&C and Engineering/Product leadership", 64, 480, 460, 60, {
    size: 21,
    color: "#CBD5EA",
  });
  addText(slide, "20 MINUTES", 64, 616, 180, 24, { size: 14, bold: true, color: TEAL });
  addText(slide, "Illustrative target state • replace with Teads ATS baselines", 250, 616, 310, 28, {
    size: 13,
    color: "#93A2C6",
  });
  setNotes(
    slide,
    "1:00",
    "Open with the business question: how do we convert Teads’ technical scale into six accepted hires per month without adding unnecessary interviews or damaging candidate experience? This presentation covers the operating model in Part 2 and the employer-brand plan in Part 3. The numbers are an illustrative target state, not claimed Teads ATS performance. The central argument is simple: Product and R&D need different funnel strategies, but both depend on the same operating discipline—clear expectations, protected interview capacity and fast evidence-based decisions. The second half then shows how the same engineering proof can strengthen the Netanya talent story.",
    [
      `Primary content: ${SOURCE_DOC}, pages 7–13.`,
      "Visual asset: original OpenAI-generated abstract data-stream image created for this deck; no external asset.",
    ]
  );
}

// 02 — Executive takeaway
{
  const slide = presentation.slides.add();
  slide.background.fill = PAPER;
  addHeader(slide, "PART 2 • EXECUTIVE TAKEAWAY", "Product owns the 0.2-accept gap", BLUE, false, "The target is within reach—but the interventions are track-specific.");
  addText(slide, "5.8", 74, 205, 250, 108, { size: 92, bold: true, color: BLUE });
  addText(slide, "forecast accepts", 80, 314, 240, 32, { size: 22, bold: true, color: INK });
  addText(slide, "against a target of 6", 80, 352, 250, 28, { size: 18, color: MUTED });
  addRect(slide, 80, 408, 345, 22, SOFT, 11);
  addRect(slide, 80, 408, 333, 22, BLUE, 11);
  addLine(slide, 425, 397, 0, 44, INK, 2);
  addText(slide, "−0.2", 352, 445, 72, 32, { size: 20, bold: true, color: CORAL, align: "right" });

  addLine(slide, 500, 190, 0, 405, GRID, 1);
  addBullet(slide, "Product is 0.4 below plan: add one panel-ready candidate.", 548, 218, 635, CORAL, 22);
  addBullet(slide, "R&D needs 40% more qualified leads for the same three accepts.", 548, 306, 635, BLUE, 22);
  addBullet(slide, "Panel → offer is the weakest decision point: Product 44%; R&D 33%.", 548, 394, 635, AMBER, 22);
  addRect(slide, 548, 505, 630, 94, NAVY_2, 10);
  addText(slide, "Leadership implication", 572, 520, 220, 22, { size: 15, bold: true, color: "#9EBBFF" });
  addText(slide, "Improve sourcing quality and decision speed together—not as separate projects.", 572, 548, 580, 46, {
    size: 19,
    bold: true,
    color: WHITE,
  });
  addFooter(slide, 2);
  setNotes(
    slide,
    "1:30",
    "Lead with the answer before the mechanics. The probability-weighted model forecasts 5.8 accepted offers against a six-hire target. That is close enough to be operationally solvable, but the gap is concentrated in Product rather than evenly distributed. Product needs one additional candidate ready for final panel. R&D is nominally on track, yet it requires a materially broader top of funnel—140 qualified leads versus 100 for Product—to deliver the same three accepts. Across both tracks, the panel-to-offer step is the weakest decision point. The implication for HR and Engineering is shared ownership: recruiting must improve evidence quality and expectation setting, while technical leadership must simplify the assessment, calibrate the bar and make decisions inside 24 to 48 hours.",
    [`Source: ${SOURCE_DOC}, page 7. All funnel and forecast values are illustrative target-state figures.`]
  );
}

// 03 — Weekly measurement system
{
  const slide = presentation.slides.add();
  slide.background.fill = WHITE;
  addHeader(slide, "PART 2 • DATA VISIBILITY", "One weekly view should drive every hiring decision", BLUE, false, "Five business questions; one consistent definition set.");
  const rows = [
    ["01", "SPEED", "Open roles • forecast vs target • days open", "Are we hiring fast enough?"],
    ["02", "SUPPLY", "Candidates by stage • coverage • source yield", "Do we have enough qualified candidates?"],
    ["03", "WAIT", "Days in stage • scheduling • feedback • offer", "Where are candidates waiting?"],
    ["04", "EFFORT", "Interviews and interviewer hours per hire", "Are we using time well?"],
    ["05", "QUALITY", "Acceptance • decline reasons • 90-day ramp", "Are we making strong hires?"],
  ];
  const startY = 185;
  rows.forEach((r, i) => {
    const y = startY + i * 78;
    addText(slide, r[0], 66, y + 4, 48, 30, { size: 16, bold: true, color: BLUE });
    addText(slide, r[1], 124, y, 120, 30, { size: 21, bold: true, color: INK });
    addText(slide, r[2], 258, y, 405, 31, { size: 18, color: INK });
    addText(slide, r[3], 258, y + 32, 405, 28, { size: 15, color: MUTED });
    if (i < rows.length - 1) addLine(slide, 66, y + 67, 610, 0, GRID, 1);
  });
  addRect(slide, 728, 188, 486, 190, NAVY_2, 12);
  addText(slide, "Probability-weighted forecast", 758, 213, 420, 30, { size: 24, bold: true, color: WHITE });
  addText(slide, "Count each active candidate once at the furthest stage, then weight by historical acceptance for the same:", 758, 260, 410, 62, {
    size: 18,
    color: "#D7DEEF",
  });
  addText(slide, "stage  ×  track  ×  location  ×  source", 758, 327, 410, 30, {
    size: 20,
    bold: true,
    color: "#8FB3FF",
    align: "center",
  });
  addRect(slide, 728, 408, 486, 170, BLUE_PALE, 12);
  addText(slide, "Assumptions to replace with ATS baselines", 758, 432, 420, 28, { size: 20, bold: true, color: NAVY_2 });
  addText(slide, "• 2 recruiters × 3 accepts / month\n• 30-day requisition target\n• 24h feedback SLA • 80% acceptance\n• pauses and duplicate records excluded", 758, 471, 405, 104, {
    size: 17,
    color: INK,
  });
  addFooter(slide, 3);
  setNotes(
    slide,
    "1:30",
    "This slide translates the one-pager into a weekly management system. The point is not to add a larger dashboard; it is to answer five decisions consistently. Speed tells us whether the plan is moving. Supply tells us whether each track has enough qualified candidates. Wait time shows where queues are building. Effort prevents interview inflation. Quality connects offer acceptance with early retention and manager satisfaction. The forecast deliberately counts each active candidate only once—at the furthest stage reached—and weights that candidate using comparable historical outcomes by stage, track, location and source. The assumptions shown here are placeholders. In implementation, the first task is to replace them with Greenhouse or HRIS baselines and agree one owner for each definition.",
    [`Source: ${SOURCE_DOC}, pages 7–8. Assumptions are explicitly illustrative and should be replaced with Teads ATS/HRIS data.`]
  );
}

// 04 — Forecast by track
{
  const slide = presentation.slides.add();
  slide.background.fill = PAPER;
  addHeader(slide, "PART 2 • FORECAST", "The gap sits in Product—not R&D", BLUE, false, "Each recruiter owns three accepted hires per month.");
  addText(slide, "5.8 / 6.0", 76, 189, 360, 84, { size: 68, bold: true, color: NAVY_2 });
  addText(slide, "combined probability-weighted forecast", 80, 273, 360, 30, { size: 18, color: MUTED });
  addRect(slide, 80, 332, 330, 86, CORAL_PALE, 10);
  addText(slide, "Action this week", 102, 347, 135, 20, { size: 14, bold: true, color: CORAL });
  addText(slide, "Move one more Product candidate to final panel.", 102, 372, 285, 42, { size: 16, bold: true, color: INK });

  addProgressBar(slide, "Recruiter A • Product", 2.6, 3.0, 490, 205, 670, CORAL, "NEEDS ACTION", "Decision within 24h after final panel.");
  addProgressBar(slide, "Recruiter B • R&D", 3.2, 3.0, 490, 385, 670, TEAL, "ON TRACK", "Protect interview slots; align motivation and offer expectations early.");
  addRect(slide, 490, 564, 670, 64, WHITE, 8, GRID, 1);
  addText(slide, "Plain English", 512, 580, 120, 20, { size: 14, bold: true, color: BLUE });
  addText(slide, "Forecast = active candidates × comparable historical likelihood of accepting.", 650, 577, 480, 26, {
    size: 17,
    bold: true,
    color: INK,
  });
  addFooter(slide, 4);
  setNotes(
    slide,
    "2:00",
    "Here is how the forecast becomes operational. Recruiter A, aligned to Product, is forecast at 2.6 accepts against a target of three. Recruiter B, aligned to R&D, is forecast at 3.2 and is therefore on track. The next action is not to add generic top-of-funnel volume. It is to move one additional qualified Product candidate to a final panel and secure a decision immediately afterward. For R&D, the focus is maintaining momentum: keep technical slots protected and align motivation, compensation and work-model expectations before the offer stage. Explain the formula in simple language: every active candidate is counted once and weighted by how often a similar candidate—same stage, track, location and source—has historically accepted. This turns the forecast into a decision aid rather than a recruiter activity report.",
    [`Source: ${SOURCE_DOC}, page 7. Forecast values are illustrative; implementation requires Teads stage-level historical conversion.`]
  );
}

// 05 — Product funnel
{
  const slide = presentation.slides.add();
  slide.background.fill = WHITE;
  addHeader(slide, "PART 2 • PRODUCT FUNNEL", "Product leaks value at panel → offer", BLUE, false, "100 qualified leads back-solve to three accepted offers.");
  addFunnel(
    slide,
    ["Qualified leads", "Recruiter screen", "HM screen", "Case / panel", "Offer", "Accept"],
    [100, 32, 18, 9, 4, 3],
    ["—", "32%", "56%", "50%", "44%", "75%"],
    ["7d", "3d", "4d", "8d", "3d", "6d"],
    250,
    194,
    470,
    58,
    [BLUE, "#447CF3", "#5C8DF5", "#79A1F5", CORAL, TEAL]
  );
  addRect(slide, 880, 194, 322, 96, CORAL_PALE, 10);
  addText(slide, "44%", 902, 205, 105, 56, { size: 44, bold: true, color: CORAL });
  addText(slide, "panel → offer", 1005, 216, 170, 28, { size: 20, bold: true, color: INK });
  addText(slide, "largest designed choke point", 1005, 247, 170, 24, { size: 14, color: MUTED });
  addText(slide, "What changes conversion", 880, 330, 310, 30, { size: 23, bold: true, color: NAVY_2 });
  addBullet(slide, "Offer one ≤90-minute case or live option.", 880, 378, 310, BLUE, 17);
  addBullet(slide, "Pre-book panels; use one anchored rubric.", 880, 438, 310, BLUE, 17);
  addBullet(slide, "Same-day debrief; approve within 48h.", 880, 498, 310, TEAL, 17);
  addText(slide, "~31 calendar days", 880, 588, 260, 32, { size: 22, bold: true, color: NAVY_2 });
  addText(slide, "if stages flow without queues", 880, 620, 285, 24, { size: 15, color: MUTED });
  addFooter(slide, 5);
  setNotes(
    slide,
    "2:00",
    "The Product model starts with 100 manually verified qualified leads and back-solves to three accepts. Early conversion is intentionally selective: 32 recruiter screens, then 18 hiring-manager screens. The largest designed loss occurs from case or panel to offer, where only four of nine progress. That is why the fix is not another sourcing campaign alone. First, reduce assessment burden with one case or live option capped at 90 minutes. Second, pre-book panel capacity and use one rubric with clear evidence anchors. Third, run the debrief the same day and complete approval inside 48 hours. Recruiting should disclose compensation range, Netanya cadence and scope before the first call; technical leadership should own the decision bar. If queues are removed, the designed elapsed time is about 31 calendar days.",
    [`Source: ${SOURCE_DOC}, page 9. Product funnel counts, pass-through rates and timing are illustrative target-state values.`]
  );
}

// 06 — R&D funnel
{
  const slide = presentation.slides.add();
  slide.background.fill = PAPER;
  addHeader(slide, "PART 2 • R&D FUNNEL", "R&D needs breadth first, then faster decisions", BLUE, false, "A narrower skill pool requires 40% more qualified leads than Product.");
  addFunnel(
    slide,
    ["Qualified leads", "Recruiter screen", "Technical screen", "Panel", "Offer", "Accept"],
    [140, 42, 24, 12, 4, 3],
    ["—", "30%", "57%", "50%", "33%", "75%"],
    ["7d", "3d", "7d", "8d", "3d", "6d"],
    250,
    194,
    470,
    58,
    [BLUE, "#447CF3", "#5C8DF5", "#79A1F5", CORAL, TEAL]
  );
  addRect(slide, 880, 194, 322, 96, BLUE_PALE, 10);
  addText(slide, "140", 902, 205, 105, 56, { size: 44, bold: true, color: BLUE });
  addText(slide, "qualified leads", 1005, 216, 170, 28, { size: 20, bold: true, color: INK });
  addText(slide, "40% more than Product", 1005, 247, 170, 24, { size: 14, color: MUTED });
  addText(slide, "What changes conversion", 880, 330, 310, 30, { size: 23, bold: true, color: NAVY_2 });
  addBullet(slide, "Score skill evidence—not exact titles.", 880, 378, 310, BLUE, 17);
  addBullet(slide, "Use one 60-minute production scenario.", 880, 438, 310, BLUE, 17);
  addBullet(slide, "Weekly interviewer pods; no extra round.", 880, 498, 310, TEAL, 17);
  addText(slide, "~34 calendar days", 880, 588, 260, 32, { size: 22, bold: true, color: NAVY_2 });
  addText(slide, "with reserved cross-hub panels", 880, 620, 285, 24, { size: 15, color: MUTED });
  addFooter(slide, 6);
  setNotes(
    slide,
    "2:00",
    "R&D requires a different operating strategy. The same three accepted hires are back-solved from 140 qualified leads because the platform skill combination is narrower and titles are less reliable. Discovery therefore needs an evidence map: cloud, infrastructure-as-code, networking, Kubernetes, distributed systems and production ownership. The technical screen should be one 60-minute production scenario rather than abstract trivia. Cross-hub interviewer pods should be reserved weekly so scheduling does not become the hidden queue. The panel-to-offer rate is only 33 percent in the target model, which signals either duplicate testing, calibration variance or slow approval. The action is an evidence-based debrief, no redundant extra round, and a decision within 48 hours. Designed elapsed time is about 34 days, assuming candidate-requested pauses are excluded.",
    [`Source: ${SOURCE_DOC}, page 10. R&D funnel counts, pass-through rates and timing are illustrative target-state values.`]
  );
}

// 07 — Country heatmap
{
  const slide = presentation.slides.add();
  slide.background.fill = WHITE;
  addHeader(slide, "PART 2 • LOCATION", "Each hub loses candidates for a different reason", BLUE, false, "One funnel definition; locally adapted candidate journey.");
  addHeatmap(slide, 68, 196);
  addText(slide, "Illustrative pass-through", 68, 168, 260, 20, { size: 13, bold: true, color: MUTED });
  addLine(slide, 786, 190, 0, 420, GRID, 1);
  const local = [
    ["ISRAEL • NETANYA", "Commute + hybrid clarity", "Disclose cadence before screen; flexible interview slots.", "Measure pre-screen withdrawal."],
    ["FRANCE • PARIS / MONTPELLIER", "Language + home-hub clarity", "Choose French/English touchpoints; confirm contract location.", "Measure reply and approval days."],
    ["SLOVENIA • LJUBLJANA", "Smaller senior platform pool", "Prioritize referrals and adjacent Central European talent.", "Measure qualified leads and aging."],
  ];
  local.forEach((r, i) => {
    const y = 190 + i * 142;
    addText(slide, r[0], 824, y, 380, 22, { size: 14, bold: true, color: i === 0 ? BLUE : i === 1 ? CORAL : TEAL });
    addText(slide, r[1], 824, y + 30, 380, 30, { size: 22, bold: true, color: INK });
    addText(slide, r[2], 824, y + 66, 375, 45, { size: 16, color: INK });
    addText(slide, r[3], 824, y + 111, 375, 24, { size: 14, color: MUTED });
    if (i < local.length - 1) addLine(slide, 824, y + 134, 376, 0, GRID, 1);
  });
  addRect(slide, 68, 455, 646, 126, NAVY_2, 10);
  addText(slide, "The management rule", 94, 476, 260, 24, { size: 16, bold: true, color: "#9EBBFF" });
  addText(slide, "Track the same stages everywhere; diagnose drop-off by hub before changing the process.", 94, 510, 590, 58, {
    size: 23,
    bold: true,
    color: WHITE,
  });
  addFooter(slide, 7);
  setNotes(
    slide,
    "1:30",
    "The location view prevents a common mistake: treating the same conversion rate as the same problem. The heatmap values are illustrative, but the operating principle is real. In Israel, the likely friction is commute and work-model clarity, so office cadence and interview path should be disclosed before the screen. In France, a bilingual journey and two hubs make language, home office and contract location important. In Slovenia, the core challenge is the size of the senior platform pool, which shifts emphasis toward referrals and adjacent Central European talent. We should keep one stage definition across countries so the data remains comparable, then adapt the candidate journey locally and measure the specific drop-off signal for each hub.",
    [
      `Source: ${SOURCE_DOC}, pages 7 and 11. Country pass-through figures are explicitly illustrative.`,
      `Hybrid-work context in the source assignment: ${URL_ANNUAL}`,
    ]
  );
}

// 08 — Operating bottlenecks
{
  const slide = presentation.slides.add();
  slide.background.fill = PAPER;
  addHeader(slide, "PART 2 • OPERATING MODEL", "Four operating fixes remove avoidable delay", BLUE, false, "Prioritize the mechanisms that affect both conversion and interviewer load.");
  const rows = [
    ["01", "CALIBRATION", "High HM rejection variance; reopened requisitions", "60-minute kickoff + monthly calibration council"],
    ["02", "RARE PLATFORM SCOPE", "Many applicants; repeated missing evidence", "Adjacent pools + evidence scorecard + technical day-in-life"],
    ["03", "INTERVIEW INFLATION", "39 Engineering / 42 Product interviews per hire*", "One competency map + one structured practical"],
    ["04", "CROSS-HUB SCHEDULING", "Lag above 3 business days; missed feedback SLA", "Reserved pods + automatic 24h escalation"],
  ];
  addText(slide, "BOTTLENECK", 112, 174, 240, 20, { size: 13, bold: true, color: MUTED });
  addText(slide, "DIAGNOSTIC SIGNAL", 414, 174, 330, 20, { size: 13, bold: true, color: MUTED });
  addText(slide, "OPERATING FIX", 814, 174, 340, 20, { size: 13, bold: true, color: MUTED });
  rows.forEach((r, i) => {
    const y = 206 + i * 101;
    addText(slide, r[0], 66, y + 16, 50, 35, { size: 18, bold: true, color: BLUE });
    addText(slide, r[1], 112, y + 10, 260, 34, { size: 20, bold: true, color: INK });
    addText(slide, r[2], 414, y + 8, 340, 52, { size: 17, color: INK });
    addText(slide, r[3], 814, y + 8, 360, 52, { size: 17, bold: true, color: i === 3 ? TEAL : NAVY_2 });
    if (i < rows.length - 1) addLine(slide, 66, y + 82, 1110, 0, GRID, 1);
  });
  addRect(slide, 66, 626, 1110, 38, NAVY_2, 8);
  addText(slide, "30-day rhythm: weekly track review • protected panels • 24h feedback • 48h decisions • monthly calibration", 88, 635, 1068, 22, {
    size: 17,
    bold: true,
    color: WHITE,
    align: "center",
  });
  addFooter(slide, 8, false, "*External benchmark cited in assignment; diagnose Teads with internal interviewer-hour data");
  setNotes(
    slide,
    "2:00",
    "These four fixes address the most avoidable sources of delay. First, calibration: a 60-minute kickoff should define outcomes, level anchors and what must be present now versus what can be learned. Second, rare platform scope: titles will not surface enough qualified people, so sourcing and screening should score evidence rather than exact labels. Third, interview inflation: the external benchmark cited in the assignment shows 39 Engineering and 42 Product interviews per hire. We should not assume Teads has the same problem; we should measure interviewer hours and check whether one competency is tested twice. Fourth, cross-hub scheduling: reserve weekly pods by track and time zone, then escalate automatically when feedback is not entered within 24 hours. Together these become a visible 30-day operating rhythm.",
    [
      `Source: ${SOURCE_DOC}, page 11.`,
      `External recruiting benchmark referenced in the assignment: ${URL_GEM}`,
      `Teads role scope referenced in the assignment: ${URL_ROLE}`,
    ]
  );
}

// 09 — Employer-brand diagnosis
{
  const slide = presentation.slides.add();
  slide.background.fill = NAVY;
  const hero = await readBytes(HERO_PATH);
  slide.images.add({
    blob: hero,
    contentType: "image/png",
    alt: "Abstract high-scale data streams used as a background for Teads engineering scale",
    fit: "cover",
    position: { left: 600, top: 0, width: 680, height: 720 },
    crop: { left: 0.27, top: 0, right: 0, bottom: 0 },
  });
  addRect(slide, 0, 0, 690, H, NAVY, 0, NAVY, 0);
  addHeader(slide, "PART 3 • EMPLOYER BRAND", "Engineering proof is Teads’ strongest employer story", TEAL, true);
  addText(slide, "Candidates can already see office and perk signals.", 66, 190, 510, 30, { size: 20, color: "#C4CEE4" });
  addText(slide, "The differentiator is the technical problem:", 66, 232, 520, 34, { size: 24, bold: true, color: WHITE });
  addMetric(slide, "~2M", "ad requests / second", 66, 298, 245, BLUE, "", "#D7DEEF");
  addMetric(slide, "<150ms", "response target", 336, 298, 245, TEAL, "", "#D7DEEF");
  addMetric(slide, "100B", "events / day", 66, 474, 245, BLUE_2, "", "#D7DEEF");
  addMetric(slide, "18M", "predictions / second", 336, 474, 245, CORAL, "", "#D7DEEF");
  addRect(slide, 738, 488, 470, 118, NAVY_2, 12, "#2D4A79", 1);
  addText(slide, "Candidate promise", 770, 506, 210, 24, { size: 15, bold: true, color: "#8FB3FF" });
  addText(slide, "“You build it, run it and monitor it”\nwith 400+ engineers across four hubs.", 770, 540, 400, 58, {
    size: 21,
    bold: true,
    color: WHITE,
  });
  addFooter(slide, 9, true, "Public role materials cited in assignment • validate figures before external publishing");
  setNotes(
    slide,
    "1:30",
    "Part 3 starts with the current candidate view. Teads has visible local signals—hybrid work, the Netanya office and perks—but those are not a distinctive employer proposition for senior technical talent. The strongest story is the engineering proof already present in public role materials: approximately two million ad requests per second, one hundred billion events per day, response times below 150 milliseconds and eighteen million predictions per second. Pair that scale with the ownership promise that engineers build, run and monitor their systems, across more than 400 engineers in four hubs. The employer-brand shift is therefore from amenities to evidence: specific systems, decisions and trade-offs told by local engineers. Figures should be validated before external publishing, and post-merger questions should be answered with one honest approved narrative.",
    [
      `Source: ${SOURCE_DOC}, page 12.`,
      `Teads role and scale claims: ${URL_ROLE}`,
      `Engineering culture and hubs: ${URL_ENGINEERING}`,
      `Combination and brand-transition context: ${URL_MERGER} and ${URL_REBRAND}`,
      `Directional review snapshot referenced in assignment: ${URL_GLASSDOOR}`,
      "Background visual: original OpenAI-generated asset created for this deck.",
    ]
  );
}

// 10 — Employer-brand roadmap
{
  const slide = presentation.slides.add();
  slide.background.fill = WHITE;
  addHeader(slide, "PART 3 • ACTION PLAN", "Clarity first. Community credibility next.", TEAL, false, "Three waves connect employer-brand activity to recruitment outcomes.");
  addLine(slide, 120, 270, 1030, 0, GRID, 4);
  const waves = [
    {
      x: 90,
      color: BLUE,
      time: "0–45 DAYS",
      title: "Create clarity",
      body: "Interview 12 employees\nPublish one post-combination FAQ\nRewrite Israel job pages",
      measure: "FAQ use • qualified applications • early withdrawal",
    },
    {
      x: 455,
      color: CORAL,
      time: "30–90 DAYS",
      title: "Add trusted voices",
      body: "Build an 8–12 person ambassador group\nPublish honest local stories\nRun technical scale talks",
      measure: "Attendance • completion • qualified conversations",
    },
    {
      x: 820,
      color: TEAL,
      time: "3–12 MONTHS",
      title: "Earn community trust",
      body: "Pilot the 150ms Reliability Lab\nRun Open Internet Build Nights\nExplore a Netanya fellowship",
      measure: "NPS • return rate • qualified leads • hires influenced",
    },
  ];
  waves.forEach((w, i) => {
    addRect(slide, w.x + 12, 252, 28, 28, w.color, 14);
    addText(slide, w.time, w.x, 190, 300, 22, { size: 14, bold: true, color: w.color });
    addText(slide, w.title, w.x, 304, 310, 38, { size: 26, bold: true, color: INK });
    addText(slide, w.body, w.x, 354, 315, 112, { size: 18, color: INK });
    addText(slide, "MEASURE", w.x, 490, 120, 18, { size: 12, bold: true, color: MUTED });
    addText(slide, w.measure, w.x, 516, 315, 64, { size: 15, color: MUTED });
    if (i < waves.length - 1) addLine(slide, w.x + 330, 184, 0, 397, GRID, 1);
  });
  addRect(slide, 90, 606, 1060, 48, TEAL_PALE, 8);
  addText(slide, "Impact chain: participation → qualified leads → recruiter screens → offers accepted → hires influenced", 112, 620, 1015, 24, {
    size: 18,
    bold: true,
    color: NAVY_2,
    align: "center",
  });
  addFooter(slide, 10, false, "Leading indicators are useful only when linked to source-attributed recruiting outcomes");
  setNotes(
    slide,
    "2:00",
    "The roadmap is intentionally sequenced. Wave one creates clarity with low-cost actions: interview employees, review candidate drop-off, publish one consistent post-combination FAQ and rewrite Israel job pages around mission, technical scale, first-90-day outcomes, work model and interview timing. Wave two adds trusted employee voices through a volunteer ambassador group and short technical talks. Wave three earns credibility through reciprocal community programs: the 150ms Reliability Lab, Open Internet Build Nights and a longer-term Netanya fellowship or education partnership. The measurement model matters. Attendance, return rate and NPS are leading indicators; the final impact should be tracked through source-attributed qualified leads, positive response, recruiter-screen conversion, offer acceptance and hires influenced.",
    [
      `Source: ${SOURCE_DOC}, page 13.`,
      `Potential community partner referenced in the assignment: ${URL_AWSUG}`,
      `Potential reliability/platform community partner: ${URL_DEVOPSDAYS}`,
    ]
  );
}

// 11 — 150ms Lab
{
  const slide = presentation.slides.add();
  slide.background.fill = PAPER;
  addHeader(slide, "PART 3 • PILOT CONCEPT", "The 150ms Lab turns scale into talent", TEAL, false, "A community learning experience—not a candidate test.");
  addText(slide, "150", 72, 202, 250, 108, { size: 98, bold: true, color: BLUE });
  addText(slide, "milliseconds", 82, 312, 230, 34, { size: 26, bold: true, color: NAVY_2 });
  addText(slide, "Keep a mocked ad request below the response-time target while failures are introduced.", 82, 372, 286, 110, {
    size: 20,
    color: INK,
  });
  addRect(slide, 82, 518, 270, 56, TEAL_PALE, 8);
  addText(slide, "Quarterly • hands-on • opt-in", 96, 534, 242, 25, { size: 16, bold: true, color: TEAL, align: "center" });

  // Connector line first, behind nodes.
  addLine(slide, 470, 328, 660, 0, "#AFC2E8", 4);
  const steps = [
    ["01", "REAL PROBLEM", "Teads engineers frame one reliability trade-off."],
    ["02", "LEARNING", "Participants work through failure scenarios together."],
    ["03", "TRUST", "The community experiences honest engineering ownership."],
    ["04", "IMPACT", "Opt-in leads enter a measurable recruiting journey."],
  ];
  steps.forEach((s, i) => {
    const x = 430 + i * 185;
    addRect(slide, x, 300, 56, 56, i === 3 ? TEAL : BLUE, 28);
    addText(slide, s[0], x, 315, 56, 25, { size: 16, bold: true, color: WHITE, align: "center" });
    addText(slide, s[1], x - 34, 382, 126, 20, { size: 13, bold: true, color: i === 3 ? TEAL : BLUE, align: "center" });
    addText(slide, s[2], x - 47, 416, 152, 82, { size: 16, color: INK, align: "center" });
  });
  addRect(slide, 430, 538, 732, 72, NAVY_2, 10);
  addText(slide, "Measure", 452, 554, 90, 20, { size: 14, bold: true, color: "#9EBBFF" });
  addText(slide, "participant NPS • opt-in community • qualified leads • recruiter-screen conversion • hires influenced", 550, 551, 584, 44, {
    size: 16,
    bold: true,
    color: WHITE,
  });
  addFooter(slide, 11);
  setNotes(
    slide,
    "1:30",
    "The 150ms Reliability Lab is the flagship pilot because it connects a real Teads engineering problem to a useful community experience. Teads engineers frame one reliability trade-off, participants work through a mocked failure scenario, and the session teaches how teams reason under latency constraints. It must be explicit that this is not a candidate assessment. Participation and future contact are opt-in. The value for technical leadership is credible demonstration of the work; the value for P&C is a source-attributed journey that can be measured from event participation to qualified lead, recruiter screen, offer and hire influenced. A quarterly pilot with a partner such as AWS User Group Israel or DevOpsDays Tel Aviv keeps the program reciprocal and operationally manageable.",
    [
      `Source: ${SOURCE_DOC}, page 13.`,
      `Technical scale and response-time claim referenced in source assignment: ${URL_ROLE}`,
      `Potential partner: ${URL_AWSUG}`,
      `Potential partner: ${URL_DEVOPSDAYS}`,
    ]
  );
}

// 12 — Close
{
  const slide = presentation.slides.add();
  slide.background.fill = NAVY;
  addHeader(slide, "LEADERSHIP DECISION", "Three commitments make the plan executable", TEAL, true, "A 30-day pilot can establish the baseline and remove the first queues.");
  const commitments = [
    ["01", "ONE SOURCE OF TRUTH", "Replace illustrative figures with Greenhouse/HRIS baselines and agree metric owners.", "TA + P&C"],
    ["02", "PROTECTED DECISION CAPACITY", "Reserve Product/R&D interviewer pods; enforce 24h feedback and 48h decisions.", "VP Engineering / Product"],
    ["03", "ONE TECHNICAL TALENT STORY", "Approve the post-combination narrative and pilot the 150ms Reliability Lab.", "P&C + Comms + DevRel"],
  ];
  commitments.forEach((c, i) => {
    const x = 64 + i * 395;
    addText(slide, c[0], x, 202, 80, 48, { size: 34, bold: true, color: i === 2 ? TEAL : BLUE });
    addText(slide, c[1], x, 274, 340, 58, { size: 22, bold: true, color: WHITE });
    addText(slide, c[2], x, 350, 330, 108, { size: 18, color: "#D7DEEF" });
    addText(slide, c[3], x, 496, 330, 24, { size: 14, bold: true, color: "#8FB3FF" });
    if (i < commitments.length - 1) addLine(slide, x + 360, 200, 0, 340, "#24345D", 1);
  });
  addRect(slide, 64, 574, 1118, 66, TEAL, 10);
  addText(slide, "Decision question: can we commit to these three actions for the next 30 days?", 92, 592, 1060, 32, {
    size: 25,
    bold: true,
    color: WHITE,
    align: "center",
  });
  addFooter(slide, 12, true, "Outcome: faster decisions • higher conversion • clearer candidate promise");
  setNotes(
    slide,
    "1:30",
    "Close with an explicit decision rather than a summary. The first commitment is one source of truth: replace every illustrative number with Teads ATS and HRIS baselines, then assign metric ownership. The second is protected decision capacity: weekly Product and R&D interview pods, 24-hour feedback and 48-hour final decisions. The third is one approved technical talent story: a clear explanation of the combined company, supported by real engineering evidence, and a 150ms Reliability Lab pilot. These commitments split ownership appropriately across TA, P&C, Engineering/Product, Communications and DevRel. Ask the room whether they can commit to the three actions for 30 days. The intended outcome is faster decisions, stronger conversion and a candidate promise that technical talent can trust.",
    [`Source: ${SOURCE_DOC}, pages 7–13. Closing commitments synthesize the operating and employer-brand recommendations in Parts 2 and 3.`]
  );
}

await fs.mkdir(PREVIEW_DIR, { recursive: true });
await fs.mkdir(LAYOUT_DIR, { recursive: true });

for (const [index, slide] of presentation.slides.items.entries()) {
  const stem = `slide-${String(index + 1).padStart(2, "0")}`;
  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await writeBlob(path.join(PREVIEW_DIR, `${stem}.png`), png);
  const layout = await slide.export({ format: "layout" });
  await fs.writeFile(path.join(LAYOUT_DIR, `${stem}.layout.json`), await layout.text());
}

const montage = await presentation.export({ format: "webp", montage: true, scale: 1 });
await writeBlob(path.join(__dirname, "deck-montage.webp"), montage);

const pptx = await PresentationFile.exportPptx(presentation);
await pptx.save(FINAL_PPTX);

console.log(`CREATED ${FINAL_PPTX}`);
console.log(`SLIDES ${presentation.slides.items.length}`);
process.exit(0);
