$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$base = Join-Path $env:USERPROFILE ".codex\אדמה ירוקה"
$v2 = Join-Path $base "V2\דוח טכנולוגי - טיוטה ממולאת - אודי.doc"
$out = Join-Path $base "V2\דוח טכנולוגי - גרסת נתוני הרעבה מעודכנת.doc"
$figBase = "C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\adama_v3_figures"
$chartBase = "C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\starvation_chart_exports"
$plasmidMap = "C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\plasmid_map_deck.jpg"

function Set-CellText {
    param($Table, [int]$Row, [int]$Column, [string]$Text)
    $range = $Table.Cell($Row, $Column).Range
    $range.End = $range.End - 1
    $range.Text = $Text
    $range.ParagraphFormat.ReadingOrder = 1
    $range.ParagraphFormat.Alignment = 2
    $range.Font.NameBi = "Arial"
    $range.Font.Name = "Arial"
    $range.Font.SizeBi = 10
    $range.Font.Size = 10
}

function Clear-Row {
    param($Table, [int]$Row)
    for ($c = 2; $c -le $Table.Columns.Count; $c++) {
        try { Set-CellText $Table $Row $c "" } catch {}
    }
}

function Append-Paragraph {
    param($Cell, [string]$Text, [int]$FontSize = 10, [bool]$Bold = $false)
    $range = $Cell.Range
    $range.End = $range.End - 1
    $range.Collapse(0)
    $range.InsertAfter("`r" + $Text)
    $range.Font.NameBi = "Arial"
    $range.Font.Name = "Arial"
    $range.Font.SizeBi = $FontSize
    $range.Font.Size = $FontSize
    $range.Font.Bold = $(if ($Bold) { 1 } else { 0 })
    $range.ParagraphFormat.ReadingOrder = 1
    $range.ParagraphFormat.Alignment = 2
}

function Append-Picture {
    param($Doc, $Cell, [string]$Path, [string]$Caption, [double]$WidthPoints = 420)
    Append-Paragraph $Cell $Caption 9 $true
    $range = $Cell.Range
    $range.End = $range.End - 1
    $range.Collapse(0)
    $range.InsertParagraphAfter()
    $range.Collapse(0)
    $pic = $Doc.InlineShapes.AddPicture($Path, $false, $true, $range)
    $pic.LockAspectRatio = -1
    $pic.Width = $WidthPoints
    Append-Paragraph $Cell "" 8 $false
}

$tasks = @(
    @{
        Name = "קבוצה 1 - סינון רצפי אנזימים ובניית UPO19 מותאם לפסאודומונס"
        Status = "כ-55% - התקבלו כל הזנים מליאנט, הפלסמידים רוצפו ב-E. coli, וכל רצפי המקור נדחו לביטוי ישיר ב-P. putida עקב GC נמוך וחוסר התאמה לקודונים. נבחר UPO19, תוכנן רצף מותאם קודונים, נוספו אות הפרשה ו-His-tag, ונבנו מספר קונסטרקטים שנשלחו לריצוף."
    },
    @{
        Name = "קבוצה 3 - דטקטורי הרעבה לחנקן, ברזל ופוספט"
        Status = "כ-70% - דטקטורי חנקן וברזל מגיבים בצורה חזקה וברורה במערכת GFP. עבור פוספט נבחנו שני פרומוטורים ללא תגובה ספציפית מספקת, וקונסטרקט שלישי נמצא בבנייה. הזנים העובדים מועברים למערכות אלקטרוכימיות ולומינסנטיות."
    },
    @{
        Name = "קבוצה 3 - דטקטור אלקנים לזיהום דלקים בקרקע"
        Status = "כ-35% - הפלסמידים הסביבתיים הרלוונטיים נמצאים בידינו. מאחר שהגנים אינם נטיביים ל-P. putida, נבנית מערכת הכוללת רצפטור וגן דיווח. הדטקטור עדיין אינו מוכן להעברה."
    }
)

$details = @(
    @{
        Activity = "סינון אנזימים ובניית UPO19 מותאם"
        Partner = "ליאנט"
        Products = "ריצוף פלסמידים; דחיית רצפי מקור שאינם מתאימים ל-P. putida; רצף UPO19 מותאם קודונים; מספר קונסטרקטים עם אות הפרשה ו-His-tag."
        Transfer = "לא מוכן להעברה עדיין; לאחר אישור ריצוף יבוצעו ביטוי, Western blot ובדיקת פעילות."
        Description = "כל הזנים מליאנט התקבלו, והריצוף של הפלסמידים ב-E. coli איפשר לסנן את רצפי האנזימים. רצפי המקור נמצאו בעלי אחוז GC נמוך, סביב 30%, ולכן אינם מתאימים לביטוי ישיר בפסאודומונס. בהתאם לכך נבחר UPO19 לפי המלצת ליאנט, סונתז רצף DNA חדש המותאם ל-P. putida תוך שמירת רצף החלבון, ונוספו signal peptide להפרשה ו-His-tag לניקוי. הקונסטרקטים נבנו ונשלחו לריצוף."
    },
    @{
        Activity = "דטקטורי הרעבה"
        Partner = "הדר; ראמז"
        Products = "זני P. putida עם GFP; דטקטורים פעילים לחנקן ולברזל; נתוני מדידה קינטיים; קונסטרקט פוספט שלישי בבנייה."
        Transfer = "דטקטורי חנקן וברזל מועברים להתאמה למדידה אלקטרוכימית ולמערכת לומינסנטית."
        Description = "נבנו ונבדקו דטקטורים לתנאי הרעבה. במדידות GFP מנורמלות ל-OD595 התקבלה תגובה חזקה וברורה עבור דטקטור ברזל ודטקטור חנקן ביחס לביקורת M9 מתאימה. עבור פוספט נבחנו שני פרומוטורים, אך לא התקבלה תגובה ספציפית מספקת, ולכן נבנה קונסטרקט שלישי."
    },
    @{
        Activity = "דטקטור אלקנים"
        Partner = "הדר; ראמז"
        Products = "פלסמידים סביבתיים רלוונטיים בידינו; מערכת רצפטור וגן דיווח בבנייה."
        Transfer = "עדיין לא מוכן להעברה; לאחר בנייה ואפיון יועבר להמשך התאמה למערכות קריאה."
        Description = "בניית דטקטור האלקנים מורכבת יותר משום שהגנים הרלוונטיים אינם גנים נטיביים של P. putida, אלא מצויים על פלסמידים בזנים סביבתיים. הפלסמידים כבר נמצאים בידינו, והמערכת נבנית כך שתכלול רכיב רצפטור וגן דיווח לזיהוי אלקנים כמייצגי זיהום דלקים בקרקע."
    }
)

$achievements = @"
במהלך התקופה התקדמו שני צירי הפיתוח המרכזיים של מעבדת בנין במסגרת מאגד אדמה ירוקה.

בקבוצה 1 התקבלו כל הזנים והפלסמידים מליאנט. בוצע ריצוף לפלסמידים שנמצאו ב-E. coli, ובעקבותיו התברר שכל רצפי האנזימים המקוריים אינם מתאימים לביטוי ישיר ב-Pseudomonas putida, בעיקר בשל אחוז GC נמוך מאוד, סביב 30%, ובשל חוסר התאמה לקודונים של המאכסן. ממצא זה שינה את כיוון העבודה: במקום להעביר את הפלסמידים המקוריים ישירות ל-P. putida, נבחר האנזים UPO19 לפי המלצת ליאנט, ותוכנן עבורו רצף DNA חדש המותאם לקודונים ולמאפייני P. putida, תוך שמירה על רצף החלבון. לרצף נוספו signal peptide לעידוד הפרשה חוץ-תאית ו-His-tag לצורך ניקוי ובדיקת ביטוי בהמשך. נבנו מספר קונסטרקטים במערכות הביטוי pJN105 ו-pBBR1mcs-2, והם נשלחו לריצוף. לאחר קבלת ריצוף תקין, השלב הבא הוא בדיקת ביטוי ב-Western blot ולאחר מכן שליחה לאלגין לבדיקת פעילות.

בקבוצה 3 נבנו דטקטורים מבוססי P. putida לתנאי הרעבה. נבחנו זנים עם GFP, ובמדידות קינטיות מנורמלות ל-OD595 התקבלה תגובה חזקה וברורה לדטקטור ברזל ולדטקטור חנקן ביחס לביקורת M9 מתאימה לכל דטקטור. עבור דטקטור פוספט נבחנו שני פרומוטורים שונים, אך נכון למועד הדיווח לא התקבלה תגובה ספציפית מספקת; קונסטרקט שלישי נמצא בבנייה. בנוסף, החל פיתוח דטקטור אלקנים לזיהוי זיהומי דלק בקרקע. מאחר שהגנים הרלוונטיים אינם נטיביים ל-P. putida אלא נמצאים על פלסמידים בזנים סביבתיים, נבנית מערכת הכוללת רצפטור וגן דיווח. הפלסמידים הדרושים כבר נמצאים בידינו.

במקביל, הדטקטורים שעובדים במערכת GFP מועברים להתאמה למערכת אלקטרוכימית עבור מדידות במעבדה של הדר, ונבנה סט נוסף עם אנזים לומינסנטי לשימוש במעבדה של ראמז. בכך התוצרים הביולוגיים מתחילים לעבור ממדידות GFP מעבדתיות למערכות קריאה יישומיות יותר במסגרת המאגד.
"@

$collaboration = @"
הפעילות בתקופה כללה ממשקי עבודה עם מספר שותפים במאגד. בקבוצה 1 העבודה התבססה על קבלת זנים, פלסמידים והמלצה אנזימטית מליאנט, ולאחר סינון רצפי המקור בוצעה בנייה מחודשת של UPO19 מותאם ל-P. putida. בהמשך, לאחר אישור ריצוף ובדיקת ביטוי, מתוכנן להעביר חומר לאלגין לבדיקת פעילות. בקבוצה 3, דטקטורי החנקן והברזל שעובדים במערכת GFP מועברים להתאמה למערכת אלקטרוכימית במעבדה של הדר, ובמקביל נבנית מערכת דיווח לומינסנטית עבור ראמז. שיתופי פעולה אלה מיועדים לאפשר מעבר ממדידות ביולוגיות בסיסיות למערכות קריאה יישומיות יותר במסגרת יעדי המאגד.
"@

Copy-Item -LiteralPath $v2 -Destination $out -Force
$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($out, $false, $false, $false)
    if ($doc.Comments.Count -gt 0) { $doc.DeleteAllComments() }

    $taskTable = $doc.Tables.Item(7)
    for ($i = 0; $i -lt $tasks.Count; $i++) {
        $row = 3 + $i
        Set-CellText $taskTable $row 2 $tasks[$i].Name
        Set-CellText $taskTable $row 11 $tasks[$i].Status
    }
    for ($r = 6; $r -le 10; $r++) { Clear-Row $taskTable $r }

    $detailTable = $doc.Tables.Item(8)
    for ($i = 0; $i -lt $details.Count; $i++) {
        $row = 2 + $i
        Set-CellText $detailTable $row 2 $details[$i].Activity
        Set-CellText $detailTable $row 3 $details[$i].Partner
        Set-CellText $detailTable $row 4 $details[$i].Products
        Set-CellText $detailTable $row 5 $details[$i].Transfer
        Set-CellText $detailTable $row 6 $details[$i].Description
    }
    for ($r = 5; $r -le 8; $r++) { Clear-Row $detailTable $r }
    Set-CellText $detailTable 3 6 "נבנו ונבדקו דטקטורים לתנאי הרעבה. בניסוי מיום 10.6.2026 בוצעה מדידה קינטית של ביטוי מנורמל עבור pvdA תחת סדרת ריכוזי ברזל ועבור glnK תחת סדרת ריכוזי חנקן. בשני הדטקטורים התקבלה תגובת מינון ברורה: ככל שריכוז היסוד ירד, האות עלה. ב-13.3 שעות אות pvdA עלה מ-28,182 ב-20 mM Fe ל-244,316 ללא ברזל, ואות glnK עלה מ-11,819 ב-10 mM N ל-202,038 ב-2 mM N. עבור פוספט נבדקו שני פרומוטורים ללא תגובה ספציפית מספקת, ולכן נבנה קונסטרקט שלישי."

    $milestoneTable = $doc.Tables.Item(10)
    Set-CellText $milestoneTable 2 4 "בביצוע. דטקטורי חנקן וברזל עובדים ומראים תגובה חזקה מול ביקורת M9. עבור פוספט נבדקו שני פרומוטורים ללא ספציפיות מספקת, וקונסטרקט שלישי נמצא בבנייה. דטקטור אלקנים נמצא בבנייה. מועד אבן הדרך טרם הגיע."
    Set-CellText $milestoneTable 3 4 "בביצוע מוקדם. לאחר סינון רצפי המקור, נבחר UPO19 ותוכנן רצף מותאם קודונים ל-P. putida. נוספו אות הפרשה ו-His-tag, ונבנו מספר קונסטרקטים במערכות pJN105 ו-pBBR1mcs-2. הקונסטרקטים נשלחו לריצוף. לאחר אישור ריצוף יבוצעו Western blot ובדיקות פעילות."
    Set-CellText $milestoneTable 2 4 "בביצוע. דטקטורי pvdA לברזל ו-glnK לחנקן הציגו תגובת מינון קינטית ברורה בסדרת ריכוזים. ב-13.3 שעות התקבלו אותות מרביים של 244,316 ללא ברזל ושל 202,038 ב-2 mM חנקן. עבור פוספט נבדקו שני פרומוטורים ללא ספציפיות מספקת וקונסטרקט שלישי נמצא בבנייה. דטקטור האלקנים נמצא בבנייה. מועד אבן הדרך טרם הגיע."

    $achCell = $doc.Tables.Item(11).Cell(1,1)
    Set-CellText $doc.Tables.Item(11) 1 1 $achievements
    Append-Paragraph $achCell "עדכון ניסוי 10.6.2026: דטקטור pvdA נבדק בסדרת ריכוזי ברזל ודטקטור glnK בסדרת ריכוזי חנקן. בשני המקרים התקבלה תגובת מינון ברורה. ב-13.3 שעות אות pvdA עלה מ-28,182 ב-20 mM Fe ל-244,316 ללא ברזל, ואות glnK עלה מ-11,819 ב-10 mM N ל-202,038 ב-2 mM N." 10 $true
    Append-Picture $doc $achCell (Join-Path $figBase "enzyme_strain_rejection_gc.png") "איור 1. סינון רצפי האנזימים המקוריים: רצפי המקור נדחו לביטוי ישיר ב-P. putida עקב GC נמוך וחוסר התאמה למאכסן." 420
    Append-Picture $doc $achCell (Join-Path $figBase "upo19_construction_workflow.png") "איור 2. אסטרטגיית בניית UPO19 מותאם: שמירת רצף החלבון, אופטימיזציית קודונים, אות הפרשה ו-His-tag." 430
    Append-Picture $doc $achCell $plasmidMap "איור 3. קונסטרקטים ראשוניים של UPO19 במערכות pJN105 ו-pBBR1mcs-2." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "pvdA_Fe_response.png") "איור 4. תגובת דטקטור pvdA לאורך זמן תחת סדרת ריכוזי ברזל." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "glnK_N_response.png") "איור 5. תגובת דטקטור glnK לאורך זמן תחת סדרת ריכוזי חנקן." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "normalized_expression_13_3h.png") "איור 6. השוואת הביטוי המנורמל לאחר 13.3 שעות בכל תנאי הברזל והחנקן שנבדקו." 430

    $riskTable = $doc.Tables.Item(13)
    Set-CellText $riskTable 2 1 "רצפי האנזימים המקוריים אינם מתאימים לביטוי ישיר ב-P. putida"
    Set-CellText $riskTable 2 2 "כל רצפי המקור סוננו ונפסלו לביטוי ישיר; נבחר UPO19 ותוכנן רצף מותאם קודונים עם אות הפרשה ו-His-tag."
    Set-CellText $riskTable 2 3 "הקונסטרקטים נבנו ונשלחו לריצוף."
    Set-CellText $riskTable 3 1 "טרם אומת ביטוי ופעילות של UPO19 ב-P. putida"
    Set-CellText $riskTable 3 2 "לאחר אישור ריצוף יבוצע Western blot לבדיקת ביטוי, ולאחר מכן שליחה לאלגין לבדיקת פעילות."
    Set-CellText $riskTable 3 3 "מתוכנן לשלב הבא."
    Set-CellText $riskTable 4 1 "דטקטור פוספט לא נתן תגובה ספציפית בשני פרומוטורים שנבדקו"
    Set-CellText $riskTable 4 2 "נבנה קונסטרקט שלישי, שייבחן מול תנאי הרעבה מבוקרים לפוספט ובהשוואה לביקורת M9."
    Set-CellText $riskTable 4 3 "בתהליך."
    try {
        $riskTable.Rows.Add() | Out-Null
        Set-CellText $riskTable 5 1 "דטקטור אלקנים מבוסס על גנים שאינם נטיביים ל-P. putida"
        Set-CellText $riskTable 5 2 "שימוש בפלסמידים סביבתיים שכבר נמצאים בידינו ובנייה הדרגתית של מערכת רצפטור וגן דיווח."
        Set-CellText $riskTable 5 3 "בתהליך בנייה."
    } catch {}

    Set-CellText $doc.Tables.Item(15) 1 1 $collaboration

    $doc.Save()
    $picCount = $doc.InlineShapes.Count
    $commentCount = $doc.Comments.Count
    $doc.Close($false)
    $word.Quit()
    Write-Output "OUTPUT=$out"
    Write-Output "INLINE_SHAPES=$picCount"
    Write-Output "COMMENTS=$commentCount"
}
finally {
    if ($doc) { [Runtime.InteropServices.Marshal]::ReleaseComObject($doc) | Out-Null }
    if ($word) { [Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null }
}
