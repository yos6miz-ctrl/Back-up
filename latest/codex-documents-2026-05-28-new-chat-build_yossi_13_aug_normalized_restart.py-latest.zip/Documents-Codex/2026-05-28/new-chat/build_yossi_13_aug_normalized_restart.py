from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont
import xlsxwriter


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
OUT_NAME = "YOSSI 13.8.26 normalized analysis restart.xlsx"
PNG_NAME = "YOSSI 13.8.26 normalized curves restart.png"

ROWS = list("BCDEFG")
OD_HEADER_ROW = 53
OD_FIRST_ROW = 54
GFP_HEADER_ROW = 89
GFP_FIRST_ROW = 90
N_READS = 18
OD_PLOT_THRESHOLD = 0.005

SERIES = [
    {"condition": "M9", "construct": "puxpA", "sample_col": 2, "control_col": 4},
    {"condition": "M9", "construct": "puxpB", "sample_col": 3, "control_col": 4},
    {"condition": "0.5 M9", "construct": "puxpA", "sample_col": 5, "control_col": 7},
    {"condition": "0.5 M9", "construct": "puxpB", "sample_col": 6, "control_col": 7},
    {"condition": "M9 -P", "construct": "puxpA", "sample_col": 8, "control_col": 10},
    {"condition": "M9 -P", "construct": "puxpB", "sample_col": 9, "control_col": 10},
]


def excel_time_to_hours(value) -> float:
    if hasattr(value, "hour") and hasattr(value, "minute") and hasattr(value, "second"):
        return value.hour + value.minute / 60 + value.second / 3600
    if isinstance(value, (int, float)):
        return float(value) * 24
    raise ValueError(f"Unsupported time value: {value!r}")


def excel_time_to_text(value) -> str:
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    hours = excel_time_to_hours(value)
    total_seconds = round(hours * 3600)
    h, rem = divmod(total_seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def safe_ratio(numerator: float, denominator: float):
    if denominator == 0:
        return None
    return numerator / denominator


def read_source():
    source = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE_NAME
    workbook = load_workbook(source, data_only=True, read_only=True)
    ws = workbook["Plate 1 - Sheet1"]
    od_idx = {ws.cell(OD_HEADER_ROW, col).value: col for col in range(1, 100) if ws.cell(OD_HEADER_ROW, col).value}
    gfp_idx = {ws.cell(GFP_HEADER_ROW, col).value: col for col in range(1, 100) if ws.cell(GFP_HEADER_ROW, col).value}

    by_well = []
    summary = []
    chart_rows = []
    for read_no in range(1, N_READS + 1):
        od_row = OD_FIRST_ROW + read_no - 1
        gfp_row = GFP_FIRST_ROW + read_no - 1
        time_value = ws.cell(od_row, 2).value
        time_text = excel_time_to_text(time_value)
        time_hours = excel_time_to_hours(time_value)

        row_summary = {"read": read_no, "time_text": time_text, "time_hours": time_hours}
        chart_row = {"read": read_no, "time_text": time_text, "time_hours": time_hours}
        for spec in SERIES:
            condition = spec["condition"]
            construct = spec["construct"]
            sample_col = spec["sample_col"]
            control_col = spec["control_col"]
            series_name = f"{condition} | {construct}"
            well_ratios = []
            sample_ods = []
            control_ods = []
            sample_gfps = []
            control_gfps = []
            for row_name in ROWS:
                sample_well = f"{row_name}{sample_col}"
                control_well = f"{row_name}{control_col}"
                od_raw = ws.cell(od_row, od_idx[sample_well]).value
                od_control = ws.cell(od_row, od_idx[control_well]).value
                gfp_raw = ws.cell(gfp_row, gfp_idx[sample_well]).value
                gfp_control = ws.cell(gfp_row, gfp_idx[control_well]).value
                od_corrected = od_raw - od_control
                gfp_corrected = gfp_raw - gfp_control
                normalized = safe_ratio(gfp_corrected, od_corrected)
                if normalized is not None:
                    well_ratios.append(normalized)
                sample_ods.append(od_raw)
                control_ods.append(od_control)
                sample_gfps.append(gfp_raw)
                control_gfps.append(gfp_control)
                by_well.append(
                    [
                        read_no,
                        time_text,
                        round(time_hours, 4),
                        condition,
                        construct,
                        sample_well,
                        control_well,
                        od_raw,
                        od_control,
                        od_corrected,
                        gfp_raw,
                        gfp_control,
                        gfp_corrected,
                        normalized,
                    ]
                )

            mean_od_corrected = mean(sample_ods) - mean(control_ods)
            mean_gfp_corrected = mean(sample_gfps) - mean(control_gfps)
            normalized_from_means = safe_ratio(mean_gfp_corrected, mean_od_corrected)
            ratio_sd = stdev(well_ratios) if len(well_ratios) > 1 else None
            summary.extend(
                [
                    [
                        read_no,
                        time_text,
                        round(time_hours, 4),
                        condition,
                        construct,
                        mean(sample_ods),
                        mean(control_ods),
                        mean_od_corrected,
                        mean(sample_gfps),
                        mean(control_gfps),
                        mean_gfp_corrected,
                        normalized_from_means,
                        mean(well_ratios) if well_ratios else None,
                        ratio_sd,
                        len(well_ratios),
                    ]
                ]
            )
            row_summary[series_name] = normalized_from_means
            chart_row[series_name] = normalized_from_means if mean_od_corrected > OD_PLOT_THRESHOLD else None
        chart_rows.append(chart_row)
    return source, by_well, summary, chart_rows


def make_png(chart_rows, png_path: Path) -> None:
    width, height = 1400, 820
    margin_left, margin_right, margin_top, margin_bottom = 125, 330, 110, 110
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    try:
        title_font = ImageFont.truetype("arial.ttf", 30)
        axis_font = ImageFont.truetype("arial.ttf", 20)
        small_font = ImageFont.truetype("arial.ttf", 18)
    except OSError:
        title_font = axis_font = small_font = ImageFont.load_default()

    names = [f"{spec['condition']} | {spec['construct']}" for spec in SERIES]
    values = [row[name] for row in chart_rows for name in names if row[name] is not None]
    x_values = [row["time_hours"] for row in chart_rows]
    x_min, x_max = min(x_values), max(x_values)
    y_min = 0
    y_max = max(values) if values else 1
    y_pad = y_max * 0.08 or 1
    y_max += y_pad

    def sx(x):
        return margin_left + (x - x_min) / (x_max - x_min) * plot_w

    def sy(y):
        return margin_top + (y_max - y) / (y_max - y_min) * plot_h

    draw.text((margin_left, 28), "Normalized GFP signal after matched control subtraction", fill="#1F2937", font=title_font)
    draw.text((margin_left, 68), f"Plot excludes points where mean corrected OD595 <= {OD_PLOT_THRESHOLD:g}", fill="#4B5563", font=small_font)

    for i in range(6):
        y = y_min + i * (y_max - y_min) / 5
        yy = sy(y)
        draw.line((margin_left, yy, margin_left + plot_w, yy), fill="#E5E7EB", width=1)
        draw.text((20, yy - 10), f"{y:,.0f}", fill="#374151", font=small_font)
    for x in range(0, 18, 3):
        xx = sx(x)
        draw.line((xx, margin_top, xx, margin_top + plot_h), fill="#F3F4F6", width=1)
        draw.text((xx - 18, margin_top + plot_h + 18), str(x), fill="#374151", font=small_font)
    draw.line((margin_left, margin_top + plot_h, margin_left + plot_w, margin_top + plot_h), fill="#111827", width=2)
    draw.line((margin_left, margin_top, margin_left, margin_top + plot_h), fill="#111827", width=2)
    draw.text((margin_left + plot_w / 2 - 70, height - 55), "Time (hours)", fill="#111827", font=axis_font)
    y_label = Image.new("RGBA", (220, 38), (255, 255, 255, 0))
    y_draw = ImageDraw.Draw(y_label)
    y_draw.text((0, 0), "RFU / OD595", fill="#111827", font=axis_font)
    image.paste(y_label.rotate(90, expand=True), (22, margin_top + plot_h // 2 - 110), y_label.rotate(90, expand=True))

    colors = ["#2563EB", "#F97316", "#16A34A", "#9333EA", "#DC2626", "#0891B2"]
    for idx, name in enumerate(names):
        points = []
        for row in chart_rows:
            y = row[name]
            points.append(None if y is None else (sx(row["time_hours"]), sy(y)))
        segment = []
        for point in points + [None]:
            if point is None:
                if len(segment) > 1:
                    draw.line(segment, fill=colors[idx], width=4, joint="curve")
                for px, py in segment:
                    draw.ellipse((px - 4, py - 4, px + 4, py + 4), fill=colors[idx])
                segment = []
            else:
                segment.append(point)
        leg_x = margin_left + plot_w + 45
        leg_y = margin_top + idx * 36
        draw.line((leg_x, leg_y + 10, leg_x + 34, leg_y + 10), fill=colors[idx], width=4)
        draw.text((leg_x + 45, leg_y), name, fill="#111827", font=small_font)
    image.save(png_path)


def write_workbook(source, by_well, summary, chart_rows, out_path: Path, png_path: Path) -> None:
    workbook = xlsxwriter.Workbook(out_path)
    title_fmt = workbook.add_format({"bold": True, "font_size": 15, "font_color": "white", "bg_color": "#1F4E79", "align": "center"})
    header_fmt = workbook.add_format({"bold": True, "bg_color": "#D9EAF7", "border": 1, "align": "center", "valign": "vcenter", "text_wrap": True})
    text_fmt = workbook.add_format({"border": 1})
    num3_fmt = workbook.add_format({"border": 1, "num_format": "0.000"})
    num1_fmt = workbook.add_format({"border": 1, "num_format": "#,##0.0"})
    int_fmt = workbook.add_format({"border": 1, "num_format": "#,##0"})
    note_fmt = workbook.add_format({"italic": True, "font_color": "#666666", "text_wrap": True})

    ws = workbook.add_worksheet("Read me")
    ws.hide_gridlines(2)
    ws.merge_range("A1:F1", "YOSSI 13.8.26 normalized starvation detector analysis", title_fmt)
    notes = [
        ["Source workbook", str(source)],
        ["Used wells", "Rows B-G; plate columns 2-10. Empty wells were ignored."],
        ["Normalization", "(GFP_sample - GFP_matched_control) / (OD595_sample - OD595_matched_control)."],
        ["Matched controls", "M9 columns 2/3 use column 4 control; 0.5 M9 columns 5/6 use column 7 control; M9 -P columns 8/9 use column 10 control."],
        ["Chart rule", f"Curves leave points blank when mean corrected OD595 <= {OD_PLOT_THRESHOLD:g}, because division by near-zero growth creates non-biological spikes."],
    ]
    ws.write_row(2, 0, ["Field", "Value"], header_fmt)
    for r, row in enumerate(notes, start=3):
        ws.write(r, 0, row[0], text_fmt)
        ws.write(r, 1, row[1], note_fmt)
    ws.set_column("A:A", 22)
    ws.set_column("B:F", 34)

    map_ws = workbook.add_worksheet("Well map")
    map_ws.hide_gridlines(2)
    map_ws.merge_range("A1:J1", "Labeled wells used for analysis", title_fmt)
    map_ws.write_row("A2", ["Row", "M9", "", "", "0.5 M9", "", "", "M9 -P", "", ""], header_fmt)
    map_ws.write_row("A3", ["", "puxpA", "puxpB", "Cont", "puxpA", "puxpB", "Cont", "puxpA", "puxpB", "Cont"], header_fmt)
    for i, row_name in enumerate(ROWS, start=3):
        map_ws.write(i, 0, row_name, header_fmt)
        for j, col in enumerate(range(2, 11), start=1):
            map_ws.write(i, j, f"{row_name}{col}", text_fmt)
    map_ws.set_column("A:J", 13)

    summary_ws = workbook.add_worksheet("Normalized summary")
    summary_ws.hide_gridlines(2)
    summary_headers = [
        "Read",
        "Time",
        "Hours",
        "Condition",
        "Construct",
        "Mean OD sample",
        "Mean OD control",
        "OD corrected",
        "Mean GFP sample",
        "Mean GFP control",
        "GFP corrected",
        "Normalized from means",
        "Mean well-normalized",
        "SD well-normalized",
        "N",
    ]
    summary_ws.write_row(0, 0, summary_headers, header_fmt)
    for r, row in enumerate(summary, start=1):
        for c, value in enumerate(row):
            if value is None:
                summary_ws.write_blank(r, c, None, text_fmt)
            elif c in {5, 6, 7}:
                summary_ws.write_number(r, c, value, num3_fmt)
            elif c in {8, 9, 10, 11, 12, 13}:
                summary_ws.write_number(r, c, value, num1_fmt)
            elif c in {0, 14}:
                summary_ws.write_number(r, c, value, int_fmt)
            else:
                summary_ws.write(r, c, value, text_fmt)
    summary_ws.autofilter(0, 0, len(summary), len(summary_headers) - 1)
    summary_ws.freeze_panes(1, 0)
    summary_ws.set_column("A:A", 8)
    summary_ws.set_column("B:E", 14)
    summary_ws.set_column("F:O", 18)

    well_ws = workbook.add_worksheet("Normalized by well")
    well_ws.hide_gridlines(2)
    well_headers = [
        "Read",
        "Time",
        "Hours",
        "Condition",
        "Construct",
        "Sample well",
        "Control well",
        "OD raw",
        "OD control",
        "OD corrected",
        "GFP raw",
        "GFP control",
        "GFP corrected",
        "Normalized GFP/OD",
    ]
    well_ws.write_row(0, 0, well_headers, header_fmt)
    for r, row in enumerate(by_well, start=1):
        for c, value in enumerate(row):
            if value is None:
                well_ws.write_blank(r, c, None, text_fmt)
            elif c in {7, 8, 9}:
                well_ws.write_number(r, c, value, num3_fmt)
            elif c in {10, 11, 12, 13}:
                well_ws.write_number(r, c, value, num1_fmt)
            elif c == 0:
                well_ws.write_number(r, c, value, int_fmt)
            else:
                well_ws.write(r, c, value, text_fmt)
    well_ws.autofilter(0, 0, len(by_well), len(well_headers) - 1)
    well_ws.freeze_panes(1, 0)
    well_ws.set_column("A:A", 8)
    well_ws.set_column("B:G", 14)
    well_ws.set_column("H:N", 18)

    chart_ws = workbook.add_worksheet("Curves")
    chart_ws.hide_gridlines(2)
    names = [f"{spec['condition']} | {spec['construct']}" for spec in SERIES]
    chart_ws.merge_range(0, 0, 0, len(names) + 2, "Chart-ready normalized curves", title_fmt)
    chart_ws.write_row(2, 0, ["Read", "Time", "Hours"] + names, header_fmt)
    for r, row in enumerate(chart_rows, start=3):
        chart_ws.write_number(r, 0, row["read"], int_fmt)
        chart_ws.write(r, 1, row["time_text"], text_fmt)
        chart_ws.write_number(r, 2, row["time_hours"], num3_fmt)
        for c, name in enumerate(names, start=3):
            value = row[name]
            if value is None:
                chart_ws.write_blank(r, c, None, text_fmt)
            else:
                chart_ws.write_number(r, c, value, num1_fmt)
    chart_ws.set_column("A:A", 8)
    chart_ws.set_column("B:B", 13)
    chart_ws.set_column("C:I", 18)
    chart_ws.write(23, 0, f"Blank chart cells indicate corrected OD595 <= {OD_PLOT_THRESHOLD:g}. Full unfiltered values are in 'Normalized summary'.", note_fmt)
    chart_ws.insert_image("A25", str(png_path), {"x_scale": 0.58, "y_scale": 0.58})

    chart = workbook.add_chart({"type": "line"})
    for c, name in enumerate(names, start=3):
        chart.add_series(
            {
                "name": ["Curves", 2, c],
                "categories": ["Curves", 3, 2, 20, 2],
                "values": ["Curves", 3, c, 20, c],
                "line": {"width": 2.25},
                "marker": {"type": "circle", "size": 4},
            }
        )
    chart.set_title({"name": "Normalized GFP/OD after matched control subtraction"})
    chart.set_x_axis({"name": "Time (hours)", "major_gridlines": {"visible": False}})
    chart.set_y_axis({"name": "Corrected GFP / corrected OD595", "major_gridlines": {"visible": True}})
    chart.set_legend({"position": "right"})
    chart.set_size({"width": 980, "height": 520})
    chart_ws.insert_chart("K3", chart)

    workbook.close()


def main() -> None:
    out_dir = Path.home() / ".codex" / PROJECT / "starvation"
    source, by_well, summary, chart_rows = read_source()
    png_path = out_dir / PNG_NAME
    out_path = out_dir / OUT_NAME
    make_png(chart_rows, png_path)
    write_workbook(source, by_well, summary, chart_rows, out_path, png_path)
    print(str(out_path).encode("unicode_escape").decode("ascii"))
    print(str(png_path).encode("unicode_escape").decode("ascii"))
    print("well_rows", len(by_well), "summary_rows", len(summary), "chart_reads", len(chart_rows))


if __name__ == "__main__":
    main()
