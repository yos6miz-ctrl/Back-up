import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const STARTER = path.join(__dirname, "template-starter.pptx");
const OUTPUT = "C:\\Users\\Popovtzer lab\\.codex\\Teads\\Teads_Part_2_3_Executive_Presentation_20min_revised.pptx";
const PREVIEW_DIR = path.join(__dirname, "final-preview");
const LAYOUT_DIR = path.join(__dirname, "final-layout");
const LOGO_PATH = path.join(__dirname, "assets", "teads-logo-white.png");

const SOURCE_DOC =
  "C:\\Users\\Popovtzer lab\\.codex\\Teads\\Teads_TA_Interview_Assignment edited moran - clean - final English.docx";
const LOGO_URL = "https://www.teads.com/wp-content/uploads/2026/07/Teads-logo-white-SVG.svg";
const URL_ROLE = "https://job-boards.eu.greenhouse.io/teads1/jobs/4924757101";
const URL_ENGINEERING = "https://engineering.teads.com/join-us/";
const URL_MERGER = "https://www.teads.com/blog/teads-outbrain-merge/2954/";
const URL_REBRAND =
  "https://investors.teads.com/news-releases/news-release-details/outbrain-completes-change-corporate-name-teads";
const URL_GEM = "https://www.gem.com/recruiting-benchmarks";
const URL_AWSUG = "https://www.meetup.com/aws-user-group-israel/";
const URL_DEVOPSDAYS = "https://devopsdays.org/events/2025-tel-aviv/";

const NAVY = "#08132D";
const WHITE = "#FFFFFF";

async function readBytes(filePath) {
  const bytes = await fs.readFile(filePath);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

let inspectRecords = [];

async function resolveText(
  presentation,
  slideNumber,
  query,
  { exact = false, minLeft = -Infinity, minTop = -Infinity, occurrence = 0 } = {},
) {
  const candidates = inspectRecords.filter((element) => {
    const text = String(element.text ?? element.textPreview ?? "");
    const bbox = element.bbox ?? [0, 0, 0, 0];
    const textMatch = exact ? text === query : text.includes(query);
    return (
      element.kind === "textbox" &&
      element.slide === slideNumber &&
      textMatch &&
      bbox[0] >= minLeft &&
      bbox[1] >= minTop
    );
  });
  if (candidates.length <= occurrence) {
    throw new Error(
      `Could not resolve text "${query}" on slide ${slideNumber}; found ${candidates.length}.`,
    );
  }
  return presentation.resolve(candidates[occurrence].id);
}

async function setText(presentation, slideNumber, query, replacement, options = {}) {
  const target = await resolveText(presentation, slideNumber, query, options);
  target.text = replacement;
  return target;
}

async function setPageNumber(presentation, slideNumber, oldNumber, newNumber) {
  const target = await resolveText(presentation, slideNumber, oldNumber, {
    exact: true,
    minLeft: 1100,
    minTop: 650,
  });
  target.text = newNumber;
}

function setNotes(slide, timing, presenterNotes, assumptions, sources) {
  slide.speakerNotes.clear();
  slide.speakerNotes.textFrame.setText(
    `[Timing] ${timing}\n\n[Presenter notes]\n${presenterNotes}\n\n[Assumptions]\n${assumptions}\n\n[Sources]\n${sources
      .map((source) => `- ${source}`)
      .join("\n")}`,
  );
  slide.speakerNotes.setVisible(true);
}

async function addLogo(slide, isDark, logoBytes) {
  if (!isDark) {
    slide.shapes.add({
      geometry: "roundRect",
      name: "teads-logo-plaque",
      position: { left: 1098, top: 22, width: 126, height: 42 },
      fill: NAVY,
      line: { style: "solid", fill: NAVY, width: 0 },
      borderRadius: 8,
    });
  }
  slide.images.add({
    blob: logoBytes,
    contentType: "image/png",
    name: "official-teads-wordmark",
    alt: "Official Teads wordmark",
    fit: "contain",
    position: { left: 1113, top: 29, width: 96, height: 28 },
  });
}

const presentation = await PresentationFile.importPptx(await FileBlob.load(STARTER));
const logoBytes = await readBytes(LOGO_PATH);
const beforeInspect = await presentation.inspect({
  kind: "textbox",
  maxChars: 200000,
});
inspectRecords = beforeInspect.ndjson
  .split(/\r?\n/)
  .filter(Boolean)
  .map((line) => JSON.parse(line));

// Slide 2 — requested funnel-first overview.
await setText(presentation, 2, "PART 2", "PART 2 • FUNNEL OVERVIEW");
await setText(
  presentation,
  2,
  "Product owns",
  "Product / R&D pass-through rates",
);
await setText(
  presentation,
  2,
  "The target is within reach",
  "Both tracks deliver three accepts—but the constraint is different.",
);
await setText(presentation, 2, "5.8", "44%");
const slide2ProductLabel = await setText(
  presentation,
  2,
  "forecast accepts",
  "Product: panel → offer",
);
slide2ProductLabel.position = { left: 80, top: 314, width: 320, height: 54 };
slide2ProductLabel.text.style = {
  fontSize: 22,
  bold: true,
  color: "#101935",
};
const slide2RndLabel = await setText(
  presentation,
  2,
  "against a target",
  "R&D: panel → offer = 33%",
);
slide2RndLabel.position = { left: 80, top: 372, width: 320, height: 28 };
slide2RndLabel.text.style = { fontSize: 18, color: "#667085" };
await setText(presentation, 2, "−0.2", "");
await setText(
  presentation,
  2,
  "Product is 0.4",
  "Product funnel: 100 → 32 → 18 → 9 → 4 → 3 accepts.",
);
await setText(
  presentation,
  2,
  "R&D needs 40%",
  "R&D funnel: 140 → 42 → 24 → 12 → 4 → 3 accepts.",
);
await setText(
  presentation,
  2,
  "Panel → offer",
  "Largest loss: panel → offer—Product 44%; R&D 33%.",
);
await setText(presentation, 2, "Leadership implication", "Bottom line");
await setText(
  presentation,
  2,
  "Improve sourcing quality",
  "Product needs stronger conversion; R&D needs a broader qualified pool.",
);
await setText(
  presentation,
  2,
  "Source: assignment model",
  "Assumptions: illustrative target state • validate with Greenhouse/HRIS",
);
await setPageNumber(presentation, 2, "02", "02");

// Slide 3 — simplified action plan.
await setText(presentation, 3, "PART 2", "PART 2 • ACTION PLAN");
await setText(
  presentation,
  3,
  "Product owns",
  "Action plan: close the gap without more interviews",
);
await setText(
  presentation,
  3,
  "The target is within reach",
  "Three moves, three owners, one 30-day operating cadence.",
);
await setText(presentation, 3, "5.8", "30");
await setText(presentation, 3, "forecast accepts", "day action plan");
await setText(presentation, 3, "against a target", "baseline → act → review");
await setText(presentation, 3, "−0.2", "");
await setText(
  presentation,
  3,
  "Product is 0.4",
  "Recruiting: move one Product candidate to a final panel.",
);
await setText(
  presentation,
  3,
  "R&D needs 40%",
  "Engineering/Product: protect interview pods; decide within 48h.",
);
await setText(
  presentation,
  3,
  "Panel → offer",
  "TA + P&C: replace illustrative figures with ATS/HRIS baselines.",
);
await setText(presentation, 3, "Leadership implication", "Success measure");
await setText(
  presentation,
  3,
  "Improve sourcing quality",
  "Six accepted hires with fewer queues—not more process.",
);
await setText(
  presentation,
  3,
  "Source: assignment model",
  "Assumptions: 30-day pilot • owners and SLAs require leadership agreement",
);
await setPageNumber(presentation, 3, "02", "03");

// Slide 4 — clearer weekly operating view.
await setText(
  presentation,
  4,
  "One weekly view",
  "Use one weekly view to find the next action",
);
await setText(
  presentation,
  4,
  "Five business questions",
  "Read it in five steps: plan → pipeline → queues → effort → outcome.",
);
await setText(presentation, 4, "SPEED", "PLAN");
await setText(
  presentation,
  4,
  "Open roles",
  "Open roles • target • forecast • days open",
);
await setText(presentation, 4, "Are we hiring fast enough?", "Are we on plan?");
await setText(presentation, 4, "SUPPLY", "PIPELINE");
await setText(
  presentation,
  4,
  "Candidates by stage",
  "Candidates by stage • coverage • source yield",
);
await setText(
  presentation,
  4,
  "Do we have enough",
  "Where is qualified supply thin?",
);
await setText(presentation, 4, "WAIT", "QUEUES");
await setText(
  presentation,
  4,
  "Days in stage",
  "Days in stage • scheduling • feedback",
);
await setText(
  presentation,
  4,
  "Where are candidates waiting?",
  "Where are candidates waiting?",
);
await setText(
  presentation,
  4,
  "Interviews and interviewer",
  "Interviewer hours • duplicate testing",
);
await setText(presentation, 4, "Are we using time well?", "Where is work duplicated?");
await setText(presentation, 4, "QUALITY", "RESULT");
await setText(
  presentation,
  4,
  "Acceptance",
  "Offer acceptance • 90-day quality",
);
await setText(presentation, 4, "Are we making strong hires?", "Are we hiring well?");
await setText(
  presentation,
  4,
  "Probability-weighted forecast",
  "Decision rule",
);
await setText(
  presentation,
  4,
  "Count each active candidate",
  "Find the red stage. Name one owner, one action and one due date.",
);
await setText(
  presentation,
  4,
  "stage",
  "forecast = stage × track × location × source",
  { minLeft: 700, minTop: 300 },
);
await setText(
  presentation,
  4,
  "Assumptions to replace",
  "Assumptions to validate",
);
await setText(
  presentation,
  4,
  "2 recruiters",
  "• 2 recruiters × 3 accepts / month\n• 30-day requisition target\n• 24h feedback • 48h decisions\n• 80% acceptance; pauses excluded",
);
await setText(
  presentation,
  4,
  "Source: assignment model",
  "Assumptions: assignment model • replace with Teads ATS/HRIS baselines",
);
await setPageNumber(presentation, 4, "03", "04");

// Slide 5 — explicit point, gap and action.
await setText(
  presentation,
  5,
  "The gap sits",
  "The forecast directs attention to Product",
);
await setText(
  presentation,
  5,
  "Each recruiter owns",
  "Product is 0.4 below target; R&D has 0.2 headroom.",
);
await setText(
  presentation,
  5,
  "combined probability",
  "forecast accepts versus a target of six",
);
await setText(presentation, 5, "Action this week", "Bottom line");
await setText(
  presentation,
  5,
  "Move one more Product",
  "Move one more Product candidate to final panel.",
);
await setText(
  presentation,
  5,
  "Decision within 24h",
  "Gap: one panel-ready candidate. Decide within 48h.",
);
await setText(
  presentation,
  5,
  "Protect interview slots",
  "No hiring gap. Protect capacity and close expectations early.",
);
await setText(presentation, 5, "Plain English", "How to read it");
await setText(
  presentation,
  5,
  "Forecast = active candidates",
  "5.8 forecast accepts vs 6.0 target; act where likelihood is lowest.",
);
await setText(
  presentation,
  5,
  "Source: assignment model",
  "Assumptions: illustrative forecast • replace with comparable Teads history",
);
await setPageNumber(presentation, 5, "04", "05");

// Update preserved Part 2 slide assumptions and sequence numbers.
await setText(
  presentation,
  6,
  "Source: assignment model",
  "Assumptions: illustrative Product funnel • validate with Teads ATS",
);
const productPanelOfferMetric = await resolveText(presentation, 6, "44%", {
  exact: true,
  minLeft: 800,
  minTop: 190,
});
productPanelOfferMetric.position = { left: 902, top: 205, width: 130, height: 60 };
productPanelOfferMetric.text.style = {
  fontSize: 44,
  bold: true,
  color: "#FF6B6F",
};
await setPageNumber(presentation, 6, "05", "06");
await setText(
  presentation,
  7,
  "Source: assignment model",
  "Assumptions: illustrative R&D funnel • validate with Teads ATS",
);
await setPageNumber(presentation, 7, "06", "07");
await setText(
  presentation,
  8,
  "Source: assignment model",
  "Assumptions: illustrative country rates • validate by hub and source",
);
await setPageNumber(presentation, 8, "07", "08");
await setText(
  presentation,
  9,
  "External benchmark cited",
  "Assumptions: external benchmark is directional • diagnose with Teads data",
);
await setPageNumber(presentation, 9, "08", "09");

// Slide 10 — requested employer-brand transition.
await setText(presentation, 10, "PARTS 2 + 3", "PART 3");
await setText(
  presentation,
  10,
  "Hiring efficiency",
  "Employer brand\nthat earns\ntechnical trust",
);
await setText(
  presentation,
  10,
  "Executive presentation",
  "Turn Teads’ engineering proof into clarity, community credibility and qualified technical hires.",
);
const slide10Marker = await setText(presentation, 10, "20 MINUTES", "10");
slide10Marker.position = { left: 1164, top: 676, width: 52, height: 24 };
slide10Marker.text.style = {
  fontSize: 12,
  bold: true,
  color: "#93A2C6",
  alignment: "right",
};
await setText(
  presentation,
  10,
  "Illustrative target state",
  "Assumption: recommended Part 3 direction • validate with employees and talent data",
);

// Slide 11 — clarify what the employer-brand evidence proves.
await setText(
  presentation,
  11,
  "Engineering proof",
  "Technical scale is the employer-brand proof",
);
await setText(
  presentation,
  11,
  "Candidates can already see",
  "Scale proves complexity. Ownership makes it credible.",
);
await setText(
  presentation,
  11,
  "The differentiator",
  "Evidence candidates can verify:",
);
await setText(presentation, 11, "Candidate promise", "What the slide proves");
await setText(
  presentation,
  11,
  "You build it",
  "Teads can differentiate on real technical scope—not generic perks.",
);
await setText(
  presentation,
  11,
  "Public role materials",
  "Assumptions: public scale claims • validate figures before external use",
);
const latencyMetric = await resolveText(presentation, 11, "<150ms", { exact: true });
latencyMetric.position = { left: 336, top: 298, width: 280, height: 100 };
latencyMetric.text.style = {
  fontSize: 64,
  bold: true,
  color: "#1BA39C",
};
await setPageNumber(presentation, 11, "09", "11");

// Slide 12 — roadmap marker and assumption footer.
await setText(
  presentation,
  12,
  "Leading indicators",
  "Assumptions: proposed roadmap and KPIs • validate owners, budget and capacity",
);
await setPageNumber(presentation, 12, "10", "12");

// Slide 13 — explain the 150ms Lab in plain language.
await setText(
  presentation,
  13,
  "The 150ms Lab turns",
  "The 150ms Lab is an event—not a candidate test",
);
await setText(
  presentation,
  13,
  "A community learning",
  "Purpose: demonstrate real engineering work, build trust and create opt-in leads.",
);
await setText(
  presentation,
  13,
  "Keep a mocked ad request",
  "What it is: a hands-on reliability workshop using a mocked ad request and failure scenarios.",
);
await setText(
  presentation,
  13,
  "Quarterly",
  "Quarterly • opt-in • no assessment",
);
await setText(
  presentation,
  13,
  "Source: assignment model",
  "Assumptions: proposed pilot • opt-in only • no candidate assessment",
);
await setPageNumber(presentation, 13, "11", "13");

// Slide 14 — clarify the decision being requested.
await setText(
  presentation,
  14,
  "Three commitments",
  "What I am asking leaders to approve today",
);
await setText(
  presentation,
  14,
  "A 30-day pilot",
  "Three 30-day commitments, each with a named owner.",
);
await setText(
  presentation,
  14,
  "Decision question",
  "Decision: approve the 30-day pilot and assign these three owners?",
);
await setText(
  presentation,
  14,
  "Outcome:",
  "Assumptions: proposed owners and SLAs • confirm in the meeting",
);
await setPageNumber(presentation, 14, "12", "14");

// Add the requested official Teads wordmark consistently.
const darkSlides = new Set([1, 10, 11, 14]);
for (let index = 0; index < presentation.slides.items.length; index += 1) {
  await addLogo(presentation.slides.items[index], darkSlides.has(index + 1), logoBytes);
}

// Exact presenter scripts for the final 20-minute sequence.
setNotes(
  presentation.slides.items[0],
  "1:00",
  "I will focus on two questions. First, where does the technical hiring funnel lose time or conversion? Second, how can Teads turn real engineering work into a stronger talent story? The numbers in this deck are an illustrative operating model, not reported Teads ATS performance. The recommendation is to use the same measurement discipline for Product and R&D, while applying different interventions to each track. Product needs better late-stage conversion. R&D needs broader qualified supply and faster technical decisions. Part 3 then connects those improvements to a credible employer brand.",
  "All funnel, forecast and timing figures are illustrative until replaced with Teads Greenhouse/HRIS baselines.",
  [
    `${SOURCE_DOC}, pages 7–13.`,
    `Official Teads wordmark: ${LOGO_URL}`,
    "Background visual: original OpenAI-generated asset already present in the source deck.",
  ],
);

setNotes(
  presentation.slides.items[1],
  "1:45",
  "I want to begin with the funnels because they make the difference between Product and R&D immediately visible. Product starts with 100 qualified leads and reaches three accepts. R&D needs 140 qualified leads to reach the same three accepts. The most important pass-through rate is panel to offer: 44 percent for Product and 33 percent for R&D. This means the two tracks should not receive the same intervention. Product needs stronger evidence and calibration at the final decision point. R&D needs a wider, skills-based sourcing pool before it reaches the interview process. Both tracks assume a 75 percent offer-to-accept rate. The bottom line is the same hiring outcome, but a different constraint.",
  "Counts and pass-through rates are illustrative target-state values derived from the assignment model.",
  [
    `${SOURCE_DOC}, Product and R&D funnel sections, pages 9–10.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[2],
  "1:30",
  "The action plan is intentionally small. First, Recruiting moves one additional qualified Product candidate to a final panel. Second, Engineering and Product leadership protect weekly interview capacity and complete the final decision within 48 hours. Third, TA and P&C replace every illustrative figure with the actual ATS and HRIS baseline. I would run this as a 30-day pilot with one weekly review. Success is not more candidate activity. Success is six accepted hires with fewer queues, fewer repeated interviews and a clearer decision owner.",
  "The 30-day cadence, named owners and SLAs are proposed actions that require leadership agreement.",
  [
    `${SOURCE_DOC}, pages 7–11.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[3],
  "1:30",
  "This slide is the weekly control view. Read it from top to bottom. Plan shows whether open roles and forecast are aligned with the target. Pipeline shows whether each track has enough qualified candidates. Queues show where candidates are waiting for scheduling, feedback or a decision. Effort tells us whether interview time is being duplicated. Outcome connects offer acceptance and early quality signals. The right-hand rule explains how to use the data: identify the red stage, name one owner, choose one action and set one due date. The formula weights each candidate once at the most advanced stage, using comparable historical outcomes.",
  "Two recruiters, six monthly accepts, 30-day requisitions, 24-hour feedback, 48-hour decisions and 80 percent acceptance are illustrative assumptions.",
  [
    `${SOURCE_DOC}, measurement and forecasting sections, pages 7–8.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[4],
  "1:45",
  "This is the management conclusion from the forecast. The combined probability-weighted forecast is 5.8 accepts against a target of six. The gap is not evenly distributed. Product is forecast at 2.6 against three, while R&D is forecast at 3.2 against three. Therefore, the immediate action is one more panel-ready Product candidate, followed by a decision within 48 hours. R&D does not need extra process; it needs protected capacity and early alignment on motivation, work model and offer expectations. In plain language, the forecast is not a measure of recruiter busyness. It tells us where the current candidate portfolio is least likely to convert.",
  "Forecast values are illustrative and require stage-, role-, location- and source-level Teads history.",
  [
    `${SOURCE_DOC}, forecast section, page 7.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[5],
  "1:30",
  "For Product, the funnel starts with 100 qualified leads and ends with three accepts. The largest loss is from panel to offer, where only four of nine candidates progress. The practical fixes are to cap the case or live exercise at 90 minutes, pre-book the full panel, use one anchored rubric, debrief on the same day and approve within 48 hours. The point is not to lower the bar. It is to make the evidence requirement clear and prevent repeated assessment. If the stages flow without queues, the designed elapsed time is about 31 calendar days.",
  "Product counts, pass-through rates and stage times are illustrative target-state values.",
  [
    `${SOURCE_DOC}, Product funnel, page 9.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[6],
  "1:30",
  "R&D reaches the same three accepts from a larger starting pool of 140 qualified leads. That is the signal to search by technical evidence rather than exact job title: cloud infrastructure, networking, Kubernetes, distributed systems and production ownership. The panel-to-offer rate is 33 percent, so calibration and decision speed still matter. I would use one 60-minute production scenario, reserve cross-hub interviewer pods and avoid an extra round unless a clearly defined competency is missing. With those conditions, the designed elapsed time is about 34 calendar days.",
  "R&D counts, pass-through rates and stage times are illustrative target-state values.",
  [
    `${SOURCE_DOC}, R&D funnel, page 10.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[7],
  "1:15",
  "The process should use one stage definition across locations, but the candidate journey should respond to local friction. In Netanya, the likely issue is commute and hybrid clarity, so cadence should be disclosed before the first screen. In France, language and home-hub expectations need to be explicit. In Slovenia, the senior platform pool is smaller, so referrals and adjacent Central European talent become more important. The management rule is to diagnose the stage and location of the drop-off before changing the whole process.",
  "Country pass-through values and local drop-off hypotheses are illustrative and require validation by hub, role and source.",
  [
    `${SOURCE_DOC}, location analysis in Part 2.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[8],
  "1:30",
  "These are the four operating fixes I would prioritize. Calibration creates a shared definition of the role and the evidence required. Skills-based sourcing expands rare platform pools beyond exact titles. A single competency map prevents interview inflation and repeated testing. Reserved cross-hub pods remove scheduling as a hidden queue. I would make the rhythm visible: weekly track review, protected panels, feedback within 24 hours, final decisions within 48 hours and one monthly calibration session. The external interviews-per-hire benchmark is directional; the first step is to compare it with Teads interviewer-hour data.",
  "The external benchmark is directional. Teads should diagnose the actual issue with internal interviewer-hour and stage-time data.",
  [
    `${SOURCE_DOC}, operating-model section, page 11.`,
    `Benchmark referenced in the assignment: ${URL_GEM}`,
    `Teads role scope: ${URL_ROLE}`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[9],
  "0:30",
  "Part 2 improved the mechanics of hiring. Part 3 addresses the candidate reason to engage. The employer-brand recommendation is to lead with technical proof, then build trusted employee voices and reciprocal community activity. The objective is not awareness alone. It is qualified technical interest that can be attributed through the recruiting funnel.",
  "This section is a recommended direction derived from the assignment; priorities should be validated with employees and local talent data.",
  [
    `${SOURCE_DOC}, Part 3, pages 12–13.`,
    `Official Teads wordmark: ${LOGO_URL}`,
    "Background visual: original OpenAI-generated asset already present in the source deck.",
  ],
);

setNotes(
  presentation.slides.items[10],
  "1:30",
  "This slide should be read as evidence, not as advertising language. The four figures describe the technical problem candidates would work on: roughly two million ad requests per second, a response target below 150 milliseconds, around 100 billion events per day and 18 million predictions per second. The second part is ownership: engineers build, run and monitor the systems. Together, scale and ownership are more distinctive than generic office or perk messages. Before external publishing, every figure should be revalidated and the post-combination company story should use one approved explanation.",
  "Public engineering-scale figures are directional claims from role materials and must be validated before external use.",
  [
    `${SOURCE_DOC}, employer-brand diagnosis, page 12.`,
    `Technical scale claims: ${URL_ROLE}`,
    `Engineering culture and hubs: ${URL_ENGINEERING}`,
    `Combination context: ${URL_MERGER}`,
    `Corporate rebrand context: ${URL_REBRAND}`,
    `Official Teads wordmark: ${LOGO_URL}`,
    "Background visual: original OpenAI-generated asset already present in the source deck.",
  ],
);

setNotes(
  presentation.slides.items[11],
  "1:30",
  "The employer-brand plan has three waves. In the first 45 days, create clarity: interview employees, publish one post-combination FAQ and rewrite Israel job pages around the technical mission, first-90-day outcomes, work model and interview timing. From 30 to 90 days, add trusted voices through a volunteer ambassador group and honest technical stories. Over three to 12 months, earn community trust through the 150ms Lab, build nights and a possible Netanya fellowship. Each activity must connect to recruiting outcomes: qualified leads, recruiter screens, offers accepted and hires influenced.",
  "The sequencing, owners, budget and KPIs are proposed and require validation.",
  [
    `${SOURCE_DOC}, employer-brand action plan, page 13.`,
    `Potential community partner: ${URL_AWSUG}`,
    `Potential reliability community: ${URL_DEVOPSDAYS}`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[12],
  "1:30",
  "The 150ms Lab is an employer-brand event, not a candidate assessment. Teads engineers introduce a real reliability trade-off using a mocked ad request. Participants work through failure scenarios together and experience how Teads engineers reason about latency, ownership and production risk. Participation and future contact are opt-in. For technical leadership, the value is an honest demonstration of the work. For P&C, the value is a measurable path from event participation to qualified lead, recruiter screen and hire influenced. I would begin with one quarterly pilot and review both experience and conversion data.",
  "The Lab is a proposed pilot. It must remain opt-in and must not be used as a candidate assessment.",
  [
    `${SOURCE_DOC}, pilot concept, page 13.`,
    `Response-time claim: ${URL_ROLE}`,
    `Potential partner: ${URL_AWSUG}`,
    `Potential partner: ${URL_DEVOPSDAYS}`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

setNotes(
  presentation.slides.items[13],
  "1:45",
  "I am asking for three decisions. First, approve one source of truth: replace the illustrative figures with Greenhouse and HRIS baselines and assign metric owners. Second, approve protected decision capacity: weekly Product and R&D interviewer pods, feedback within 24 hours and final decisions within 48 hours. Third, approve one technical talent story: a consistent post-combination narrative supported by real engineering evidence, plus a 150ms Lab pilot. The owners are deliberately different across TA, P&C, Engineering, Product, Communications and DevRel. My closing question is whether we can approve the 30-day pilot and name the three owners today.",
  "The owners, SLAs and 30-day pilot are recommendations that require leadership approval.",
  [
    `${SOURCE_DOC}, pages 7–13.`,
    `Official Teads wordmark: ${LOGO_URL}`,
  ],
);

await fs.mkdir(PREVIEW_DIR, { recursive: true });
await fs.mkdir(LAYOUT_DIR, { recursive: true });

for (const [index, slide] of presentation.slides.items.entries()) {
  const stem = `slide-${String(index + 1).padStart(2, "0")}`;
  await writeBlob(
    path.join(PREVIEW_DIR, `${stem}.png`),
    await presentation.export({ slide, format: "png", scale: 1 }),
  );
  const layout = await slide.export({ format: "layout" });
  await fs.writeFile(path.join(LAYOUT_DIR, `${stem}.layout.json`), await layout.text());
}

await writeBlob(
  path.join(__dirname, "final-montage.webp"),
  await presentation.export({ format: "webp", montage: true, scale: 1 }),
);

const inspect = await presentation.inspect({
  kind: "slide,textbox,shape,image,notes,layout",
  maxChars: 30000,
});
await fs.writeFile(path.join(__dirname, "final-inspect.ndjson"), inspect.ndjson, "utf8");

const outputPptx = await PresentationFile.exportPptx(presentation);
await outputPptx.save(OUTPUT);

console.log(`CREATED ${OUTPUT}`);
console.log(`SLIDES ${presentation.slides.items.length}`);
process.exit(0);
