from __future__ import annotations

from pathlib import Path
from statistics import mean, stdev

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont
import xlsxwriter


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
OUT_NAME = "YOSSI 13.8.26 USE THIS ONE averaged curves.xlsx"
PNG_NAME = "YOSSI 13.8.26 USE THIS ONE averaged curves.png"

SHEET_NAME = "Plate 1 - Sheet1"
TIME_COL = 58  # BF
START_ROW = 4
END_ROW = 21
MARKER_CELL = "BG1"

SERIES = [
    ("M9 | puxpA", [59, 65, 71, 77, 83, 89]),       # BG, BM, BS, BY, CE, CK
    ("M9 | puxpB", [60, 66, 72, 78, 84, 90]),       # BH, BN, BT, BZ, CF, CL
    ("0.5 M9 | puxpA", [61, 67, 73, 79, 85, 91]),   # BI, BO, BU, CA, CG, CM
    ("0.5 M9 | puxpB", [62, 68, 74, 80, 86, 92]),   # BJ, BP, BV, CB, CH, CN
    ("MP -P | puxpA", [63, 69, 75, 81, 87, 93]),    # BK, BQ, BW, CC, CI, CO
    ("MP -P | puxpB", [64, 70, 76, 82, 88, 94]),    # BL, BR, BX, CD, CJ, CP
]


def time_to_text(value) -> str:
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    if isinstance(value, (int, float)):
        total_seconds = round(float(value) * 24 * 3600)
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    return str(value)


def time_to_hours(value) -> float:
    if hasattr(value, "hour") and hasattr(value, "minute") and hasattr(value, "second"):
        return value.hour + value.minute / 60 + value.second / 3600
    if isinstance(value, (int, float)):
        return float(value) * 24
    raise ValueError(f"Unsupported time value: {value!r}")


def read_data():
    source = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE_NAME
    wb = load_workbook(source, data_only=True, read_only=True)
    ws = wb[SHEET_NAME]
    marker = ws[MARKER_CELL].value
    if not isinstance(marker, str) or "USE THIS ONE" not in marker.upper():
        raise ValueError(f"Expected USE THIS ONE marker at {SHEET_NAME}!{MARKER_CELL}")

    averages = []
    replicate_rows = []
    for row_idx in range(START_ROW, END_ROW + 1):
        time_value = ws.cell(row_idx, TIME_COL).value
        record = {
            "read": row_idx - START_ROW + 1,
            "time": time_to_text(time_value),
            "hours": time_to_hours(time_value),
        }
        for name, columns in SERIES:
            values = [ws.cell(row_idx, col).value for col in columns]
            values = [float(v) for v in values if isinstance(v, (int, float))]
            avg = mean(values) if values else None
            sd = stdev(values) if len(values) > 1 else None
            record[f"{name} avg"] = avg
            record[f"{name} sd"] = sd
            record[f"{name} n"] = len(values)
            for replicate_no, col in enumerate(columns, start=1):
                value = ws.cell(row_idx, col).value
                replicate_rows.append(
                    [
                        record["read"],
                        record["time"],
                        round(record["hours"], 4),
                        name,
                        replicate_no,
                        get_column_letter(col),
                        value,
                    ]
                )
        averages.append(record)
    return source, averages, replicate_rows


def make_png(averages, png_path: Path) -> None:
    width, height = 1400, 820
    margin_left, margin_right, margin_top, margin_bottom = 120, 330, 100, 110
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    try:
        title_font = ImageFont.truetype("arial.ttf", 30)
        axis_font = ImageFont.truetype("arial.ttf", 20)
        small_font = ImageFont.truetype("arial.ttf", 18)
    except OSError:
        title_font = axis_font = small_font = ImageFont.load_default()

    names = [name for name, _ in SERIES]
    x_values = [row["hours"] for row in averages]
    y_values = [row[f"{name} avg"] for row in averages for name in names if row[f"{name} avg"] is not None]
    x_min, x_max = min(x_values), max(x_values)
    y_min = min(0, min(y_values))
    y_max = max(y_values)
    y_pad = (y_max - y_min) * 0.08 or 1
    y_min -= y_pad
    y_max += y_pad

    def sx(x):
        return margin_left + (x - x_min) / (x_max - x_min) * plot_w

    def sy(y):
        return margin_top + (y_max - y) / (y_max - y_min) * plot_h

    draw.text((margin_left, 30), "Average normalized signal from USE THIS ONE table", fill="#1F2937", font=title_font)
    draw.text((margin_left, 68), "Each curve is the mean of 6 replicate columns", fill="#4B5563", font=small_font)

    for i in range(6):
        y = y_min + i * (y_max - y_min) / 5
        yy = sy(y)
        draw.line((margin_left, yy, margin_left + plot_w, yy), fill="#E5E7EB", width=1)
        draw.text((20, yy - 10), f"{y:,.0f}", fill="#374151", font=small_font)
    for x in range(0, 18, 3):
        xx = sx(x)
        draw.line((xx, margin_top, xx, margin_top + plot_h), fill="#F3F4F6", width=1)
        draw.text((xx - 18, margin_top + plot_h + 18), str(x), fill="#374151", font=small_font)

    draw.line((margin_left, margin_top + plot_h, margin_left + plot_w, margin_top + plot_h), fill="#111827", width=2)
    draw.line((margin_left, margin_top, margin_left, margin_top + plot_h), fill="#111827", width=2)
    draw.text((margin_left + plot_w / 2 - 70, height - 55), "Time (hours)", fill="#111827", font=axis_font)
    draw.text((24, margin_top + plot_h // 2 - 10), "Signal", fill="#111827", font=axis_font)

    colors = ["#2563EB", "#F97316", "#16A34A", "#9333EA", "#DC2626", "#0891B2"]
    for idx, name in enumerate(names):
        points = [(sx(row["hours"]), sy(row[f"{name} avg"])) for row in averages if row[f"{name} avg"] is not None]
        if len(points) > 1:
            draw.line(points, fill=colors[idx], width=4, joint="curve")
        for px, py in points:
            draw.ellipse((px - 4, py - 4, px + 4, py + 4), fill=colors[idx])
        leg_x = margin_left + plot_w + 45
        leg_y = margin_top + idx * 36
        draw.line((leg_x, leg_y + 10, leg_x + 34, leg_y + 10), fill=colors[idx], width=4)
        draw.text((leg_x + 45, leg_y), name, fill="#111827", font=small_font)
    image.save(png_path)


def save_outputs(source: Path, averages, replicate_rows, out_path: Path, png_path: Path):
    workbook = xlsxwriter.Workbook(out_path)
    title_fmt = workbook.add_format({"bold": True, "font_size": 15, "font_color": "white", "bg_color": "#1F4E79", "align": "center"})
    header_fmt = workbook.add_format({"bold": True, "bg_color": "#D9EAF7", "border": 1, "align": "center", "valign": "vcenter", "text_wrap": True})
    text_fmt = workbook.add_format({"border": 1})
    num_fmt = workbook.add_format({"border": 1, "num_format": "#,##0.0"})
    hour_fmt = workbook.add_format({"border": 1, "num_format": "0.000"})
    note_fmt = workbook.add_format({"italic": True, "font_color": "#666666", "text_wrap": True})

    names = [name for name, _ in SERIES]

    readme = workbook.add_worksheet("Read me")
    readme.hide_gridlines(2)
    readme.merge_range("A1:F1", "USE THIS ONE averaged curve analysis", title_fmt)
    readme.write_row("A3", ["Field", "Value"], header_fmt)
    rows = [
        ["Source workbook", str(source)],
        ["Source marker", f"{SHEET_NAME}!{MARKER_CELL}"],
        ["Source table", f"{SHEET_NAME}!BF3:CP21"],
        ["Calculation", "For each time point and group, average the 6 replicate columns in the USE THIS ONE table."],
    ]
    for r, row in enumerate(rows, start=3):
        readme.write(r, 0, row[0], text_fmt)
        readme.write(r, 1, row[1], note_fmt)
    readme.set_column("A:A", 18)
    readme.set_column("B:F", 38)

    avg_ws = workbook.add_worksheet("Averages")
    avg_ws.hide_gridlines(2)
    headers = ["Read", "Time", "Hours"] + names + [f"{name} SD" for name in names] + [f"{name} N" for name in names]
    avg_ws.write_row(0, 0, headers, header_fmt)
    for r, row in enumerate(averages, start=1):
        avg_ws.write_number(r, 0, row["read"], text_fmt)
        avg_ws.write(r, 1, row["time"], text_fmt)
        avg_ws.write_number(r, 2, row["hours"], hour_fmt)
        c = 3
        for name in names:
            avg_ws.write_number(r, c, row[f"{name} avg"], num_fmt)
            c += 1
        for name in names:
            avg_ws.write_number(r, c, row[f"{name} sd"], num_fmt)
            c += 1
        for name in names:
            avg_ws.write_number(r, c, row[f"{name} n"], text_fmt)
            c += 1
    avg_ws.autofilter(0, 0, len(averages), len(headers) - 1)
    avg_ws.freeze_panes(1, 0)
    avg_ws.set_column("A:A", 8)
    avg_ws.set_column("B:C", 12)
    avg_ws.set_column("D:U", 17)

    rep_ws = workbook.add_worksheet("Replicate source")
    rep_ws.hide_gridlines(2)
    rep_headers = ["Read", "Time", "Hours", "Group", "Replicate", "Source column", "Value"]
    rep_ws.write_row(0, 0, rep_headers, header_fmt)
    for r, row in enumerate(replicate_rows, start=1):
        for c, value in enumerate(row):
            if c in {2, 6} and isinstance(value, (int, float)):
                rep_ws.write_number(r, c, value, hour_fmt if c == 2 else num_fmt)
            else:
                rep_ws.write(r, c, value, text_fmt)
    rep_ws.autofilter(0, 0, len(replicate_rows), len(rep_headers) - 1)
    rep_ws.freeze_panes(1, 0)
    rep_ws.set_column("A:G", 15)
    rep_ws.set_column("D:D", 18)

    curve_ws = workbook.add_worksheet("Curve")
    curve_ws.hide_gridlines(2)
    curve_ws.merge_range("A1:I1", "Average curves", title_fmt)
    curve_ws.write_row(2, 0, ["Hours"] + names, header_fmt)
    for r, row in enumerate(averages, start=3):
        curve_ws.write_number(r, 0, row["hours"], hour_fmt)
        for c, name in enumerate(names, start=1):
            curve_ws.write_number(r, c, row[f"{name} avg"], num_fmt)
    curve_ws.set_column("A:G", 17)

    chart = workbook.add_chart({"type": "line"})
    for c, name in enumerate(names, start=1):
        chart.add_series(
            {
                "name": ["Curve", 2, c],
                "categories": ["Curve", 3, 0, 20, 0],
                "values": ["Curve", 3, c, 20, c],
                "line": {"width": 2.25},
                "marker": {"type": "circle", "size": 4},
            }
        )
    chart.set_title({"name": "Average signal over time"})
    chart.set_x_axis({"name": "Time (hours)", "major_gridlines": {"visible": False}})
    chart.set_y_axis({"name": "Average signal", "major_gridlines": {"visible": True}})
    chart.set_legend({"position": "right"})
    chart.set_size({"width": 920, "height": 500})
    curve_ws.insert_chart("I3", chart)
    curve_ws.insert_image("A24", str(png_path), {"x_scale": 0.58, "y_scale": 0.58})

    workbook.close()


def main() -> None:
    out_dir = Path.home() / ".codex" / PROJECT / "starvation"
    source, averages, replicate_rows = read_data()
    png_path = out_dir / PNG_NAME
    out_path = out_dir / OUT_NAME
    make_png(averages, png_path)
    save_outputs(source, averages, replicate_rows, out_path, png_path)
    print(str(out_path).encode("unicode_escape").decode("ascii"))
    print(str(png_path).encode("unicode_escape").decode("ascii"))
    print("average_rows", len(averages), "replicate_rows", len(replicate_rows))


if __name__ == "__main__":
    main()
