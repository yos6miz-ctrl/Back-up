﻿param(
  [string]$Workspace = "C:\Users\Popovtzer lab\Documents\Codex\2026-06-30\yo",
  [string]$CodexHome = "C:\Users\Popovtzer lab\.codex"
)

$ErrorActionPreference = "Stop"

$Outputs = Join-Path $Workspace "outputs"
$LogDir = Join-Path $Outputs "backup-logs"
$Stage = Join-Path $Outputs "google-drive-latest"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Git = "C:\Users\Popovtzer lab\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe"
$Python = "C:\Users\Popovtzer lab\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
$DocumentsCodex = "C:\Users\Popovtzer lab\Documents\Codex"

New-Item -ItemType Directory -Path $Outputs, $LogDir -Force | Out-Null

function Get-TreeStats {
  param([Parameter(Mandatory=$true)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) {
    return [ordered]@{ exists = $false; files = 0; dirs = 0; bytes = 0 }
  }
  $items = Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
  $files = @($items | Where-Object { -not $_.PSIsContainer })
  $dirs = @($items | Where-Object { $_.PSIsContainer })
  $bytes = ($files | Measure-Object -Property Length -Sum).Sum
  if ($null -eq $bytes) { $bytes = 0 }
  [ordered]@{ exists = $true; files = $files.Count; dirs = $dirs.Count; bytes = [int64]$bytes }
}

function Invoke-RobocopyBackup {
  param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$Destination,
    [string[]]$ExcludeDirs = @(),
    [string[]]$ExcludeFiles = @()
  )

  New-Item -ItemType Directory -Path $Destination -Force | Out-Null
  $args = @($Source, $Destination, "/E", "/XJ", "/R:2", "/W:5", "/FFT", "/NP")
  if ($ExcludeDirs.Count -gt 0) { $args += "/XD"; $args += $ExcludeDirs }
  if ($ExcludeFiles.Count -gt 0) { $args += "/XF"; $args += $ExcludeFiles }
  $output = & robocopy @args
  $code = $LASTEXITCODE
  if ($code -ge 8) { throw "Robocopy failed with code $code for $Source -> $Destination" }
  [ordered]@{
    source = $Source
    destination = $Destination
    robocopyCode = $code
    stats = Get-TreeStats -Path $Destination
    outputTail = @($output | Select-Object -Last 12)
  }
}

function Remove-BackupGeneratedCopies {
  param([Parameter(Mandatory=$true)][string]$BackupRoot)
  if (-not (Test-Path -LiteralPath $BackupRoot)) { return @() }
  $removed = @()
  $resolvedRoot = (Resolve-Path -LiteralPath $BackupRoot).Path
  $workspaceBackupRoot = Join-Path $BackupRoot "Documents-Codex\2026-06-30\yo"
  $relativeDirs = @(
    "outputs\backup-logs",
    "outputs\google-drive-latest",
    "outputs\codex-github-backup-repo",
    "outputs\rnaseq-agent-repo",
    "work\sqlite-repair",
    "work\config-safe-core-staging"
  )
  foreach ($rel in $relativeDirs) {
    $target = Join-Path $workspaceBackupRoot $rel
    if (Test-Path -LiteralPath $target) {
      $resolvedTarget = (Resolve-Path -LiteralPath $target).Path
      if ($resolvedTarget.StartsWith($resolvedRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item -LiteralPath $resolvedTarget -Recurse -Force -ErrorAction SilentlyContinue
        $removed += $resolvedTarget
      }
    }
  }
  Get-ChildItem -LiteralPath (Join-Path $BackupRoot "Documents-Codex") -Recurse -Force -File -Filter "codex-*.zip" -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.FullName.StartsWith($resolvedRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
      Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
      $removed += $_.FullName
    }
  }
  return $removed
}

function Get-UserAgentDirectories {
  param([Parameter(Mandatory=$true)][string]$Root)

  $exclude = @(
    ".sandbox", ".sandbox-bin", ".sandbox-secrets", ".tmp", "tmp", ".tmp.driveupload", ".tmp.drivedownload",
    "ambient-suggestions", "archived_sessions", "attachments", "automations", "browser",
    "cache", "computer-use", "computer-use-turn-ended", "generated_images", "logs",
    "node_repl", "pets", "plugins", "process_manager", "repair-quarantine", "rules",
    "sessions", "skills", "sqlite", "vendor_imports", "visualizations"
  )

  Get-ChildItem -LiteralPath $Root -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { $exclude -notcontains $_.Name } |
    Sort-Object Name
}

function Invoke-GitSync {
  param(
    [Parameter(Mandatory=$true)][string]$Repo,
    [Parameter(Mandatory=$true)][string]$Message
  )
  if (-not (Test-Path -LiteralPath (Join-Path $Repo ".git"))) {
    return [ordered]@{ repo = $Repo; skipped = $true; reason = "not a git repository" }
  }
  $status = (& $Git -C $Repo status --porcelain | Out-String).Trim()
  if ([string]::IsNullOrWhiteSpace($status)) {
    return [ordered]@{ repo = $Repo; changed = $false; pushed = $false }
  }
  & $Git -C $Repo add -A | Out-Null
  & $Git -C $Repo commit -m $Message | Out-Null
  & $Git -C $Repo push | Out-Null
  $head = (& $Git -C $Repo log --oneline -1 | Out-String).Trim()
  return [ordered]@{ repo = $Repo; changed = $true; pushed = $true; head = $head }
}

function Reset-GeneratedRepoToRemote {
  param([Parameter(Mandatory=$true)][string]$Repo)

  if (-not (Test-Path -LiteralPath (Join-Path $Repo ".git"))) { return }
  & $Git -C $Repo fetch origin | Out-Null
  $branch = (& $Git -C $Repo rev-parse --abbrev-ref HEAD | Out-String).Trim()
  if ([string]::IsNullOrWhiteSpace($branch) -or $branch -eq "HEAD") { $branch = "main" }
  & $Git -C $Repo reset --hard ("origin/" + $branch) | Out-Null
  & $Git -C $Repo clean -fd | Out-Null
}

$documentsExcludeDirs = @(
  ".git", "node_modules", "__pycache__", ".venv",
  "backup-logs", "google-drive-latest", "codex-github-backup-repo",
  "rnaseq-agent-repo", "recruiter-jobs-finder-repo",
  "stock-management-assistant-repo", "sqlite-repair", "config-safe-core-staging"
)
$documentsExcludeFiles = @("*.tmp", "~$*", "codex-*.zip")

$codexExcludeDirs = @(
  ".sandbox", ".sandbox-bin", ".sandbox-secrets", ".tmp", "tmp",
  ".tmp.driveupload", "cache", "plugins", "sessions", "logs", "sqlite",
  "process_manager", "repair-quarantine", "vendor_imports"
)
$codexExcludeFiles = @(
  "auth.json", "*.sqlite", "*.sqlite-wal", "*.sqlite-shm", "*.bak", "*.tmp",
  "models_cache.json", "session_index.jsonl", "cap_sid", "~$*"
)

$run = [ordered]@{
  startedAt = (Get-Date).ToString("o")
  workspace = $Workspace
  codexHome = $CodexHome
  diagnostics = $null
  quarantine = @()
  oneDrive = @()
  packaging = $null
  github = @()
  completedAt = $null
}

# Validate and repair core Codex state where possible.
$diagScript = @'
import json, pathlib, sqlite3, sys
try:
    import tomllib
except Exception:
    tomllib = None
base = pathlib.Path(sys.argv[1])
result = {"json": {}, "toml": {}, "jsonl": {}, "sqlite": {}}
for name in [".codex-global-state.json", "auth.json"]:
    p = base / name
    try:
        json.loads(p.read_text(encoding="utf-8"))
        result["json"][name] = "ok"
    except Exception as e:
        result["json"][name] = f"bad: {e}"
try:
    tomllib.loads((base / "config.toml").read_text(encoding="utf-8"))
    result["toml"]["config.toml"] = "ok"
except Exception as e:
    result["toml"]["config.toml"] = f"bad: {e}"
try:
    count = 0
    for line in (base / "session_index.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            count += 1
            json.loads(line)
    result["jsonl"]["session_index.jsonl"] = f"ok records={count}"
except Exception as e:
    result["jsonl"]["session_index.jsonl"] = f"bad: {e}"
for name in ["goals_1.sqlite", "logs_2.sqlite", "memories_1.sqlite", "state_5.sqlite"]:
    p = base / name
    if not p.exists():
        result["sqlite"][name] = "missing"
        continue
    try:
        con = sqlite3.connect(str(p), timeout=10)
        check = con.execute("PRAGMA integrity_check").fetchone()[0]
        if check != "ok":
            con.execute("VACUUM")
            check = con.execute("PRAGMA integrity_check").fetchone()[0]
        con.close()
        result["sqlite"][name] = check
    except Exception as e:
        result["sqlite"][name] = f"bad: {e}"
print(json.dumps(result, ensure_ascii=False))
'@
$run.diagnostics = $diagScript | & $Python - $CodexHome | ConvertFrom-Json

# Quarantine known recovery/upload leftovers from active Codex home.
$qRoot = Join-Path $CodexHome "repair-quarantine"
New-Item -ItemType Directory -Path $qRoot -Force | Out-Null
$qDir = Join-Path $qRoot ("recovery-artifacts-" + $Stamp)
New-Item -ItemType Directory -Path $qDir -Force | Out-Null
$recoveryPatterns = @("logs_2 (*).sqlite-wal", "state_5 (*).sqlite-wal", "state_5 (*).sqlite-shm")
foreach ($pattern in $recoveryPatterns) {
  Get-ChildItem -LiteralPath $CodexHome -Force -File -Filter $pattern -ErrorAction SilentlyContinue | ForEach-Object {
    Move-Item -LiteralPath $_.FullName -Destination (Join-Path $qDir $_.Name) -Force
    $run.quarantine += $_.FullName
  }
}
$driveUpload = Join-Path $CodexHome ".tmp.driveupload"
if (Test-Path -LiteralPath $driveUpload) {
  Move-Item -LiteralPath $driveUpload -Destination (Join-Path $qDir ".tmp.driveupload") -Force
  $run.quarantine += $driveUpload
}
if (-not (Get-ChildItem -LiteralPath $qDir -Force -ErrorAction SilentlyContinue)) {
  Remove-Item -LiteralPath $qDir -Force
}

# Refresh OneDrive backups.
$destinations = @()
if ($env:OneDriveCommercial) {
  $destinations += [ordered]@{
    name = "Bar-Ilan OneDrive"
    path = Join-Path $env:OneDriveCommercial "Banin Lab Files\Lab members\Yosi\Codex-backup"
  }
}
if ($env:OneDriveConsumer) {
  $destinations += [ordered]@{
    name = "Personal OneDrive"
    path = Join-Path $env:OneDriveConsumer "Codex-backup"
  }
}

foreach ($destination in $destinations) {
  $root = $destination.path
  $result = [ordered]@{
    name = $destination.name
    root = $root
    removedGeneratedCopies = @(Remove-BackupGeneratedCopies -BackupRoot $root)
    documentsCodex = $null
    codexConfigSafe = $null
  }
  $result.documentsCodex = Invoke-RobocopyBackup -Source $DocumentsCodex -Destination (Join-Path $root "Documents-Codex") -ExcludeDirs $documentsExcludeDirs -ExcludeFiles $documentsExcludeFiles
  $result.codexConfigSafe = Invoke-RobocopyBackup -Source $CodexHome -Destination (Join-Path $root "codex-config-safe") -ExcludeDirs $codexExcludeDirs -ExcludeFiles $codexExcludeFiles
  $result.completedAt = (Get-Date).ToString("o")
  $result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $root "backup-manifest.json") -Encoding UTF8
  $run.oneDrive += $result
}

# Stage latest upload artifacts for Google Drive and GitHub.
$payload = Join-Path $Stage "payload-stage"
Remove-Item -LiteralPath $Stage -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $payload -Force | Out-Null
$docsStage = Join-Path $payload "Documents-Codex"
$configStage = Join-Path $payload "codex-config-safe"
$coreStage = Join-Path $payload "codex-config-safe-core"
$agentsManifestPath = Join-Path $Stage "codex-agent-manifest-latest.json"
Invoke-RobocopyBackup -Source $DocumentsCodex -Destination $docsStage -ExcludeDirs $documentsExcludeDirs -ExcludeFiles $documentsExcludeFiles | Out-Null
Invoke-RobocopyBackup -Source $CodexHome -Destination $configStage -ExcludeDirs $codexExcludeDirs -ExcludeFiles $codexExcludeFiles | Out-Null
Invoke-RobocopyBackup -Source $configStage -Destination $coreStage -ExcludeDirs @("RNAseq agent") -ExcludeFiles @() | Out-Null
Get-ChildItem -LiteralPath $coreStage -Force -Directory -ErrorAction SilentlyContinue | Where-Object {
  $_.Name.StartsWith([string][char]0x05D0) -or $_.Name.StartsWith([string][char]0x05DB)
} | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
if ($run.oneDrive.Count -gt 0) {
  Copy-Item -LiteralPath (Join-Path $run.oneDrive[0].root "backup-manifest.json") -Destination (Join-Path $Stage "codex-backup-manifest-latest.json") -Force
}
$agentDirs = @(Get-UserAgentDirectories -Root $configStage | ForEach-Object {
  $archivePrefix = $null
  if ($_.Name -eq "Excel file editor") { $archivePrefix = "excel-file-editor" }
  elseif ($_.Name -eq "IBD vs IBS marker finder") { $archivePrefix = "ibd-vs-ibs-marker-finder" }
  elseif ($_.Name -eq "IBD-IBS Sample Classifier") { $archivePrefix = "ibd-ibs-sample-classifier" }
  elseif ($_.Name -eq "RNAseq agent") { $archivePrefix = "rnaseq-agent" }
  elseif ($_.Name -eq "Teads") { $archivePrefix = "teads" }
  elseif ($_.Name.Length -gt 0 -and [int][char]$_.Name[0] -eq 1488) { $archivePrefix = "adama-yeruka" }
  elseif ($_.Name.Length -gt 0 -and [int][char]$_.Name[0] -eq 1499) { $archivePrefix = "kamin" }
  if (-not $archivePrefix) {
    $archivePrefix = ($_.Name.ToLowerInvariant() -replace '[^a-z0-9._-]+', '-') -replace '-+', '-'
    $archivePrefix = $archivePrefix.Trim('-')
    if ([string]::IsNullOrWhiteSpace($archivePrefix)) { $archivePrefix = "agent" }
  }
  [ordered]@{
    name = $_.Name
    relativePath = $_.Name
    archivePrefix = $archivePrefix
  }
})
$agentDirs | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $agentsManifestPath -Encoding UTF8

$packageScript = @'
import pathlib, zipfile, json, sys
stage = pathlib.Path(sys.argv[1])
payload = stage / "payload-stage"
docs = payload / "Documents-Codex"
config = payload / "codex-config-safe"
core = payload / "codex-config-safe-core"
agent_manifest = stage / "codex-agent-manifest-latest.json"
max_zip_bytes = 20_000_000

def safe_name(name):
    text = "".join(c.lower() if ("a" <= c.lower() <= "z") or ("0" <= c <= "9") or c in "-_." else "-" for c in name)
    while "--" in text:
        text = text.replace("--", "-")
    return text.strip("-") or "item"

def zip_dir(src, dest, root_parent=None):
    src = pathlib.Path(src)
    dest = pathlib.Path(dest)
    if not src.exists():
        return {"name": dest.name, "missing": True, "files": 0, "bytes": 0}
    if dest.exists():
        dest.unlink()
    if root_parent is None:
        root_parent = src.parent
    files = [src] if src.is_file() else [p for p in src.rglob("*") if p.is_file()]
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
        for p in files:
            try:
                zf.write(p, p.relative_to(root_parent).as_posix())
            except FileNotFoundError:
                pass
    return {"name": dest.name, "files": len(files), "bytes": dest.stat().st_size}

def zip_docs_tree(src, prefix):
    src = pathlib.Path(src)
    dest = stage / f"{prefix}-latest.zip"
    item = zip_dir(src, dest, docs.parent)
    if item["bytes"] <= max_zip_bytes or not src.is_dir():
        return [item]
    dest.unlink(missing_ok=True)
    pieces = []
    children = sorted(src.iterdir(), key=lambda p: p.name)
    if not children:
        return [zip_dir(src, dest, docs.parent)]
    for child in children:
        pieces.extend(zip_docs_tree(child, f"{prefix}-{safe_name(child.name)}"))
    return pieces

def zip_tree(src, prefix, root_parent):
    src = pathlib.Path(src)
    dest = stage / f"{prefix}-latest.zip"
    item = zip_dir(src, dest, root_parent)
    if item["bytes"] <= max_zip_bytes or not src.is_dir():
        return [item]
    dest.unlink(missing_ok=True)
    pieces = []
    children = sorted(src.iterdir(), key=lambda p: p.name)
    if not children:
        return [zip_dir(src, dest, root_parent)]
    for child in children:
        pieces.extend(zip_tree(child, f"{prefix}-{safe_name(child.name)}", root_parent))
    return pieces

artifacts = []
if docs.exists():
    for child in sorted(docs.iterdir(), key=lambda p: p.name):
        if child.is_dir():
            artifacts.extend(zip_docs_tree(child, f"codex-documents-{safe_name(child.name)}"))
artifacts.append(zip_dir(core, stage / "codex-config-safe-core-latest.zip"))
rnaseq = config / "RNAseq agent"
artifacts.append(zip_dir(rnaseq, stage / "codex-config-safe-rnaseq-agent-latest.zip"))
for folder in [p for p in config.iterdir() if p.is_dir()]:
    if folder.name.startswith("א"):
        artifacts.append(zip_dir(folder, stage / "codex-config-safe-adama-latest.zip"))
    if folder.name.startswith("כ"):
        artifacts.append(zip_dir(folder, stage / "codex-config-safe-kamin-latest.zip"))

agent_entries = json.loads(agent_manifest.read_text(encoding="utf-8-sig")) if agent_manifest.exists() else []
for entry in agent_entries:
    rel = entry.get("relativePath")
    if not rel:
        continue
    folder = config / rel
    if not folder.exists():
        continue
    archive_prefix = entry.get("archivePrefix") or safe_name(entry.get("name", rel))
    prefix = f"codex-agent-{safe_name(archive_prefix)}"
    artifacts.extend(zip_tree(folder, prefix, config))
print(json.dumps(artifacts, ensure_ascii=True))
'@
$run.packaging = $packageScript | & $Python - $Stage | ConvertFrom-Json

# Update GitHub backup repository with latest artifacts.
$backupRepo = Join-Path $Outputs "codex-github-backup-repo"
if (Test-Path -LiteralPath (Join-Path $backupRepo ".git")) {
  Reset-GeneratedRepoToRemote -Repo $backupRepo
  $latestDir = Join-Path $backupRepo "latest"
  New-Item -ItemType Directory -Path $latestDir -Force | Out-Null
  Get-ChildItem -LiteralPath $latestDir -Force -File -ErrorAction SilentlyContinue | Remove-Item -Force
  $githubSafeMaxBytes = 95MB
  $githubCopied = @()
  $githubSkipped = @()
  Get-ChildItem -LiteralPath $Stage -Force -File -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.Length -le $githubSafeMaxBytes) {
      Copy-Item -LiteralPath $_.FullName -Destination $latestDir -Force
      $githubCopied += [ordered]@{ name = $_.Name; bytes = $_.Length }
    } else {
      $githubSkipped += [ordered]@{ name = $_.Name; bytes = $_.Length; reason = "exceeds_github_file_limit" }
    }
  }
  [ordered]@{
    generatedAt = (Get-Date).ToString("o")
    maxFileBytes = $githubSafeMaxBytes
    copied = $githubCopied
    skipped = $githubSkipped
  } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backupRepo "latest-manifest.json") -Encoding UTF8
  Get-ChildItem -LiteralPath $latestDir -File | Get-FileHash -Algorithm SHA256 | ForEach-Object {
    "{0}  latest/{1}" -f $_.Hash.ToLowerInvariant(), (Split-Path $_.Path -Leaf)
  } | Set-Content -LiteralPath (Join-Path $backupRepo "SHA256SUMS.latest.txt") -Encoding ASCII
  $run.github += Invoke-GitSync -Repo $backupRepo -Message "Update automated Codex backup"
}

# Update RNAseq agent repository from the safe local source.
$rnaseqRepo = Join-Path $Outputs "rnaseq-agent-repo"
$rnaseqSource = Join-Path $CodexHome "RNAseq agent"
if ((Test-Path -LiteralPath (Join-Path $rnaseqRepo ".git")) -and (Test-Path -LiteralPath $rnaseqSource)) {
  Reset-GeneratedRepoToRemote -Repo $rnaseqRepo
  Invoke-RobocopyBackup -Source $rnaseqSource -Destination $rnaseqRepo -ExcludeDirs @(".git", "__pycache__") -ExcludeFiles @("*.tmp", "~$*") | Out-Null
  Get-ChildItem -LiteralPath $rnaseqRepo -Recurse -Force -File | Where-Object { $_.FullName -notmatch "\\.git\\" -and $_.Name -ne "SHA256SUMS.txt" } | Get-FileHash -Algorithm SHA256 | ForEach-Object {
    $rel = $_.Path.Substring($rnaseqRepo.Length + 1).Replace("\", "/")
    "{0}  {1}" -f $_.Hash.ToLowerInvariant(), $rel
  } | Set-Content -LiteralPath (Join-Path $rnaseqRepo "SHA256SUMS.txt") -Encoding ASCII
  $run.github += Invoke-GitSync -Repo $rnaseqRepo -Message "Update RNAseq agent backup"
}

$run.completedAt = (Get-Date).ToString("o")
$logPath = Join-Path $LogDir ("codex-maintenance-backup-$Stamp.json")
$run | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $logPath -Encoding UTF8
Write-Output "Codex maintenance backup completed: $logPath"
