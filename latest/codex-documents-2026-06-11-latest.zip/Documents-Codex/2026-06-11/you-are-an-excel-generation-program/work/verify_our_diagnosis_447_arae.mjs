import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourceDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE";
const deliveryDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_our_diagnosis_final_verify";
const files = ["Final 447.xlsx", "Final araE.xlsx"];

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

await fs.mkdir(previewDir, { recursive: true });

for (const fileName of files) {
  const sourcePath = path.join(sourceDir, fileName);
  const deliveryPath = path.join(deliveryDir, fileName);
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
  const sheetName = fileName.replace(".xlsx", "");
  const finalTable = await workbook.inspect({
    kind: "table",
    range: `${sheetName}!A1:N60`,
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 14,
    maxChars: 50000,
  });
  const logTable = await workbook.inspect({
    kind: "table",
    range: "Sample Log!A1:N59",
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 14,
    maxChars: 50000,
  });
  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 300 },
    summary: "formula error scan",
    maxChars: 2000,
  });
  const logJson = JSON.parse(logTable.ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
  const header = logJson.values[0];
  const counts = {};
  for (const row of logJson.values.slice(1)) {
    counts[row[13]] = (counts[row[13]] ?? 0) + 1;
  }
  const finalJson = JSON.parse(finalTable.ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
  const finalHeader = finalJson.values[0];
  const preview = await workbook.render({ sheetName, range: "A1:N60", scale: 0.7, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
  const logPreview = await workbook.render({ sheetName: "Sample Log", range: "A1:N59", scale: 0.55, format: "png" });
  await fs.writeFile(path.join(previewDir, `Sample_Log_${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await logPreview.arrayBuffer()));

  const hashMatch = await sha256(sourcePath) === await sha256(deliveryPath);
  process.stdout.write(JSON.stringify({
    fileName,
    finalHeader,
    sampleLogHeader: header,
    diagnosisCounts: counts,
    errors: errors.ndjson,
    hashMatch,
  }, null, 2) + "\n");
}

const sidecars = [];
for (const dir of [sourceDir, deliveryDir]) {
  for (const entry of await fs.readdir(dir)) {
    if (entry.endsWith(".inspect.ndjson")) sidecars.push(path.join(dir, entry));
  }
}
process.stdout.write(JSON.stringify({ sidecars }, null, 2) + "\n");
