from __future__ import annotations

import math
import random
import shutil
import zipfile
from datetime import date
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart3D, Reference
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter


CODEX_ROOT = Path(r"C:\Users\Popovtzer lab\.codex")
ROOT = [p for p in CODEX_ROOT.iterdir() if p.is_dir() and (p / "exemp").exists()][0]
TARGET_ROOT = ROOT / "work"
THREAD_ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-06-11\you-are-an-excel-generation-program")
OUTPUT_ROOT = THREAD_ROOT / "outputs" / "generated_detector_workbooks"

MEASUREMENT_DATES = [
    date(2026, 1, 1),
    date(2026, 1, 5),
    date(2026, 1, 8),
    date(2026, 1, 12),
    date(2026, 1, 15),
    date(2026, 1, 19),
    date(2026, 1, 22),
    date(2026, 1, 26),
    date(2026, 1, 29),
    date(2026, 2, 3),
    date(2026, 2, 8),
    date(2026, 2, 12),
    date(2026, 2, 16),
    date(2026, 2, 19),
    date(2026, 2, 23),
    date(2026, 2, 26),
    date(2026, 3, 4),
    date(2026, 3, 8),
    date(2026, 3, 12),
    date(2026, 3, 16),
    date(2026, 3, 19),
    date(2026, 3, 23),
    date(2026, 3, 26),
    date(2026, 3, 30),
    date(2026, 4, 12),
    date(2026, 4, 16),
    date(2026, 4, 19),
    date(2026, 4, 23),
    date(2026, 4, 27),
    date(2026, 5, 3),
    date(2026, 5, 7),
    date(2026, 5, 11),
    date(2026, 5, 18),
    date(2026, 5, 25),
    date(2026, 5, 28),
]

HS = ["CT81", "CT608", "CT-595", "CT-644", "CT650", "CT-604", "CT646", "CT-632", "CT635"]
CDF = [
    "DY-247 ",
    "CT-156",
    "CT113",
    "CT-130",
    "F-DBH-164",
    "CT-203",
    "CT-412",
    "F-SB-2067",
    "F-IP-20191",
    "F-DS-20527",
    "F-PM-20543",
    "CT-132",
    "CT-238",
    "CT-344",
    "CT-233",
]
IBS = [
    "F-AT-23197",
    "F-GG-23196",
    "F-IS-23142",
    "OB-266",
    "YG-2386",
    "BZ-2387",
    "AP-2390",
    "F-DG-12.5",
    "F-MI-24133",
    "F-AP-24104",
]

GROUPS = {"HS": HS, "CDf": CDF, "IBS": IBS}

DAILY_ALIASES = {
    "CT81": "CT-81",
    "CT608": "CT-608",
    "CT650": "CT-650",
    "BZ-2387": "F-BZ-2387",
    "AP-2390": "F-AP-2390",
    "YG-2386": "F-YG-2386",
    "F-MI-24133": "F-MI-24133l",
}

DAY_PATIENTS = [
    ["F-AP-24104", "CT-344", "CT-233", "CT635"],
    ["CT646", "CT-632", "F-PM-20543", "CT-132", "CT-238", "F-MI-24133"],
    ["CT650", "CT-604", "F-SB-2067", "F-IP-20191", "F-DS-20527", "F-DG-12.5"],
    ["AP-2390", "F-IS-23142", "F-DBH-164", "F-AT-23197", "CT-203", "CT-412"],
    ["YG-2386", "CT-130", "DY-247 ", "OB-266", "CT-595", "CT-644"],
    ["CT81", "BZ-2387", "CT113", "CT-156", "F-GG-23196", "CT608"],
]

QC_PATIENTS = ["CT-132", "F-IS-23142", "F-AT-23197", "CT-238", "CT-604", "CT608"]

TARGETS = [
    "1. norB +dnr",
    "2. nirS + dnr",
    "3. PA0132",
    "4. aotQ",
    "5. PA4683",
]

PROFILES = {
    "norB +dnr": {"zero": 0.42, "means": {"HS": 0.055, "CDf": 0.08, "IBS": 0.09}, "max": 0.34, "base": 0.36},
    "nirS + dnr": {"zero": 0.28, "means": {"HS": 0.12, "CDf": 0.17, "IBS": 0.18}, "max": 0.58, "base": 0.22},
    "PA0132": {"zero": 0.24, "means": {"HS": 0.18, "CDf": 0.24, "IBS": 0.2}, "max": 0.72, "base": 0.48},
    "aotQ": {"zero": 0.5, "means": {"HS": 0.045, "CDf": 0.07, "IBS": 0.055}, "max": 0.28, "base": 0.31},
    "PA4683": {"zero": 0.3, "means": {"HS": 0.11, "CDf": 0.21, "IBS": 0.16}, "max": 0.64, "base": 0.41},
}

HEADER_FILL = PatternFill("solid", fgColor="D9EAD3")
SUBHEADER_FILL = PatternFill("solid", fgColor="EADCF8")


def detector_label(folder_name: str) -> str:
    return folder_name.split(". ", 1)[1] if ". " in folder_name else folder_name


def canonical_group(patient: str) -> str:
    for group, names in GROUPS.items():
        if patient in names:
            return group
    raise KeyError(patient)


def daily_alias(patient: str) -> str:
    return DAILY_ALIASES.get(patient, patient)


def normalized_value(rng: random.Random, profile: dict, group: str) -> float:
    if rng.random() < profile["zero"]:
        return 0.0
    mean = profile["means"][group]
    value = rng.lognormvariate(math.log(max(mean, 0.001)), 0.75)
    if rng.random() < 0.08:
        value *= rng.uniform(1.8, 3.0)
    return round(min(value, profile["max"]), 12)


def build_values(label: str) -> dict[str, float]:
    rng = random.Random(f"values::{label}")
    profile = PROFILES[label]
    values = {}
    for group, patients in GROUPS.items():
        for patient in patients:
            values[patient] = normalized_value(rng, profile, group)
    return values


def endpoint_for(rng: random.Random, control_endpoint: float, normalized: float) -> float:
    noise = rng.uniform(-0.003, 0.003)
    return max(0.0001, control_endpoint * (1.0 + normalized) + noise)


def curve_value(t: int, endpoint: float, rng: random.Random, mode: str) -> float:
    if mode == "rising":
        start = max(0.0001, endpoint * rng.uniform(0.015, 0.08))
        val = endpoint - (endpoint - start) * math.exp(-t / rng.uniform(430, 760))
    else:
        start = endpoint * rng.uniform(3.0, 6.8)
        val = endpoint + (start - endpoint) / ((t + 1) ** rng.uniform(0.36, 0.5))
    return round(max(-0.01, val + rng.uniform(-0.00045, 0.00045)), 12)


def style_header(ws, row: int, max_col: int) -> None:
    for cell in ws[row][:max_col]:
        cell.font = Font(bold=True)
        cell.fill = HEADER_FILL


def autosize(ws, max_width: int = 24) -> None:
    for col_idx in range(1, ws.max_column + 1):
        width = 8
        for row in range(1, min(ws.max_row, 80) + 1):
            value = ws.cell(row, col_idx).value
            if value is not None:
                width = max(width, min(max_width, len(str(value)) + 2))
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def mark_recalculate(wb: Workbook) -> None:
    wb.calculation.fullCalcOnLoad = True
    wb.calculation.forceFullCalc = True
    wb.calculation.calcMode = "auto"


def write_daily_workbook(
    path: Path,
    label: str,
    patients: list[str],
    values: dict[str, float],
    day_index: int,
) -> list[dict]:
    rng = random.Random(f"daily::{label}::{day_index}")
    profile = PROFILES[label]
    mode = "rising" if label in {"aotQ"} else "decay"
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    n = len(patients)
    aliases = [daily_alias(p) for p in patients]
    control_endpoint = max(0.03, profile["base"] * rng.uniform(0.82, 1.18))
    endpoints = {p: endpoint_for(rng, control_endpoint, values[p]) for p in patients}

    ws.cell(1, 1).value = None
    for idx, alias in enumerate(aliases, start=2):
        ws.cell(1, idx).value = alias
    control_col = n + 2
    ws.cell(1, control_col).value = "control"
    ws.cell(2, 1).value = "s"
    for idx in range(2, control_col + 1):
        ws.cell(2, idx).value = "µA"

    gap_col = control_col + 1
    time_summary_col = control_col + 2
    right_start = control_col + 3
    ws.cell(2, time_summary_col).value = 1500
    for idx, alias in enumerate(aliases + ["control"], start=right_start):
        ws.cell(1, idx).value = alias
    for idx, patient in enumerate(patients, start=right_start):
        ws.cell(2, idx).value = endpoints[patient]
    control_summary_col = right_start + n
    ws.cell(2, control_summary_col).value = control_endpoint

    for t in range(0, 1801):
        row = t + 3
        ws.cell(row, 1).value = t
        for col_offset, patient in enumerate(patients, start=2):
            ws.cell(row, col_offset).value = curve_value(t, endpoints[patient], rng, mode)
        ws.cell(row, control_col).value = curve_value(t, control_endpoint, rng, mode)

    for idx in range(right_start, right_start + n):
        col = get_column_letter(idx)
        ccol = get_column_letter(control_summary_col)
        ws.cell(3, idx).value = f"={col}2-${ccol}$2"
        ws.cell(7, idx).value = f"=({col}2-${ccol}$2)/${ccol}$2"
    ws.cell(3, control_summary_col).value = 0
    ws.cell(7, control_summary_col).value = 0
    ws.freeze_panes = "B3"
    ws.column_dimensions[get_column_letter(gap_col)].width = 3
    ws.column_dimensions[get_column_letter(time_summary_col)].width = 10
    style_header(ws, 1, ws.max_column)
    for cell in ws[2]:
        if cell.value is not None:
            cell.fill = SUBHEADER_FILL
    for row in ws.iter_rows(min_row=1, max_row=7, min_col=right_start, max_col=control_summary_col):
        for cell in row:
            cell.number_format = "0.000000"
    mark_recalculate(wb)
    wb.save(path)

    return [
        {
            "date": path.name[:8],
            "file": path.name,
            "group": canonical_group(patient),
            "patient": patient,
            "sample_name": daily_alias(patient),
            "endpoint": endpoints[patient],
            "control_endpoint": control_endpoint,
            "delta": endpoints[patient] - control_endpoint,
            "normalized": values[patient],
        }
        for patient in patients
    ]


def write_qc_workbook(path: Path, label: str, values: dict[str, float]) -> None:
    rng = random.Random(f"qc::{label}")
    profile = PROFILES[label]
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    patients = QC_PATIENTS
    control_endpoint = max(0.03, profile["base"] * rng.uniform(0.82, 1.18))
    endpoints = {p: endpoint_for(rng, control_endpoint, values[p]) for p in patients}

    col = 1
    for patient in patients:
        ws.cell(1, col).value = daily_alias(patient)
        ws.cell(1, col + 1).value = None
        ws.cell(2, col).value = "s"
        ws.cell(2, col + 1).value = "µA"
        col += 2
    ws.cell(1, col).value = "control"
    ws.cell(2, col).value = "s"
    ws.cell(2, col + 1).value = "µA"

    mode = "rising" if label in {"aotQ"} else "decay"
    for t in range(0, 1801):
        row = t + 3
        col = 1
        for patient in patients:
            ws.cell(row, col).value = t
            ws.cell(row, col + 1).value = curve_value(t, endpoints[patient], rng, mode)
            col += 2
        ws.cell(row, col).value = t
        ws.cell(row, col + 1).value = curve_value(t, control_endpoint, rng, mode)

    style_header(ws, 1, ws.max_column)
    mark_recalculate(wb)
    wb.save(path)


def write_final_workbook(path: Path, label: str, values: dict[str, float]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.append([label, "HS", "CDf", "IBS"])
    for group, patients in GROUPS.items():
        for patient in patients:
            row = [patient, None, None, None]
            row[["HS", "CDf", "IBS"].index(group) + 1] = values[patient]
            ws.append(row)
    style_header(ws, 1, 4)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=2, max_col=4):
        for cell in row:
            cell.number_format = "0.000000"
    autosize(ws)
    chart = BarChart3D()
    data = Reference(ws, min_col=2, max_col=4, min_row=1, max_row=ws.max_row)
    cats = Reference(ws, min_col=1, min_row=2, max_row=ws.max_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 9.2
    chart.width = 13.5
    chart.legend.position = "r"
    chart.x_axis.title = "Patient"
    chart.y_axis.title = "Normalized measurement"
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    chart.x_axis.majorTickMark = "out"
    chart.y_axis.majorTickMark = "out"
    chart.y_axis.majorGridlines = None
    ws.add_chart(chart, "G2")
    mark_recalculate(wb)
    wb.save(path)


def write_long_workbook(path: Path, label: str, rows: list[dict]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    headers = [
        "Detector",
        "Measurement date",
        "Weekday",
        "Source file",
        "Group",
        "Patient",
        "Sample name in file",
        "Endpoint time (s)",
        "Endpoint signal",
        "Control endpoint signal",
        "Delta",
        "Normalized value",
    ]
    ws.append(headers)
    for item in rows:
        d = date(int(item["date"][:4]), int(item["date"][4:6]), int(item["date"][6:]))
        ws.append(
            [
                label,
                d.isoformat(),
                d.strftime("%A"),
                item["file"],
                item["group"],
                item["patient"],
                item["sample_name"],
                1500,
                item["endpoint"],
                item["control_endpoint"],
                item["delta"],
                item["normalized"],
            ]
        )
    style_header(ws, 1, len(headers))
    ws.auto_filter.ref = ws.dimensions
    ws.freeze_panes = "A2"
    for row in ws.iter_rows(min_row=2, min_col=9, max_col=12):
        for cell in row:
            cell.number_format = "0.000000"
    autosize(ws, max_width=30)
    mark_recalculate(wb)
    wb.save(path)


def prepare_output_dirs() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    for child in OUTPUT_ROOT.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def main() -> None:
    prepare_output_dirs()
    manifest = []
    for target_index, folder_name in enumerate(TARGETS):
        label = detector_label(folder_name)
        target_dir = TARGET_ROOT / folder_name
        mirror_dir = OUTPUT_ROOT / folder_name
        target_dir.mkdir(parents=True, exist_ok=True)
        mirror_dir.mkdir(parents=True, exist_ok=True)
        for old_path in list(target_dir.glob("20*.xlsx")) + list(target_dir.glob("Final *.xlsx")) + list(
            target_dir.glob("Long normalized measurements *.xlsx")
        ):
            old_path.unlink()
        values = build_values(label)

        for idx, patients in enumerate(DAY_PATIENTS):
            measurement_date = MEASUREMENT_DATES[target_index * 7 + idx]
            date_prefix = measurement_date.strftime("%Y%m%d")
            daily_name = f"{date_prefix} {label}.xlsx"
            daily_path = target_dir / daily_name
            write_daily_workbook(daily_path, label, patients, values, idx)
            shutil.copy2(daily_path, mirror_dir / daily_name)
            manifest.append(str(daily_path))

        qc_date = MEASUREMENT_DATES[target_index * 7 + 6]
        qc_name = f"{qc_date.strftime('%Y%m%d')} {label}.xlsx"
        qc_path = target_dir / qc_name
        write_qc_workbook(qc_path, label, values)
        shutil.copy2(qc_path, mirror_dir / qc_name)
        manifest.append(str(qc_path))

        final_name = f"Final {label}.xlsx"
        final_path = target_dir / final_name
        write_final_workbook(final_path, label, values)
        shutil.copy2(final_path, mirror_dir / final_name)
        manifest.append(str(final_path))

    manifest_path = OUTPUT_ROOT / "manifest.txt"
    manifest_path.write_text("\n".join(manifest), encoding="utf-8")
    zip_path = THREAD_ROOT / "outputs" / "generated_detector_workbooks.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in OUTPUT_ROOT.rglob("*.xlsx"):
            zf.write(path, path.relative_to(OUTPUT_ROOT))
        zf.write(manifest_path, manifest_path.relative_to(OUTPUT_ROOT))
    print(f"generated {len(manifest)} Excel files")
    print(zip_path)


if __name__ == "__main__":
    main()
