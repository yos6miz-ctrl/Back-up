import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE/Final 447 and araE single tab.xlsx";
const deliveryPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae/Final 447 and araE single tab.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_single_tab_final_verify";

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

function tableFrom(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

await fs.mkdir(previewDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const table = await workbook.inspect({
  kind: "table",
  range: "Final 447 and araE!A1:T56",
  include: "values,formulas",
  tableMaxRows: 60,
  tableMaxCols: 20,
  maxChars: 80000,
});
const drawings = await workbook.inspect({ kind: "drawing", sheetId: "Final 447 and araE", maxChars: 4000 });
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "single-tab formula error scan",
  maxChars: 2000,
});
const values = tableFrom(table.ndjson).values;
const counts = {};
for (const row of values.slice(1, 56)) {
  const diagnosis = row[12];
  counts[diagnosis] = (counts[diagnosis] ?? 0) + 1;
}
const preview = await workbook.render({ sheetName: "Final 447 and araE", range: "A1:V60", scale: 0.65, format: "png" });
await fs.writeFile(path.join(previewDir, "Final_447_and_araE_single_tab.png"), new Uint8Array(await preview.arrayBuffer()));
process.stdout.write(JSON.stringify({
  sheets: workbook.worksheets.items.map((sheet) => sheet.name),
  headers: values[0],
  diagnosisCounts: counts,
  drawings: drawings.ndjson,
  errors: errors.ndjson,
  sourceDeliveryHashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
}, null, 2));
