from __future__ import annotations

import datetime as dt
import shutil
import zipfile
from pathlib import Path

from lxml import etree


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_NS = "http://www.w3.org/XML/1998/namespace"
NS = {"w": W_NS}


ROOT = Path.home() / ".codex" / "כמין" / "דוח כמין"
OUT_DIR = ROOT / "tracked corrections"
DELIVERY_DIR = Path.cwd() / "outputs" / "דוח כמין tracked corrections"
AUTHOR = "Codex"


COMMON_REPLACEMENTS: list[tuple[str, str]] = [
    ("תסמונת המעי הרגיש", "תסמונת המעי הרגיז"),
    ('ע"י', "על ידי"),
    ("השניה", "השנייה"),
    ("ביוסנסורים-שנה", "ביוסנסורים - שנה"),
    ("ביוסנסורים- שנה", "ביוסנסורים - שנה"),
    ("IBD ו- IBS -המשך", "IBD ו-IBS - המשך"),
    ("IBD ו- IBS", "IBD ו-IBS"),
    ("חבילת עבודה זו+חבילת עבודה", "חבילת עבודה זו + חבילת עבודה"),
    ("חיידקים ביוסנסורים", "ביוסנסורים חיידקיים"),
]


FILE_REPLACEMENTS: dict[str, list[tuple[str, str]]] = {
    "IIA_AcademyIndustryGrant-Report4Packag9.docx": [
        (
            "פותחו במהלך תקופה זו חמישה ביוסנסורים חיידקיים חדשים, מתוכם שלושה ביוסנסורים חדשים המבוססים על מטרות חדשות, ושני ביוסנסורים שפותחו מחדש לאחר אופטימיזציה של גרסאות קודמות.",
            "פותחו במהלך תקופה זו חמישה ביוסנסורים חיידקיים נוספים, מתוכם שלושה המבוססים על מטרות חדשות ושניים שהם גרסאות שעברו אופטימיזציה של ביוסנסורים קודמים.",
        ),
        ("norB and nirS based reporter strains", "norB- and nirS-based reporter strains"),
        ("#IB003 - based on", "#IB003 is based on"),
        ("#IB004 - based on", "#IB004 is based on"),
        ("#IB005 - based on", "#IB005 is based on"),
        (
            "#IB005 exhibited a broader disease-associated response pattern",
            "#IB005 exhibited a broader clinical-group-associated response pattern",
        ),
    ],
    "IIA_AcademyIndustryGrant-Report4Package11.docx": [
        (
            "הערכת יכולת המערכת הכוללת להבחין בין IBS ו-IBD באמצעות ניתוח אותות חשמליים – המשך.",
            "הערכת יכולת המערכת הכוללת להבחין בין IBD ו-IBS באמצעות ניתוח אותות חשמליים - המשך.",
        ),
        (
            "המשך בדיקת דגימות הצואה מהקבוצות השונות לנוכחות הביומרקרים השונים באמצעות מערכת הביוצ'יפ מדידת הסיגנל החשמלי המתקבל",
            "המשך בדיקת דגימות הצואה מהקבוצות השונות לנוכחות הביומרקרים השונים באמצעות מערכת הביוצ'יפ, מדידת האות החשמלי המתקבל",
        ),
        (
            "נמדדו ואופיינו במהלך תקופה זו חמישה ביוסנסורים חיידקיים נוספים על אלו שדווחו",
            "נמדדו ואופיינו במהלך תקופה זו חמישה ביוסנסורים חיידקיים נוספים מעבר לאלו שדווחו",
        ),
        ('בדו"ח הנ"ל', 'בדוח זה'),
        (
            "Application of a constant potential of 280 mV between the working and reference electrodes.",
            "Application of a constant potential of 280 mV to the working electrode relative to the reference electrode.",
        ),
        ("the new optimized nirS", "the newly optimized nirS"),
        ("patients with Crohn’s disease (CD) and IBS-D", "patients with Crohn’s disease (CD) and IBS"),
        ("15 patients with CD and 15 patients with IBS-D", "15 patients with CD and 15 patients with IBS"),
        ("Longitudinal Evaluation of IBS Patients", "Longitudinal Evaluation of Patients Initially Diagnosed with IBS"),
        (
            "Longitudinal biochip measurements were performed for 15 patients clinically diagnosed with IBS",
            "Longitudinal biochip measurements were performed for 15 patients initially clinically diagnosed with IBS",
        ),
        (
            "Electrochemical responses obtained from longitudinal fecal samples of 15 patients clinically diagnosed with IBS.",
            "Electrochemical responses obtained from longitudinal fecal samples of 15 patients initially clinically diagnosed with IBS.",
        ),
        (
            "support the potential of the #IB001/araE biosensor panel for accurate differentiation between Crohn’s disease and IBS",
            "support the potential of the #IB001/araE biosensor panel for clinically relevant differentiation between Crohn’s disease and IBS",
        ),
        (
            "below 150 µg/g, providing no evidence of active Crohn’s disease based on the conventional calprotectin assessment",
            "below 150 µg/g, providing no strong biochemical evidence of active Crohn’s disease based on the conventional calprotectin assessment",
        ),
        (
            "absence of evidence for active Crohn’s disease based on fecal calprotectin testing",
            "absence of strong biochemical evidence for active Crohn’s disease based on fecal calprotectin testing",
        ),
        (
            "absence of evidence for active disease according to fecal calprotectin testing",
            "absence of strong biochemical evidence for active disease according to fecal calprotectin testing",
        ),
        (
            "below 150 µg/g, providing no evidence of active Crohn’s disease based on conventional calprotectin assessment",
            "below 150 µg/g, providing no strong biochemical evidence of active Crohn’s disease based on conventional calprotectin assessment",
        ),
        ("each group- Crohn’s disease", "each group - Crohn’s disease"),
        (
            "strong diagnostic performance for differentiation between Crohn’s disease and IBS (Fig. 8)",
            "strong diagnostic performance for differentiation between Crohn’s disease and non-Crohn’s samples, including IBS and healthy controls (Fig. 8)",
        ),
        (
            "specificity of 97% for distinguishing Crohn’s disease from IBS",
            "specificity of 97% for distinguishing Crohn’s disease from non-Crohn’s samples",
        ),
        (
            "false-positive Crohn’s disease classification among IBS samples",
            "false-positive Crohn’s disease classification among IBS and healthy control samples",
        ),
        (
            "The final biochip analysis achieved 90% sensitivity and 97% specificity for differentiation between Crohn’s disease and IBS",
            "The final biochip analysis achieved 90% sensitivity and 97% specificity for differentiation between Crohn’s disease and non-Crohn’s samples, including IBS and healthy controls",
        ),
        (
            "the biochip achieved 90% sensitivity and 97% specificity for differentiation between Crohn’s disease and IBS",
            "the biochip achieved 90% sensitivity and 97% specificity for differentiation between Crohn’s disease and non-Crohn’s samples, including IBS and healthy controls",
        ),
        (
            "Among patients clinically diagnosed with IBS",
            "Among patients initially clinically diagnosed with IBS",
        ),
        (
            "strong and reproducible differentiation between Crohn’s disease and IBS",
            "strong differentiation between Crohn’s disease and IBS in the evaluated cohort",
        ),
        (
            "improving the diagnostic pathway and clinical management of patients with gastrointestinal disease and beyond",
            "improving the diagnostic pathway and clinical management of patients with gastrointestinal diseases",
        ),
    ],
}


def w(tag: str) -> str:
    return f"{{{W_NS}}}{tag}"


def enable_track_revisions(settings_root: etree._Element) -> None:
    if settings_root.find("w:trackRevisions", namespaces=NS) is None:
        settings_root.insert(0, etree.Element(w("trackRevisions")))


def next_change_id(root: etree._Element) -> int:
    ids: list[int] = []
    for el in root.xpath(".//*[@w:id]", namespaces=NS):
        try:
            ids.append(int(el.get(w("id"))))
        except (TypeError, ValueError):
            pass
    return max(ids, default=0) + 1


def visible_text_nodes(p: etree._Element) -> list[etree._Element]:
    nodes: list[etree._Element] = []
    for t in p.xpath(".//w:t", namespaces=NS):
        if any(a.tag in {w("del"), w("ins")} for a in t.iterancestors()):
            continue
        nodes.append(t)
    return nodes


def immediate_child_of(parent: etree._Element, descendant: etree._Element) -> etree._Element:
    node = descendant
    while node.getparent() is not None and node.getparent() is not parent:
        node = node.getparent()
    return node


def clone_rpr_from_text_node(node: etree._Element) -> etree._Element | None:
    run = node.getparent()
    if run is None:
        return None
    rpr = run.find("w:rPr", namespaces=NS)
    if rpr is None:
        return None
    return etree.fromstring(etree.tostring(rpr))


def set_text_preserve_space(t: etree._Element, text: str) -> None:
    if text.startswith(" ") or text.endswith(" "):
        t.set(f"{{{XML_NS}}}space", "preserve")
    t.text = text


def make_run(text: str, rpr: etree._Element | None = None) -> etree._Element:
    run = etree.Element(w("r"))
    if rpr is not None:
        run.append(etree.fromstring(etree.tostring(rpr)))
    t = etree.SubElement(run, w("t"))
    set_text_preserve_space(t, text)
    return run


def make_change(
    tag: str,
    text_tag: str,
    text: str,
    cid: int,
    when: str,
    rpr: etree._Element | None = None,
) -> etree._Element:
    el = etree.Element(w(tag))
    el.set(w("id"), str(cid))
    el.set(w("author"), AUTHOR)
    el.set(w("date"), when)
    run = etree.SubElement(el, w("r"))
    if rpr is not None:
        run.append(etree.fromstring(etree.tostring(rpr)))
    t = etree.SubElement(run, w(text_tag))
    set_text_preserve_space(t, text)
    return el


def replace_once(p: etree._Element, old: str, new: str, cid: int, when: str) -> tuple[bool, int]:
    nodes = visible_text_nodes(p)
    full = "".join(n.text or "" for n in nodes)
    start = full.find(old)
    if start < 0:
        return False, cid
    end = start + len(old)

    spans: list[tuple[etree._Element, int, int, int, int]] = []
    pos = 0
    for node in nodes:
        text = node.text or ""
        n_start, n_end = pos, pos + len(text)
        if n_end > start and n_start < end:
            spans.append((node, n_start, n_end, max(start - n_start, 0), min(end - n_start, len(text))))
        pos = n_end

    first, *_first_span, first_from, first_to = spans[0]
    last, *_last_span, _last_from, last_to = spans[-1]
    first_text = first.text or ""
    last_text = last.text or ""
    rpr = clone_rpr_from_text_node(first)
    suffix_run: etree._Element | None = None
    if first is last:
        first.text = first_text[:first_from]
        suffix = first_text[first_to:]
        if suffix:
            suffix_run = make_run(suffix, rpr)
    else:
        first.text = first_text[:first_from]
        for middle, *_ in spans[1:-1]:
            middle.text = ""
        last.text = last_text[last_to:]

    anchor = immediate_child_of(p, first)
    idx = p.index(anchor) + 1
    p.insert(idx, make_change("del", "delText", old, cid, when, rpr))
    cid += 1
    p.insert(idx + 1, make_change("ins", "t", new, cid, when, rpr))
    cid += 1
    if suffix_run is not None:
        p.insert(idx + 2, suffix_run)
    return True, cid


def apply_replacements(doc_root: etree._Element, replacements: list[tuple[str, str]]) -> list[tuple[str, str, int]]:
    when = dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    cid = next_change_id(doc_root)
    paragraphs = doc_root.xpath(".//w:p", namespaces=NS)
    results: list[tuple[str, str, int]] = []
    for old, new in replacements:
        count = 0
        changed = True
        while changed:
            changed = False
            for p in paragraphs:
                ok, cid = replace_once(p, old, new, cid, when)
                if ok:
                    count += 1
                    changed = True
                    break
        results.append((old, new, count))
    return results


def xml_bytes(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")


def patch_docx(src: Path) -> tuple[Path, Path, list[tuple[str, str, int]]]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    DELIVERY_DIR.mkdir(parents=True, exist_ok=True)
    out = OUT_DIR / f"{src.stem} - tracked corrections.docx"
    delivery = DELIVERY_DIR / out.name
    replacements = COMMON_REPLACEMENTS + FILE_REPLACEMENTS.get(src.name, [])

    with zipfile.ZipFile(src, "r") as zin:
        doc_root = etree.fromstring(zin.read("word/document.xml"))
        settings_name = "word/settings.xml"
        settings_root = (
            etree.fromstring(zin.read(settings_name))
            if settings_name in zin.namelist()
            else etree.Element(w("settings"), nsmap={"w": W_NS})
        )
        enable_track_revisions(settings_root)
        results = apply_replacements(doc_root, replacements)
        overrides = {
            "word/document.xml": xml_bytes(doc_root),
            settings_name: xml_bytes(settings_root),
        }

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            wrote_settings = False
            for info in zin.infolist():
                if info.filename in overrides:
                    zout.writestr(info, overrides[info.filename])
                    wrote_settings = wrote_settings or info.filename == settings_name
                else:
                    zout.writestr(info, zin.read(info.filename))
            if not wrote_settings:
                zout.writestr(settings_name, overrides[settings_name])

    shutil.copy2(out, delivery)
    return out, delivery, results


def main() -> None:
    for src in sorted(FILE_REPLACEMENTS):
        out, delivery, results = patch_docx(ROOT / src)
        print(f"Wrote: {out}")
        print(f"Copied: {delivery}")
        for old, new, count in results:
            if count:
                print(f"  {count:2d} | {old} -> {new}")
        print()


if __name__ == "__main__":
    main()
