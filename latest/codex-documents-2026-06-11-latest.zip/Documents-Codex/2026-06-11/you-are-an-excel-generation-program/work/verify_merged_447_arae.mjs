import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE/Final 447 and araE.xlsx";
const deliveryPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae/Final 447 and araE.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/merged_447_arae_final_verify";

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

function tableFrom(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

await fs.mkdir(previewDir, { recursive: true });

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const sheets = workbook.worksheets.items.map((sheet) => sheet.name);
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "merged workbook final formula error scan",
  maxChars: 2000,
});
const drawings = {};
const diagnosisCounts = {};
for (const sheetName of ["Final 447", "Final araE"]) {
  const drawing = await workbook.inspect({ kind: "drawing", sheetId: sheetName, maxChars: 2000 });
  drawings[sheetName] = drawing.ndjson;
  const preview = await workbook.render({ sheetName, range: "A1:N60", scale: 0.7, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}
for (const sheetName of ["Sample Log 447", "Sample Log araE"]) {
  const table = await workbook.inspect({
    kind: "table",
    range: `${sheetName}!A1:N59`,
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 14,
    maxChars: 50000,
  });
  const values = tableFrom(table.ndjson).values;
  const counts = {};
  for (const row of values.slice(1)) counts[row[13]] = (counts[row[13]] ?? 0) + 1;
  diagnosisCounts[sheetName] = counts;
}

const sidecars = [];
for (const dir of [path.dirname(sourcePath), path.dirname(deliveryPath)]) {
  for (const entry of await fs.readdir(dir)) {
    if (entry.endsWith(".inspect.ndjson")) sidecars.push(path.join(dir, entry));
  }
}

process.stdout.write(JSON.stringify({
  sheets,
  errors: errors.ndjson,
  diagnosisCounts,
  drawings,
  sourceDeliveryHashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
  sidecars,
}, null, 2));
