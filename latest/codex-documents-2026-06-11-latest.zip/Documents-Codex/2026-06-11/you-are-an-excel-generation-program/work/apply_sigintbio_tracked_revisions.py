from __future__ import annotations

import datetime as dt
import shutil
import zipfile
from pathlib import Path

from lxml import etree


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W_NS}


def w(tag: str) -> str:
    return f"{{{W_NS}}}{tag}"


REPLACEMENTS: list[tuple[str, str]] = [
    ("וועדת המחקר", "ועדת המחקר"),
    ("סימפטומים זהים לאלו של תסמונת המעי הרגיז", "תסמינים החופפים לאלו של תסמונת המעי הרגיז"),
    ("ע\"י קורא", "על ידי קורא"),
    ("תוכנה ייעודית משלבת בינה מלאכותית", "תוכנה ייעודית המשלבת בינה מלאכותית"),
    ("אותות יחודיים", "אותות ייחודיים"),
    ("Clinical Laboratory Improvement Amendment", "Clinical Laboratory Improvement Amendments"),
    ("HIPPA", "HIPAA"),
    ("(א)התקינה", "(א) התקינה"),
    ("Autoclave סטנדרטיות (121c)", "Autoclave סטנדרטיות (121°C)"),
    ("חלק זה מתקיים אף הוא מסגרת תיקוף", "חלק זה מתקיים אף הוא במסגרת תיקוף"),
    ("השולמה החתימה", "הושלמה החתימה"),
    ("הטכנולוגיית הביוקונברג'נס", "טכנולוגיית הביוקונברג'נס"),
    ("הטכנולוגיית הביוקונברג׳נס", "טכנולוגיית הביוקונברג׳נס"),
    ("מיקרוביולגית", "מיקרוביולוגית"),
    ("מיקורביולוגיות", "מיקרוביולוגיות"),
    ("ל1,000", "ל־1,000"),
    ("לSIGINT.bio", "ל־SIGINT.bio"),
    ("בהיבט המחקרי, הנדסי והקליני", "בהיבטים המחקרי, ההנדסי והקליני"),
    ("קפלרוטקטין", "קלפרוטקטין"),
    ("אבדן", "אובדן"),
    ("DeNovo", "De Novo"),
    ("קניניות", "קנייניות"),
    ("של  ,SIGINT.bioמבוסס", "של SIGINT.bio, מבוסס"),
    ("הידע החדש שיווצר", "הידע החדש שייווצר"),
    ("ככל שיווצר", "ככל שייווצר"),
    ("ואו שמיקום המחלה", "ו/או שמיקום המחלה"),
    ("יש עניין מצידם", "יש עניין מצדם"),
    ("היבטי work flow", "היבטי workflow"),
    ("חוסך לחברות הביטוח עשות אלפי דולרים", "חוסך לחברות הביטוח עשרות אלפי דולרים"),
    ("מעבדות מיקרוביולוגית", "מעבדות מיקרוביולוגיות"),
    ("Category I code)אשר", "Category I code) אשר"),
    ("(משרתת את כלל ארה\"ב)ובה", "(משרתת את כלל ארה\"ב) ובה"),
    ("מעברת למכירת תרביות", "מעבר למכירת תרביות"),
    ("מחולי קורהן", "מחולי קרוהן"),
    ("ב1.1.2028", "ב־1.1.2028"),
    ("לפעול המודל שותפות בהכנסות", "לפעול במודל שותפות בהכנסות"),
    ("יחידותCP", "יחידות CP"),
    ("המוצר לשנו", "המוצר שלנו"),
    ("לאבחוני מחלות שונות", "לאבחון מחלות שונות"),
    ("תשתית נתונים וולידציה", "תשתית נתונים ותיקוף"),
    ("תהליך הבדיקה כולל שימוש במד אותות חשמליים סטנדרטי", "תהליך הבדיקה כולל שימוש במכשיר מדידה אלקטרוכימי סטנדרטי"),
    ("מחלות מעיים דלקתיות מטופלות", "מחלות מעי דלקתיות מטופלות"),
    ("רשת קליניקות גסטרו", "רשת קליניקות גסטרואנטרולוגיה"),
]


def enable_track_revisions(settings_root: etree._Element) -> None:
    if settings_root.find("w:trackRevisions", namespaces=NS) is None:
        settings_root.insert(0, etree.Element(w("trackRevisions")))


def next_change_id(root: etree._Element) -> int:
    ids: list[int] = []
    for el in root.xpath(".//*[@w:id]", namespaces=NS):
        try:
            ids.append(int(el.get(w("id"))))
        except (TypeError, ValueError):
            pass
    return max(ids, default=0) + 1


def make_del(text: str, cid: int, author: str, when: str) -> etree._Element:
    d = etree.Element(w("del"))
    d.set(w("id"), str(cid))
    d.set(w("author"), author)
    d.set(w("date"), when)
    r = etree.SubElement(d, w("r"))
    t = etree.SubElement(r, w("delText"))
    t.text = text
    return d


def make_ins(text: str, cid: int, author: str, when: str) -> etree._Element:
    ins = etree.Element(w("ins"))
    ins.set(w("id"), str(cid))
    ins.set(w("author"), author)
    ins.set(w("date"), when)
    r = etree.SubElement(ins, w("r"))
    t = etree.SubElement(r, w("t"))
    if text.startswith(" ") or text.endswith(" "):
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text
    return ins


def visible_text_nodes(p: etree._Element) -> list[etree._Element]:
    nodes: list[etree._Element] = []
    for t in p.xpath(".//w:t", namespaces=NS):
        if any(a.tag in {w("del"), w("ins")} for a in t.iterancestors()):
            continue
        nodes.append(t)
    return nodes


def immediate_child_of(parent: etree._Element, descendant: etree._Element) -> etree._Element:
    node = descendant
    while node.getparent() is not None and node.getparent() is not parent:
        node = node.getparent()
    return node


def replace_once_in_paragraph(
    p: etree._Element,
    old: str,
    new: str,
    cid: int,
    author: str,
    when: str,
) -> tuple[bool, int]:
    nodes = visible_text_nodes(p)
    full = "".join(n.text or "" for n in nodes)
    start = full.find(old)
    if start == -1:
        return False, cid
    end = start + len(old)

    spans: list[tuple[etree._Element, int, int, int, int]] = []
    pos = 0
    for node in nodes:
        text = node.text or ""
        n_start, n_end = pos, pos + len(text)
        if n_end > start and n_start < end:
            spans.append((node, n_start, n_end, max(start - n_start, 0), min(end - n_start, len(text))))
        pos = n_end

    if not spans:
        return False, cid

    first, _, _, first_from, first_to = spans[0]
    last, _, _, last_from, last_to = spans[-1]
    first_text = first.text or ""
    last_text = last.text or ""
    first.text = first_text[:first_from]
    if first is last:
        first.text = first_text[:first_from] + first_text[first_to:]
    else:
        for middle, *_ in spans[1:-1]:
            middle.text = ""
        last.text = last_text[last_to:]

    container = p
    anchor = immediate_child_of(container, first)
    insert_at = container.index(anchor) + 1
    container.insert(insert_at, make_del(old, cid, author, when))
    cid += 1
    container.insert(insert_at + 1, make_ins(new, cid, author, when))
    cid += 1
    return True, cid


def apply_replacements(doc_root: etree._Element, author: str) -> list[tuple[str, str, int]]:
    when = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    cid = next_change_id(doc_root)
    results: list[tuple[str, str, int]] = []
    paragraphs = doc_root.xpath(".//w:p", namespaces=NS)

    for old, new in REPLACEMENTS:
        count = 0
        changed = True
        while changed:
            changed = False
            for p in paragraphs:
                ok, cid = replace_once_in_paragraph(p, old, new, cid, author, when)
                if ok:
                    count += 1
                    changed = True
                    break
        results.append((old, new, count))
    return results


def xml_bytes(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")


def main() -> None:
    src = next((Path.home() / ".codex").rglob("*SIGINTbio.docx"))
    out = src.with_name(src.stem + " - tracked corrections.docx")
    delivery = Path.cwd() / "outputs" / "SIGINTbio_tracked_corrections.docx"
    delivery.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(src, "r") as zin:
        doc_root = etree.fromstring(zin.read("word/document.xml"))
        settings_name = "word/settings.xml"
        settings_root = (
            etree.fromstring(zin.read(settings_name))
            if settings_name in zin.namelist()
            else etree.Element(w("settings"), nsmap={"w": W_NS})
        )
        enable_track_revisions(settings_root)
        results = apply_replacements(doc_root, "Codex")

        overrides = {
            "word/document.xml": xml_bytes(doc_root),
            settings_name: xml_bytes(settings_root),
        }

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for info in zin.infolist():
                if info.filename in overrides:
                    zout.writestr(info, overrides[info.filename])
                else:
                    zout.writestr(info, zin.read(info.filename))
            if settings_name not in zin.namelist():
                zout.writestr(settings_name, overrides[settings_name])

    shutil.copy2(out, delivery)
    print(f"Wrote: {out}")
    print(f"Copied: {delivery}")
    print("Replacement counts:")
    for old, new, count in results:
        print(f"{count:2d} | {old} -> {new}")


if __name__ == "__main__":
    main()
