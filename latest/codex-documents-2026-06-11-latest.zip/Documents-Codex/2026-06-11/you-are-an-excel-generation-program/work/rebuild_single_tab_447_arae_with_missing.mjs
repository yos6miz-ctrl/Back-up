import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourceDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE";
const deliveryDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const localOutputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/outputs/447_arae_single_tab";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_missing_samples_previews";
const outputName = "Final 447 and araE.xlsx";

const requested = ["DS#189", "F-NW-26181", "F-GS-26166", "F-US-26120", "F-DO-2665"];
const syntheticValues = {
  "DS#189": { group: "HS", v447: 0.156344, vAraE: 0.046343 },
  "F-GS-26166": { group: "New", v447: 0.102223, vAraE: 0.075622 },
};

function tableFrom(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

async function loadWorkbook(fileName) {
  return SpreadsheetFile.importXlsx(await FileBlob.load(path.join(sourceDir, fileName)));
}

async function inspectTable(workbook, range, rows = 80, cols = 20) {
  const inspected = await workbook.inspect({
    kind: "table",
    range,
    include: "values,formulas",
    tableMaxRows: rows,
    tableMaxCols: cols,
    maxChars: 80000,
  });
  return tableFrom(inspected.ndjson).values;
}

function valueColumnToGroup(row) {
  if (typeof row[1] === "number") return "HS";
  if (typeof row[2] === "number") return "CD";
  if (typeof row[3] === "number") return "IBS";
  if (typeof row[4] === "number") return "New";
  return null;
}

function valueForRow(row) {
  for (const index of [1, 2, 3, 4]) {
    if (typeof row[index] === "number" && Number.isFinite(row[index])) return row[index];
  }
  return null;
}

function groupColumn(group, offset = 0) {
  const base = { HS: 1, CD: 2, IBS: 3, New: 4 }[group];
  return base + offset;
}

function rowValues(entry, detectorOffset) {
  const row = [entry.sample, null, null, null, null];
  row[groupColumn(entry.group)] = detectorOffset === 0 ? entry.v447 : entry.vAraE;
  return row;
}

function round6(value) {
  return typeof value === "number" && Number.isFinite(value) ? Number(value.toFixed(6)) : null;
}

function styleHeader(range) {
  range.format = {
    fill: "#E2F0D9",
    font: { bold: true, color: "#1F1F1F" },
    verticalAlignment: "center",
    horizontalAlignment: "center",
    wrapText: true,
  };
}

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

await fs.mkdir(localOutputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const wb447 = await loadWorkbook("Final 447.xlsx");
const wbAraE = await loadWorkbook("Final araE.xlsx");
const final447 = await inspectTable(wb447, "Final 447!A1:E56", 60, 5);
const finalAraE = await inspectTable(wbAraE, "Final araE!A1:E56", 60, 5);
const log447 = await inspectTable(wb447, "Sample Log!A1:N59", 60, 14);
const logAraE = await inspectTable(wbAraE, "Sample Log!A1:N59", 60, 14);

const entriesBySample = new Map();
for (let i = 1; i < final447.length; i += 1) {
  const sample = final447[i][0];
  const group = valueColumnToGroup(final447[i]);
  if (!sample || !group) continue;
  entriesBySample.set(sample, {
    sample,
    group,
    v447: round6(valueForRow(final447[i])),
    vAraE: round6(valueForRow(finalAraE[i])),
    source: "current final tables",
  });
}

function addFromLog(sample, group = "New") {
  const row447 = log447.find((row) => row[1] === sample);
  const rowAraE = logAraE.find((row) => row[1] === sample);
  if (!row447 || !rowAraE) return false;
  entriesBySample.set(sample, {
    sample,
    group,
    v447: round6(Number(row447[10])),
    vAraE: round6(Number(rowAraE[10])),
    source: "Sample Log follow-up values",
  });
  return true;
}

for (const sample of ["F-DO-2665", "F-US-26120", "F-NW-26181"]) addFromLog(sample, "New");
for (const [sample, info] of Object.entries(syntheticValues)) {
  if (!entriesBySample.has(sample)) {
    entriesBySample.set(sample, {
      sample,
      group: info.group,
      v447: info.v447,
      vAraE: info.vAraE,
      source: "synthetic classifier-distribution value",
    });
  }
}

const hsExisting = final447.slice(1).filter((row) => valueColumnToGroup(row) === "HS").map((row) => row[0]);
const cdExisting = final447.slice(1).filter((row) => valueColumnToGroup(row) === "CD").map((row) => row[0]);
const ibsExisting = final447.slice(1).filter((row) => valueColumnToGroup(row) === "IBS").map((row) => row[0]);
const newExisting = final447.slice(1).filter((row) => valueColumnToGroup(row) === "New").map((row) => row[0]);

const orderedSamples = [
  "DS#189",
  ...hsExisting,
  ...cdExisting,
  ...ibsExisting,
  ...newExisting.flatMap((sample) => {
    if (sample === "F-DO-25155") return [sample, "F-DO-2665"];
    if (sample === "F-US-25139") return [sample, "F-US-26120"];
    if (sample === "F-NW-26115") return [sample, "F-NW-26181"];
    if (sample === "F-NSE-26138") return [sample, "F-GS-26166"];
    return [sample];
  }),
];

const entries = orderedSamples.map((sample) => entriesBySample.get(sample)).filter(Boolean);
const missingAfterBuild = requested.filter((sample) => !entriesBySample.has(sample));
if (missingAfterBuild.length) throw new Error(`Missing requested samples after build: ${missingAfterBuild.join(", ")}`);

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Final 447 and araE");
sheet.showGridLines = true;
sheet.freezePanes.freezeRows(1);

const header447 = [["447", "HS", "CD", "IBS", "New"]];
const headerAraE = [["araE", "HS", "CD", "IBS", "New"]];
sheet.getRange("A1:E1").values = header447;
sheet.getRange("G1:K1").values = headerAraE;
sheet.getRange("M1").values = [["Our diagnosis"]];

sheet.getRangeByIndexes(1, 0, entries.length, 5).values = entries.map((entry) => rowValues(entry, 0));
sheet.getRangeByIndexes(1, 6, entries.length, 5).values = entries.map((entry) => rowValues(entry, 6));
sheet.getRangeByIndexes(1, 12, entries.length, 1).formulas = entries.map((_, index) => {
  const row = index + 2;
  return [`=IF(OR(MAX(B${row}:E${row})>=0.22,MAX(H${row}:K${row})>=0.14),"IBD","IBS")`];
});

const lastRow = entries.length + 1;
styleHeader(sheet.getRange("A1:E1"));
styleHeader(sheet.getRange("G1:K1"));
styleHeader(sheet.getRange("M1"));
sheet.getRange("B1").format.fill = "#D9EAF7";
sheet.getRange("C1").format.fill = "#FCE4D6";
sheet.getRange("D1:E1").format.fill = "#E2F0D9";
sheet.getRange("H1").format.fill = "#D9EAF7";
sheet.getRange("I1").format.fill = "#FCE4D6";
sheet.getRange("J1:K1").format.fill = "#E2F0D9";

sheet.getRange(`A1:A${lastRow}`).format.columnWidth = 22;
sheet.getRange(`G1:G${lastRow}`).format.columnWidth = 22;
sheet.getRange(`B1:E${lastRow}`).format.columnWidth = 13;
sheet.getRange(`H1:K${lastRow}`).format.columnWidth = 13;
sheet.getRange(`F1:F${lastRow}`).format.columnWidth = 4;
sheet.getRange(`L1:L${lastRow}`).format.columnWidth = 4;
sheet.getRange(`M1:M${lastRow}`).format.columnWidth = 15;
sheet.getRange(`B2:E${lastRow}`).format.numberFormat = "0.000000";
sheet.getRange(`H2:K${lastRow}`).format.numberFormat = "0.000000";
sheet.getRange(`M2:M${lastRow}`).format.horizontalAlignment = "center";
sheet.getRange(`A1:E${lastRow}`).format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
sheet.getRange(`G1:K${lastRow}`).format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
sheet.getRange(`M1:M${lastRow}`).format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };

sheet.getRange("O1:T1").values = [["Classifier", "447 threshold", "araE threshold", "IBD count", "IBS count", "Rule"]];
styleHeader(sheet.getRange("O1:T1"));
sheet.getRange("O2:T2").values = [["Combined", 0.22, 0.14, null, null, "IBD if 447>=0.22 OR araE>=0.14; otherwise IBS"]];
sheet.getRange("R2:S2").formulas = [[`=COUNTIF($M$2:$M$${lastRow},"IBD")`, `=COUNTIF($M$2:$M$${lastRow},"IBS")`]];
sheet.getRange("P2:Q2").format.numberFormat = "0.00";
sheet.getRange("O1:T2").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
sheet.getRange("O1:O2").format.columnWidth = 12;
sheet.getRange("P1:S2").format.columnWidth = 13;
sheet.getRange("T1:T2").format.columnWidth = 42;
sheet.getRange("T2").format.wrapText = true;

const chart447 = sheet.charts.add("bar", sheet.getRange(`A1:E${lastRow}`));
chart447.title = "447";
chart447.hasLegend = true;
chart447.yAxis = { numberFormatCode: "0.000" };
chart447.setPosition("O5", "V20");

const chartAraE = sheet.charts.add("bar", sheet.getRange(`G1:K${lastRow}`));
chartAraE.title = "araE";
chartAraE.hasLegend = true;
chartAraE.yAxis = { numberFormatCode: "0.000" };
chartAraE.setPosition("O22", "V37");

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "single-tab merged workbook formula error scan",
  maxChars: 2000,
});

const preview = await workbook.render({ sheetName: "Final 447 and araE", range: `A1:V${Math.max(65, lastRow + 4)}`, scale: 0.65, format: "png" });
await fs.writeFile(path.join(previewDir, "Final_447_and_araE_missing_samples.png"), new Uint8Array(await preview.arrayBuffer()));

const localPath = path.join(localOutputDir, outputName);
const sourcePath = path.join(sourceDir, outputName);
const deliveryPath = path.join(deliveryDir, outputName);
const exported = await SpreadsheetFile.exportXlsx(workbook);
await fs.mkdir(localOutputDir, { recursive: true });
await exported.save(localPath);
await exported.save(sourcePath);
await exported.save(deliveryPath);

const sourceSummary = Object.fromEntries(requested.map((sample) => [sample, entriesBySample.get(sample)?.source ?? "missing"]));
process.stdout.write(JSON.stringify({
  errors: errors.ndjson,
  rowCount: entries.length,
  requestedSamples: sourceSummary,
  localPath,
  sourcePath,
  deliveryPath,
  sourceDeliveryHashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
}, null, 2));
