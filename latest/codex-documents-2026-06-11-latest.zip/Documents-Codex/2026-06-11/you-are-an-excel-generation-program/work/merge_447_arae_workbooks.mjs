import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourceDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE";
const deliveryDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const localOutputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/outputs/447_arae_merged";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_merged_previews";

const specs = [
  { detector: "447", fileName: "Final 447.xlsx", resultSheet: "Final 447", logSheet: "Sample Log 447", pairSheet: "Follow-up Pairs 447" },
  { detector: "araE", fileName: "Final araE.xlsx", resultSheet: "Final araE", logSheet: "Sample Log araE", pairSheet: "Follow-up Pairs araE" },
];

function extractTable(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

async function sourceTable(workbook, range) {
  const inspected = await workbook.inspect({
    kind: "table",
    range,
    include: "values,formulas",
    tableMaxRows: 80,
    tableMaxCols: 20,
    maxChars: 80000,
  });
  return extractTable(inspected.ndjson).values;
}

function cloneRows(rows) {
  return rows.map((row) => row.map((value) => value ?? null));
}

function adjustFormula(value, logSheet) {
  if (typeof value !== "string" || !value.startsWith("=")) return value;
  return value.replace(/'Sample Log'!/g, `'${logSheet}'!`);
}

function writeMatrix(sheet, range, matrix, logSheet = null) {
  const values = matrix.map((row) => row.map((value) => adjustFormula(value, logSheet)));
  sheet.getRange(range).values = values.map((row) => row.map((value) => (typeof value === "string" && value.startsWith("=") ? null : value)));
  const formulas = values.map((row) => row.map((value) => (typeof value === "string" && value.startsWith("=") ? value : null)));
  const hasFormula = formulas.some((row) => row.some((value) => value));
  if (hasFormula) sheet.getRange(range).formulas = formulas;
}

function styleHeader(range) {
  range.format = {
    fill: "#375623",
    font: { color: "#FFFFFF", bold: true },
    wrapText: true,
    verticalAlignment: "center",
  };
}

function styleResultSheet(sheet, detector) {
  sheet.showGridLines = true;
  sheet.freezePanes.freezeRows(1);
  sheet.getRange("A1:F1").format = {
    fill: "#E2F0D9",
    font: { bold: true, color: "#1F1F1F" },
    verticalAlignment: "center",
    wrapText: true,
  };
  sheet.getRange("B1").format.fill = "#D9EAF7";
  sheet.getRange("C1").format.fill = "#FCE4D6";
  sheet.getRange("D1:F1").format.fill = "#E2F0D9";
  sheet.getRange("A1:F56").format.columnWidth = 15;
  sheet.getRange("A1:A56").format.columnWidth = 22;
  sheet.getRange("B2:E56").format.numberFormat = "0.000000";
  sheet.getRange("F2:F56").format = { horizontalAlignment: "center" };
  sheet.getRange("G1:K5").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
  styleHeader(sheet.getRange("G1:K1"));
  sheet.getRange("H2:H5").format.numberFormat = "0.000000";
  sheet.getRange("I2:K5").format.numberFormat = "0";
  sheet.getRange("G1:G5").format.columnWidth = 12;
  sheet.getRange("H1:H5").format.columnWidth = 14;
  sheet.getRange("I1:K5").format.columnWidth = 11;
  sheet.getRange("G24:K24").format = {
    fill: "#375623",
    font: { color: "#FFFFFF", bold: true },
    horizontalAlignment: "center",
  };
  sheet.getRange("G25:K25").format = {
    borders: { preset: "all", style: "thin", color: "#D9E2F3" },
    wrapText: true,
  };
  sheet.getRange("I25:J25").format.numberFormat = "0.00";

  const chart = sheet.charts.add("bar", sheet.getRange("G1:H5"));
  chart.title = `Mean normalized ${detector} response by group`;
  chart.hasLegend = false;
  chart.yAxis = { numberFormatCode: "0.000" };
  chart.setPosition("G7", "N22");
}

function styleLogSheet(sheet) {
  sheet.showGridLines = false;
  sheet.freezePanes.freezeRows(1);
  styleHeader(sheet.getRange("A1:N1"));
  sheet.getRange("A1:N1").format.rowHeight = 32;
  sheet.getRange("A2:N59").format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
  sheet.getRange("F2:K59").format.numberFormat = "0.000000";
  sheet.getRange("J2:J59").format.numberFormat = "0.0%";
  sheet.getRange("A1:A59").format.columnWidth = 11;
  sheet.getRange("B1:B59").format.columnWidth = 20;
  sheet.getRange("C1:C59").format.columnWidth = 31;
  sheet.getRange("D1:D59").format.columnWidth = 23;
  sheet.getRange("E1:E59").format.columnWidth = 12;
  sheet.getRange("F1:K59").format.columnWidth = 14;
  sheet.getRange("L1:L59").format.columnWidth = 25;
  sheet.getRange("M1:M59").format.columnWidth = 55;
  sheet.getRange("N1:N59").format.columnWidth = 15;
  sheet.getRange("C2:E59").format.wrapText = true;
  sheet.getRange("L2:N59").format.wrapText = true;
  sheet.getRange("N2:N59").format.horizontalAlignment = "center";
}

function stylePairsSheet(sheet) {
  sheet.showGridLines = false;
  sheet.freezePanes.freezeRows(1);
  styleHeader(sheet.getRange("A1:I1"));
  sheet.getRange("A1:I1").format.rowHeight = 32;
  sheet.getRange("A2:I4").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
  sheet.getRange("D2:F4").format.numberFormat = "0.000000";
  sheet.getRange("A1:A4").format.columnWidth = 10;
  sheet.getRange("B1:B4").format.columnWidth = 22;
  sheet.getRange("C1:C4").format.columnWidth = 20;
  sheet.getRange("D1:D4").format.columnWidth = 16;
  sheet.getRange("E1:E4").format.columnWidth = 20;
  sheet.getRange("F1:F4").format.columnWidth = 16;
  sheet.getRange("G1:H4").format.columnWidth = 16;
  sheet.getRange("I1:I4").format.columnWidth = 31;
  sheet.getRange("I2:I4").format.wrapText = true;
}

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

await fs.mkdir(localOutputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const sourceData = [];
for (const spec of specs) {
  const sourcePath = path.join(sourceDir, spec.fileName);
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
  sourceData.push({
    spec,
    resultRows: await sourceTable(workbook, `${spec.resultSheet}!A1:K56`),
    logRows: await sourceTable(workbook, "Sample Log!A1:N59"),
    pairRows: await sourceTable(workbook, "Follow-up Pairs!A1:I4"),
  });
}

const merged = Workbook.create();

for (const { spec, resultRows, logRows, pairRows } of sourceData) {
  const result = merged.worksheets.add(spec.resultSheet);
  const log = merged.worksheets.add(spec.logSheet);
  const pairs = merged.worksheets.add(spec.pairSheet);

  writeMatrix(result, "A1:K56", cloneRows(resultRows), spec.logSheet);
  writeMatrix(log, "A1:N59", cloneRows(logRows), spec.logSheet);
  writeMatrix(pairs, "A1:I4", cloneRows(pairRows), spec.logSheet);

  styleResultSheet(result, spec.detector);
  styleLogSheet(log);
  stylePairsSheet(pairs);
}

const errors = await merged.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "merged workbook formula error scan",
  maxChars: 2000,
});

for (const sheetName of ["Final 447", "Final araE"]) {
  const preview = await merged.render({ sheetName, range: "A1:N60", scale: 0.7, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}
for (const sheetName of ["Sample Log 447", "Sample Log araE", "Follow-up Pairs 447", "Follow-up Pairs araE"]) {
  const range = sheetName.startsWith("Follow") ? "A1:I7" : "A1:N59";
  const preview = await merged.render({ sheetName, range, scale: sheetName.startsWith("Follow") ? 1 : 0.55, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}

const fileName = "Final 447 and araE.xlsx";
const localPath = path.join(localOutputDir, fileName);
const sourcePath = path.join(sourceDir, fileName);
const deliveryPath = path.join(deliveryDir, fileName);
const exported = await SpreadsheetFile.exportXlsx(merged);
await exported.save(localPath);
await exported.save(sourcePath);
await exported.save(deliveryPath);

process.stdout.write(JSON.stringify({
  errors: errors.ndjson,
  localPath,
  sourcePath,
  deliveryPath,
  sourceDeliveryHashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
  sheets: merged.worksheets.items.map((sheet) => sheet.name),
}, null, 2));
