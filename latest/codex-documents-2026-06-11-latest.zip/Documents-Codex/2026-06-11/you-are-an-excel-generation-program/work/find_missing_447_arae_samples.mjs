import fs from "node:fs/promises";

const workDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/work/447_arae";
const targets = ["DS#189", "F-NW-26181", "F-GS-26166", "F-US-26120", "F-DO-2665"];

function canonical(v) {
  return String(v ?? "")
    .toUpperCase()
    .trim()
    .replace(/^(?:IBS|CDF|CDR|CD|HS|UN)\s*/g, "")
    .replace(/[^A-Z0-9]/g, "")
    .replace(/^F/, "");
}

const merged = JSON.parse(await fs.readFile(`${workDir}/inspect_merged/01.json`, "utf8")).sheets[0].values;
const diagnosis = JSON.parse(await fs.readFile(`${workDir}/inspect_diagnosis/01.json`, "utf8")).sheets[0].values;
const shipment = JSON.parse(await fs.readFile(`${workDir}/inspect/07.json`, "utf8")).sheets[0].values;
const july = JSON.parse(await fs.readFile(`${workDir}/inspect/08.json`, "utf8")).sheets[0].values;

function findRows(rows, target) {
  const key = canonical(target);
  return rows
    .map((row, index) => ({ index: index + 1, row }))
    .filter(({ row }) => row.some((cell) => canonical(cell) === key));
}

const found = {};
for (const target of targets) {
  found[target] = {
    merged: findRows(merged, target),
    diagnosis: findRows(diagnosis, target),
    shipment: findRows(shipment, target),
    july: findRows(july, target),
  };
}

for (const [target, sources] of Object.entries(found)) {
  process.stdout.write(`\n${target}\n`);
  for (const [name, rows] of Object.entries(sources)) {
    process.stdout.write(` ${name}: ${rows.length}\n`);
    for (const item of rows.slice(0, 5)) process.stdout.write(`  row ${item.index}: ${JSON.stringify(item.row)}\n`);
  }
}
