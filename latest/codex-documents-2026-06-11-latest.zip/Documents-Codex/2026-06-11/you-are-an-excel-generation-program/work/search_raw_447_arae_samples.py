from __future__ import annotations

import json
import re
from pathlib import Path

from openpyxl import load_workbook

ROOT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip")
SEARCH_DIRS = [
    ROOT / "447 and araE 2026",
]
TARGETS = ["DS#189", "F-NW-26181", "F-GS-26166", "F-US-26120", "F-DO-2665"]


def canonical(value) -> str:
    s = str(value or "").upper().strip()
    s = re.sub(r"^(IBS|CDF|CDR|CD|HS|UN)\s*", "", s)
    s = re.sub(r"[^A-Z0-9]", "", s)
    s = re.sub(r"^F", "", s)
    return s


target_keys = {canonical(t): t for t in TARGETS}
matches = []

for directory in SEARCH_DIRS:
    for path in sorted(directory.glob("*.xls*")):
        if path.name.startswith("~$"):
            continue
        try:
            wb = load_workbook(path, data_only=True, read_only=True)
        except Exception as exc:
            matches.append({"file": str(path), "error": repr(exc)})
            continue
        for ws in wb.worksheets:
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 80), values_only=False):
                for cell in row:
                    key = canonical(cell.value)
                    if key in target_keys:
                        values = [c.value for c in row]
                        matches.append(
                            {
                                "target": target_keys[key],
                                "file": str(path),
                                "sheet": ws.title,
                                "cell": cell.coordinate,
                                "row": cell.row,
                                "col": cell.column,
                                "row_values": values,
                            }
                        )
        wb.close()

out = Path("work/raw_447_arae_sample_search.json")
out.write_text(json.dumps(matches, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(matches, ensure_ascii=False, indent=2))
