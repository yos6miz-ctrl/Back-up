import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const sourceDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE";
const deliveryDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const localOutputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/outputs/447_arae_single_tab";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_single_tab_previews";
const outputName = "Final 447 and araE.xlsx";

function tableFrom(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

async function sourceTable(fileName, sheetName, range) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(sourceDir, fileName)));
  const inspected = await workbook.inspect({
    kind: "table",
    range: `${sheetName}!${range}`,
    include: "values",
    tableMaxRows: 80,
    tableMaxCols: 20,
    maxChars: 80000,
  });
  return tableFrom(inspected.ndjson).values;
}

function valueOrBlank(value) {
  return value === undefined ? null : value;
}

function writeValues(sheet, startCell, values) {
  sheet.getRange(startCell).write(values.map((row) => row.map(valueOrBlank)));
}

function styleHeader(range) {
  range.format = {
    fill: "#E2F0D9",
    font: { bold: true, color: "#1F1F1F" },
    verticalAlignment: "center",
    horizontalAlignment: "center",
    wrapText: true,
  };
}

function setResultBlockStyle(sheet, rangePrefix, diagnosisCol = null) {
  const header = sheet.getRange(`${rangePrefix}1:${diagnosisCol ?? rangePrefix.replace(/[A-Z]+$/, "")}1`);
  styleHeader(header);
}

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

await fs.mkdir(localOutputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const table447 = await sourceTable("Final 447.xlsx", "Final 447", "A1:E56");
const tableAraE = await sourceTable("Final araE.xlsx", "Final araE", "A1:E56");

const samples = table447.slice(1).map((row) => row[0]);
const combinedDiagnoses = [];
for (let i = 1; i < table447.length; i += 1) {
  const values447 = table447[i].slice(1, 5).filter((v) => typeof v === "number" && Number.isFinite(v));
  const valuesAraE = tableAraE[i].slice(1, 5).filter((v) => typeof v === "number" && Number.isFinite(v));
  const v447 = values447.length ? values447[0] : null;
  const vAraE = valuesAraE.length ? valuesAraE[0] : null;
  const diagnosis = (typeof v447 === "number" && v447 >= 0.22) || (typeof vAraE === "number" && vAraE >= 0.14)
    ? "IBD"
    : "IBS";
  combinedDiagnoses.push([diagnosis]);
}

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Final 447 and araE");
sheet.showGridLines = true;
sheet.freezePanes.freezeRows(1);

writeValues(sheet, "A1", table447);
writeValues(sheet, "G1", tableAraE);
sheet.getRange("M1").values = [["Our diagnosis"]];
sheet.getRange("M2:M56").values = combinedDiagnoses;

styleHeader(sheet.getRange("A1:E1"));
styleHeader(sheet.getRange("G1:K1"));
styleHeader(sheet.getRange("M1"));
sheet.getRange("A1").format.fill = "#E2F0D9";
sheet.getRange("B1").format.fill = "#D9EAF7";
sheet.getRange("C1").format.fill = "#FCE4D6";
sheet.getRange("D1:E1").format.fill = "#E2F0D9";
sheet.getRange("G1").format.fill = "#E2F0D9";
sheet.getRange("H1").format.fill = "#D9EAF7";
sheet.getRange("I1").format.fill = "#FCE4D6";
sheet.getRange("J1:K1").format.fill = "#E2F0D9";
sheet.getRange("M1").format.fill = "#E2F0D9";

sheet.getRange("A1:A56").format.columnWidth = 22;
sheet.getRange("G1:G56").format.columnWidth = 22;
sheet.getRange("B1:E56").format.columnWidth = 13;
sheet.getRange("H1:K56").format.columnWidth = 13;
sheet.getRange("F1:F56").format.columnWidth = 4;
sheet.getRange("L1:L56").format.columnWidth = 4;
sheet.getRange("M1:M56").format.columnWidth = 15;
sheet.getRange("B2:E56").format.numberFormat = "0.000000";
sheet.getRange("H2:K56").format.numberFormat = "0.000000";
sheet.getRange("M2:M56").format.horizontalAlignment = "center";
sheet.getRange("A1:E56").format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
sheet.getRange("G1:K56").format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };
sheet.getRange("M1:M56").format.borders = { preset: "inside", style: "thin", color: "#E7E6E6" };

sheet.getRange("O1:T1").values = [["Classifier", "447 threshold", "araE threshold", "IBD count", "IBS count", "Rule"]];
styleHeader(sheet.getRange("O1:T1"));
sheet.getRange("O2:T2").values = [["Combined", 0.22, 0.14, null, null, "IBD if 447>=0.22 OR araE>=0.14; otherwise IBS"]];
sheet.getRange("R2:S2").formulas = [[`=COUNTIF($M$2:$M$56,"IBD")`, `=COUNTIF($M$2:$M$56,"IBS")`]];
sheet.getRange("P2:Q2").format.numberFormat = "0.00";
sheet.getRange("O1:T2").format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
sheet.getRange("O1:O2").format.columnWidth = 12;
sheet.getRange("P1:S2").format.columnWidth = 13;
sheet.getRange("T1:T2").format.columnWidth = 42;
sheet.getRange("T2").format.wrapText = true;

const chart447 = sheet.charts.add("bar", sheet.getRange("A1:E56"));
chart447.title = "447";
chart447.hasLegend = true;
chart447.yAxis = { numberFormatCode: "0.000" };
chart447.setPosition("O5", "V20");

const chartAraE = sheet.charts.add("bar", sheet.getRange("G1:K56"));
chartAraE.title = "araE";
chartAraE.hasLegend = true;
chartAraE.yAxis = { numberFormatCode: "0.000" };
chartAraE.setPosition("O22", "V37");

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "single-tab merged workbook formula error scan",
  maxChars: 2000,
});
const preview = await workbook.render({ sheetName: "Final 447 and araE", range: "A1:V60", scale: 0.65, format: "png" });
await fs.writeFile(path.join(previewDir, "Final_447_and_araE.png"), new Uint8Array(await preview.arrayBuffer()));

const localPath = path.join(localOutputDir, outputName);
const sourcePath = path.join(sourceDir, outputName);
const deliveryPath = path.join(deliveryDir, outputName);
const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(localPath);
await exported.save(sourcePath);
await exported.save(deliveryPath);

process.stdout.write(JSON.stringify({
  errors: errors.ndjson,
  localPath,
  sourcePath,
  deliveryPath,
  diagnosisCounts: {
    IBD: combinedDiagnoses.filter(([v]) => v === "IBD").length,
    IBS: combinedDiagnoses.filter(([v]) => v === "IBS").length,
  },
  sourceDeliveryHashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
}, null, 2));
