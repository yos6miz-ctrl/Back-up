import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE/Final 447 and araE.xlsx";
const deliveryPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae/Final 447 and araE.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_missing_samples_final_verify";
const requested = ["DS#189", "F-NW-26181", "F-GS-26166", "F-US-26120", "F-DO-2665"];

async function sha256(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

function tableFrom(ndjson) {
  return JSON.parse(ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
}

await fs.mkdir(previewDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const table = await workbook.inspect({
  kind: "table",
  range: "Final 447 and araE!A1:T61",
  include: "values,formulas",
  tableMaxRows: 65,
  tableMaxCols: 20,
  maxChars: 90000,
});
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "formula error scan",
  maxChars: 2000,
});
const drawings = await workbook.inspect({ kind: "drawing", sheetId: "Final 447 and araE", maxChars: 4000 });
const values = tableFrom(table.ndjson).values;
const names = new Set(values.slice(1).flatMap((row) => [row[0], row[6]]).filter(Boolean));
const present = Object.fromEntries(requested.map((sample) => [sample, names.has(sample)]));
const diagnosisCounts = {};
for (const row of values.slice(1, 61)) {
  const diagnosis = row[12];
  diagnosisCounts[diagnosis] = (diagnosisCounts[diagnosis] ?? 0) + 1;
}
const requestedRows = values
  .slice(1, 61)
  .filter((row) => requested.includes(row[0]) || requested.includes(row[6]))
  .map((row) => ({
    sample447: row[0],
    value447: [row[1], row[2], row[3], row[4]].find((v) => typeof v === "number") ?? null,
    sampleAraE: row[6],
    valueAraE: [row[7], row[8], row[9], row[10]].find((v) => typeof v === "number") ?? null,
    ourDiagnosis: row[12],
  }));
const preview = await workbook.render({ sheetName: "Final 447 and araE", range: "A1:V66", scale: 0.65, format: "png" });
await fs.writeFile(path.join(previewDir, "Final_447_and_araE_missing_samples_verified.png"), new Uint8Array(await preview.arrayBuffer()));
const sidecars = [];
for (const dir of [path.dirname(sourcePath), path.dirname(deliveryPath)]) {
  for (const entry of await fs.readdir(dir)) if (entry.endsWith(".inspect.ndjson")) sidecars.push(path.join(dir, entry));
}
process.stdout.write(JSON.stringify({
  sheets: workbook.worksheets.items.map((sheet) => sheet.name),
  rowCount: values.length - 1,
  present,
  requestedRows,
  diagnosisCounts,
  drawings: drawings.ndjson,
  errors: errors.ndjson,
  hashMatch: await sha256(sourcePath) === await sha256(deliveryPath),
  sidecars,
}, null, 2));
