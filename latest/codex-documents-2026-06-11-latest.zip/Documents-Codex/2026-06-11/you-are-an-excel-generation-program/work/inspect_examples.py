from __future__ import annotations

import json
import re
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\.codex\כמין")
EXEMP = ROOT / "exemp"


def cell_value(v):
    if v is None:
        return None
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v


def sheet_summary(ws, max_rows=35, max_cols=20):
    rows = []
    for row in ws.iter_rows(
        min_row=1,
        max_row=min(ws.max_row, max_rows),
        min_col=1,
        max_col=min(ws.max_column, max_cols),
        values_only=True,
    ):
        rows.append([cell_value(v) for v in row])
    nonempty = 0
    formulas = []
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None:
                nonempty += 1
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formulas.append(cell.coordinate)
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    return {
        "title": ws.title,
        "max_row": ws.max_row,
        "max_col": ws.max_column,
        "nonempty": nonempty,
        "formula_count": len(formulas),
        "formula_sample": formulas[:20],
        "merged_ranges": merged[:20],
        "top_rows": rows,
    }


def workbook_summary(path: Path):
    wb = load_workbook(path, data_only=False, read_only=False)
    return {
        "file": str(path),
        "name": path.name,
        "detector": path.parent.name,
        "is_final": path.name.lower().startswith("final"),
        "date_prefix": re.match(r"^(\d{8})", path.name).group(1)
        if re.match(r"^(\d{8})", path.name)
        else None,
        "sheets": [sheet_summary(ws) for ws in wb.worksheets],
    }


def main():
    summaries = []
    for path in sorted(EXEMP.glob("*/*.xls*")):
        if path.name.startswith("~$"):
            continue
        summaries.append(workbook_summary(path))
    out = Path("work/example_inspection.json")
    out.write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {out} with {len(summaries)} workbooks")
    by_detector = {}
    for item in summaries:
        by_detector.setdefault(item["detector"], []).append(item)
    for detector, items in by_detector.items():
        finals = [i["name"] for i in items if i["is_final"]]
        daily = [i for i in items if not i["is_final"]]
        dates = [i["date_prefix"] for i in daily]
        shapes = [(i["name"], [(s["title"], s["max_row"], s["max_col"]) for s in i["sheets"]]) for i in items]
        print(detector, "daily", len(daily), dates, "final", finals)
        print("  shapes", shapes[:4], "..." if len(shapes) > 4 else "")


if __name__ == "__main__":
    main()
