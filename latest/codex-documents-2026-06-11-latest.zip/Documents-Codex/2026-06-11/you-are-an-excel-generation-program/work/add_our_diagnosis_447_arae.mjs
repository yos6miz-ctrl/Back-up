import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourceDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/דוח כמין/שנה 2/447 and araE";
const deliveryDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-08-09/yo/outputs/447_arae";
const localOutputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/outputs/447_arae_our_diagnosis";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-06-11/you-are-an-excel-generation-program/work/447_arae_our_diagnosis_previews";

const files = [
  { detector: "447", fileName: "Final 447.xlsx", threshold: 0.22 },
  { detector: "araE", fileName: "Final araE.xlsx", threshold: 0.14 },
];

async function importWorkbook(fileName) {
  const filePath = path.join(sourceDir, fileName);
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(filePath));
  return { workbook, filePath };
}

async function sampleLogValues(workbook) {
  const inspect = await workbook.inspect({
    kind: "table",
    range: "Sample Log!A1:N59",
    include: "values,formulas",
    tableMaxRows: 60,
    tableMaxCols: 14,
    maxChars: 60000,
  });
  const json = JSON.parse(inspect.ndjson.split("\n").find((line) => line.includes('"kind":"table"')));
  return json.values;
}

const imported = new Map();
const valuesByDetector = new Map();

for (const spec of files) {
  const importedWorkbook = await importWorkbook(spec.fileName);
  imported.set(spec.detector, importedWorkbook);
  const rows = await sampleLogValues(importedWorkbook.workbook);
  const bySample = new Map();
  for (const row of rows.slice(1)) {
    const sample = row[1];
    const finalMeasurement = Number(row[10]);
    if (sample && Number.isFinite(finalMeasurement)) {
      bySample.set(sample, finalMeasurement);
    }
  }
  valuesByDetector.set(spec.detector, bySample);
}

const sampleNames = [...valuesByDetector.get("447").keys()];
const diagnosisBySample = new Map();
for (const sample of sampleNames) {
  const value447 = valuesByDetector.get("447").get(sample);
  const valueAraE = valuesByDetector.get("araE").get(sample);
  const diagnosis = value447 >= 0.22 || valueAraE >= 0.14 ? "IBD" : "IBS";
  diagnosisBySample.set(sample, diagnosis);
}

function diagnosisRowsFor(logRows) {
  return logRows.slice(1).map((row) => [diagnosisBySample.get(row[1]) ?? ""]);
}

function applyDiagnosisFormatting(sheetName, workbook) {
  const results = workbook.worksheets.getItem(sheetName);
  const log = workbook.worksheets.getItem("Sample Log");

  log.getRange("N1").values = [["Our diagnosis"]];
  log.getRange("N1").format = {
    fill: "#375623",
    font: { color: "#FFFFFF", bold: true },
    wrapText: true,
    verticalAlignment: "center",
  };
  log.getRange("N1").format.columnWidth = 15;
  log.getRange("N2:N59").format = {
    borders: { preset: "inside", style: "thin", color: "#E7E6E6" },
    horizontalAlignment: "center",
  };

  results.getRange("F1").values = [["Our diagnosis"]];
  results.getRange("F1").format = {
    fill: "#E2F0D9",
    font: { bold: true, color: "#1F1F1F" },
    wrapText: true,
    horizontalAlignment: "center",
    verticalAlignment: "center",
  };
  results.getRange("F1:F56").format.columnWidth = 15;
  results.getRange("F2:F56").formulas = Array.from({ length: 55 }, (_, index) => [`='Sample Log'!$N$${index + 2}`]);
  results.getRange("F2:F56").format = {
    horizontalAlignment: "center",
    borders: { preset: "inside", style: "thin", color: "#E7E6E6" },
  };

  const ruleStart = 24;
  results.getRange(`G${ruleStart}:K${ruleStart}`).values = [["Sample classifier", "Rule", "447 threshold", "araE threshold", ""]];
  results.getRange(`G${ruleStart}:K${ruleStart}`).format = {
    fill: "#375623",
    font: { color: "#FFFFFF", bold: true },
    horizontalAlignment: "center",
  };
  results.getRange(`G${ruleStart + 1}:K${ruleStart + 1}`).values = [["Our diagnosis", "IBD if 447>=0.22 OR araE>=0.14", 0.22, 0.14, "otherwise IBS"]];
  results.getRange(`G${ruleStart + 1}:K${ruleStart + 1}`).format = {
    borders: { preset: "all", style: "thin", color: "#D9E2F3" },
    wrapText: true,
  };
  results.getRange(`I${ruleStart + 1}:J${ruleStart + 1}`).format.numberFormat = "0.00";
}

await fs.mkdir(localOutputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

for (const spec of files) {
  const { workbook } = imported.get(spec.detector);
  const rows = await sampleLogValues(workbook);
  const sheetName = `Final ${spec.detector}`;
  workbook.worksheets.getItem("Sample Log").getRange("N2:N59").values = diagnosisRowsFor(rows);
  applyDiagnosisFormatting(sheetName, workbook);

  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 300 },
    summary: "formula error scan after adding Our diagnosis",
    maxChars: 2000,
  });
  const finalPreview = await workbook.render({ sheetName, range: "A1:N60", scale: 0.75, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replace(/\s+/g, "_")}.png`), new Uint8Array(await finalPreview.arrayBuffer()));
  const logPreview = await workbook.render({ sheetName: "Sample Log", range: "A1:N59", scale: 0.55, format: "png" });
  await fs.writeFile(path.join(previewDir, `Sample_Log_${spec.detector}.png`), new Uint8Array(await logPreview.arrayBuffer()));

  const xlsx = await SpreadsheetFile.exportXlsx(workbook);
  const localPath = path.join(localOutputDir, spec.fileName);
  const sourcePath = path.join(sourceDir, spec.fileName);
  const deliveryPath = path.join(deliveryDir, spec.fileName);
  await xlsx.save(localPath);
  await xlsx.save(sourcePath);
  await xlsx.save(deliveryPath);
  process.stdout.write(`${spec.fileName}\n${errors.ndjson}\n${localPath}\n${sourcePath}\n${deliveryPath}\n`);
}
