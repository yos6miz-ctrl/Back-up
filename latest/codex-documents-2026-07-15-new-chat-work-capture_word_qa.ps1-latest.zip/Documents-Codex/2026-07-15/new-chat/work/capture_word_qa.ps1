$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Win32Capture {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
}
'@

function Save-WordWindow {
    param(
        [Parameter(Mandatory=$true)] $Window,
        [Parameter(Mandatory=$true)] [string] $Path
    )
    $hwnd = [IntPtr]$Window.Hwnd
    [void][Win32Capture]::SetForegroundWindow($hwnd)
    Start-Sleep -Milliseconds 900
    $rect = New-Object Win32Capture+RECT
    if (-not [Win32Capture]::GetWindowRect($hwnd, [ref]$rect)) {
        throw 'Could not read the Word window rectangle.'
    }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    $bitmap = New-Object System.Drawing.Bitmap($width, $height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, $bitmap.Size)
        $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    }
    finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

$docPath = (Resolve-Path 'outputs\Teads_TA_Interview_Assignment.docx').Path
$qaDir = (Resolve-Path 'work\qa_review_comments_20260715').Path
$word = $null
$doc = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $true
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($docPath, $false, $true)
    $doc.Repaginate()
    $window = $word.ActiveWindow
    $window.WindowState = 1
    $window.View.Type = 3
    $window.View.Zoom.PageFit = 1

    $targets = @(
        @{ Text = 'FIVE-MINUTE READER PATH'; File = 'page1-cover-reader-path.png' },
        @{ Text = 'Modular LinkedIn Recruiter searches'; File = 'page2-modular-searches.png' },
        @{ Text = 'Exploratory adjacent-pool prospect'; File = 'page5-exploratory-prospect.png' },
        @{ Text = 'ChatGPT Enterprise'; File = 'page6-ai-stack.png' },
        @{ Text = 'Branching sequence'; File = 'page7-branching-outreach.png' },
        @{ Text = 'LOCATION DROP-OFF HEATMAP'; File = 'page8-country-heatmap.png' }
    )

    foreach ($item in $targets) {
        $range = $doc.Content.Duplicate
        $find = $range.Find
        $find.ClearFormatting()
        $find.Text = $item.Text
        $find.MatchCase = $true
        $find.Forward = $true
        $find.Wrap = 0
        if (-not $find.Execute()) {
            throw "Could not find target: $($item.Text)"
        }
        $range.Select()
        $window.ScrollIntoView($range, $true)
        $window.View.Zoom.PageFit = 1
        if ($item.File -ne 'page1-cover-reader-path.png') {
            $window.LargeScroll(1)
            $window.SmallScroll(0, 8)
        }
        Start-Sleep -Milliseconds 1200
        Save-WordWindow -Window $window -Path (Join-Path $qaDir $item.File)
    }

    "WORD_PAGES=$($doc.ComputeStatistics(2))"
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
