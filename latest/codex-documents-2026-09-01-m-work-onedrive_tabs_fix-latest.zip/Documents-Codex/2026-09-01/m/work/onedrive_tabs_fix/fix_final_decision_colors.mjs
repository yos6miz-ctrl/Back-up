import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/final_decision_color_fix_20260903";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/decision_colors_after";
const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const finalStyles = {
  IBD: { fill: "#C00000", text: "#FFFFFF", bold: true },
  IBS: { fill: "#003399", text: "#FFFFFF", bold: true },
  inconclusive: { fill: "#D9D2E9", text: "#4C3868", bold: true },
  missing: { fill: "#E7E6E6", text: "#666666", bold: true },
  "לא נבדק": { fill: "#D9D2E9", text: "#4C3868", bold: true },
  "IBD*": { fill: null, text: "#000000", bold: false },
  "IBS*": { fill: null, text: "#000000", bold: false },
};
const legacyStyleReferences = {
  "IBD*": { sheet: "Older samples - before 2021", cell: "E154" },
  "IBS*": { sheet: "Older samples - before 2021", cell: "E156" },
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const beforeValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  beforeValues[sheetName] = workbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
}

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}

function compactStyle(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
    horizontalAlignment: style?.horizontalAlignment ?? null,
  };
}

function expectedCompact(value) {
  const expected = finalStyles[value];
  if (!expected) throw new Error(`Unsupported final-decision value: ${value}`);
  return {
    fill: expected.fill?.slice(1) ?? null,
    text: expected.text.slice(1),
    bold: expected.bold,
    horizontalAlignment: "center",
  };
}

function sameStyle(actual, expected, value) {
  const fillMatches = value === "IBD*" || value === "IBS*"
    ? actual.fill == null || actual.fill === "FFFFFF"
    : actual.fill === expected.fill;
  return fillMatches
    && actual.text === expected.text
    && actual.bold === expected.bold
    && actual.horizontalAlignment === expected.horizontalAlignment;
}

const changedCells = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  const values = beforeValues[sheetName];
  for (let row = 2; row <= lastRow; row += 1) {
    const value = values[row - 1][4];
    if (value == null || value === "") continue;
    const cellAddress = `E${row}`;
    const inspected = await workbook.inspect({ kind: "computedStyle", sheetId: sheetName, range: cellAddress, maxChars: 2500 });
    const beforeStyle = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
    const expectedStyle = expectedCompact(value);
    if (sameStyle(beforeStyle, expectedStyle, value)) continue;

    const cell = sheet.getRange(cellAddress);
    if (value === "IBD*" || value === "IBS*") {
      cell.format.fill = "#FFFFFF";
      cell.format.font = { name: "Calibri", size: 10, color: "#000000", bold: false };
      cell.format.horizontalAlignment = "center";
    } else {
      const style = finalStyles[value];
      cell.format.fill = style.fill;
      cell.format.font = { name: "Calibri", size: 10, color: style.text, bold: style.bold };
      cell.format.horizontalAlignment = "center";
    }
    changedCells.push({ sheet: sheetName, cell: cellAddress, primary: values[row - 1][0], value, beforeStyle, expectedStyle });
  }
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  return value === "" ? null : value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const valueMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const actual = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const expected = beforeValues[sheetName];
  for (let row = 0; row < expected.length; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[row][col], expected[row][col])) {
        valueMismatches.push({ sheet: sheetName, row: row + 1, col: col + 1, before: normalized(expected[row][col]), after: normalized(actual[row][col]) });
      }
    }
  }
}
if (valueMismatches.length) throw new Error(`Workbook values changed: ${JSON.stringify(valueMismatches.slice(0, 12))}`);

const finalStyleMismatches = [];
const detectorStyleMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const values = beforeValues[sheetName];
  for (let row = 2; row <= lastRow; row += 1) {
    const finalValue = values[row - 1][4];
    if (finalValue != null && finalValue !== "") {
      const cell = `E${row}`;
      const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: sheetName, range: cell, maxChars: 2500 });
      const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
      const expected = expectedCompact(finalValue);
      if (!sameStyle(actual, expected, finalValue)) finalStyleMismatches.push({ sheet: sheetName, cell, value: finalValue, actual, expected });
    }

    for (const [column, valueIndex] of [["P", 15], ["W", 22]]) {
      const detectorValue = values[row - 1][valueIndex];
      if (detectorValue == null || detectorValue === "") continue;
      const cell = `${column}${row}`;
      const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: sheetName, range: cell, maxChars: 2500 });
      const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
      if (actual.fill !== "FFFFFF" || actual.text !== "000000" || actual.bold || actual.horizontalAlignment !== "center") {
        detectorStyleMismatches.push({ sheet: sheetName, cell, value: detectorValue, actual });
      }
    }
  }
}
if (finalStyleMismatches.length) throw new Error(`Final-decision style verification failed: ${JSON.stringify(finalStyleMismatches.slice(0, 12))}`);
if (detectorStyleMismatches.length) throw new Error(`Detector-decision style verification failed: ${JSON.stringify(detectorStyleMismatches.slice(0, 12))}`);

const formulaErrors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-final-decision-color-fix formula error scan",
  maxChars: 5000,
});

for (const [sheetName, startRow, endRow] of [
  ["Older samples - before 2021", 1, 65],
  ["Older samples - before 2021", 66, 130],
  ["Older samples - before 2021", 131, 190],
  ["2021 onward", 1, 55],
  ["2021 onward", 56, 110],
  ["2021 onward", 111, 158],
]) {
  const safeSheet = sheetName.startsWith("Older") ? "older" : "onward";
  const image = await finalWorkbook.render({ sheetName, range: `A${startRow}:E${endRow}`, scale: 1.4, format: "png" });
  await fs.writeFile(path.join(previewDir, `${safeSheet}_${startRow}_${endRow}.png`), new Uint8Array(await image.arrayBuffer()));
}

console.log(JSON.stringify({
  outputPath,
  changedCellCount: changedCells.length,
  changedCells,
  valueMismatchCount: valueMismatches.length,
  finalDecisionStyleMismatchCount: finalStyleMismatches.length,
  detectorDecisionStyleMismatchCount: detectorStyleMismatches.length,
  formulaErrors: formulaErrors.ndjson,
}, null, 2));
