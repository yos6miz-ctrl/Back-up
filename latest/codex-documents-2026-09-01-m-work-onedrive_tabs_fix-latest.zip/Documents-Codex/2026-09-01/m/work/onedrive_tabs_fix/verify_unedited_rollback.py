from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m")
CURRENT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
EXPECTED = ROOT / "outputs" / "aliquot_status_and_font_fix_20260903" / "Final Known and Unknown merged.xlsx"
OUTPUT = ROOT / "outputs" / "remove_unedited_measurements_20260914" / "Final Known and Unknown merged.xlsx"
LEDGER = ROOT / "work" / "onedrive_tabs_fix" / "latest_repeat_update_ledger.json"
SHEETS = ["Older samples - before 2021", "2021 onward"]
DETECTOR_COLUMN = {"PA447": "P", "araE": "W"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def same_value(left, right) -> bool:
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1e-12)
    return left == right


def color_value(color):
    if color is None:
        return None
    return (color.type, color.rgb, color.indexed, color.theme, color.tint)


def style_value(cell):
    return (
        cell.font.name,
        cell.font.sz,
        cell.font.bold,
        cell.font.italic,
        cell.font.underline,
        color_value(cell.font.color),
        cell.fill.fill_type,
        color_value(cell.fill.fgColor),
        color_value(cell.fill.bgColor),
        cell.number_format,
        cell.alignment.horizontal,
        cell.alignment.vertical,
        cell.alignment.wrap_text,
        cell.alignment.text_rotation,
    )


def rgb(color) -> str | None:
    if color is not None and color.type == "rgb" and color.rgb:
        return color.rgb[-6:].upper()
    return None


def fill_rgb(cell) -> str | None:
    if cell.fill.fill_type == "solid":
        return rgb(cell.fill.fgColor)
    return None


def main() -> None:
    ledger = json.loads(LEDGER.read_text(encoding="utf-8"))
    current = load_workbook(CURRENT, data_only=False)
    expected = load_workbook(EXPECTED, data_only=False)
    output = load_workbook(OUTPUT, data_only=False)

    assert current.sheetnames == expected.sheetnames == output.sheetnames == SHEETS
    assert sha256(CURRENT) == "71520CA29B69CB629254021864CE3586D8CA9177F02CB528991E7E6D58EE6D69"
    assert sha256(EXPECTED) == "3EE6DB13B74DE8305D53CB5F9A5B95519625F131690013F37BEF056A9D5091B2"

    output_vs_expected_value_diffs = []
    output_vs_expected_style_diffs = []
    current_vs_output_value_diffs = {}
    for sheet_name in SHEETS:
        ws_current = current[sheet_name]
        ws_expected = expected[sheet_name]
        ws_output = output[sheet_name]
        assert (ws_current.max_row, ws_current.max_column) == (ws_expected.max_row, ws_expected.max_column)
        assert (ws_output.max_row, ws_output.max_column) == (ws_expected.max_row, ws_expected.max_column)
        assert ws_output.freeze_panes == ws_expected.freeze_panes
        assert ws_output.auto_filter.ref == ws_expected.auto_filter.ref
        for row in range(1, ws_expected.max_row + 1):
            for col in range(1, ws_expected.max_column + 1):
                expected_cell = ws_expected.cell(row, col)
                output_cell = ws_output.cell(row, col)
                current_cell = ws_current.cell(row, col)
                if not same_value(output_cell.value, expected_cell.value):
                    output_vs_expected_value_diffs.append((sheet_name, output_cell.coordinate))
                if style_value(output_cell) != style_value(expected_cell):
                    output_vs_expected_style_diffs.append((sheet_name, output_cell.coordinate))
                if not same_value(current_cell.value, output_cell.value):
                    current_vs_output_value_diffs[(sheet_name, output_cell.coordinate)] = (
                        current_cell.value,
                        output_cell.value,
                    )

    assert not output_vs_expected_value_diffs, output_vs_expected_value_diffs[:20]
    assert not output_vs_expected_style_diffs, output_vs_expected_style_diffs[:20]

    expected_changed = set()
    categories = Counter()
    for item in ledger["assignment_proofs"]:
        expected_changed.add((item["sheet"], item["target_cell"]))
        categories["measurements"] += 1
    for item in ledger["source_updates"]:
        expected_changed.add((item["sheet"], f"Y{item['row']}"))
        categories["sources"] += 1
    for item in ledger["decision_changes"]:
        expected_changed.add((item["sheet"], f"{DETECTOR_COLUMN[item['detector']]}{item['row']}"))
        categories["detector_decisions"] += 1
    for item in ledger["final_changes"]:
        expected_changed.add((item["sheet"], f"E{item['row']}"))
        categories["final_decisions"] += 1
    for item in ledger["status_changes"]:
        if item["before"] != item["after"]:
            expected_changed.add((item["sheet"], f"C{item['row']}"))
            categories["statuses"] += 1
    assert set(current_vs_output_value_diffs) == expected_changed
    assert categories == Counter(measurements=24, sources=18, detector_decisions=21, final_decisions=16)

    selected_files = {item["file"] for item in ledger["selected_files"]}
    assert len(selected_files) == 5
    selected_source_hits = []
    yellow_measurements = 0
    yellow_statuses = 0
    grey_measurements = 0
    not_tested_rows = 0
    formula_count = 0
    error_values = []
    measurement_columns = ["H", "I", "J", "K", "L", "M", "N", "O", "Q", "R", "S", "T", "U", "V"]
    for sheet_name in SHEETS:
        ws = output[sheet_name]
        for row in range(2, ws.max_row + 1):
            if ws[f"C{row}"].value == "לא נבדק":
                not_tested_rows += 1
            if fill_rgb(ws[f"C{row}"]) == "FFD966":
                yellow_statuses += 1
            for col in measurement_columns:
                cell = ws[f"{col}{row}"]
                if fill_rgb(cell) == "FFD966":
                    yellow_measurements += 1
                if cell.value is not None and rgb(cell.font.color) == "A6A6A6":
                    grey_measurements += 1
        for row in ws.iter_rows():
            for cell in row:
                value = cell.value
                if isinstance(value, str):
                    if value.startswith("="):
                        formula_count += 1
                    if value in {"#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!", "#NULL!"}:
                        error_values.append((sheet_name, cell.coordinate, value))
                    for file in selected_files:
                        if file in value:
                            selected_source_hits.append((sheet_name, cell.coordinate, file))

    assert not selected_source_hits, selected_source_hits
    assert formula_count == 0
    assert not error_values
    assert not_tested_rows == 17
    assert yellow_measurements == 145
    assert yellow_statuses == 35

    ct606 = None
    for sheet_name in SHEETS:
        ws = output[sheet_name]
        for row in range(2, ws.max_row + 1):
            if ws[f"A{row}"].value == "CT-606":
                cell = ws[f"A{row}"]
                ct606 = (sheet_name, cell.coordinate, cell.font.name, cell.font.sz, cell.font.bold, cell.font.italic, rgb(cell.font.color))
    assert ct606 == ("Older samples - before 2021", "A190", "Calibri", 10.0, False, False, "000000"), ct606

    print(json.dumps({
        "status": "PASS",
        "output_sha256": sha256(OUTPUT),
        "removed_files": sorted(selected_files),
        "removed_measurements": ledger["measurements_added"],
        "restored_value_cells": len(current_vs_output_value_diffs),
        "restored_categories": dict(categories),
        "output_equals_pre_addition_values": True,
        "output_equals_pre_addition_styles": True,
        "yellow_measurements": yellow_measurements,
        "yellow_statuses": yellow_statuses,
        "grey_measurements": grey_measurements,
        "not_tested_rows": not_tested_rows,
        "ct606": ct606,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
