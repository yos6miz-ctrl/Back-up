from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import sys

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\onedrive_tabs_fix")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPEAT_FOLDER = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats")
SELECTED_FILES = [
    REPEAT_FOLDER / "20260903 447 sample repeats.xlsx",
    REPEAT_FOLDER / "20260907 447 sample repeats.xlsx",
    REPEAT_FOLDER / "20260907 araE sample repeats.xlsx",
    REPEAT_FOLDER / "20260909 araE sample repeats.xlsx",
    REPEAT_FOLDER / "20260910 araE sample repeats.xlsx",
]
OUTPUT = WORK / "latest_raw_trace_addition_analysis.json"
LEGACY_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
RAW_AUDIT_PATH = LEGACY_DIR / "audit_final_measurements_without_source.py"
RAW_TRACE_PATH = LEGACY_DIR / "extract_raw_trace_2026_measurements.py"
EXPAND_PATH = LEGACY_DIR / "expand_measurement_columns_and_show_all.py"
TOLERANCE = 5e-7
DETECTOR_COLUMNS = {"PA447": list(range(8, 16)), "araE": list(range(17, 23))}


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def hash_file(path):
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


sys.path.insert(0, str(LEGACY_DIR))
raw_audit = load_module("latest_raw_trace_audit", RAW_AUDIT_PATH)
raw_trace = load_module("latest_raw_trace_extractor", RAW_TRACE_PATH)
expand = load_module("latest_raw_trace_expand", EXPAND_PATH)
training, feature_cols, _fill_values, training_sources = expand.importer.classifier.load_training()
bars = expand.importer.classifier.learn_detector_bars(training, feature_cols)

workbook = load_workbook(FINAL, data_only=True, read_only=False)
rows = []
row_values = {}
for sheet_name in workbook.sheetnames:
    sheet = workbook[sheet_name]
    for row in range(2, sheet.max_row + 1):
        values = [sheet.cell(row, col).value for col in range(1, 28)]
        primary, secondary = values[0], values[1]
        exact_names = {
            raw_audit.norm(part)
            for name in (primary, secondary)
            for part in str(name or "").replace("\n", ";").split(";")
            if raw_audit.norm(part)
        }
        record = {
            "sheet": sheet_name,
            "row": row,
            "row_id": f"{sheet_name}!{row}",
            "primary": primary,
            "secondary": secondary,
            "exact_names": exact_names,
            "keys": raw_audit.expand_manual_aliases(raw_audit.variants(primary, secondary)),
            "values": {
                detector: [float(values[c - 1]) for c in cols if is_numeric(values[c - 1])]
                for detector, cols in DETECTOR_COLUMNS.items()
            },
        }
        rows.append(record)
        row_values[record["row_id"]] = values
workbook.close()


def candidates_for(record):
    sample_norm = raw_audit.norm(record["sample_name"])
    exact = [row for row in rows if sample_norm and sample_norm in row["exact_names"]]
    if exact:
        return exact, "exact_name"
    record_keys = raw_audit.expand_manual_aliases(raw_audit.variants(record["sample_name"], None))
    scored = []
    for row in rows:
        shared = set(record_keys) & row["keys"]
        if shared:
            scored.append((max(len(key) for key in shared), row))
    best = max((score for score, _row in scored), default=0)
    return [row for score, row in scored if score == best], "alias_keys" if best else "none"


file_info = []
raw_records = []
for path in SELECTED_FILES:
    if not path.exists():
        raise FileNotFoundError(path)
    records = raw_trace.extract_file(path)
    file_info.append({
        "path": str(path),
        "file": path.name,
        "sha256": hash_file(path),
        "record_count": len(records),
        "records": records,
    })
    raw_records.extend(records)

unique = {}
for record in raw_records:
    key = (record["detector"], raw_audit.norm(record["sample_name"]), round(float(record["value"]), 9))
    unique.setdefault(key, record)

classifications = []
selected = []
for record in unique.values():
    candidates, method = candidates_for(record)
    matching = [
        row for row in candidates
        if any(abs(float(record["value"]) - value) <= TOLERANCE for value in row["values"][record["detector"]])
    ]
    if matching:
        classification = "already_present"
    elif len(candidates) == 1:
        classification = "new_measurement_for_existing_sample"
    elif len(candidates) > 1:
        classification = "ambiguous_sample_match"
    else:
        classification = "sample_not_in_final"
    item = {
        **record,
        "classification": classification,
        "match_method": method,
        "candidate_rows": [
            {"sheet": row["sheet"], "row": row["row"], "row_id": row["row_id"], "primary": row["primary"], "secondary": row["secondary"]}
            for row in candidates
        ],
        "matching_rows": [row["row_id"] for row in matching],
    }
    classifications.append(item)
    if classification == "new_measurement_for_existing_sample":
        selected.append({**item, "target": item["candidate_rows"][0]})

additions_by_row = defaultdict(list)
capacity_issues = []
for item in selected:
    additions_by_row[item["target"]["row_id"]].append(item)
for row_id, additions in additions_by_row.items():
    existing = rows[[r["row_id"] for r in rows].index(row_id)]["values"]
    for detector, capacity in (("PA447", 8), ("araE", 6)):
        count = len(existing[detector]) + sum(x["detector"] == detector for x in additions)
        if count > capacity:
            capacity_issues.append({"row_id": row_id, "detector": detector, "count": count, "capacity": capacity})

affected = []
for row_id, additions in additions_by_row.items():
    row = next(r for r in rows if r["row_id"] == row_id)
    detector_results = {}
    for detector in ("PA447", "araE"):
        values = list(row["values"][detector]) + [x["value"] for x in additions if x["detector"] == detector]
        result = expand.detector_consensus_with_used(values, bars[detector]["bar"])
        detector_results[detector] = {"values": values, **result}
    calls = [x["call"] for x in detector_results.values() if x.get("call")]
    final = expand.importer.classifier.final_classification(calls) if calls else "missing"
    affected.append({
        "row_id": row_id,
        "sheet": row["sheet"],
        "row": row["row"],
        "primary": row["primary"],
        "secondary": row["secondary"],
        "additions": [{k: x[k] for k in ("sample_name", "detector", "value", "source_file", "source_cell")} for x in additions],
        "old_PA447": row_values[row_id][15],
        "old_araE": row_values[row_id][22],
        "old_final": row_values[row_id][4],
        "PA447": detector_results["PA447"],
        "araE": detector_results["araE"],
        "new_final": final,
    })

result = {
    "final": str(FINAL),
    "final_sha256": hash_file(FINAL),
    "files": file_info,
    "bars": {detector: bars[detector]["bar"] for detector in ("PA447", "araE")},
    "training_rows": len(training),
    "training_sources": training_sources,
    "raw_record_count": len(raw_records),
    "unique_record_count": len(unique),
    "classification_counts": dict(Counter(x["classification"] for x in classifications)),
    "classifications": classifications,
    "selected_addition_count": len(selected),
    "affected_row_count": len(affected),
    "capacity_issues": capacity_issues,
    "affected": affected,
}
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({
    "output": str(OUTPUT),
    "final_sha256": result["final_sha256"],
    "files": [{"file": f["file"], "record_count": f["record_count"], "sha256": f["sha256"]} for f in file_info],
    "raw_record_count": result["raw_record_count"],
    "unique_record_count": result["unique_record_count"],
    "classification_counts": result["classification_counts"],
    "selected_addition_count": result["selected_addition_count"],
    "affected_row_count": result["affected_row_count"],
    "capacity_issues": capacity_issues,
    "affected": affected,
    "non_additions": [x for x in classifications if x["classification"] != "new_measurement_for_existing_sample"],
}, ensure_ascii=False, indent=2))
