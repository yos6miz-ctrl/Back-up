import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const finalPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const rawFiles = [
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/sample repeats/20260901 araE sample repeats.xlsx",
    range: "A1:P6",
    name: "raw_20260901_araE.png",
  },
  {
    path: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/sample repeats/20260902 447 sample repeats.xlsx",
    range: "A1:P6",
    name: "raw_20260902_447.png",
  },
];
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/new_repeat_files_before";
await fs.mkdir(previewDir, { recursive: true });

const summary = [];
for (const raw of rawFiles) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(raw.path));
  const sheets = await workbook.inspect({ kind: "sheet", include: "id,name", maxChars: 5000 });
  const table = await workbook.inspect({ kind: "table", sheetId: "Sheet1", range: raw.range, include: "values,formulas", tableMaxRows: 6, tableMaxCols: 16, maxChars: 12000 });
  const image = await workbook.render({ sheetName: "Sheet1", range: raw.range, scale: 1.6, format: "png" });
  const imagePath = path.join(previewDir, raw.name);
  await fs.writeFile(imagePath, new Uint8Array(await image.arrayBuffer()));
  summary.push({ path: raw.path, sheets: sheets.ndjson, table: table.ndjson, imagePath });
}

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(finalPath));
for (const [sheetName, range, name] of [
  ["Older samples - before 2021", "A1:Y12", "final_older_top.png"],
  ["Older samples - before 2021", "A31:Y42", "final_older_conflict_targets.png"],
  ["2021 onward", "A21:Y26", "final_onward_ct1156.png"],
]) {
  const image = await finalWorkbook.render({ sheetName, range, scale: 1.6, format: "png" });
  const imagePath = path.join(previewDir, name);
  await fs.writeFile(imagePath, new Uint8Array(await image.arrayBuffer()));
  summary.push({ path: finalPath, sheetName, range, imagePath });
}

console.log(JSON.stringify(summary, null, 2));
