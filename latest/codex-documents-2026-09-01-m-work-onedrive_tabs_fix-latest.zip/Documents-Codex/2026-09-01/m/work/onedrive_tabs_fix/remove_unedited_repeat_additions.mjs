import fs from "node:fs/promises";
import crypto from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const currentPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const restoredSourcePath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/aliquot_status_and_font_fix_20260903/Final Known and Unknown merged.xlsx";
const ledgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/latest_repeat_update_ledger.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/remove_unedited_measurements_20260914";
const outputPath = `${outputDir}/Final Known and Unknown merged.xlsx`;
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/remove_unedited_after";

const expectedCurrentHash = "71520CA29B69CB629254021864CE3586D8CA9177F02CB528991E7E6D58EE6D69";
const expectedRestoredHash = "3EE6DB13B74DE8305D53CB5F9A5B95519625F131690013F37BEF056A9D5091B2";
const sheets = ["Older samples - before 2021", "2021 onward"];
const detectorColumn = { PA447: "P", araE: "W" };

async function sha256(path) {
  const bytes = await fs.readFile(path);
  return crypto.createHash("sha256").update(bytes).digest("hex").toUpperCase();
}

function sameValue(a, b) {
  if (a instanceof Date && b instanceof Date) return a.getTime() === b.getTime();
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-12;
  return a === b;
}

function key(sheet, cell) {
  return `${sheet}!${cell}`;
}

function columnName(index) {
  let n = index + 1;
  let result = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    result = String.fromCharCode(65 + rem) + result;
    n = Math.floor((n - 1) / 26);
  }
  return result;
}

const currentHash = await sha256(currentPath);
const restoredHash = await sha256(restoredSourcePath);
if (currentHash !== expectedCurrentHash) throw new Error(`Live workbook changed: ${currentHash}`);
if (restoredHash !== expectedRestoredHash) throw new Error(`Rollback source changed: ${restoredHash}`);

const ledger = JSON.parse(await fs.readFile(ledgerPath, "utf8"));
const selectedFiles = new Set(ledger.selected_files.map((item) => item.file));
if (selectedFiles.size !== 5 || ledger.measurements_added !== 24) {
  throw new Error(`Unexpected rollback scope: ${selectedFiles.size} files and ${ledger.measurements_added} measurements`);
}

const current = await SpreadsheetFile.importXlsx(await FileBlob.load(currentPath));
const restored = await SpreadsheetFile.importXlsx(await FileBlob.load(restoredSourcePath));

const allowedDifferences = new Set();
for (const item of ledger.assignment_proofs) allowedDifferences.add(key(item.sheet, item.target_cell));
for (const item of ledger.source_updates) allowedDifferences.add(key(item.sheet, `Y${item.row}`));
for (const item of ledger.decision_changes) {
  allowedDifferences.add(key(item.sheet, `${detectorColumn[item.detector]}${item.row}`));
}
for (const item of ledger.final_changes) allowedDifferences.add(key(item.sheet, `E${item.row}`));
for (const item of ledger.status_changes) {
  if (item.before !== item.after) allowedDifferences.add(key(item.sheet, `C${item.row}`));
}

const actualDifferences = new Set();
for (const sheetName of sheets) {
  const currentSheet = current.worksheets.getItem(sheetName);
  const restoredSheet = restored.worksheets.getItem(sheetName);
  const currentValues = currentSheet.getUsedRange().values;
  const restoredValues = restoredSheet.getUsedRange().values;
  if (currentValues.length !== restoredValues.length) throw new Error(`${sheetName}: row dimensions differ`);
  for (let row = 0; row < currentValues.length; row += 1) {
    if (currentValues[row].length !== restoredValues[row].length) throw new Error(`${sheetName}: column dimensions differ`);
    for (let col = 0; col < currentValues[row].length; col += 1) {
      if (!sameValue(currentValues[row][col], restoredValues[row][col])) {
        actualDifferences.add(key(sheetName, `${columnName(col)}${row + 1}`));
      }
    }
  }
}

const unexpected = [...actualDifferences].filter((item) => !allowedDifferences.has(item));
const missing = [...allowedDifferences].filter((item) => !actualDifferences.has(item));
if (unexpected.length || missing.length) {
  throw new Error(`Rollback scope mismatch. Unexpected=${JSON.stringify(unexpected)} Missing=${JSON.stringify(missing)}`);
}
if (actualDifferences.size !== 79) throw new Error(`Expected 79 changed cells, found ${actualDifferences.size}`);

for (const item of ledger.assignment_proofs) {
  const oldValue = restored.worksheets.getItem(item.sheet).getRange(item.target_cell).values[0][0];
  if (oldValue !== null && oldValue !== undefined && oldValue !== "") {
    throw new Error(`Pre-addition target is not blank: ${item.sheet}!${item.target_cell}`);
  }
}

for (const sheetName of sheets) {
  const sheet = restored.worksheets.getItem(sheetName);
  const values = sheet.getUsedRange().values;
  for (const row of values) {
    for (const value of row) {
      if (typeof value === "string") {
        for (const file of selectedFiles) {
          if (value.includes(file)) throw new Error(`Unedited source name remains in ${sheetName}: ${file}`);
        }
      }
    }
  }
}

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const output = await SpreadsheetFile.exportXlsx(restored);
await output.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
for (const sheetName of sheets) {
  const beforeValues = restored.worksheets.getItem(sheetName).getUsedRange().values;
  const afterValues = finalWorkbook.worksheets.getItem(sheetName).getUsedRange().values;
  if (beforeValues.length !== afterValues.length) throw new Error(`${sheetName}: exported row dimensions changed`);
  for (let row = 0; row < beforeValues.length; row += 1) {
    if (beforeValues[row].length !== afterValues[row].length) throw new Error(`${sheetName}: exported column dimensions changed`);
    for (let col = 0; col < beforeValues[row].length; col += 1) {
      if (!sameValue(beforeValues[row][col], afterValues[row][col])) {
        throw new Error(`${sheetName}!${columnName(col)}${row + 1}: exported value mismatch`);
      }
    }
  }
}

const errors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
if ((errors.ndjson.match(/\n/g) || []).length > 0 || /#REF!|#DIV\/0!|#VALUE!|#NAME\?|#N\/A/.test(errors.ndjson)) {
  throw new Error(`Formula error scan returned matches: ${errors.ndjson}`);
}

const inspections = {};
inspections.older = (await finalWorkbook.inspect({
  kind: "table",
  sheetId: "Older samples - before 2021",
  range: "A1:Y60",
  include: "values,formulas",
  tableMaxRows: 60,
  tableMaxCols: 25,
  maxChars: 8000,
})).ndjson;
inspections.onward = (await finalWorkbook.inspect({
  kind: "table",
  sheetId: "2021 onward",
  range: "A1:Y120",
  include: "values,formulas",
  tableMaxRows: 120,
  tableMaxCols: 25,
  maxChars: 8000,
})).ndjson;

for (const [sheetName, fileName] of [
  ["Older samples - before 2021", "older_samples.png"],
  ["2021 onward", "2021_onward.png"],
]) {
  const preview = await finalWorkbook.render({ sheetName, autoCrop: "all", scale: 0.7, format: "png" });
  await fs.writeFile(`${previewDir}/${fileName}`, new Uint8Array(await preview.arrayBuffer()));
}

console.log(JSON.stringify({
  status: "PASS",
  outputPath,
  outputSha256: await sha256(outputPath),
  removedFiles: [...selectedFiles].sort(),
  removedMeasurements: ledger.measurements_added,
  restoredDetectorDecisions: ledger.decision_changes.length,
  restoredFinalDecisions: ledger.final_changes.length,
  restoredValueCells: actualDifferences.size,
  formulaErrorMatches: 0,
  inspections: {
    olderChars: inspections.older.length,
    onwardChars: inspections.onward.length,
  },
}, null, 2));
