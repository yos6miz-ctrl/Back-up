import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const file = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const dir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/repeat_logic_before";
await fs.mkdir(dir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
const outputs = [];
for (const [sheetName, range, name] of [
  ["Older samples - before 2021", "A1:W15", "older_top.png"],
  ["2021 onward", "A103:W113", "onward_example.png"],
]) {
  const table = await workbook.inspect({ kind: "table", sheetId: sheetName, range, include: "values,formulas", tableMaxRows: 16, tableMaxCols: 23, maxChars: 10000 });
  const image = await workbook.render({ sheetName, range, scale: 1.7, format: "png" });
  const imagePath = `${dir}/${name}`;
  await fs.writeFile(imagePath, new Uint8Array(await image.arrayBuffer()));
  outputs.push({ sheetName, range, table: table.ndjson, imagePath });
}
console.log(JSON.stringify(outputs, null, 2));
