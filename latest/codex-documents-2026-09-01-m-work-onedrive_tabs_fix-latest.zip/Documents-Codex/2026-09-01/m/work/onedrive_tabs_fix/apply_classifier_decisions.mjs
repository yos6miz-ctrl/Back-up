import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const decisionPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/classifier_decisions_20260902";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_after";

const PROBLEM_YELLOW = "#FFD966";
const NEEDS_REPEAT_ORANGE = "#F4B183";
const DETECTOR_STYLES = {
  Pos: { fill: "#F4C7C3", color: "#5A1212" },
  Neg: { fill: "#CFE2F3", color: "#17365D" },
  Int: { fill: "#FFF2CC", color: "#7F6000" },
};
const FINAL_STYLES = {
  IBD: { fill: "#C00000", color: "#FFFFFF" },
  IBS: { fill: "#003399", color: "#FFFFFF" },
  inconclusive: { fill: "#D9D2E9", color: "#4C3868" },
  missing: { fill: "#E7E6E6", color: "#666666" },
  "לא נבדק": { fill: "#D9D2E9", color: "#4C3868" },
};
const detectorColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const decisions = JSON.parse(await fs.readFile(decisionPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));

const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 159,
};
const sourceValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  sourceValues[sheetName] = sheet.getRange(`A1:AA${lastRow}`).values;
  for (const address of [`J2:Q${lastRow}`, `S2:X${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = "#FFFFFF";
    range.format.font = { name: "Calibri", size: 10, color: "#000000", bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

function styleDetector(cell, decision) {
  if (!decision) {
    cell.format.fill = "#FFFFFF";
    cell.format.font = { name: "Calibri", size: 10, color: "#000000", bold: false };
    cell.format.horizontalAlignment = "center";
    return;
  }
  const style = DETECTOR_STYLES[decision];
  if (!style) throw new Error(`Unsupported detector decision: ${decision}`);
  cell.format.fill = style.fill;
  cell.format.font = { name: "Calibri", size: 10, color: style.color, bold: true };
  cell.format.horizontalAlignment = "center";
}

function styleFinal(cell, finalValue) {
  const style = FINAL_STYLES[finalValue];
  if (!style) throw new Error(`Unsupported final decision: ${finalValue}`);
  cell.format.fill = style.fill;
  cell.format.font = { name: "Calibri", size: 10, color: style.color, bold: true };
  cell.format.horizontalAlignment = "center";
}

const warningCells = new Map();
const changeLog = [];
for (const record of decisions.records) {
  if (record.preserve) continue;
  const sheet = workbook.worksheets.getItem(record.sheet);
  const sourceRow = sourceValues[record.sheet][record.row - 1];
  const after = { PA447: record.PA447.decision, araE: record.araE.decision, final: record.final };
  const before = { PA447: sourceRow[17], araE: sourceRow[24], final: sourceRow[4] };

  sheet.getRange(`R${record.row}`).values = [[after.PA447]];
  sheet.getRange(`Y${record.row}`).values = [[after.araE]];
  sheet.getRange(`E${record.row}`).values = [[after.final]];
  styleDetector(sheet.getRange(`R${record.row}`), after.PA447);
  styleDetector(sheet.getRange(`Y${record.row}`), after.araE);
  styleFinal(sheet.getRange(`E${record.row}`), after.final);

  if (before.PA447 !== after.PA447 || before.araE !== after.araE || before.final !== after.final) {
    changeLog.push({ sheet: record.sheet, row: record.row, sample: record.primary, before, after });
  }

  for (const detector of ["PA447", "araE"]) {
    for (const index of record[detector].problem_indices) {
      const cell = `${detectorColumns[detector][index]}${record.row}`;
      warningCells.set(`${record.sheet}!${cell}`, { sheet: record.sheet, cell, type: "problem", fill: PROBLEM_YELLOW, sample: record.primary, detector });
    }
    for (const index of record[detector].needs_repeat_indices) {
      const cell = `${detectorColumns[detector][index]}${record.row}`;
      const key = `${record.sheet}!${cell}`;
      if (warningCells.has(key)) throw new Error(`Overlapping warning states at ${key}`);
      warningCells.set(key, { sheet: record.sheet, cell, type: "repeat", fill: NEEDS_REPEAT_ORANGE, sample: record.primary, detector });
    }
  }
}

for (const item of warningCells.values()) {
  workbook.worksheets.getItem(item.sheet).getRange(item.cell).format.fill = item.fill;
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  if (value === "") return null;
  return value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const expectedByCell = new Map();
for (const record of decisions.records) {
  if (record.preserve) continue;
  expectedByCell.set(`${record.sheet}!E${record.row}`, record.final);
  expectedByCell.set(`${record.sheet}!R${record.row}`, record.PA447.decision);
  expectedByCell.set(`${record.sheet}!Y${record.row}`, record.araE.decision);
}

const unexpectedValueChanges = [];
const decisionMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const actual = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const before = sourceValues[sheetName];
  for (let rowIndex = 0; rowIndex < before.length; rowIndex += 1) {
    for (let colIndex = 0; colIndex < 27; colIndex += 1) {
      const column = String.fromCharCode(65 + colIndex);
      const key = `${sheetName}!${column}${rowIndex + 1}`;
      if (expectedByCell.has(key)) {
        const expected = expectedByCell.get(key);
        if (!equal(actual[rowIndex][colIndex], expected)) {
          decisionMismatches.push({ cell: key, actual: normalized(actual[rowIndex][colIndex]), expected: normalized(expected) });
        }
      } else if (!equal(actual[rowIndex][colIndex], before[rowIndex][colIndex])) {
        unexpectedValueChanges.push({ cell: key, before: normalized(before[rowIndex][colIndex]), after: normalized(actual[rowIndex][colIndex]) });
      }
    }
  }
}
if (decisionMismatches.length) throw new Error(`Decision value mismatch: ${JSON.stringify(decisionMismatches.slice(0, 10))}`);
if (unexpectedValueChanges.length) throw new Error(`Unexpected value changes: ${JSON.stringify(unexpectedValueChanges.slice(0, 10))}`);

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}

const warningStyleMismatches = [];
for (const item of warningCells.values()) {
  const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: item.sheet, range: item.cell, maxChars: 2500 });
  const style = firstStyleRecord(inspected.ndjson)?.style;
  const actualFill = style?.fill?.color?.value ?? null;
  if (actualFill !== item.fill.slice(1) || style?.font?.bold === true) {
    warningStyleMismatches.push({ ...item, actualFill, bold: style?.font?.bold ?? false });
  }
}
if (warningStyleMismatches.length) throw new Error(`Warning style mismatch: ${JSON.stringify(warningStyleMismatches.slice(0, 10))}`);

const formulaErrorScan = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-classifier formula error scan",
  maxChars: 5000,
});

for (const [sheetName, range, fileName] of [
  ["Older samples - before 2021", "A1:Y20", "older_top.png"],
  ["Older samples - before 2021", "A68:Y80", "older_changed.png"],
  ["Older samples - before 2021", "A164:Y190", "older_end.png"],
  ["2021 onward", "A1:Y60", "onward_top_changed.png"],
  ["2021 onward", "A95:Y125", "onward_middle.png"],
]) {
  const blob = await finalWorkbook.render({ sheetName, range, scale: 1.55, format: "png" });
  await fs.writeFile(path.join(previewDir, fileName), new Uint8Array(await blob.arrayBuffer()));
}

const problemCount = [...warningCells.values()].filter((item) => item.type === "problem").length;
const repeatCount = [...warningCells.values()].filter((item) => item.type === "repeat").length;
console.log(JSON.stringify({
  outputPath,
  changedRows: changeLog.length,
  changeLog,
  problemYellowCells: problemCount,
  needsRepeatOrangeCells: repeatCount,
  decisionMismatchCount: decisionMismatches.length,
  unexpectedValueChangeCount: unexpectedValueChanges.length,
  warningStyleMismatchCount: warningStyleMismatches.length,
  formulaErrorScan: formulaErrorScan.ndjson,
}, null, 2));
