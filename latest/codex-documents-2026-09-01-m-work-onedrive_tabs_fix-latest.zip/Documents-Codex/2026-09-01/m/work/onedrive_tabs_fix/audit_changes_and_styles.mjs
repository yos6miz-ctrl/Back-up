import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const currentPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const verifiedBasePath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_split_20260901/Final Known and Unknown - verified raw measurements.xlsx";
const requestedLedgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/requested_edit_ledger.json";
const additionsLedgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additional_measurements_ledger.json";

const [requestedLedger, additionsLedger] = await Promise.all([
  fs.readFile(requestedLedgerPath, "utf8").then(JSON.parse),
  fs.readFile(additionsLedgerPath, "utf8").then(JSON.parse),
]);
const [current, verifiedBase] = await Promise.all([
  SpreadsheetFile.importXlsx(await FileBlob.load(currentPath)),
  SpreadsheetFile.importXlsx(await FileBlob.load(verifiedBasePath)),
]);

function normalized(value) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (value === "") return null;
  return value;
}

function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "string" && /^\d{4}-\d{2}-\d{2}$/.test(b)) {
    return new Date(Date.UTC(1899, 11, 30) + Math.round(a) * 86400000).toISOString().slice(0, 10) === b;
  }
  if (typeof b === "number" && typeof a === "string" && /^\d{4}-\d{2}-\d{2}$/.test(a)) {
    return new Date(Date.UTC(1899, 11, 30) + Math.round(b) * 86400000).toISOString().slice(0, 10) === a;
  }
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

function compareRows(actualRows, expectedRecords, sheetName, label) {
  const mismatches = [];
  if (actualRows.length !== expectedRecords.length) {
    mismatches.push({ label, sheetName, kind: "row-count", actual: actualRows.length, expected: expectedRecords.length });
  }
  const count = Math.min(actualRows.length, expectedRecords.length);
  for (let i = 0; i < count; i += 1) {
    const expected = expectedRecords[i].values;
    const actual = actualRows[i];
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[col], expected[col])) {
        mismatches.push({
          label,
          sheetName,
          row: i + 2,
          col: col + 1,
          primary: expected[0],
          actual: normalized(actual[col]),
          expected: normalized(expected[col]),
        });
      }
    }
  }
  return mismatches;
}

const baseOlderRows = verifiedBase.worksheets.getItem("Older samples - before 2021").getRange("A2:AA189").values;
const baseOnwardRows = verifiedBase.worksheets.getItem("2021 onward").getRange("A2:AA159").values;
const expectedRequestedOlder = requestedLedger.rows.filter((row) => row.split === "Before 2021");
const expectedRequestedOnward = requestedLedger.rows.filter((row) => row.split === "2021 onward");
const requestedMismatches = [
  ...compareRows(baseOlderRows, expectedRequestedOlder, "Older samples - before 2021", "requested-edit ledger"),
  ...compareRows(baseOnwardRows, expectedRequestedOnward, "2021 onward", "requested-edit ledger"),
];

const currentOlderRows = current.worksheets.getItem("Older samples - before 2021").getRange("A2:AA190").values;
const currentOnwardRows = current.worksheets.getItem("2021 onward").getRange("A2:AA159").values;
const updateByRowId = new Map(additionsLedger.existing_row_updates.map((item) => [item.row_id, item]));
const finalMismatches = [];

for (const [sheetName, baseRows, currentRows] of [
  ["Older samples - before 2021", baseOlderRows, currentOlderRows.slice(0, 188)],
  ["2021 onward", baseOnwardRows, currentOnwardRows],
]) {
  for (let index = 0; index < baseRows.length; index += 1) {
    const rowNumber = index + 2;
    const rowId = `${sheetName}!${rowNumber}`;
    const expected = updateByRowId.get(rowId)?.values ?? baseRows[index];
    const actual = currentRows[index];
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[col], expected[col])) {
        finalMismatches.push({ sheetName, row: rowNumber, col: col + 1, primary: expected[0], actual: normalized(actual[col]), expected: normalized(expected[col]) });
      }
    }
  }
}

const newExpected = additionsLedger.new_rows[0].values;
const newActual = currentOlderRows[188];
for (let col = 0; col < 27; col += 1) {
  if (!equal(newActual[col], newExpected[col])) {
    finalMismatches.push({ sheetName: "Older samples - before 2021", row: 190, col: col + 1, primary: newExpected[0], actual: normalized(newActual[col]), expected: normalized(newExpected[col]) });
  }
}

const measurementIndexes = [...Array(8).keys()].map((i) => i + 9).concat([...Array(6).keys()].map((i) => i + 18));
const allRows = [...currentOlderRows, ...currentOnwardRows];
const measurementCount = allRows.reduce(
  (total, row) => total + measurementIndexes.filter((index) => typeof row[index] === "number" && Number.isFinite(row[index])).length,
  0,
);

const requestedNames = ["CDr 179", "CDr 615", "HS 606", "UN FZK58", "UNFNS98"];
const excludedNames = ["IBS P4 w0", "IBS P6", "IBS P7"];
const nameFindings = {};
for (const name of [...requestedNames, ...excludedNames]) {
  const matches = [];
  for (const [sheetName, rows] of [["Older samples - before 2021", currentOlderRows], ["2021 onward", currentOnwardRows]]) {
    rows.forEach((row, index) => {
      const combined = `${row[0] ?? ""} ${row[1] ?? ""}`.toLowerCase();
      if (combined.includes(name.toLowerCase())) matches.push({ sheet: sheetName, row: index + 2, primary: row[0], secondary: row[1] });
    });
  }
  nameFindings[name] = matches;
}

const detectorColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};
const expectedRepeatCells = [];
for (const [sheetName, records] of [
  ["Older samples - before 2021", expectedRequestedOlder],
  ["2021 onward", expectedRequestedOnward],
]) {
  records.forEach((baseRecord, index) => {
    const row = index + 2;
    const record = updateByRowId.get(`${sheetName}!${row}`) ?? baseRecord;
    for (const detector of ["PA447", "araE"]) {
      const result = record.detector_results?.[detector];
      for (const repeatIndex of result?.needs_repeat_indices ?? []) {
        expectedRepeatCells.push({
          sheet: sheetName,
          row,
          sample: record.values[0],
          detector,
          cell: `${detectorColumns[detector][repeatIndex]}${row}`,
        });
      }
    }
  });
}
for (const record of additionsLedger.new_rows) {
  const sheetName = record.split === "Before 2021" ? "Older samples - before 2021" : "2021 onward";
  const row = sheetName === "Older samples - before 2021" ? 190 : 160;
  for (const detector of ["PA447", "araE"]) {
    const result = record.detector_results?.[detector];
    for (const repeatIndex of result?.needs_repeat_indices ?? []) {
      expectedRepeatCells.push({ sheet: sheetName, row, sample: record.values[0], detector, cell: `${detectorColumns[detector][repeatIndex]}${row}` });
    }
  }
}

const repeatStyleMismatches = [];
for (const item of expectedRepeatCells) {
  const styleResult = await current.inspect({ kind: "computedStyle", sheetId: item.sheet, range: item.cell, maxChars: 3000 });
  const record = styleResult.ndjson.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line))[0];
  const fillColor = record?.style?.fill?.color?.value ?? null;
  if (fillColor !== "F4B183") repeatStyleMismatches.push({ ...item, actualFill: fillColor });
}

const styles = {};
for (const [key, sheetId, range] of [
  ["repeat_F_ZK_2158", "2021 onward", "J16"],
  ["repeat_CT_606", "Older samples - before 2021", "J190"],
  ["bold_used_F_MI_24133", "2021 onward", "J101:K101"],
  ["problem_F_MI_24133", "2021 onward", "L101"],
]) {
  const result = await current.inspect({ kind: "computedStyle", sheetId, range, maxChars: 4000 });
  styles[key] = result.ndjson;
}

console.log(JSON.stringify({
  sheetRows: { older: currentOlderRows.length, onward: currentOnwardRows.length, total: allRows.length },
  requestedEditLedger: {
    exactMismatchCount: requestedMismatches.length,
    removedMeasurementCells: requestedLedger.removed_measurement_cells,
    removalCounts: requestedLedger.removal_counts,
    citationMeasurementsCorrected: requestedLedger.citation_measurements_corrected,
    citationRowsCorrected: requestedLedger.citation_rows_corrected,
  },
  additionsLedger: {
    exactMismatchCount: finalMismatches.length,
    measurementCount,
    addedTotal: additionsLedger.measurements_added,
    rawMeasurementsForOriginal75: additionsLedger.raw_extra_measurements_for_original_75_samples,
    aliasMeasurements: additionsLedger.measurements_added_via_confirmed_aliases,
    aliquotMeasurements: additionsLedger.measurements_added_via_aliquot_identity_matches,
    newRowMeasurements: additionsLedger.measurements_added_with_new_rows,
    existingSamplesUpdated: additionsLedger.existing_samples_updated,
    newSamplesAdded: additionsLedger.new_samples_added,
  },
  nameFindings,
  repeatWarnings: {
    expectedCount: expectedRepeatCells.length,
    correctlyOrangeCount: expectedRepeatCells.length - repeatStyleMismatches.length,
    styleMismatchCount: repeatStyleMismatches.length,
    mismatchPreview: repeatStyleMismatches.slice(0, 10),
    exampleCells: expectedRepeatCells.slice(0, 8),
  },
  mismatchPreview: { requested: requestedMismatches.slice(0, 10), final: finalMismatches.slice(0, 10) },
  styles,
}, null, 2));
