import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const requestedLedgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/requested_edit_ledger.json";
const additionsLedgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/split_final/additional_measurements_ledger.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/consistent_measurement_marking_20260902";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/style_after";

const PROBLEM_YELLOW = "#FFD966";
const NEEDS_REPEAT_ORANGE = "#F4B183";
const detectorColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const [requestedLedger, additionsLedger] = await Promise.all([
  fs.readFile(requestedLedgerPath, "utf8").then(JSON.parse),
  fs.readFile(additionsLedgerPath, "utf8").then(JSON.parse),
]);
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));

const sourceValues = {
  "Older samples - before 2021": workbook.worksheets.getItem("Older samples - before 2021").getRange("A1:AA190").values,
  "2021 onward": workbook.worksheets.getItem("2021 onward").getRange("A1:AA159").values,
};

for (const [sheetName, lastRow] of [["Older samples - before 2021", 190], ["2021 onward", 159]]) {
  const sheet = workbook.worksheets.getItem(sheetName);
  for (const address of [`J2:Q${lastRow}`, `S2:X${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = "#FFFFFF";
    range.format.font = { name: "Calibri", size: 10, color: "#000000", bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

const updateByRowId = new Map(additionsLedger.existing_row_updates.map((item) => [item.row_id, item]));
const problemCells = new Map();
const repeatCells = new Map();

function collectWarningCells(sheetName, rowNumber, record) {
  for (const detector of ["PA447", "araE"]) {
    const result = record.detector_results?.[detector];
    for (const problemIndex of result?.problem_indices ?? []) {
      const cell = `${detectorColumns[detector][problemIndex]}${rowNumber}`;
      problemCells.set(`${sheetName}!${cell}`, { sheetName, cell, sample: record.values[0], detector });
    }
    for (const repeatIndex of result?.needs_repeat_indices ?? []) {
      const cell = `${detectorColumns[detector][repeatIndex]}${rowNumber}`;
      repeatCells.set(`${sheetName}!${cell}`, { sheetName, cell, sample: record.values[0], detector });
    }
  }
}

for (const [sheetName, split] of [["Older samples - before 2021", "Before 2021"], ["2021 onward", "2021 onward"]]) {
  const baseRecords = requestedLedger.rows.filter((row) => row.split === split);
  baseRecords.forEach((baseRecord, index) => {
    const rowNumber = index + 2;
    const record = updateByRowId.get(`${sheetName}!${rowNumber}`) ?? baseRecord;
    collectWarningCells(sheetName, rowNumber, record);
  });
}
for (const record of additionsLedger.new_rows) {
  const sheetName = record.split === "Before 2021" ? "Older samples - before 2021" : "2021 onward";
  const rowNumber = sheetName === "Older samples - before 2021" ? 190 : 160;
  collectWarningCells(sheetName, rowNumber, record);
}

const overlaps = [...problemCells.keys()].filter((key) => repeatCells.has(key));
if (overlaps.length) throw new Error(`Warning-state overlap detected: ${overlaps.join(", ")}`);

for (const item of problemCells.values()) {
  workbook.worksheets.getItem(item.sheetName).getRange(item.cell).format.fill = PROBLEM_YELLOW;
}
for (const item of repeatCells.values()) {
  workbook.worksheets.getItem(item.sheetName).getRange(item.cell).format.fill = NEEDS_REPEAT_ORANGE;
}

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));

function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  if (value === "") return null;
  return value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const valueMismatches = [];
for (const [sheetName, range] of [["Older samples - before 2021", "A1:AA190"], ["2021 onward", "A1:AA159"]]) {
  const finalValues = finalWorkbook.worksheets.getItem(sheetName).getRange(range).values;
  const expectedValues = sourceValues[sheetName];
  for (let row = 0; row < expectedValues.length; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(finalValues[row][col], expectedValues[row][col])) {
        valueMismatches.push({ sheetName, row: row + 1, col: col + 1, before: normalized(expectedValues[row][col]), after: normalized(finalValues[row][col]) });
      }
    }
  }
}
if (valueMismatches.length) throw new Error(`Data changed during formatting: ${JSON.stringify(valueMismatches.slice(0, 10))}`);

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}

const warningStyleMismatches = [];
for (const [items, expectedColor, label] of [
  [problemCells.values(), PROBLEM_YELLOW.slice(1), "problem"],
  [repeatCells.values(), NEEDS_REPEAT_ORANGE.slice(1), "repeat"],
]) {
  for (const item of items) {
    const result = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: item.sheetName, range: item.cell, maxChars: 2500 });
    const style = firstStyleRecord(result.ndjson)?.style;
    const actualColor = style?.fill?.color?.value ?? null;
    if (actualColor !== expectedColor || style?.font?.bold === true) {
      warningStyleMismatches.push({ label, ...item, actualColor, bold: style?.font?.bold ?? false });
    }
  }
}
if (warningStyleMismatches.length) throw new Error(`Warning formatting mismatch: ${JSON.stringify(warningStyleMismatches.slice(0, 10))}`);

const formerlyBoldChecks = [
  ["Older samples - before 2021", "J5:K5"],
  ["2021 onward", "J101:K101"],
  ["2021 onward", "S120:T120"],
];
const remainingBoldChecks = [];
for (const [sheetName, range] of formerlyBoldChecks) {
  const result = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: sheetName, range, maxChars: 6000 });
  for (const line of result.ndjson.split(/\r?\n/).filter(Boolean)) {
    const record = JSON.parse(line);
    if (record?.style?.font?.bold === true) remainingBoldChecks.push({ sheetName, cell: record.for });
  }
}
if (remainingBoldChecks.length) throw new Error(`Bold measurement formatting remains: ${JSON.stringify(remainingBoldChecks)}`);

const errorScan = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-format formula error scan",
  maxChars: 5000,
});

for (const [sheetName, range, fileName] of [
  ["Older samples - before 2021", "I1:Y15", "older_top.png"],
  ["Older samples - before 2021", "I108:Y120", "older_middle.png"],
  ["Older samples - before 2021", "I185:Y190", "older_end.png"],
  ["2021 onward", "I1:Y25", "onward_top.png"],
  ["2021 onward", "I95:Y120", "onward_middle.png"],
]) {
  const blob = await finalWorkbook.render({ sheetName, range, scale: 1.75, format: "png" });
  await fs.writeFile(`${previewDir}/${fileName}`, new Uint8Array(await blob.arrayBuffer()));
}

console.log(JSON.stringify({
  outputPath,
  problemYellowCells: problemCells.size,
  needsRepeatOrangeCells: repeatCells.size,
  overlapCount: overlaps.length,
  valueMismatchCount: valueMismatches.length,
  warningStyleMismatchCount: warningStyleMismatches.length,
  remainingBoldCheckCount: remainingBoldChecks.length,
  errorScan: errorScan.ndjson,
}, null, 2));
