from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import re
import sys

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\onedrive_tabs_fix")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPEAT_FOLDER = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats")
SELECTED_FILES = [
    REPEAT_FOLDER / "20260901 araE sample repeats.xlsx",
    REPEAT_FOLDER / "20260902 447 sample repeats.xlsx",
]
OUTPUT = WORK / "selected_repeat_update_ledger.json"
RAW_AUDIT_SCRIPT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure"
    r"\audit_final_measurements_without_source.py"
)
LEGACY_DIR = RAW_AUDIT_SCRIPT.parent
EXPAND_PATH = LEGACY_DIR / "expand_measurement_columns_and_show_all.py"
TOLERANCE = 5e-7
SHEET_BOUNDS = {"Older samples - before 2021": 190, "2021 onward": 158}
DETECTOR_COLUMNS = {
    "PA447": list(range(8, 16)),
    "araE": list(range(17, 23)),
}
DECISION_COLUMNS = {"PA447": 16, "araE": 23}
FINAL_COLUMN = 5
SOURCE_COLUMN = 25


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sys.path.insert(0, str(LEGACY_DIR))
raw_audit = load_module("selected_repeat_raw_audit", RAW_AUDIT_SCRIPT)
expand = load_module("selected_repeat_expand", EXPAND_PATH)
training, feature_cols, _fill_values, training_sources = expand.importer.classifier.load_training()
bars = expand.importer.classifier.learn_detector_bars(training, feature_cols)


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def source_parts(value):
    text = str(value or "")
    result = {"PA447": [], "araE": []}
    for detector in result:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if match:
            result[detector] = [part.strip() for part in match.group(1).split(",") if part.strip()]
    return result


def append_source(value, additions):
    parts = source_parts(value)
    for detector in ("PA447", "araE"):
        for file_name in additions.get(detector, []):
            if file_name not in parts[detector]:
                parts[detector].append(file_name)
    return "; ".join(
        f"{detector}: {', '.join(parts[detector])}"
        for detector in ("PA447", "araE")
        if parts[detector]
    )


def hash_file(path):
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


workbook = load_workbook(FINAL, data_only=True, read_only=False)
if workbook.sheetnames != list(SHEET_BOUNDS):
    raise AssertionError(f"Unexpected sheets: {workbook.sheetnames}")

rows = []
row_values = {}
for sheet_name, last_row in SHEET_BOUNDS.items():
    sheet = workbook[sheet_name]
    if sheet.max_row != last_row or sheet.max_column < 27:
        raise AssertionError(f"Unexpected dimensions for {sheet_name}: {sheet.max_row}x{sheet.max_column}")
    for row in range(2, last_row + 1):
        values = [sheet.cell(row, col).value for col in range(1, 28)]
        row_id = f"{sheet_name}!{row}"
        row_values[row_id] = values
        primary, secondary = values[0], values[1]
        exact_names = {
            raw_audit.norm(part)
            for name in (primary, secondary)
            for part in re.split(r"[;,\n]+", str(name or ""))
            if raw_audit.norm(part)
        }
        rows.append(
            {
                "row_id": row_id,
                "sheet": sheet_name,
                "row": row,
                "primary": primary,
                "secondary": secondary,
                "exact_names": exact_names,
                "keys": raw_audit.expand_manual_aliases(raw_audit.variants(primary, secondary)),
            }
        )


def candidates_for(record):
    sample_norm = raw_audit.norm(record["sample"])
    exact = [row for row in rows if sample_norm and sample_norm in row["exact_names"]]
    if exact:
        return exact, "exact_name"
    scored = []
    for row in rows:
        shared = set(record["keys"]) & row["keys"]
        if shared:
            scored.append((max(len(key) for key in shared), row))
    best = max((score for score, _row in scored), default=0)
    return [row for score, row in scored if score == best], "alias_keys" if best else "none"


raw_records = []
selected_file_info = []
for path in SELECTED_FILES:
    if not path.exists():
        raise FileNotFoundError(path)
    records = raw_audit.extract_formula_records(path)
    raw_records.extend(records)
    selected_file_info.append(
        {
            "path": str(path),
            "file": path.name,
            "sha256": hash_file(path),
            "record_occurrences": len(records),
        }
    )

unique_raw = {}
for record in raw_records:
    key = (record["source_file"], record["detector"], raw_audit.norm(record["sample"]), round(float(record["value"]), 9))
    unique_raw.setdefault(key, record)
if len(unique_raw) != 10:
    raise AssertionError(f"Expected 10 unique raw measurements, found {len(unique_raw)}")

matched_additions = []
for record in unique_raw.values():
    candidates, method = candidates_for(record)
    if len(candidates) != 1:
        raise AssertionError(f"Expected one target for {record['sample']}, found {[row['row_id'] for row in candidates]}")
    target = candidates[0]
    values = row_values[target["row_id"]]
    detector_values = [values[col - 1] for col in DETECTOR_COLUMNS[record["detector"]]]
    if any(is_numeric(value) and abs(float(value) - float(record["value"])) <= TOLERANCE for value in detector_values):
        raise AssertionError(f"Raw measurement already present for {record['sample']} {record['detector']}: {record['value']}")
    matched_additions.append(
        {
            "sheet": target["sheet"],
            "row": target["row"],
            "row_id": target["row_id"],
            "primary": target["primary"],
            "secondary": target["secondary"],
            "detector": record["detector"],
            "value": float(record["value"]),
            "source_file": record["source_file"],
            "source_path": record["path"],
            "source_cell": record["source_cell"],
            "raw_sample": record["sample"],
            "match_method": method,
        }
    )

additions_by_row = defaultdict(list)
for item in matched_additions:
    additions_by_row[item["row_id"]].append(item)

source_updates = []
assignment_proofs = []
for row_id, additions in additions_by_row.items():
    values = row_values[row_id]
    source_additions = defaultdict(list)
    for item in sorted(additions, key=lambda item: (item["detector"], item["source_file"], item["source_cell"])):
        columns = DETECTOR_COLUMNS[item["detector"]]
        target_column = next((col for col in columns if not is_numeric(values[col - 1])), None)
        if target_column is None:
            raise AssertionError(f"No open measurement column for {row_id} {item['detector']}")
        values[target_column - 1] = item["value"]
        source_additions[item["detector"]].append(item["source_file"])
        item["target_column"] = target_column
        item["target_cell"] = f"{expand.get_column_letter(target_column)}{item['row']}" if hasattr(expand, "get_column_letter") else None
        assignment_proofs.append(item)
    old_source = values[SOURCE_COLUMN - 1]
    new_source = append_source(old_source, source_additions)
    values[SOURCE_COLUMN - 1] = new_source
    source_updates.append({
        "row_id": row_id,
        "sheet": additions[0]["sheet"],
        "row": additions[0]["row"],
        "primary": additions[0]["primary"],
        "before": old_source,
        "after": new_source,
    })

records = []
decision_changes = []
final_changes = []
for sheet_name, last_row in SHEET_BOUNDS.items():
    for row in range(2, last_row + 1):
        row_id = f"{sheet_name}!{row}"
        values = row_values[row_id]
        status = str(values[2] or "").strip()
        if status == "old metering system":
            records.append({
                "sheet": sheet_name,
                "row": row,
                "primary": values[0],
                "status": status,
                "preserve": True,
                "PA447": None,
                "araE": None,
                "final": values[FINAL_COLUMN - 1],
            })
            continue

        has_numeric = any(
            is_numeric(values[col - 1])
            for columns in DETECTOR_COLUMNS.values()
            for col in columns
        )
        if not has_numeric:
            results = {
                detector: {"call": None, "decision": None, "used_indices": [], "problem_indices": [], "needs_repeat_indices": []}
                for detector in ("PA447", "araE")
            }
            final = "לא נבדק" if status == "לא נבדק" else "missing"
        else:
            results = {}
            for detector in ("PA447", "araE"):
                detector_values = [values[col - 1] if is_numeric(values[col - 1]) else None for col in DETECTOR_COLUMNS[detector]]
                result = expand.detector_consensus_with_used(detector_values, bars[detector]["bar"])
                results[detector] = {
                    "call": result.get("call"),
                    "decision": result.get("decision"),
                    "used_indices": result.get("used_indices", []),
                    "problem_indices": result.get("problem_indices", []),
                    "needs_repeat_indices": result.get("needs_repeat_indices", []),
                }
            calls = [result["call"] for result in results.values() if result["call"]]
            final = expand.importer.classifier.final_classification(calls) if calls else "missing"

        for detector in ("PA447", "araE"):
            old = values[DECISION_COLUMNS[detector] - 1]
            new = results[detector]["decision"]
            if old != new:
                decision_changes.append({
                    "sheet": sheet_name,
                    "row": row,
                    "primary": values[0],
                    "detector": detector,
                    "before": old,
                    "after": new,
                })
            values[DECISION_COLUMNS[detector] - 1] = new
        old_final = values[FINAL_COLUMN - 1]
        if old_final != final:
            final_changes.append({
                "sheet": sheet_name,
                "row": row,
                "primary": values[0],
                "before": old_final,
                "after": final,
            })
        values[FINAL_COLUMN - 1] = final
        records.append({
            "sheet": sheet_name,
            "row": row,
            "primary": values[0],
            "status": status,
            "preserve": False,
            "PA447": results["PA447"],
            "araE": results["araE"],
            "final": final,
        })

workbook.close()

for item in assignment_proofs:
    if item["target_cell"] is None:
        from openpyxl.utils import get_column_letter
        item["target_cell"] = f"{get_column_letter(item['target_column'])}{item['row']}"

result = {
    "input": str(FINAL),
    "input_sha256": hash_file(FINAL),
    "selected_files": selected_file_info,
    "bars": {detector: bars[detector]["bar"] for detector in ("PA447", "araE")},
    "training_rows": len(training),
    "training_sources": training_sources,
    "measurements_added": len(assignment_proofs),
    "affected_rows": len(additions_by_row),
    "assignment_proofs": assignment_proofs,
    "source_updates": source_updates,
    "records": records,
    "decision_changes": decision_changes,
    "final_changes": final_changes,
    "decision_change_count": len(decision_changes),
    "final_change_count": len(final_changes),
    "classification_counts": dict(Counter(str(record["final"]) for record in records)),
}
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
print(json.dumps({
    "output": str(OUTPUT),
    "input_sha256": result["input_sha256"],
    "selected_files": selected_file_info,
    "measurements_added": result["measurements_added"],
    "affected_rows": result["affected_rows"],
    "decision_changes": decision_changes,
    "final_changes": final_changes,
}, ensure_ascii=False, indent=2))
