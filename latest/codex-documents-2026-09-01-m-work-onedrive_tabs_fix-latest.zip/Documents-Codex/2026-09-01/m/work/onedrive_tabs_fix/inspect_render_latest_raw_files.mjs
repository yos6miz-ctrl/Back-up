import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const repeatDir = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/sample repeats";
const names = [
  "20260831 447 sample repeats.xlsx",
  "20260831 araE sample repeats.xlsx",
  "20260903 447 sample repeats.xlsx",
  "20260907 447 sample repeats.xlsx",
  "20260907 araE sample repeats.xlsx",
  "20260909 araE sample repeats.xlsx",
  "20260910 araE sample repeats.xlsx",
];
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/latest_raw_previews";
await fs.mkdir(previewDir, { recursive: true });

const results = [];
for (const name of names) {
  const filePath = `${repeatDir}/${name}`;
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(filePath));
  const sheets = [];
  for (const sheet of workbook.worksheets.items) {
    const used = sheet.getUsedRange(true);
    const values = used?.values ?? [];
    const formulas = used?.formulas ?? [];
    const rows = values.length;
    const cols = values[0]?.length ?? 0;
    const range = rows && cols ? `A1:${String.fromCharCode(64 + Math.min(cols, 22))}${Math.min(rows, 16)}` : "A1:V16";
    const table = await workbook.inspect({
      kind: "table",
      sheetId: sheet.name,
      range,
      include: "values,formulas",
      tableMaxRows: 16,
      tableMaxCols: 22,
      maxChars: 18000,
    });
    const formulaScan = await workbook.inspect({
      kind: "formula",
      sheetId: sheet.name,
      maxChars: 14000,
      options: { maxResults: 100 },
    });
    let imagePath = null;
    if (rows && cols) {
      const image = await workbook.render({ sheetName: sheet.name, range, scale: 1.5, format: "png" });
      imagePath = path.join(previewDir, `${name.replace(/\.xlsx$/i, "").replace(/[^A-Za-z0-9]+/g, "_")}_${sheet.name.replace(/[^A-Za-z0-9]+/g, "_")}.png`);
      await fs.writeFile(imagePath, new Uint8Array(await image.arrayBuffer()));
    }
    sheets.push({ name: sheet.name, rows, cols, range, table: table.ndjson, formulaScan: formulaScan.ndjson, imagePath });
  }
  results.push({ filePath, sheets });
}

const outputPath = `${previewDir}/inspection.json`;
await fs.writeFile(outputPath, JSON.stringify(results, null, 2));
console.log(JSON.stringify({ outputPath, files: results.map((r) => ({ file: path.basename(r.filePath), sheets: r.sheets.map((s) => ({ name: s.name, rows: s.rows, cols: s.cols, range: s.range, imagePath: s.imagePath })) })) }, null, 2));
