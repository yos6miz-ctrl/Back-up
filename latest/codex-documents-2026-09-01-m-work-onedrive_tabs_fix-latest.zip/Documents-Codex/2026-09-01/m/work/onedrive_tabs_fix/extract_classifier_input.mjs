import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = process.argv[2] ?? "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const outputPath = process.argv[3] ?? "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_input.json";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));

const sheets = [];
for (const [sheetName, lastRow] of [
  ["Older samples - before 2021", 190],
  ["2021 onward", 159],
]) {
  const values = workbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  sheets.push({ sheetName, values });
}

await fs.writeFile(outputPath, JSON.stringify({ workbookPath, sheets }, null, 2), "utf8");
console.log(JSON.stringify({ outputPath, sheets: sheets.map((s) => ({ sheet: s.sheetName, rows: s.values.length })) }, null, 2));
