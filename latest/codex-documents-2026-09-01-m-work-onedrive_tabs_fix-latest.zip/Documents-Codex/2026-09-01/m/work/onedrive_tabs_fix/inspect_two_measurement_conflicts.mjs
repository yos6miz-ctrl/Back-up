import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const classifierPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/two_measurement_conflicts_before";
const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const detectorLayout = {
  PA447: { columns: ["H", "I", "J", "K", "L", "M", "N", "O"], startIndex: 7 },
  araE: { columns: ["Q", "R", "S", "T", "U", "V"], startIndex: 16 },
};

await fs.mkdir(previewDir, { recursive: true });
const classifier = JSON.parse(await fs.readFile(classifierPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));
const sheetValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  sheetValues[sheetName] = workbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
}

function mappedRow(record) {
  if (record.sheet !== "2021 onward") return record.row;
  if (record.primary === "F-NY-21358" || record.row === 20) return null;
  return record.row > 20 ? record.row - 1 : record.row;
}

function measurementCall(value, bar) {
  if (value > bar * 1.05) return "IBD-like";
  if (value < bar * 0.95) return "IBS-like";
  return "inconclusive";
}

function parseFirstLine(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}

function compactStyle(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
  };
}

const conflicts = [];
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const values = sheetValues[record.sheet][row - 1];
  if (String(values[0] ?? "").trim() !== String(record.primary ?? "").trim()) {
    throw new Error(`Ledger alignment failed at ${record.sheet}!${row}`);
  }
  const anyPositive = record.PA447?.decision === "Pos" || record.araE?.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    const entries = layout.columns.flatMap((column, index) => {
      const value = values[layout.startIndex + index];
      return typeof value === "number" && Number.isFinite(value)
        ? [{ column, index, value, call: measurementCall(value, classifier.summary.bars[detector]) }]
        : [];
    });
    const calls = new Set(entries.map((entry) => entry.call));
    if (entries.length !== 2 || !calls.has("IBD-like") || !calls.has("IBS-like")) continue;

    const styledEntries = [];
    for (const entry of entries) {
      const cell = `${entry.column}${row}`;
      const inspected = await workbook.inspect({ kind: "computedStyle", sheetId: record.sheet, range: cell, maxChars: 2500 });
      styledEntries.push({ ...entry, cell, style: compactStyle(parseFirstLine(inspected.ndjson)?.style) });
    }
    conflicts.push({
      sheet: record.sheet,
      row,
      sample: record.primary,
      detector,
      detectorDecision: record[detector]?.decision,
      otherDetectorDecision: record[detector === "PA447" ? "araE" : "PA447"]?.decision,
      finalDecision: record.final,
      repeatRequired: !anyPositive,
      entries: styledEntries,
    });
  }
}

let renderIndex = 1;
for (const conflict of conflicts) {
  const startRow = Math.max(1, conflict.row - 1);
  const endRow = Math.min(bounds[conflict.sheet], conflict.row + 1);
  const image = await workbook.render({ sheetName: conflict.sheet, range: `A${startRow}:W${endRow}`, scale: 1.7, format: "png" });
  const safeName = `${String(renderIndex).padStart(2, "0")}_${conflict.sheet.startsWith("Older") ? "older" : "onward"}_row_${conflict.row}_${conflict.detector}.png`;
  await fs.writeFile(path.join(previewDir, safeName), new Uint8Array(await image.arrayBuffer()));
  conflict.preview = path.join(previewDir, safeName);
  renderIndex += 1;
}

console.log(JSON.stringify({
  workbookPath,
  conflictCount: conflicts.length,
  repeatRequiredCount: conflicts.filter((item) => item.repeatRequired).length,
  suppressedBecauseOtherDetectorPositiveCount: conflicts.filter((item) => !item.repeatRequired).length,
  conflicts,
}, null, 2));
