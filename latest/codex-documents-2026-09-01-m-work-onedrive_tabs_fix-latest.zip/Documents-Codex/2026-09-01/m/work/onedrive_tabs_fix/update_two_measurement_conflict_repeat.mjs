import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const classifierPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/two_measurement_conflict_repeat_20260903";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/two_measurement_conflicts_after";

const GREY_TEXT = "#A6A6A6";
const NORMAL_TEXT = "#000000";
const WHITE = "#FFFFFF";
const REPEAT_YELLOW = "#FFD966";
const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const detectorLayout = {
  PA447: { columns: ["H", "I", "J", "K", "L", "M", "N", "O"], startIndex: 7 },
  araE: { columns: ["Q", "R", "S", "T", "U", "V"], startIndex: 16 },
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const classifier = JSON.parse(await fs.readFile(classifierPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const beforeValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  beforeValues[sheetName] = sheet.getRange(`A1:AA${lastRow}`).values;
  if (beforeValues[sheetName][0][15] !== "PA447 decision" || beforeValues[sheetName][0][22] !== "araE decision") {
    throw new Error(`Unexpected detector layout on ${sheetName}`);
  }
}

function mappedRow(record) {
  if (record.sheet !== "2021 onward") return record.row;
  if (record.primary === "F-NY-21358" || record.row === 20) return null;
  return record.row > 20 ? record.row - 1 : record.row;
}

function measurementCall(value, bar) {
  if (value > bar * 1.05) return "IBD-like";
  if (value < bar * 0.95) return "IBS-like";
  return "inconclusive";
}

for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null) continue;
  const currentPrimary = beforeValues[record.sheet]?.[row - 1]?.[0];
  if (String(currentPrimary ?? "").trim() !== String(record.primary ?? "").trim()) {
    throw new Error(`Classifier ledger no longer aligns at ${record.sheet}!${row}: workbook=${currentPrimary} ledger=${record.primary}`);
  }
}

// Establish the conflicting-pair exception before rebuilding all measurement formatting.
const conflictingPairs = [];
const conflictingCellKeys = new Set();
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const values = beforeValues[record.sheet][row - 1];
  const anyPositive = record.PA447?.decision === "Pos" || record.araE?.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    const entries = layout.columns.flatMap((column, index) => {
      const value = values[layout.startIndex + index];
      return typeof value === "number" && Number.isFinite(value)
        ? [{ column, index, value, call: measurementCall(value, classifier.summary.bars[detector]) }]
        : [];
    });
    const calls = new Set(entries.map((entry) => entry.call));
    if (entries.length !== 2 || !calls.has("IBD-like") || !calls.has("IBS-like")) continue;
    const cells = entries.map((entry) => `${entry.column}${row}`);
    for (const cell of cells) conflictingCellKeys.add(`${record.sheet}!${cell}`);
    conflictingPairs.push({
      sheet: record.sheet,
      row,
      sample: record.primary,
      detector,
      cells,
      values: entries.map(({ value, call }) => ({ value, call })),
      repeatRequired: !anyPositive,
      otherDetectorDecision: record[detector === "PA447" ? "araE" : "PA447"]?.decision ?? null,
      finalDecision: record.final,
    });
  }
}

for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  for (const address of [`H2:O${lastRow}`, `Q2:V${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = WHITE;
    range.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

const problemCells = new Map();
const repeatCells = new Map();
const suppressedCells = new Map();

for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const anyPositive = record.PA447?.decision === "Pos" || record.araE?.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    for (const index of record[detector]?.problem_indices ?? []) {
      const cell = `${layout.columns[index]}${row}`;
      const key = `${record.sheet}!${cell}`;
      if (!conflictingCellKeys.has(key)) {
        problemCells.set(key, { sheet: record.sheet, cell, detector, sample: record.primary, reason: "excluded" });
      }
    }
    for (const index of record[detector]?.needs_repeat_indices ?? []) {
      const cell = `${layout.columns[index]}${row}`;
      const key = `${record.sheet}!${cell}`;
      const item = { sheet: record.sheet, cell, detector, sample: record.primary, reason: "classifier-repeat" };
      if (anyPositive) suppressedCells.set(key, item);
      else repeatCells.set(key, item);
    }
  }
}

for (const pair of conflictingPairs) {
  for (const cell of pair.cells) {
    const key = `${pair.sheet}!${cell}`;
    const item = { sheet: pair.sheet, cell, detector: pair.detector, sample: pair.sample, reason: "two-measurement-conflict" };
    problemCells.delete(key);
    if (pair.repeatRequired) {
      suppressedCells.delete(key);
      repeatCells.set(key, item);
    } else {
      repeatCells.delete(key);
      suppressedCells.set(key, item);
    }
  }
}

const overlaps = [...problemCells.keys()].filter((key) => repeatCells.has(key) || suppressedCells.has(key));
if (overlaps.length) throw new Error(`Overlapping measurement states: ${overlaps.join(", ")}`);

for (const item of problemCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = WHITE;
  cell.format.font = { name: "Calibri", size: 10, color: GREY_TEXT, bold: false };
}
for (const item of repeatCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = REPEAT_YELLOW;
  cell.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  return value === "" ? null : value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const valueMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const actual = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const expected = beforeValues[sheetName];
  for (let row = 0; row < expected.length; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[row][col], expected[row][col])) {
        valueMismatches.push({ sheet: sheetName, row: row + 1, col: col + 1, before: normalized(expected[row][col]), after: normalized(actual[row][col]) });
      }
    }
  }
}
if (valueMismatches.length) throw new Error(`Data or classification values changed: ${JSON.stringify(valueMismatches.slice(0, 12))}`);

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}
function styleValues(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
  };
}

const styleMismatches = [];
for (const [items, expectedFill, expectedText, label] of [
  [problemCells.values(), WHITE.slice(1), GREY_TEXT.slice(1), "excluded"],
  [repeatCells.values(), REPEAT_YELLOW.slice(1), NORMAL_TEXT.slice(1), "repeat"],
  [suppressedCells.values(), WHITE.slice(1), NORMAL_TEXT.slice(1), "suppressed-repeat"],
]) {
  for (const item of items) {
    const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: item.sheet, range: item.cell, maxChars: 2500 });
    const actual = styleValues(firstStyleRecord(inspected.ndjson)?.style);
    if (actual.fill !== expectedFill || actual.text !== expectedText || actual.bold) {
      styleMismatches.push({ label, ...item, ...actual, expectedFill, expectedText });
    }
  }
}
if (styleMismatches.length) throw new Error(`Measurement-style verification failed: ${JSON.stringify(styleMismatches.slice(0, 12))}`);

const formulaErrors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-conflict-formatting formula error scan",
  maxChars: 5000,
});

for (const [sheetName, range, name] of [
  ["Older samples - before 2021", "A31:W45", "older_conflicts_yellow.png"],
  ["2021 onward", "A3:W8", "onward_conflict_suppressed_by_positive.png"],
  ["2021 onward", "A19:W46", "onward_conflicts_yellow_1.png"],
  ["2021 onward", "A63:W82", "onward_conflicts_yellow_2.png"],
  ["2021 onward", "A118:W122", "onward_conflict_yellow_3.png"],
]) {
  const image = await finalWorkbook.render({ sheetName, range, scale: 1.7, format: "png" });
  await fs.writeFile(path.join(previewDir, name), new Uint8Array(await image.arrayBuffer()));
}

console.log(JSON.stringify({
  outputPath,
  valueMismatchCount: valueMismatches.length,
  conflictingPairCount: conflictingPairs.length,
  conflictingPairsRequestingRepeat: conflictingPairs.filter((pair) => pair.repeatRequired).length,
  conflictingPairsSuppressedByPositiveOtherDetector: conflictingPairs.filter((pair) => !pair.repeatRequired).length,
  conflictingPairYellowCells: conflictingPairs.filter((pair) => pair.repeatRequired).length * 2,
  conflictingPairRestoredNormalCells: conflictingPairs.filter((pair) => !pair.repeatRequired).length * 2,
  problemGreyTextCells: problemCells.size,
  repeatYellowCells: repeatCells.size,
  suppressedRepeatCells: suppressedCells.size,
  styleMismatchCount: styleMismatches.length,
  formulaErrors: formulaErrors.ndjson,
  conflictingPairs,
}, null, 2));
