import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const classifierPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/repeat_logic_update_20260903";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/repeat_logic_after";

const GREY_TEXT = "#A6A6A6";
const NORMAL_TEXT = "#000000";
const REPEAT_YELLOW = "#FFD966";
const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const measurementColumns = {
  PA447: ["H", "I", "J", "K", "L", "M", "N", "O"],
  araE: ["Q", "R", "S", "T", "U", "V"],
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const classifier = JSON.parse(await fs.readFile(classifierPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const beforeValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  beforeValues[sheetName] = sheet.getRange(`A1:AA${lastRow}`).values;
  if (beforeValues[sheetName][0][15] !== "PA447 decision" || beforeValues[sheetName][0][22] !== "araE decision") {
    throw new Error(`Unexpected detector layout on ${sheetName}: ${JSON.stringify(beforeValues[sheetName][0])}`);
  }
}

function mappedRow(record) {
  if (record.sheet !== "2021 onward") return record.row;
  if (record.primary === "F-NY-21358" || record.row === 20) return null;
  return record.row > 20 ? record.row - 1 : record.row;
}

for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null) continue;
  const currentPrimary = beforeValues[record.sheet]?.[row - 1]?.[0];
  if (String(currentPrimary ?? "").trim() !== String(record.primary ?? "").trim()) {
    throw new Error(`Classifier ledger no longer aligns at ${record.sheet}!${row}: workbook=${currentPrimary} ledger=${record.primary}`);
  }
}

for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  for (const address of [`H2:O${lastRow}`, `Q2:V${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = "#FFFFFF";
    range.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

const problemCells = new Map();
const repeatCells = new Map();
const suppressedCells = new Map();
let suppressedByPA447 = 0;
let suppressedByAraE = 0;

for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const paPositive = record.PA447?.decision === "Pos";
  const araePositive = record.araE?.decision === "Pos";
  for (const detector of ["PA447", "araE"]) {
    for (const index of record[detector]?.problem_indices ?? []) {
      const cell = `${measurementColumns[detector][index]}${row}`;
      problemCells.set(`${record.sheet}!${cell}`, { sheet: record.sheet, cell, detector, sample: record.primary });
    }
    for (const index of record[detector]?.needs_repeat_indices ?? []) {
      const cell = `${measurementColumns[detector][index]}${row}`;
      const item = { sheet: record.sheet, cell, detector, sample: record.primary };
      if (paPositive || araePositive) {
        suppressedCells.set(`${record.sheet}!${cell}`, item);
        if (paPositive) suppressedByPA447 += 1;
        else suppressedByAraE += 1;
      } else {
        repeatCells.set(`${record.sheet}!${cell}`, item);
      }
    }
  }
}

const overlaps = [...problemCells.keys()].filter((key) => repeatCells.has(key) || suppressedCells.has(key));
if (overlaps.length) throw new Error(`Overlapping measurement states: ${overlaps.join(", ")}`);

for (const item of problemCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = "#FFFFFF";
  cell.format.font = { name: "Calibri", size: 10, color: GREY_TEXT, bold: false };
}
for (const item of repeatCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = REPEAT_YELLOW;
  cell.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  return value === "" ? null : value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const valueMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const actual = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const expected = beforeValues[sheetName];
  for (let row = 0; row < expected.length; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[row][col], expected[row][col])) {
        valueMismatches.push({ sheet: sheetName, row: row + 1, col: col + 1, before: normalized(expected[row][col]), after: normalized(actual[row][col]) });
      }
    }
  }
}
if (valueMismatches.length) throw new Error(`Data or classification values changed: ${JSON.stringify(valueMismatches.slice(0, 12))}`);

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}
function styleValues(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
  };
}

const styleMismatches = [];
for (const [items, expectedFill, expectedText, label] of [
  [problemCells.values(), "FFFFFF", GREY_TEXT.slice(1), "excluded"],
  [repeatCells.values(), REPEAT_YELLOW.slice(1), NORMAL_TEXT.slice(1), "repeat"],
  [suppressedCells.values(), "FFFFFF", NORMAL_TEXT.slice(1), "suppressed-repeat"],
]) {
  for (const item of items) {
    const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: item.sheet, range: item.cell, maxChars: 2500 });
    const actual = styleValues(firstStyleRecord(inspected.ndjson)?.style);
    if (actual.fill !== expectedFill || actual.text !== expectedText || actual.bold) {
      styleMismatches.push({ label, ...item, ...actual, expectedFill, expectedText });
    }
  }
}
if (styleMismatches.length) throw new Error(`Repeat-style verification failed: ${JSON.stringify(styleMismatches.slice(0, 12))}`);

const formulaErrors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-repeat-logic formula error scan",
  maxChars: 5000,
});
const keyRange = await finalWorkbook.inspect({
  kind: "table",
  sheetId: "Older samples - before 2021",
  range: "A1:W15",
  include: "values,formulas",
  tableMaxRows: 15,
  tableMaxCols: 23,
  maxChars: 12000,
});

for (const [sheetName, range, name] of [
  ["Older samples - before 2021", "A1:W15", "older_positive_447.png"],
  ["Older samples - before 2021", "A65:W75", "older_repeat_still_required.png"],
  ["2021 onward", "A103:W113", "onward_positive_447.png"],
  ["2021 onward", "A93:W103", "onward_repeat_still_required.png"],
]) {
  const image = await finalWorkbook.render({ sheetName, range, scale: 1.7, format: "png" });
  await fs.writeFile(path.join(previewDir, name), new Uint8Array(await image.arrayBuffer()));
}

console.log(JSON.stringify({
  outputPath,
  valueMismatchCount: valueMismatches.length,
  problemGreyTextCells: problemCells.size,
  repeatYellowCells: repeatCells.size,
  suppressedRepeatCells: suppressedCells.size,
  newlySuppressedBecausePA447Pos: suppressedByPA447,
  suppressedBecauseAraEPos: suppressedByAraE,
  styleMismatchCount: styleMismatches.length,
  formulaErrors: formulaErrors.ndjson,
  keyRange: keyRange.ndjson,
}, null, 2));
