import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/decision_colors_before";
const bounds = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const decisionColumns = { final: "E", PA447: "P", araE: "W" };

await fs.mkdir(previewDir, { recursive: true });
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));

function firstRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}

function compactStyle(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
    italic: style?.font?.italic ?? false,
    horizontalAlignment: style?.horizontalAlignment ?? null,
  };
}

const groups = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  const values = sheet.getRange(`A1:W${lastRow}`).values;
  groups[sheetName] = {};
  for (const [label, column] of Object.entries(decisionColumns)) {
    const byDecision = {};
    for (let row = 2; row <= lastRow; row += 1) {
      const columnIndex = label === "final" ? 4 : label === "PA447" ? 15 : 22;
      const value = values[row - 1][columnIndex];
      if (value == null || value === "") continue;
      const cell = `${column}${row}`;
      const inspected = await workbook.inspect({ kind: "computedStyle", sheetId: sheetName, range: cell, maxChars: 2500 });
      const style = compactStyle(firstRecord(inspected.ndjson)?.style);
      const styleKey = JSON.stringify(style);
      byDecision[value] ??= {};
      byDecision[value][styleKey] ??= { style, count: 0, examples: [] };
      byDecision[value][styleKey].count += 1;
      if (byDecision[value][styleKey].examples.length < 8) {
        byDecision[value][styleKey].examples.push({ cell, primary: values[row - 1][0] });
      }
    }
    groups[sheetName][label] = Object.fromEntries(
      Object.entries(byDecision).map(([value, styleGroups]) => [value, Object.values(styleGroups)]),
    );
  }

  const chunks = sheetName.startsWith("Older")
    ? [[1, 65], [66, 130], [131, lastRow]]
    : [[1, 55], [56, 110], [111, lastRow]];
  for (const [startRow, endRow] of chunks) {
    const image = await workbook.render({ sheetName, range: `A${startRow}:E${endRow}`, scale: 1.4, format: "png" });
    const safeSheet = sheetName.startsWith("Older") ? "older" : "onward";
    await fs.writeFile(path.join(previewDir, `${safeSheet}_${startRow}_${endRow}.png`), new Uint8Array(await image.arrayBuffer()));
  }
}

console.log(JSON.stringify({ workbookPath, groups }, null, 2));
