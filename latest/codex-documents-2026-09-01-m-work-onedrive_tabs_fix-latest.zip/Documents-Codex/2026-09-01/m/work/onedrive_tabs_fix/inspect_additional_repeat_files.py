from __future__ import annotations

from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import sys

from openpyxl import load_workbook


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\onedrive_tabs_fix")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPEAT_FOLDER = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats")
OUTPUT = WORK / "additional_repeat_file_inspection.json"
RAW_AUDIT_SCRIPT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure"
    r"\audit_final_measurements_without_source.py"
)
TOLERANCE = 5e-7


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def hash_file(path):
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


sys.path.insert(0, str(RAW_AUDIT_SCRIPT.parent))
raw_audit = load_module("additional_repeat_raw_audit", RAW_AUDIT_SCRIPT)

workbook = load_workbook(FINAL, data_only=True, read_only=False)
rows = []
for sheet_name in workbook.sheetnames:
    sheet = workbook[sheet_name]
    for row in range(2, sheet.max_row + 1):
        primary = sheet.cell(row, 1).value
        secondary = sheet.cell(row, 2).value
        exact_names = {
            raw_audit.norm(part)
            for name in (primary, secondary)
            for part in str(name or "").replace("\n", ";").split(";")
            if raw_audit.norm(part)
        }
        rows.append({
            "sheet": sheet_name,
            "row": row,
            "primary": primary,
            "secondary": secondary,
            "exact_names": exact_names,
            "keys": raw_audit.expand_manual_aliases(raw_audit.variants(primary, secondary)),
            "values": {
                "PA447": [float(sheet.cell(row, col).value) for col in range(8, 16) if is_numeric(sheet.cell(row, col).value)],
                "araE": [float(sheet.cell(row, col).value) for col in range(17, 23) if is_numeric(sheet.cell(row, col).value)],
            },
        })
workbook.close()


def candidates_for(record):
    sample_norm = raw_audit.norm(record["sample"])
    exact = [row for row in rows if sample_norm and sample_norm in row["exact_names"]]
    if exact:
        return exact, "exact_name"
    scored = []
    for row in rows:
        shared = set(record["keys"]) & row["keys"]
        if shared:
            scored.append((max(len(key) for key in shared), row))
    best = max((score for score, _row in scored), default=0)
    return [row for score, row in scored if score == best], "alias_keys" if best else "none"


files = sorted(REPEAT_FOLDER.glob("*.xlsx"), key=lambda p: p.name.lower())
file_results = []
all_records = []
for file_path in files:
    records = raw_audit.extract_formula_records(file_path)
    unique = {}
    for record in records:
        key = (record["detector"], raw_audit.norm(record["sample"]), round(float(record["value"]), 9))
        unique.setdefault(key, record)

    details = []
    for record in unique.values():
        candidates, method = candidates_for(record)
        matching = [
            row for row in candidates
            if any(abs(float(record["value"]) - value) <= TOLERANCE for value in row["values"][record["detector"]])
        ]
        if matching:
            classification = "already_present"
        elif len(candidates) == 1:
            classification = "new_measurement_for_existing_sample"
        elif len(candidates) > 1:
            classification = "ambiguous_sample_match"
        else:
            classification = "sample_not_in_final"
        detail = {
            "file": file_path.name,
            "sample": record["sample"],
            "sample_norm": raw_audit.norm(record["sample"]),
            "detector": record["detector"],
            "value": float(record["value"]),
            "source_cell": record["source_cell"],
            "classification": classification,
            "match_method": method,
            "candidate_rows": [
                {"sheet": row["sheet"], "row": row["row"], "primary": row["primary"], "secondary": row["secondary"]}
                for row in candidates
            ],
            "matching_rows": [f"{row['sheet']}!{row['row']}:{row['primary']}" for row in matching],
        }
        details.append(detail)
        all_records.append(detail)

    file_results.append({
        "path": str(file_path),
        "file": file_path.name,
        "sha256": hash_file(file_path),
        "created": file_path.stat().st_ctime,
        "modified": file_path.stat().st_mtime,
        "record_occurrences": len(records),
        "unique_measurements": len(unique),
        "classification_counts": dict(Counter(item["classification"] for item in details)),
        "details": details,
    })

cross_file = {}
for record in all_records:
    key = (record["detector"], record["sample_norm"], round(record["value"], 9))
    cross_file.setdefault(key, []).append(record["file"])
cross_file_duplicates = [
    {"detector": key[0], "sample_norm": key[1], "value": key[2], "files": sorted(set(names))}
    for key, names in cross_file.items() if len(set(names)) > 1
]

result = {
    "final": str(FINAL),
    "final_sha256": hash_file(FINAL),
    "files": file_results,
    "cross_file_duplicates": cross_file_duplicates,
}
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({
    "output": str(OUTPUT),
    "final_sha256": result["final_sha256"],
    "files": [
        {
            "file": f["file"],
            "sha256": f["sha256"],
            "unique_measurements": f["unique_measurements"],
            "classification_counts": f["classification_counts"],
        }
        for f in file_results
    ],
    "cross_file_duplicate_count": len(cross_file_duplicates),
}, ensure_ascii=False, indent=2))
