from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import os
import sys


WORK_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\onedrive_tabs_fix")
INPUT_PATH = Path(os.environ.get("CLASSIFIER_INPUT_PATH", str(WORK_DIR / "classifier_input.json")))
OUTPUT_PATH = Path(os.environ.get("CLASSIFIER_OUTPUT_PATH", str(WORK_DIR / "classifier_decisions.json")))
LEGACY_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXPAND_PATH = LEGACY_DIR / "expand_measurement_columns_and_show_all.py"
sys.path.insert(0, str(LEGACY_DIR))


def load_module(name: str, path: Path):
    spec = spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load {path}")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


expand = load_module("expand_measurement_columns_and_show_all", EXPAND_PATH)
classifier = expand.importer.classifier
training, feature_cols, _fill_values, sources = classifier.load_training()
bars = classifier.learn_detector_bars(training, feature_cols)


def numeric_values(row, indexes):
    return [value if isinstance(value, (int, float)) and not isinstance(value, bool) else None for value in (row[i] for i in indexes)]


def detector_result(values, detector):
    result = expand.detector_consensus_with_used(values, bars[detector]["bar"])
    return {
        "call": result.get("call"),
        "decision": result.get("decision"),
        "used_indices": result.get("used_indices", []),
        "problem_indices": result.get("problem_indices", []),
        "needs_repeat_indices": result.get("needs_repeat_indices", []),
    }


payload = json.loads(INPUT_PATH.read_text(encoding="utf-8"))
records = []
decision_changes = []
final_changes = []

for sheet in payload["sheets"]:
    sheet_name = sheet["sheetName"]
    for row_number, row in enumerate(sheet["values"][1:], start=2):
        status = str(row[2] or "").strip()
        current_final = row[4]
        current_pa = row[17]
        current_arae = row[24]
        pa_values = numeric_values(row, range(9, 17))
        arae_values = numeric_values(row, range(18, 24))
        has_numeric = any(value is not None for value in pa_values + arae_values)

        if status == "old metering system":
            record = {
                "sheet": sheet_name,
                "row": row_number,
                "primary": row[0],
                "status": status,
                "preserve": True,
                "PA447": None,
                "araE": None,
                "final": current_final,
            }
            records.append(record)
            continue

        if not has_numeric:
            final = "לא נבדק" if status == "לא נבדק" else "missing"
            pa_result = {"call": None, "decision": None, "used_indices": [], "problem_indices": [], "needs_repeat_indices": []}
            arae_result = {"call": None, "decision": None, "used_indices": [], "problem_indices": [], "needs_repeat_indices": []}
        else:
            pa_result = detector_result(pa_values, "PA447")
            arae_result = detector_result(arae_values, "araE")
            calls = [result["call"] for result in (pa_result, arae_result) if result["call"]]
            final = classifier.final_classification(calls) if calls else "missing"

        record = {
            "sheet": sheet_name,
            "row": row_number,
            "primary": row[0],
            "status": status,
            "preserve": False,
            "PA447": pa_result,
            "araE": arae_result,
            "final": final,
        }
        records.append(record)

        if current_pa != pa_result["decision"]:
            decision_changes.append({"sheet": sheet_name, "row": row_number, "sample": row[0], "detector": "PA447", "before": current_pa, "after": pa_result["decision"]})
        if current_arae != arae_result["decision"]:
            decision_changes.append({"sheet": sheet_name, "row": row_number, "sample": row[0], "detector": "araE", "before": current_arae, "after": arae_result["decision"]})
        if current_final != final:
            final_changes.append({"sheet": sheet_name, "row": row_number, "sample": row[0], "before": current_final, "after": final})

summary = {
    "training_rows": len(training),
    "training_sources": sources,
    "bars": {name: info["bar"] for name, info in bars.items()},
    "records": len(records),
    "preserved_old_metering_rows": sum(1 for record in records if record["preserve"]),
    "classification_counts": dict(Counter(str(record["final"]) for record in records)),
    "detector_decision_counts": {
        detector: dict(Counter(str(record[detector]["decision"]) for record in records if not record["preserve"]))
        for detector in ("PA447", "araE")
    },
    "problem_cells": sum(len(record[detector]["problem_indices"]) for record in records if not record["preserve"] for detector in ("PA447", "araE")),
    "needs_repeat_cells": sum(len(record[detector]["needs_repeat_indices"]) for record in records if not record["preserve"] for detector in ("PA447", "araE")),
    "decision_change_count": len(decision_changes),
    "final_change_count": len(final_changes),
    "decision_changes": decision_changes,
    "final_changes": final_changes,
}

OUTPUT_PATH.write_text(json.dumps({"summary": summary, "records": records}, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
