from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m")
INPUT = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
OUTPUT = ROOT / "outputs" / "latest_repeat_files_20260914" / "Final Known and Unknown merged.xlsx"
LEDGER = ROOT / "work" / "onedrive_tabs_fix" / "latest_repeat_update_ledger.json"

EXPECTED_SHEETS = ["Older samples - before 2021", "2021 onward"]
EXPECTED_OUTPUT_SHA256 = "71520CA29B69CB629254021864CE3586D8CA9177F02CB528991E7E6D58EE6D69"
EXPECTED_YELLOW_MEASUREMENTS = 118
EXPECTED_YELLOW_STATUSES = 35
EXPECTED_GREY_MEASUREMENTS = 62
EXPECTED_NOT_TESTED_ROWS = 17


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def same_value(left, right) -> bool:
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1e-12)
    return left == right


def rgb(color) -> str | None:
    if color is None:
        return None
    if color.type == "rgb" and color.rgb:
        return color.rgb[-6:].upper()
    return None


def fill_rgb(cell) -> str | None:
    if cell.fill.fill_type != "solid":
        return None
    return rgb(cell.fill.fgColor)


def font_rgb(cell) -> str | None:
    return rgb(cell.font.color)


def main() -> None:
    ledger = json.loads(LEDGER.read_text(encoding="utf-8"))
    assertions: list[str] = []

    input_hash = sha256(INPUT)
    output_hash = sha256(OUTPUT)
    assert input_hash == ledger["input_sha256"].upper(), (input_hash, ledger["input_sha256"])
    assert output_hash == EXPECTED_OUTPUT_SHA256, output_hash
    assertions.extend(["input hash matches ledger", "output hash matches successful build"])

    before = load_workbook(INPUT, data_only=False)
    after = load_workbook(OUTPUT, data_only=False)
    assert before.sheetnames == EXPECTED_SHEETS
    assert after.sheetnames == EXPECTED_SHEETS
    assertions.append("two required date sheets preserved")

    for sheet_name in EXPECTED_SHEETS:
        ws_before = before[sheet_name]
        ws_after = after[sheet_name]
        assert (ws_before.max_row, ws_before.max_column) == (ws_after.max_row, ws_after.max_column)
        assert ws_before.freeze_panes == ws_after.freeze_panes
        assert ws_before.auto_filter.ref == ws_after.auto_filter.ref
    assertions.append("sheet dimensions, freeze panes, and filters preserved")

    expected_after: dict[tuple[str, str], object] = {}
    for item in ledger["assignment_proofs"]:
        expected_after[(item["sheet"], item["target_cell"])] = item["value"]
    for item in ledger["source_updates"]:
        expected_after[(item["sheet"], f"Y{item['row']}")] = item["after"]
    detector_col = {"PA447": "P", "araE": "W"}
    for item in ledger["decision_changes"]:
        expected_after[(item["sheet"], f"{detector_col[item['detector']]}{item['row']}")] = item["after"]
    for item in ledger["final_changes"]:
        expected_after[(item["sheet"], f"E{item['row']}")] = item["after"]
    for item in ledger["status_changes"]:
        if item["before"] != item["after"]:
            expected_after[(item["sheet"], f"C{item['row']}")] = item["after"]

    actual_differences: dict[tuple[str, str], tuple[object, object]] = {}
    for sheet_name in EXPECTED_SHEETS:
        ws_before = before[sheet_name]
        ws_after = after[sheet_name]
        for row in range(1, ws_before.max_row + 1):
            for col in range(1, ws_before.max_column + 1):
                left = ws_before.cell(row, col).value
                right = ws_after.cell(row, col).value
                if not same_value(left, right):
                    key = (sheet_name, ws_after.cell(row, col).coordinate)
                    actual_differences[key] = (left, right)

    assert set(actual_differences) == set(expected_after), {
        "unexpected": sorted(set(actual_differences) - set(expected_after)),
        "missing": sorted(set(expected_after) - set(actual_differences)),
    }
    for key, expected in expected_after.items():
        assert same_value(actual_differences[key][1], expected), (key, actual_differences[key], expected)

    categories = Counter()
    measurement_cells = {(x["sheet"], x["target_cell"]) for x in ledger["assignment_proofs"]}
    source_cells = {(x["sheet"], f"Y{x['row']}") for x in ledger["source_updates"]}
    detector_cells = {
        (x["sheet"], f"{detector_col[x['detector']]}{x['row']}") for x in ledger["decision_changes"]
    }
    final_cells = {(x["sheet"], f"E{x['row']}") for x in ledger["final_changes"]}
    for key in actual_differences:
        if key in measurement_cells:
            categories["measurements"] += 1
        elif key in source_cells:
            categories["sources"] += 1
        elif key in detector_cells:
            categories["detector_decisions"] += 1
        elif key in final_cells:
            categories["final_decisions"] += 1
        else:
            categories["other"] += 1
    assert categories == Counter(
        measurements=24,
        sources=18,
        detector_decisions=21,
        final_decisions=16,
    ), categories
    assertions.append("all 79 value changes are exactly the planned additions and recalculations")

    yellow_measurements = 0
    grey_measurements = 0
    yellow_statuses = 0
    not_tested_rows = 0
    formula_count = 0
    formula_errors: list[tuple[str, str, object]] = []
    for sheet_name in EXPECTED_SHEETS:
        ws = after[sheet_name]
        for row in range(2, ws.max_row + 1):
            if ws[f"C{row}"].value == "לא נבדק":
                not_tested_rows += 1
            if fill_rgb(ws[f"C{row}"]) == "FFD966":
                yellow_statuses += 1
            for col in ["H", "I", "J", "K", "L", "M", "N", "O", "Q", "R", "S", "T", "U", "V"]:
                cell = ws[f"{col}{row}"]
                if fill_rgb(cell) == "FFD966":
                    yellow_measurements += 1
                if cell.value is not None and font_rgb(cell) == "A6A6A6":
                    grey_measurements += 1
        for row in ws.iter_rows():
            for cell in row:
                value = cell.value
                if isinstance(value, str) and value.startswith("="):
                    formula_count += 1
                if isinstance(value, str) and value in {
                    "#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NUM!", "#NULL!"
                }:
                    formula_errors.append((sheet_name, cell.coordinate, value))

    assert yellow_measurements == EXPECTED_YELLOW_MEASUREMENTS, yellow_measurements
    assert yellow_statuses == EXPECTED_YELLOW_STATUSES, yellow_statuses
    assert grey_measurements == EXPECTED_GREY_MEASUREMENTS, grey_measurements
    assert not_tested_rows == EXPECTED_NOT_TESTED_ROWS, not_tested_rows
    assert formula_count == 0, formula_count
    assert not formula_errors, formula_errors
    assertions.append("yellow repeats, yellow statuses, grey exclusions, and not-tested rows match expected counts")
    assertions.append("no formulas or formula-error values are present")

    ct606_matches = []
    for sheet_name in EXPECTED_SHEETS:
        ws = after[sheet_name]
        for row in range(2, ws.max_row + 1):
            if ws[f"A{row}"].value == "CT-606":
                cell = ws[f"A{row}"]
                ct606_matches.append(
                    {
                        "sheet": sheet_name,
                        "cell": cell.coordinate,
                        "name": cell.font.name,
                        "size": cell.font.sz,
                        "bold": bool(cell.font.bold),
                        "italic": bool(cell.font.italic),
                        "color": font_rgb(cell),
                    }
                )
    assert len(ct606_matches) == 1, ct606_matches
    assert ct606_matches[0]["name"] == "Calibri"
    assert math.isclose(float(ct606_matches[0]["size"]), 10.0)
    assert ct606_matches[0]["bold"] is False
    assert ct606_matches[0]["italic"] is False
    assert ct606_matches[0]["color"] in {None, "000000"}, ct606_matches
    assertions.append("CT-606 uses the standard Calibri 10 regular font")

    print(
        json.dumps(
            {
                "status": "PASS",
                "input_sha256": input_hash,
                "output_sha256": output_hash,
                "sheet_dimensions": {
                    name: [after[name].max_row, after[name].max_column] for name in EXPECTED_SHEETS
                },
                "value_change_categories": dict(categories),
                "yellow_measurements": yellow_measurements,
                "yellow_statuses": yellow_statuses,
                "grey_measurements": grey_measurements,
                "not_tested_rows": not_tested_rows,
                "ct606": ct606_matches[0],
                "assertions": assertions,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
