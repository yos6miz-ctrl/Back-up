import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const classifierPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const bounds = { "Older samples - before 2021": 190, "2021 onward": 158 };
const detectorLayout = {
  PA447: { columns: ["H", "I", "J", "K", "L", "M", "N", "O"], startIndex: 7 },
  araE: { columns: ["Q", "R", "S", "T", "U", "V"], startIndex: 16 },
};
const finalStyles = {
  IBD: { fill: "C00000", text: "FFFFFF", bold: true },
  IBS: { fill: "003399", text: "FFFFFF", bold: true },
  inconclusive: { fill: "D9D2E9", text: "4C3868", bold: true },
  missing: { fill: "E7E6E6", text: "666666", bold: true },
  "לא נבדק": { fill: "D9D2E9", text: "4C3868", bold: true },
};

const classifier = JSON.parse(await fs.readFile(classifierPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));
const valuesBySheet = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  valuesBySheet[sheetName] = workbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
}

function mappedRow(record) {
  if (record.sheet !== "2021 onward") return record.row;
  if (record.primary === "F-NY-21358" || record.row === 20) return null;
  return record.row > 20 ? record.row - 1 : record.row;
}
function measurementCall(value, bar) {
  if (value > bar * 1.05) return "IBD-like";
  if (value < bar * 0.95) return "IBS-like";
  return "inconclusive";
}
function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}
function compactStyle(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
    horizontalAlignment: style?.horizontalAlignment ?? null,
  };
}

const conflictKeys = new Set();
const conflictRepeatKeys = new Set();
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const values = valuesBySheet[record.sheet][row - 1];
  const anyPositive = record.PA447?.decision === "Pos" || record.araE?.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    const entries = layout.columns.flatMap((column, index) => {
      const value = values[layout.startIndex + index];
      return typeof value === "number" && Number.isFinite(value)
        ? [{ column, call: measurementCall(value, classifier.summary.bars[detector]) }]
        : [];
    });
    const calls = new Set(entries.map((entry) => entry.call));
    if (entries.length !== 2 || !calls.has("IBD-like") || !calls.has("IBS-like")) continue;
    for (const entry of entries) {
      const key = `${record.sheet}!${entry.column}${row}`;
      conflictKeys.add(key);
      if (!anyPositive) conflictRepeatKeys.add(key);
    }
  }
}

const problemKeys = new Set();
const repeatKeys = new Set();
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const anyPositive = record.PA447?.decision === "Pos" || record.araE?.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    for (const index of record[detector]?.problem_indices ?? []) {
      const key = `${record.sheet}!${layout.columns[index]}${row}`;
      if (!conflictKeys.has(key)) problemKeys.add(key);
    }
    if (!anyPositive) {
      for (const index of record[detector]?.needs_repeat_indices ?? []) {
        repeatKeys.add(`${record.sheet}!${layout.columns[index]}${row}`);
      }
    }
  }
}
for (const key of conflictRepeatKeys) repeatKeys.add(key);

const mismatches = [];
let numericMeasurementCells = 0;
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const values = valuesBySheet[record.sheet][row - 1];
  for (const layout of Object.values(detectorLayout)) {
    for (let index = 0; index < layout.columns.length; index += 1) {
      const value = values[layout.startIndex + index];
      if (typeof value !== "number" || !Number.isFinite(value)) continue;
      numericMeasurementCells += 1;
      const cell = `${layout.columns[index]}${row}`;
      const key = `${record.sheet}!${cell}`;
      const expected = repeatKeys.has(key)
        ? { fill: "FFD966", text: "000000", bold: false }
        : problemKeys.has(key)
          ? { fill: "FFFFFF", text: "A6A6A6", bold: false }
          : { fill: "FFFFFF", text: "000000", bold: false };
      const inspected = await workbook.inspect({ kind: "computedStyle", sheetId: record.sheet, range: cell, maxChars: 2500 });
      const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
      if (actual.fill !== expected.fill || actual.text !== expected.text || actual.bold !== expected.bold) {
        mismatches.push({ sheet: record.sheet, cell, sample: record.primary, actual, expected });
      }
    }
  }
}

const finalDecisionMismatches = [];
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const values = valuesBySheet[sheetName];
  for (let row = 2; row <= lastRow; row += 1) {
    const value = values[row - 1][4];
    if (value == null || value === "") continue;
    const cell = `E${row}`;
    const inspected = await workbook.inspect({ kind: "computedStyle", sheetId: sheetName, range: cell, maxChars: 2500 });
    const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
    if (value === "IBD*" || value === "IBS*") {
      if (!([null, "FFFFFF"].includes(actual.fill)) || actual.text !== "000000" || actual.bold) {
        finalDecisionMismatches.push({ sheet: sheetName, cell, value, actual });
      }
    } else {
      const expected = finalStyles[value];
      if (!expected || actual.fill !== expected.fill || actual.text !== expected.text || actual.bold !== expected.bold) {
        finalDecisionMismatches.push({ sheet: sheetName, cell, value, actual, expected });
      }
    }
  }
}

console.log(JSON.stringify({
  workbookPath,
  numericMeasurementCells,
  problemGreyTextCells: problemKeys.size,
  repeatYellowCells: repeatKeys.size,
  measurementStyleMismatchCount: mismatches.length,
  measurementStyleMismatches: mismatches.slice(0, 12),
  finalDecisionStyleMismatchCount: finalDecisionMismatches.length,
  finalDecisionStyleMismatches: finalDecisionMismatches.slice(0, 12),
}, null, 2));
