from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import sys

LEGACY = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
REPEATS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats")


def load(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sys.path.insert(0, str(LEGACY))
audit = load("raw_validation_audit", LEGACY / "audit_final_measurements_without_source.py")
trace = load("raw_validation_trace", LEGACY / "extract_raw_trace_2026_measurements.py")

results = []
for name in [
    "20260831 447 sample repeats.xlsx",
    "20260831 araE sample repeats.xlsx",
    "20260901 araE sample repeats.xlsx",
    "20260902 447 sample repeats.xlsx",
]:
    path = REPEATS / name
    formula = audit.extract_formula_records(path)
    raw = trace.extract_file(path)
    formula_by_key = {(x["detector"], audit.norm(x["sample"])): float(x["value"]) for x in formula}
    raw_by_key = {(x["detector"], audit.norm(x["sample_name"])): float(x["value"]) for x in raw}
    keys = sorted(set(formula_by_key) | set(raw_by_key))
    comparisons = []
    for key in keys:
        f = formula_by_key.get(key)
        r = raw_by_key.get(key)
        comparisons.append({"key": key, "formula": f, "raw_trace": r, "difference": None if f is None or r is None else abs(f-r)})
    results.append({"file": name, "formula_count": len(formula_by_key), "raw_count": len(raw_by_key), "comparisons": comparisons})

print(json.dumps(results, ensure_ascii=False, indent=2))
