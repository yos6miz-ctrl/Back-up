import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const ledgerPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/selected_repeat_update_ledger.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/new_repeat_files_20260903";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/new_repeat_files_after";
const bounds = { "Older samples - before 2021": 190, "2021 onward": 158 };
const detectorLayout = {
  PA447: { columns: ["H", "I", "J", "K", "L", "M", "N", "O"], startIndex: 7, decisionColumn: "P" },
  araE: { columns: ["Q", "R", "S", "T", "U", "V"], startIndex: 16, decisionColumn: "W" },
};
const FINAL_STYLES = {
  IBD: { fill: "#C00000", text: "#FFFFFF", bold: true },
  IBS: { fill: "#003399", text: "#FFFFFF", bold: true },
  inconclusive: { fill: "#D9D2E9", text: "#4C3868", bold: true },
  missing: { fill: "#E7E6E6", text: "#666666", bold: true },
  "לא נבדק": { fill: "#D9D2E9", text: "#4C3868", bold: true },
};
const WHITE = "#FFFFFF";
const BLACK = "#000000";
const GREY = "#A6A6A6";
const YELLOW = "#FFD966";

async function sha256(filePath) {
  const bytes = await fs.readFile(filePath);
  return createHash("sha256").update(bytes).digest("hex").toUpperCase();
}
function columnIndex(column) {
  let result = 0;
  for (const char of column) result = (result * 26) + char.charCodeAt(0) - 64;
  return result - 1;
}
function measurementCall(value, bar) {
  if (value > bar * 1.05) return "IBD-like";
  if (value < bar * 0.95) return "IBS-like";
  return "inconclusive";
}
function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}
function compactStyle(style) {
  return {
    fill: style?.fill?.color?.value ?? null,
    text: style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null,
    bold: style?.font?.bold ?? false,
    horizontalAlignment: style?.horizontalAlignment ?? null,
  };
}

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const ledger = JSON.parse(await fs.readFile(ledgerPath, "utf8"));
if (await sha256(sourcePath) !== ledger.input_sha256) throw new Error("The live final workbook changed after the repeat-file analysis.");
for (const file of ledger.selected_files) {
  if (await sha256(file.path) !== file.sha256) throw new Error(`Raw repeat file changed after analysis: ${file.path}`);
}

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const beforeValues = {};
const expectedValues = {};
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  beforeValues[sheetName] = sheet.getRange(`A1:AA${lastRow}`).values;
  expectedValues[sheetName] = beforeValues[sheetName].map((row) => [...row]);
  const headers = beforeValues[sheetName][0];
  if (headers[15] !== "PA447 decision" || headers[22] !== "araE decision" || headers[24] !== "Measurement/source file") {
    throw new Error(`Unexpected column layout on ${sheetName}`);
  }
}

for (const item of ledger.assignment_proofs) {
  const sheet = workbook.worksheets.getItem(item.sheet);
  const currentPrimary = beforeValues[item.sheet][item.row - 1][0];
  if (String(currentPrimary ?? "").trim() !== String(item.primary ?? "").trim()) {
    throw new Error(`Target row no longer matches ${item.primary}: ${item.sheet}!${item.row}`);
  }
  const colIndex = columnIndex(item.target_cell.match(/^[A-Z]+/)[0]);
  const currentValue = beforeValues[item.sheet][item.row - 1][colIndex];
  if (typeof currentValue === "number" && Number.isFinite(currentValue)) {
    throw new Error(`Target measurement cell is no longer empty: ${item.sheet}!${item.target_cell}`);
  }
  sheet.getRange(item.target_cell).values = [[item.value]];
  expectedValues[item.sheet][item.row - 1][colIndex] = item.value;
}

for (const update of ledger.source_updates) {
  workbook.worksheets.getItem(update.sheet).getRange(`Y${update.row}`).values = [[update.after]];
  expectedValues[update.sheet][update.row - 1][24] = update.after;
}

for (const record of ledger.records) {
  if (record.preserve) continue;
  const sheet = workbook.worksheets.getItem(record.sheet);
  sheet.getRange(`P${record.row}`).values = [[record.PA447.decision]];
  sheet.getRange(`W${record.row}`).values = [[record.araE.decision]];
  sheet.getRange(`E${record.row}`).values = [[record.final]];
  expectedValues[record.sheet][record.row - 1][15] = record.PA447.decision;
  expectedValues[record.sheet][record.row - 1][22] = record.araE.decision;
  expectedValues[record.sheet][record.row - 1][4] = record.final;
}

for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  for (const address of [`H2:O${lastRow}`, `Q2:V${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = WHITE;
    range.format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

const conflictKeys = new Set();
const conflictRepeatKeys = new Set();
for (const record of ledger.records) {
  if (record.preserve) continue;
  const values = expectedValues[record.sheet][record.row - 1];
  const anyPositive = record.PA447.decision === "Pos" || record.araE.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    const entries = layout.columns.flatMap((column, index) => {
      const value = values[layout.startIndex + index];
      return typeof value === "number" && Number.isFinite(value)
        ? [{ column, value, call: measurementCall(value, ledger.bars[detector]) }]
        : [];
    });
    const calls = new Set(entries.map((entry) => entry.call));
    if (entries.length !== 2 || !calls.has("IBD-like") || !calls.has("IBS-like")) continue;
    for (const entry of entries) {
      const key = `${record.sheet}!${entry.column}${record.row}`;
      conflictKeys.add(key);
      if (!anyPositive) conflictRepeatKeys.add(key);
    }
  }
}

const problemCells = new Map();
const repeatCells = new Map();
const suppressedCells = new Map();
for (const record of ledger.records) {
  if (record.preserve) continue;
  const anyPositive = record.PA447.decision === "Pos" || record.araE.decision === "Pos";
  for (const [detector, layout] of Object.entries(detectorLayout)) {
    for (const index of record[detector].problem_indices ?? []) {
      const cell = `${layout.columns[index]}${record.row}`;
      const key = `${record.sheet}!${cell}`;
      if (!conflictKeys.has(key)) problemCells.set(key, { sheet: record.sheet, cell, detector, sample: record.primary });
    }
    for (const index of record[detector].needs_repeat_indices ?? []) {
      const cell = `${layout.columns[index]}${record.row}`;
      const key = `${record.sheet}!${cell}`;
      const item = { sheet: record.sheet, cell, detector, sample: record.primary };
      if (anyPositive) suppressedCells.set(key, item);
      else repeatCells.set(key, item);
    }
  }
}
for (const key of conflictKeys) {
  const [sheetName, cell] = key.split("!");
  const item = { sheet: sheetName, cell, detector: null, sample: null };
  problemCells.delete(key);
  if (conflictRepeatKeys.has(key)) repeatCells.set(key, item);
  else suppressedCells.set(key, item);
}

for (const item of problemCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = WHITE;
  cell.format.font = { name: "Calibri", size: 10, color: GREY, bold: false };
}
for (const item of repeatCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = YELLOW;
  cell.format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
}

for (const record of ledger.records) {
  const sheet = workbook.worksheets.getItem(record.sheet);
  if (record.preserve) continue;
  for (const detector of ["PA447", "araE"]) {
    const cell = sheet.getRange(`${detectorLayout[detector].decisionColumn}${record.row}`);
    cell.format.fill = WHITE;
    cell.format.font = { name: "Calibri", size: 10, color: BLACK, bold: false };
    cell.format.horizontalAlignment = "center";
  }
  const style = FINAL_STYLES[record.final];
  if (!style) throw new Error(`Unsupported final decision: ${record.final}`);
  const finalCell = sheet.getRange(`E${record.row}`);
  finalCell.format.fill = style.fill;
  finalCell.format.font = { name: "Calibri", size: 10, color: style.text, bold: style.bold };
  finalCell.format.horizontalAlignment = "center";
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  return value === "" ? null : value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}

const valueMismatches = [];
let beforeMeasurementCount = 0;
let afterMeasurementCount = 0;
for (const [sheetName, lastRow] of Object.entries(bounds)) {
  const actual = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const expected = expectedValues[sheetName];
  for (let row = 0; row < expected.length; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actual[row][col], expected[row][col])) {
        valueMismatches.push({ sheet: sheetName, row: row + 1, col: col + 1, actual: normalized(actual[row][col]), expected: normalized(expected[row][col]) });
      }
    }
    if (row > 0) {
      for (const layout of Object.values(detectorLayout)) {
        for (let index = 0; index < layout.columns.length; index += 1) {
          if (typeof beforeValues[sheetName][row][layout.startIndex + index] === "number") beforeMeasurementCount += 1;
          if (typeof actual[row][layout.startIndex + index] === "number") afterMeasurementCount += 1;
        }
      }
    }
  }
}
if (valueMismatches.length) throw new Error(`Workbook value verification failed: ${JSON.stringify(valueMismatches.slice(0, 12))}`);
if (afterMeasurementCount - beforeMeasurementCount !== ledger.measurements_added) {
  throw new Error(`Measurement count changed by ${afterMeasurementCount - beforeMeasurementCount}, expected ${ledger.measurements_added}`);
}

const assignmentFailures = [];
const citationFailures = [];
for (const item of ledger.assignment_proofs) {
  const sheet = finalWorkbook.worksheets.getItem(item.sheet);
  const actualValue = sheet.getRange(item.target_cell).values[0][0];
  if (!equal(actualValue, item.value)) assignmentFailures.push({ ...item, actualValue });
  const sourceText = String(sheet.getRange(`Y${item.row}`).values[0][0] ?? "");
  if (!sourceText.includes(item.source_file)) citationFailures.push({ ...item, sourceText });
}
if (assignmentFailures.length) throw new Error(`Measurement assignment verification failed: ${JSON.stringify(assignmentFailures)}`);
if (citationFailures.length) throw new Error(`Source citation verification failed: ${JSON.stringify(citationFailures)}`);

const styleMismatches = [];
for (const record of ledger.records) {
  if (record.preserve) continue;
  const values = expectedValues[record.sheet][record.row - 1];
  for (const layout of Object.values(detectorLayout)) {
    for (let index = 0; index < layout.columns.length; index += 1) {
      const value = values[layout.startIndex + index];
      if (typeof value !== "number" || !Number.isFinite(value)) continue;
      const cell = `${layout.columns[index]}${record.row}`;
      const key = `${record.sheet}!${cell}`;
      const expected = repeatCells.has(key)
        ? { fill: "FFD966", text: "000000", bold: false }
        : problemCells.has(key)
          ? { fill: "FFFFFF", text: "A6A6A6", bold: false }
          : { fill: "FFFFFF", text: "000000", bold: false };
      const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: record.sheet, range: cell, maxChars: 2500 });
      const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
      if (actual.fill !== expected.fill || actual.text !== expected.text || actual.bold !== expected.bold) {
        styleMismatches.push({ kind: "measurement", sheet: record.sheet, cell, actual, expected });
      }
    }
  }
  for (const detector of ["PA447", "araE"]) {
    if (record[detector].decision == null) continue;
    const cell = `${detectorLayout[detector].decisionColumn}${record.row}`;
    const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: record.sheet, range: cell, maxChars: 2500 });
    const actual = compactStyle(firstStyleRecord(inspected.ndjson)?.style);
    if (actual.fill !== "FFFFFF" || actual.text !== "000000" || actual.bold || actual.horizontalAlignment !== "center") {
      styleMismatches.push({ kind: "detector-decision", sheet: record.sheet, cell, actual });
    }
  }
  const expectedStyle = FINAL_STYLES[record.final];
  const finalInspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: record.sheet, range: `E${record.row}`, maxChars: 2500 });
  const finalActual = compactStyle(firstStyleRecord(finalInspected.ndjson)?.style);
  if (finalActual.fill !== expectedStyle.fill.slice(1) || finalActual.text !== expectedStyle.text.slice(1) || finalActual.bold !== expectedStyle.bold) {
    styleMismatches.push({ kind: "final-decision", sheet: record.sheet, cell: `E${record.row}`, actual: finalActual, expected: expectedStyle });
  }
}
if (styleMismatches.length) throw new Error(`Style verification failed: ${JSON.stringify(styleMismatches.slice(0, 12))}`);

const formulaErrors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-new-repeat-file formula error scan",
  maxChars: 5000,
});
const keyRanges = [];
for (const [sheetName, range, name] of [
  ["Older samples - before 2021", "A1:Y12", "older_top_updated.png"],
  ["Older samples - before 2021", "A31:Y42", "older_conflicts_resolved.png"],
  ["2021 onward", "A21:Y26", "onward_ct1156_updated.png"],
]) {
  const table = await finalWorkbook.inspect({ kind: "table", sheetId: sheetName, range, include: "values,formulas", tableMaxRows: 15, tableMaxCols: 25, maxChars: 12000 });
  keyRanges.push({ sheetName, range, table: table.ndjson });
  const image = await finalWorkbook.render({ sheetName, range, scale: 1.6, format: "png" });
  await fs.writeFile(path.join(previewDir, name), new Uint8Array(await image.arrayBuffer()));
}

console.log(JSON.stringify({
  outputPath,
  measurementsAdded: afterMeasurementCount - beforeMeasurementCount,
  affectedRows: ledger.affected_rows,
  detectorDecisionChanges: ledger.decision_changes,
  finalDecisionChanges: ledger.final_changes,
  problemGreyTextCells: problemCells.size,
  repeatYellowCells: repeatCells.size,
  suppressedRepeatCells: suppressedCells.size,
  assignmentFailureCount: assignmentFailures.length,
  citationFailureCount: citationFailures.length,
  valueMismatchCount: valueMismatches.length,
  styleMismatchCount: styleMismatches.length,
  formulaErrors: formulaErrors.ndjson,
  keyRanges,
}, null, 2));
