import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const classifierPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/classifier_decisions.json";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/final_layout_warning_update_20260903";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/final_layout_warning_after";
const sampleName = "F-NY-21358";
const GREY_TEXT = "#A6A6A6";
const NORMAL_TEXT = "#000000";
const REPEAT_YELLOW = "#FFD966";

const boundsBefore = {
  "Older samples - before 2021": 190,
  "2021 onward": 159,
};
const boundsAfter = {
  "Older samples - before 2021": 190,
  "2021 onward": 158,
};
const oldMeasurementColumns = {
  PA447: ["J", "K", "L", "M", "N", "O", "P", "Q"],
  araE: ["S", "T", "U", "V", "W", "X"],
};
const newMeasurementColumns = {
  PA447: ["H", "I", "J", "K", "L", "M", "N", "O"],
  araE: ["Q", "R", "S", "T", "U", "V"],
};

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const classifier = JSON.parse(await fs.readFile(classifierPath, "utf8"));
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(sourcePath));
const beforeValues = {};
for (const [sheetName, lastRow] of Object.entries(boundsBefore)) {
  beforeValues[sheetName] = workbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
}

const onwardBefore = beforeValues["2021 onward"];
const matchingRows = [];
for (let rowIndex = 1; rowIndex < onwardBefore.length; rowIndex += 1) {
  if (String(onwardBefore[rowIndex][0] ?? "").trim().toUpperCase() === sampleName) matchingRows.push(rowIndex + 1);
}
if (matchingRows.length !== 1 || matchingRows[0] !== 20) {
  throw new Error(`Expected exactly one ${sampleName} row at row 20; found ${JSON.stringify(matchingRows)}`);
}

for (const record of classifier.records) {
  const row = beforeValues[record.sheet]?.[record.row - 1];
  if (!row || String(row[0] ?? "").trim() !== String(record.primary ?? "").trim()) {
    throw new Error(`Classifier ledger no longer aligns at ${record.sheet}!${record.row}: workbook=${row?.[0]} ledger=${record.primary}`);
  }
}

// Remove the unsupported sample by shifting every following row upward, including its formatting.
const onward = workbook.worksheets.getItem("2021 onward");
onward.getRange("A20:AA158").copyFrom(onward.getRange("A21:AA159"), "all");
onward.getRange("A159:AA159").clear({ applyTo: "all" });

// Move Longitudinal sample (old H) and Patient unique code (old I) to the far right.
// Temporary columns prevent overlap while moving old J:AA into new H:Y.
for (const [sheetName, lastRow] of Object.entries(boundsAfter)) {
  const sheet = workbook.worksheets.getItem(sheetName);
  sheet.getRange(`AB1:AB${lastRow}`).copyFrom(sheet.getRange(`H1:H${lastRow}`), "all");
  sheet.getRange(`AC1:AC${lastRow}`).copyFrom(sheet.getRange(`I1:I${lastRow}`), "all");
  sheet.getRange(`AD1:AU${lastRow}`).copyFrom(sheet.getRange(`J1:AA${lastRow}`), "all");
  sheet.getRange(`H1:Y${lastRow}`).copyFrom(sheet.getRange(`AD1:AU${lastRow}`), "all");
  sheet.getRange(`Z1:Z${lastRow}`).copyFrom(sheet.getRange(`AC1:AC${lastRow}`), "all");
  sheet.getRange(`AA1:AA${lastRow}`).copyFrom(sheet.getRange(`AB1:AB${lastRow}`), "all");
  sheet.getRange(`AB1:AU${lastRow}`).clear({ applyTo: "all" });

  sheet.getRange(`H1:O${lastRow}`).format.columnWidth = 13;
  sheet.getRange(`P1:P${lastRow}`).format.columnWidth = 12;
  sheet.getRange(`Q1:V${lastRow}`).format.columnWidth = 13;
  sheet.getRange(`W1:W${lastRow}`).format.columnWidth = 12;
  sheet.getRange(`X1:X${lastRow}`).format.columnWidth = 13;
  sheet.getRange(`Y1:Y${lastRow}`).format.columnWidth = 58;
  sheet.getRange(`Z1:Z${lastRow}`).format.columnWidth = 18;
  sheet.getRange(`AA1:AA${lastRow}`).format.columnWidth = 14;
  sheet.getRange(`X2:X${lastRow}`).format.numberFormat = "yyyy-mm-dd";
  sheet.getRange(`X2:X${lastRow}`).format.horizontalAlignment = "center";
  sheet.getRange(`Z2:Z${lastRow}`).format.numberFormat = "0";
  sheet.getRange(`Z2:Z${lastRow}`).format.horizontalAlignment = "center";
  sheet.getRange(`AA2:AA${lastRow}`).format.numberFormat = "0";
  sheet.getRange(`AA2:AA${lastRow}`).format.horizontalAlignment = "center";

  // Reset measurement formatting before applying the two user-visible states.
  for (const address of [`H2:O${lastRow}`, `Q2:V${lastRow}`]) {
    const range = sheet.getRange(address);
    range.format.fill = "#FFFFFF";
    range.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
    range.format.numberFormat = "0.000";
    range.format.horizontalAlignment = "center";
  }
}

function mappedRow(record) {
  if (record.sheet !== "2021 onward") return record.row;
  if (record.row === 20) return null;
  return record.row > 20 ? record.row - 1 : record.row;
}

const problemCells = new Map();
const repeatCells = new Map();
let suppressedRepeatCount = 0;
for (const record of classifier.records) {
  const row = mappedRow(record);
  if (row == null || record.preserve) continue;
  const suppressRepeats = record.araE?.decision === "Pos";
  for (const detector of ["PA447", "araE"]) {
    for (const index of record[detector]?.problem_indices ?? []) {
      const cell = `${newMeasurementColumns[detector][index]}${row}`;
      problemCells.set(`${record.sheet}!${cell}`, { sheet: record.sheet, cell, detector, sample: record.primary });
    }
    for (const index of record[detector]?.needs_repeat_indices ?? []) {
      if (suppressRepeats) {
        suppressedRepeatCount += 1;
        continue;
      }
      const cell = `${newMeasurementColumns[detector][index]}${row}`;
      repeatCells.set(`${record.sheet}!${cell}`, { sheet: record.sheet, cell, detector, sample: record.primary });
    }
  }
}

const overlaps = [...problemCells.keys()].filter((key) => repeatCells.has(key));
if (overlaps.length) throw new Error(`Overlapping warning states: ${overlaps.join(", ")}`);

for (const item of problemCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = "#FFFFFF";
  cell.format.font = { name: "Calibri", size: 10, color: GREY_TEXT, bold: false };
}
for (const item of repeatCells.values()) {
  const cell = workbook.worksheets.getItem(item.sheet).getRange(item.cell);
  cell.format.fill = REPEAT_YELLOW;
  cell.format.font = { name: "Calibri", size: 10, color: NORMAL_TEXT, bold: false };
}

const exported = await SpreadsheetFile.exportXlsx(workbook);
await exported.save(outputPath);

const finalWorkbook = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
function normalized(value) {
  if (value instanceof Date) return value.toISOString();
  return value === "" ? null : value;
}
function equal(left, right) {
  const a = normalized(left);
  const b = normalized(right);
  if (a == null && b == null) return true;
  if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) <= 1e-10;
  return a === b;
}
function reordered(row) {
  return [...row.slice(0, 7), ...row.slice(9, 27), row[8], row[7]];
}

const mismatches = [];
const finalValues = {};
for (const [sheetName, lastRow] of Object.entries(boundsAfter)) {
  finalValues[sheetName] = finalWorkbook.worksheets.getItem(sheetName).getRange(`A1:AA${lastRow}`).values;
  const expectedRows = sheetName === "2021 onward"
    ? beforeValues[sheetName].filter((_row, index) => index !== 19).map(reordered)
    : beforeValues[sheetName].map(reordered);
  const actualRows = finalValues[sheetName];
  if (actualRows.length !== expectedRows.length) mismatches.push({ sheet: sheetName, kind: "row-count", actual: actualRows.length, expected: expectedRows.length });
  const rows = Math.min(actualRows.length, expectedRows.length);
  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < 27; col += 1) {
      if (!equal(actualRows[row][col], expectedRows[row][col])) {
        mismatches.push({ sheet: sheetName, row: row + 1, col: col + 1, actual: normalized(actualRows[row][col]), expected: normalized(expectedRows[row][col]) });
      }
    }
  }
}
if (mismatches.length) throw new Error(`Post-edit data mismatch: ${JSON.stringify(mismatches.slice(0, 12))}`);

const headersBySheet = {};
for (const [sheetName, values] of Object.entries(finalValues)) {
  headersBySheet[sheetName] = values[0];
  if (values[0][25] !== "Patient unique code" || values[0][26] !== "Longitudinal sample") {
    throw new Error(`Trailing header order mismatch on ${sheetName}: ${JSON.stringify(values[0])}`);
  }
}

const residualMatches = [];
for (const [sheetName, values] of Object.entries(finalValues)) {
  values.slice(1).forEach((row, index) => {
    if (String(row[0] ?? "").trim().toUpperCase() === sampleName) residualMatches.push(`${sheetName}!A${index + 2}`);
  });
}
if (residualMatches.length) throw new Error(`${sampleName} remains at ${residualMatches.join(", ")}`);

function firstStyleRecord(ndjson) {
  const line = ndjson.split(/\r?\n/).find(Boolean);
  return line ? JSON.parse(line) : null;
}
const styleMismatches = [];
for (const [items, expectedFill, expectedText, label] of [
  [problemCells.values(), "FFFFFF", GREY_TEXT.slice(1), "excluded"],
  [repeatCells.values(), REPEAT_YELLOW.slice(1), NORMAL_TEXT.slice(1), "repeat"],
]) {
  for (const item of items) {
    const inspected = await finalWorkbook.inspect({ kind: "computedStyle", sheetId: item.sheet, range: item.cell, maxChars: 2500 });
    const style = firstStyleRecord(inspected.ndjson)?.style;
    const fill = style?.fill?.color?.value ?? null;
    const color = style?.font?.color?.value ?? style?.font?.fill?.color?.value ?? null;
    if (fill !== expectedFill || color !== expectedText || style?.font?.bold === true) {
      styleMismatches.push({ label, ...item, actualFill: fill, actualText: color, bold: style?.font?.bold ?? false });
    }
  }
}
if (styleMismatches.length) throw new Error(`Warning style mismatch: ${JSON.stringify(styleMismatches.slice(0, 12))}`);

const formulaErrors = await finalWorkbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "post-edit formula error scan",
  maxChars: 5000,
});
const keyRange = await finalWorkbook.inspect({
  kind: "table",
  sheetId: "2021 onward",
  range: "A15:AA24",
  include: "values,formulas",
  tableMaxRows: 11,
  tableMaxCols: 27,
  maxChars: 12000,
});

for (const [sheetName, range, fileName] of [
  ["Older samples - before 2021", "A1:AA20", "older_top.png"],
  ["Older samples - before 2021", "A65:AA82", "older_warning_examples.png"],
  ["2021 onward", "A15:AA24", "onward_removed_row.png"],
  ["2021 onward", "A95:AA125", "onward_warning_examples.png"],
  ["2021 onward", "A148:AA158", "onward_end.png"],
]) {
  const image = await finalWorkbook.render({ sheetName, range, scale: 1.6, format: "png" });
  await fs.writeFile(path.join(previewDir, fileName), new Uint8Array(await image.arrayBuffer()));
}

const measurementIndexes = [...Array(8).keys()].map((i) => i + 7).concat([...Array(6).keys()].map((i) => i + 16));
const measurementRows = Object.values(finalValues).flatMap((values) => values.slice(1));
const measurementCount = measurementRows.reduce(
  (total, row) => total + measurementIndexes.filter((index) => typeof row[index] === "number" && Number.isFinite(row[index])).length,
  0,
);

console.log(JSON.stringify({
  outputPath,
  removedSample: sampleName,
  residualMatchCount: residualMatches.length,
  valueMismatchCount: mismatches.length,
  headersBySheet,
  problemGreyTextCells: problemCells.size,
  repeatYellowCells: repeatCells.size,
  suppressedRepeatCellsDueToPositiveAraE: suppressedRepeatCount,
  styleMismatchCount: styleMismatches.length,
  measurementCount,
  formulaErrors: formulaErrors.ndjson,
  keyRange: keyRange.ndjson,
}, null, 2));
