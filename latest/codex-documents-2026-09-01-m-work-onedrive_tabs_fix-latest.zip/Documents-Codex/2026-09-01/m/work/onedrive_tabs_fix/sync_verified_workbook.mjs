import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_additions_20260902/Final Known and Unknown - additional raw measurements.xlsx";
const outputDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/onedrive_synced_20260902";
const outputPath = path.join(outputDir, "Final Known and Unknown merged.xlsx");
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/final_previews";

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const input = await FileBlob.load(sourcePath);
const workbook = await SpreadsheetFile.importXlsx(input);

const overview = await workbook.inspect({
  kind: "workbook,sheet,table",
  include: "id,name,values,formulas",
  maxChars: 12000,
  tableMaxRows: 5,
  tableMaxCols: 8,
  tableMaxCellChars: 100,
});
console.log("PRE-EXPORT OVERVIEW");
console.log(overview.ndjson);

const errorScan = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
  maxChars: 6000,
});
console.log("PRE-EXPORT ERROR SCAN");
console.log(errorScan.ndjson);

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

const finalInput = await FileBlob.load(outputPath);
const finalWorkbook = await SpreadsheetFile.importXlsx(finalInput);
const finalOverview = await finalWorkbook.inspect({
  kind: "workbook,sheet,table",
  include: "id,name,values,formulas",
  maxChars: 12000,
  tableMaxRows: 5,
  tableMaxCols: 8,
  tableMaxCellChars: 100,
});
console.log("POST-EXPORT OVERVIEW");
console.log(finalOverview.ndjson);

for (const sheetName of ["Older samples - before 2021", "2021 onward"]) {
  const preview = await finalWorkbook.render({ sheetName, range: "A1:H15", scale: 1.25, format: "png" });
  await fs.writeFile(
    path.join(previewDir, `${sheetName.replace(/[^a-z0-9]+/gi, "_")}.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}

console.log(`OUTPUT_PATH=${outputPath}`);
