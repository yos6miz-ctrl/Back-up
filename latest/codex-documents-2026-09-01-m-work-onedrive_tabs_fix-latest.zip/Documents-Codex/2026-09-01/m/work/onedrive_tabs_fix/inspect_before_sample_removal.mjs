import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const previewPath = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/before_remove_fny21358.png";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));
const sheet = workbook.worksheets.getItem("2021 onward");
const values = sheet.getRange("A1:AA159").values;
const matches = [];
for (let index = 1; index < values.length; index += 1) {
  if (String(values[index][0] ?? "").trim().toUpperCase() === "F-NY-21358") {
    matches.push({ row: index + 1, values: values[index] });
  }
}
const region = await workbook.inspect({
  kind: "table",
  sheetId: "2021 onward",
  range: "A15:AA25",
  include: "values,formulas",
  tableMaxRows: 12,
  tableMaxCols: 27,
  maxChars: 12000,
});
const preview = await workbook.render({ sheetName: "2021 onward", range: "A15:AA25", scale: 1.6, format: "png" });
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
const deleteHelp = workbook.help("range.delete", { include: "index,examples,notes", maxChars: 5000 });
console.log(JSON.stringify({ matches, region: region.ndjson, deleteHelp: deleteHelp.ndjson, previewPath }, null, 2));
