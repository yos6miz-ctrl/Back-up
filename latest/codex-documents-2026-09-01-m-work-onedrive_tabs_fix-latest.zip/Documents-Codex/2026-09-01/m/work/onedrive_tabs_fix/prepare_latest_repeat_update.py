from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import re
import sys

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


WORK = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-09-01\m\work\onedrive_tabs_fix")
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
ALIQUOTS = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\aliqauts 20260801.xlsx")
ANALYSIS = WORK / "latest_raw_trace_addition_analysis.json"
OUTPUT = WORK / "latest_repeat_update_ledger.json"
LEGACY_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXPAND_PATH = LEGACY_DIR / "expand_measurement_columns_and_show_all.py"
SHEET_BOUNDS = {"Older samples - before 2021": 190, "2021 onward": 158}
DETECTOR_COLUMNS = {"PA447": list(range(8, 16)), "araE": list(range(17, 23))}
DECISION_COLUMNS = {"PA447": 16, "araE": 23}
FINAL_COLUMN = 5
SOURCE_COLUMN = 25


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def hash_file(path):
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def clean(value):
    return "" if value is None else str(value).strip()


def norm(value):
    return re.sub(r"[^A-Z0-9]", "", clean(value).upper())


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def source_parts(value):
    text = str(value or "")
    result = {"PA447": [], "araE": []}
    for detector in result:
        match = re.search(rf"{detector}:\s*(.*?)(?=;\s*(?:PA447|araE):|$)", text, flags=re.I)
        if match:
            result[detector] = [part.strip() for part in match.group(1).split(",") if part.strip()]
    return result


def append_source(value, additions):
    parts = source_parts(value)
    for detector in ("PA447", "araE"):
        for file_name in additions.get(detector, []):
            if file_name not in parts[detector]:
                parts[detector].append(file_name)
    return "; ".join(
        f"{detector}: {', '.join(parts[detector])}"
        for detector in ("PA447", "araE") if parts[detector]
    )


def parse_qty(value):
    if value is None or isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        return max(float(value), 0.0)
    match = re.search(r"-?\d+(?:[.,]\d+)?", clean(value))
    return max(float(match.group(0).replace(",", ".")), 0.0) if match else 0.0


def load_inventory():
    workbook = load_workbook(ALIQUOTS, data_only=True, read_only=True)
    inventory = []
    for sheet in workbook.worksheets:
        values = list(sheet.iter_rows(min_row=1, max_row=min(sheet.max_row or 1, 1000), max_col=min(sheet.max_column or 1, 40), values_only=True))
        quantity_col = None
        id_cols = []
        for row_number, row in enumerate(values, start=1):
            lower = [clean(value).lower() for value in row]
            q_candidates = [index for index, value in enumerate(lower) if "aliquot" in value]
            if q_candidates:
                quantity_col = q_candidates[0]
                id_cols = [
                    index for index, value in enumerate(lower)
                    if ("sample" in value or "patient number" in value or value == "name" or "מספר מטופל" in value)
                    and "status" not in value
                ]
                continue
            if quantity_col is None or quantity_col >= len(row):
                continue
            identifiers = [norm(row[index]) for index in id_cols if index < len(row) and norm(row[index])]
            if not identifiers:
                continue
            inventory.append({
                "sheet": sheet.title,
                "row": row_number,
                "quantity_raw": clean(row[quantity_col]),
                "quantity": parse_qty(row[quantity_col]),
                "identifiers": identifiers,
            })
    workbook.close()
    return inventory


def aliquot_matches(primary, secondary, inventory):
    primary_norm = norm(primary)
    secondary_norm = norm(secondary)
    primary_matches = [item for item in inventory if primary_norm and primary_norm in item["identifiers"]]
    matches = primary_matches or [item for item in inventory if secondary_norm and secondary_norm in item["identifiers"]]
    return matches


sys.path.insert(0, str(LEGACY_DIR))
expand = load_module("prepare_latest_repeat_expand", EXPAND_PATH)
training, feature_cols, _fill_values, training_sources = expand.importer.classifier.load_training()
bars = expand.importer.classifier.learn_detector_bars(training, feature_cols)

analysis = json.loads(ANALYSIS.read_text(encoding="utf-8"))
if analysis["final_sha256"] != hash_file(FINAL):
    raise AssertionError("The live workbook changed after raw-file analysis.")
if analysis["capacity_issues"]:
    raise AssertionError(analysis["capacity_issues"])
selected = [item for item in analysis["classifications"] if item["classification"] == "new_measurement_for_existing_sample"]
if len(selected) != 24:
    raise AssertionError(f"Expected 24 selected measurements, found {len(selected)}")

selected_files = []
for file_info in analysis["files"]:
    path = Path(file_info["path"])
    if hash_file(path) != file_info["sha256"]:
        raise AssertionError(f"Raw file changed after analysis: {path}")
    selected_files.append({"path": str(path), "file": path.name, "sha256": file_info["sha256"], "record_count": file_info["record_count"]})

workbook = load_workbook(FINAL, data_only=True, read_only=False)
if workbook.sheetnames != list(SHEET_BOUNDS):
    raise AssertionError(f"Unexpected sheets: {workbook.sheetnames}")
row_values = {}
for sheet_name, last_row in SHEET_BOUNDS.items():
    sheet = workbook[sheet_name]
    if sheet.max_row != last_row or sheet.max_column < 27:
        raise AssertionError(f"Unexpected dimensions for {sheet_name}: {sheet.max_row}x{sheet.max_column}")
    for row in range(2, last_row + 1):
        row_values[f"{sheet_name}!{row}"] = [sheet.cell(row, col).value for col in range(1, 28)]
workbook.close()

additions_by_row = defaultdict(list)
for item in selected:
    target = item["candidate_rows"][0]
    additions_by_row[target["row_id"]].append({
        "sheet": target["sheet"],
        "row": target["row"],
        "row_id": target["row_id"],
        "primary": target["primary"],
        "secondary": target["secondary"],
        "detector": item["detector"],
        "value": float(item["value"]),
        "source_file": item["source_file"],
        "source_cell": item["source_cell"],
        "raw_sample": item["sample_name"],
        "normalization": {
            "current_at_1500": item["current_at_1500"],
            "control_current_at_1500": item["control_current_at_1500"],
            "control_baseline_rounded": item["control_baseline_rounded"],
            "substrate_current_at_1500": item["substrate_current_at_1500"],
            "denominator": item["denominator"],
        },
    })

assignment_proofs = []
source_updates = []
for row_id, additions in additions_by_row.items():
    values = row_values[row_id]
    source_additions = defaultdict(list)
    for item in sorted(additions, key=lambda x: (x["detector"], x["source_file"], x["source_cell"])):
        target_column = next((col for col in DETECTOR_COLUMNS[item["detector"]] if not is_numeric(values[col - 1])), None)
        if target_column is None:
            raise AssertionError(f"No empty {item['detector']} cell for {row_id}")
        values[target_column - 1] = item["value"]
        item["target_column"] = target_column
        item["target_cell"] = f"{get_column_letter(target_column)}{item['row']}"
        assignment_proofs.append(item)
        source_additions[item["detector"]].append(item["source_file"])
    before = values[SOURCE_COLUMN - 1]
    after = append_source(before, source_additions)
    values[SOURCE_COLUMN - 1] = after
    source_updates.append({"row_id": row_id, "sheet": additions[0]["sheet"], "row": additions[0]["row"], "primary": additions[0]["primary"], "before": before, "after": after})

inventory = load_inventory()
records = []
decision_changes = []
final_changes = []
status_changes = []
status_yellow_count = 0

for sheet_name, last_row in SHEET_BOUNDS.items():
    for row in range(2, last_row + 1):
        row_id = f"{sheet_name}!{row}"
        values = row_values[row_id]
        old_status = clean(values[2])
        old_final = values[FINAL_COLUMN - 1]
        if old_status == "old metering system":
            records.append({"sheet": sheet_name, "row": row, "primary": values[0], "status_before": old_status, "status_after": old_status, "status_yellow": False, "preserve": True, "PA447": None, "araE": None, "final": old_final})
            continue

        has_numeric = any(is_numeric(values[col - 1]) for cols in DETECTOR_COLUMNS.values() for col in cols)
        if not has_numeric:
            results = {detector: {"call": None, "decision": None, "used_indices": [], "problem_indices": [], "needs_repeat_indices": []} for detector in ("PA447", "araE")}
            final = "לא נבדק" if old_status == "לא נבדק" else "missing"
        else:
            results = {}
            for detector in ("PA447", "araE"):
                detector_values = [values[col - 1] if is_numeric(values[col - 1]) else None for col in DETECTOR_COLUMNS[detector]]
                result = expand.detector_consensus_with_used(detector_values, bars[detector]["bar"])
                results[detector] = {
                    "call": result.get("call"),
                    "decision": result.get("decision"),
                    "used_indices": result.get("used_indices", []),
                    "problem_indices": result.get("problem_indices", []),
                    "needs_repeat_indices": result.get("needs_repeat_indices", []),
                }
            calls = [result["call"] for result in results.values() if result["call"]]
            final = expand.importer.classifier.final_classification(calls) if calls else "missing"

        any_positive = any(results[d]["decision"] == "Pos" for d in ("PA447", "araE"))
        repeat_required = False
        if not any_positive:
            repeat_required = any(results[d].get("needs_repeat_indices") for d in ("PA447", "araE"))
            for detector in ("PA447", "araE"):
                detector_values = [float(values[col - 1]) for col in DETECTOR_COLUMNS[detector] if is_numeric(values[col - 1])]
                calls = {
                    expand.importer.classifier.detector_call(value, bars[detector]["bar"])[0]
                    for value in detector_values
                }
                if len(detector_values) == 2 and {"IBD-like", "IBS-like"}.issubset(calls):
                    repeat_required = True

        matches = aliquot_matches(values[0], values[1], inventory)
        aliquot_available = any(item["quantity"] > 0 for item in matches)
        if old_status == "לא נבדק":
            status_after = old_status
            status_yellow = False
        elif old_status == "missing":
            status_after = "missing"
            status_yellow = aliquot_available
        else:
            status_after = "measured and empty" if repeat_required and not aliquot_available else "measured"
            status_yellow = status_after == "measured and empty"
        if status_yellow:
            status_yellow_count += 1
        if old_status != status_after or status_yellow:
            status_changes.append({
                "sheet": sheet_name,
                "row": row,
                "primary": values[0],
                "before": old_status,
                "after": status_after,
                "yellow": status_yellow,
                "repeat_required": repeat_required,
                "aliquot_available": aliquot_available,
                "aliquot_matches": matches,
            })
        values[2] = status_after

        for detector in ("PA447", "araE"):
            old = values[DECISION_COLUMNS[detector] - 1]
            new = results[detector]["decision"]
            if old != new:
                decision_changes.append({"sheet": sheet_name, "row": row, "primary": values[0], "detector": detector, "before": old, "after": new})
            values[DECISION_COLUMNS[detector] - 1] = new
        if old_final != final:
            final_changes.append({"sheet": sheet_name, "row": row, "primary": values[0], "before": old_final, "after": final})
        values[FINAL_COLUMN - 1] = final
        records.append({
            "sheet": sheet_name,
            "row": row,
            "primary": values[0],
            "status_before": old_status,
            "status_after": status_after,
            "status_yellow": status_yellow,
            "aliquot_available": aliquot_available,
            "repeat_required": repeat_required,
            "preserve": False,
            "PA447": results["PA447"],
            "araE": results["araE"],
            "final": final,
        })

result = {
    "input": str(FINAL),
    "input_sha256": hash_file(FINAL),
    "aliquot_file": str(ALIQUOTS),
    "aliquot_sha256": hash_file(ALIQUOTS),
    "selected_files": selected_files,
    "bars": {detector: bars[detector]["bar"] for detector in ("PA447", "araE")},
    "training_rows": len(training),
    "training_sources": training_sources,
    "measurements_added": len(assignment_proofs),
    "affected_rows": len(additions_by_row),
    "assignment_proofs": assignment_proofs,
    "source_updates": source_updates,
    "records": records,
    "decision_changes": decision_changes,
    "final_changes": final_changes,
    "status_changes": status_changes,
    "status_yellow_count": status_yellow_count,
    "classification_counts": dict(Counter(clean(record["final"]) for record in records)),
}
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
print(json.dumps({
    "output": str(OUTPUT),
    "input_sha256": result["input_sha256"],
    "aliquot_sha256": result["aliquot_sha256"],
    "measurements_added": result["measurements_added"],
    "affected_rows": result["affected_rows"],
    "decision_change_count": len(decision_changes),
    "decision_changes": decision_changes,
    "final_change_count": len(final_changes),
    "final_changes": final_changes,
    "status_change_count": len(status_changes),
    "status_yellow_count": status_yellow_count,
    "status_value_changes": [x for x in status_changes if x["before"] != x["after"]],
}, ensure_ascii=False, indent=2))
