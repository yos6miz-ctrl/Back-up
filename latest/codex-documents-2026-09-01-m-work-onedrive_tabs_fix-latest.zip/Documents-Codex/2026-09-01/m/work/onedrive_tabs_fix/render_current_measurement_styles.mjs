import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workbookPath = "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx";
const previewDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix/style_before";
await fs.mkdir(previewDir, { recursive: true });

const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(workbookPath));
for (const [sheetName, range, fileName] of [
  ["Older samples - before 2021", "I1:Y15", "older_top.png"],
  ["Older samples - before 2021", "I108:Y120", "older_middle.png"],
  ["Older samples - before 2021", "I185:Y190", "older_end.png"],
  ["2021 onward", "I1:Y25", "onward_top.png"],
  ["2021 onward", "I95:Y120", "onward_middle.png"],
]) {
  const blob = await workbook.render({ sheetName, range, scale: 1.75, format: "png" });
  await fs.writeFile(`${previewDir}/${fileName}`, new Uint8Array(await blob.arrayBuffer()));
}
