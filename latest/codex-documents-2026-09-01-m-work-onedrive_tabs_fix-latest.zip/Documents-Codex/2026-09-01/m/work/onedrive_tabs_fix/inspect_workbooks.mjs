import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const workDir = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/work/onedrive_tabs_fix";
const inputs = [
  {
    label: "onedrive",
    file: "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Final Known and Unknown merged.xlsx",
  },
  {
    label: "verified",
    file: "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/verified_raw_additions_20260902/Final Known and Unknown - additional raw measurements.xlsx",
  },
];

await fs.mkdir(workDir, { recursive: true });

for (const item of inputs) {
  const input = await FileBlob.load(item.file);
  const wb = await SpreadsheetFile.importXlsx(input);
  const overview = await wb.inspect({
    kind: "workbook,sheet,table",
    include: "id,name,values,formulas",
    maxChars: 12000,
    tableMaxRows: 5,
    tableMaxCols: 8,
    tableMaxCellChars: 100,
  });
  await fs.writeFile(path.join(workDir, `${item.label}_inspect.ndjson`), overview.ndjson, "utf8");
  console.log(`=== ${item.label} ===`);
  console.log(overview.ndjson);

  const sheets = await wb.inspect({ kind: "sheet", include: "id,name", maxChars: 5000 });
  const sheetNames = [];
  for (const line of sheets.ndjson.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const rec = JSON.parse(line);
      if (rec.name) sheetNames.push(rec.name);
    } catch {}
  }
  for (const sheetName of sheetNames) {
    const preview = await wb.render({ sheetName, range: "A1:H15", scale: 1.25, format: "png" });
    await fs.writeFile(
      path.join(workDir, `${item.label}_${sheetName.replace(/[^a-z0-9]+/gi, "_")}.png`),
      new Uint8Array(await preview.arrayBuffer()),
    );
  }
}
