import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const files = [
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/aliqauts 20260801.xlsx",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Excel file editor/deta/aliqauts 20250112.xlsx",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Old sampels/Stool aliquots updated.xlsx",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Old sampels/All Stool aliquots updated 10.8.23.xlsx",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Excel file editor/Old sampels/Stool aliquots updated.xlsx",
  "C:/Users/Popovtzer lab/OneDrive/RNA-seq-Biochip/Excel file editor/Old sampels/All Stool aliquots updated 10.8.23.xlsx",
];

function normalized(value) {
  return String(value ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function columnName(index) {
  let n = index + 1;
  let name = "";
  while (n > 0) {
    n -= 1;
    name = String.fromCharCode(65 + (n % 26)) + name;
    n = Math.floor(n / 26);
  }
  return name;
}

const exactTarget = "FNY21358";
const numberTarget = "21358";
const alternateTargets = ["986664", "FNY358", "NY358"];
const results = [];

for (const file of files) {
  const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
  const fileResult = { file, sheets: [], exactMatches: [], numberMatches: [], alternateRowMatches: [] };
  for (const sheet of workbook.worksheets.items) {
    const used = sheet.getUsedRange(true);
    const values = used?.values ?? [];
    fileResult.sheets.push({ name: sheet.name, rows: values.length, cols: values[0]?.length ?? 0 });
    for (let rowIndex = 0; rowIndex < values.length; rowIndex += 1) {
      const row = values[rowIndex];
      const normalizedRow = row.map(normalized).join("|");
      const alternateHits = alternateTargets.filter((target) => normalizedRow.includes(target));
      if (alternateHits.length) {
        fileResult.alternateRowMatches.push({ sheet: sheet.name, row: rowIndex + 1, alternateHits, rowValues: row });
      }
      for (let colIndex = 0; colIndex < row.length; colIndex += 1) {
        const value = row[colIndex];
        const norm = normalized(value);
        if (!norm) continue;
        const match = {
          sheet: sheet.name,
          cell: `${columnName(colIndex)}${rowIndex + 1}`,
          value,
          rowValues: row,
        };
        if (norm === exactTarget || norm.includes(exactTarget)) fileResult.exactMatches.push(match);
        if (norm.includes(numberTarget)) fileResult.numberMatches.push(match);
      }
    }
  }
  results.push(fileResult);
}

console.log(JSON.stringify(results, null, 2));
