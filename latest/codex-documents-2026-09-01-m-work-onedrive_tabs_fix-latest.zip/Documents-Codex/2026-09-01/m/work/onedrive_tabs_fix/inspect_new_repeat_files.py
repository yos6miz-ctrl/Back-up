from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import math
import sys

from openpyxl import load_workbook


RAW_AUDIT_SCRIPT = Path(
    r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure"
    r"\audit_final_measurements_without_source.py"
)
FINAL = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\Final Known and Unknown merged.xlsx")
REPEAT_FOLDER = Path(r"C:\Users\Popovtzer lab\OneDrive\RNA-seq-Biochip\sample repeats")
FILES = [
    REPEAT_FOLDER / "20260831 447 sample repeats.xlsx",
    REPEAT_FOLDER / "20260831 araE sample repeats.xlsx",
    REPEAT_FOLDER / "20260901 araE sample repeats.xlsx",
    REPEAT_FOLDER / "20260902 447 sample repeats.xlsx",
]
TOLERANCE = 5e-7
LEGACY_DIR = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\you-are-an-exel-file-editure")
EXPAND_PATH = LEGACY_DIR / "expand_measurement_columns_and_show_all.py"
SELECTED_FILES = {
    "20260901 araE sample repeats.xlsx",
    "20260902 447 sample repeats.xlsx",
}

sys.path.insert(0, str(RAW_AUDIT_SCRIPT.parent))
spec = spec_from_file_location("raw_repeat_audit", RAW_AUDIT_SCRIPT)
raw_audit = module_from_spec(spec)
spec.loader.exec_module(raw_audit)

sys.path.insert(0, str(LEGACY_DIR))
expand_spec = spec_from_file_location("repeat_expand", EXPAND_PATH)
expand = module_from_spec(expand_spec)
expand_spec.loader.exec_module(expand)
training, feature_cols, _fill_values, _sources = expand.importer.classifier.load_training()
bars = expand.importer.classifier.learn_detector_bars(training, feature_cols)


def is_numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def final_rows():
    workbook = load_workbook(FINAL, data_only=True, read_only=False)
    rows = []
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        for row in range(2, sheet.max_row + 1):
            primary = sheet.cell(row, 1).value
            secondary = sheet.cell(row, 2).value
            exact_names = {
                raw_audit.norm(part)
                for name in (primary, secondary)
                for part in str(name or "").split(";")
                if raw_audit.norm(part)
            }
            rows.append(
                {
                    "sheet": sheet_name,
                    "row": row,
                    "primary": primary,
                    "secondary": secondary,
                    "exact_names": exact_names,
                    "keys": raw_audit.expand_manual_aliases(raw_audit.variants(primary, secondary)),
                    "values": {
                        "PA447": [float(sheet.cell(row, col).value) for col in range(8, 16) if is_numeric(sheet.cell(row, col).value)],
                        "araE": [float(sheet.cell(row, col).value) for col in range(17, 23) if is_numeric(sheet.cell(row, col).value)],
                    },
                }
            )
    workbook.close()
    return rows


def candidates_for(record, rows):
    sample_norm = raw_audit.norm(record["sample"])
    exact = [row for row in rows if sample_norm and sample_norm in row["exact_names"]]
    if exact:
        return exact, "exact_name"
    scored = []
    for row in rows:
        shared = set(record["keys"]) & row["keys"]
        if shared:
            scored.append((max(len(key) for key in shared), row))
    best = max((score for score, _row in scored), default=0)
    return [row for score, row in scored if score == best], "alias_keys" if best else "none"


rows = final_rows()
results = []
selected_additions = []
for file_path in FILES:
    records = raw_audit.extract_formula_records(file_path)
    unique = {}
    for record in records:
        key = (record["detector"], raw_audit.norm(record["sample"]), round(float(record["value"]), 9))
        unique.setdefault(key, record)

    details = []
    for record in unique.values():
        candidates, method = candidates_for(record, rows)
        matching = [
            row
            for row in candidates
            if any(abs(float(record["value"]) - value) <= TOLERANCE for value in row["values"][record["detector"]])
        ]
        if matching:
            classification = "already_present"
        elif len(candidates) == 1:
            classification = "new_measurement_for_existing_sample"
        elif len(candidates) > 1:
            classification = "ambiguous_sample_match"
        else:
            classification = "sample_not_in_final"
        details.append(
            {
                "sample": record["sample"],
                "detector": record["detector"],
                "value": float(record["value"]),
                "source_cell": record["source_cell"],
                "classification": classification,
                "match_method": method,
                "candidate_rows": [f"{row['sheet']}!{row['row']}:{row['primary']}" for row in candidates],
                "matching_rows": [f"{row['sheet']}!{row['row']}:{row['primary']}" for row in matching],
            }
        )
        if file_path.name in SELECTED_FILES and classification == "new_measurement_for_existing_sample":
            selected_additions.append({**record, "target": candidates[0]})

    results.append(
        {
            "file": str(file_path),
            "exists": file_path.exists(),
            "size": file_path.stat().st_size if file_path.exists() else None,
            "created": file_path.stat().st_ctime if file_path.exists() else None,
            "modified": file_path.stat().st_mtime if file_path.exists() else None,
            "record_occurrences": len(records),
            "unique_measurements": len(unique),
            "classification_counts": dict(Counter(item["classification"] for item in details)),
            "details": details,
        }
    )

affected = {}
for addition in selected_additions:
    target = addition["target"]
    row_key = (target["sheet"], target["row"])
    affected.setdefault(
        row_key,
        {
            "sheet": target["sheet"],
            "row": target["row"],
            "primary": target["primary"],
            "secondary": target["secondary"],
            "current_values": target["values"],
            "additions": {"PA447": [], "araE": []},
        },
    )
    affected[row_key]["additions"][addition["detector"]].append(
        {
            "value": float(addition["value"]),
            "source_file": addition["source_file"],
            "source_cell": addition["source_cell"],
            "raw_sample": addition["sample"],
        }
    )

workbook = load_workbook(FINAL, data_only=True, read_only=False)
affected_results = []
for key, item in affected.items():
    sheet = workbook[item["sheet"]]
    old_decisions = {"PA447": sheet.cell(item["row"], 16).value, "araE": sheet.cell(item["row"], 23).value}
    old_final = sheet.cell(item["row"], 5).value
    detector_results = {}
    for detector in ("PA447", "araE"):
        values = list(item["current_values"][detector]) + [entry["value"] for entry in item["additions"][detector]]
        capacity = 8 if detector == "PA447" else 6
        if len(values) > capacity:
            raise AssertionError(f"Capacity exceeded for {item['primary']} {detector}: {len(values)} > {capacity}")
        result = expand.detector_consensus_with_used(values, bars[detector]["bar"])
        detector_results[detector] = {
            "values": values,
            "old_decision": old_decisions[detector],
            "new_decision": result["decision"],
            "call": result["call"],
            "used_indices": result.get("used_indices", []),
            "problem_indices": result.get("problem_indices", []),
            "needs_repeat_indices": result.get("needs_repeat_indices", []),
        }
    calls = [result["call"] for result in detector_results.values() if result["call"]]
    new_final = expand.importer.classifier.final_classification(calls) if calls else "missing"
    affected_results.append(
        {
            **item,
            "old_decisions": old_decisions,
            "old_final": old_final,
            "detector_results": detector_results,
            "new_final": new_final,
            "current_source": sheet.cell(item["row"], 25).value,
        }
    )
workbook.close()

print(json.dumps({
    "final": str(FINAL),
    "selected_files": sorted(SELECTED_FILES),
    "selected_new_measurement_count": len(selected_additions),
    "selected_affected_row_count": len(affected_results),
    "bars": {detector: bars[detector]["bar"] for detector in ("PA447", "araE")},
    "affected_results": affected_results,
    "files": results,
}, ensure_ascii=False, indent=2))
