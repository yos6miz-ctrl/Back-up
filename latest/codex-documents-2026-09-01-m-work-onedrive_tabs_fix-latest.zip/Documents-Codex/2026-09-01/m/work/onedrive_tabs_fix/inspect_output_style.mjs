import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";
const file = "C:/Users/Popovtzer lab/Documents/Codex/2026-09-01/m/outputs/final_layout_warning_update_20260903/Final Known and Unknown merged.xlsx";
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(file));
for (const [sheetId, range] of [["Older samples - before 2021", "H6"], ["Older samples - before 2021", "H68"], ["2021 onward", "H20"]]) {
  const result = await workbook.inspect({ kind: "computedStyle", sheetId, range, maxChars: 5000 });
  console.log(sheetId, range, result.ndjson);
}
