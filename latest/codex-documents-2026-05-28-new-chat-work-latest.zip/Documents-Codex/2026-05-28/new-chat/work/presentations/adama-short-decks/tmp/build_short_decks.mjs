import { Presentation, PresentationFile } from "@oai/artifact-tool";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const W = 1280;
const H = 720;

const outDir = "C:/Users/Popovtzer lab/.codex/\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4/V2";
const root = "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat";
const chartDir = `${root}/starvation_chart_exports`;
const assetDir = `${root}/adama_short_decks_assets`;
const projectDir = "C:/Users/Popovtzer lab/.codex/\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4";

const outputs = {
  starvation: `${outDir}/Starvation and alkane detectors.pptx`,
  upo: `${outDir}/UPO19 enzyme.pptx`,
  previewStarvation: `${root}/adama_short_decks_previews/starvation_alkane`,
  previewUpo: `${root}/adama_short_decks_previews/upo19`,
};

const C = {
  ink: "#101010",
  muted: "#555555",
  rule: "#B8BCC4",
  panel: "#EDEDED",
  canvas: "#FFFFFF",
  highlight: "#FF6B35",
  blue: "#1F6F8B",
  green: "#286B3F",
  amber: "#A45B13",
};

async function bytes(filePath) {
  const buf = await readFile(filePath);
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

function deck() {
  return Presentation.create({ slideSize: { width: W, height: H } });
}

function addText(slide, text, x, y, w, h, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    fontFace: "Helvetica Neue",
    fontSize: opts.size ?? 24,
    bold: opts.bold ?? false,
    color: opts.color ?? C.ink,
    alignment: opts.align ?? "left",
  };
  return shape;
}

function addRule(slide, x, y, w, color = C.rule, weight = 2) {
  slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height: weight },
    fill: color,
    line: { style: "solid", fill: color, width: 0 },
  });
}

function addPanel(slide, x, y, w, h, fill = C.panel, line = "none") {
  return slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 },
  });
}

async function addImage(slide, filePath, x, y, w, h, alt, fit = "contain", contentType = "image/png") {
  slide.images.add({
    blob: await bytes(filePath),
    contentType,
    alt,
    fit,
    position: { left: x, top: y, width: w, height: h },
  });
}

function slideBase(presentation, section, title, kicker = "") {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addText(slide, section.toUpperCase(), 42, 30, 420, 26, { size: 12, bold: true, color: C.muted });
  addText(slide, title, 42, 70, 1040, 70, { size: 40, bold: true });
  if (kicker) addText(slide, kicker, 42, 136, 1000, 32, { size: 17, color: C.muted });
  addRule(slide, 42, 174, 1196, C.rule, 1);
  return slide;
}

function cover(presentation, title, subtitle, tag) {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addText(slide, "ADAMA YERUKA", 42, 44, 300, 30, { size: 13, bold: true, color: C.muted });
  addText(slide, title, 42, 190, 930, 160, { size: 58, bold: true });
  addText(slide, subtitle, 44, 370, 720, 72, { size: 24, color: C.muted });
  addText(slide, tag, 44, 590, 500, 34, { size: 18, bold: true, color: C.highlight });
  addPanel(slide, 940, 0, 340, 720, C.panel);
  addText(slide, "Binin Lab\nBar-Ilan University", 985, 535, 220, 70, { size: 22, bold: true });
  addRule(slide, 42, 540, 230, C.ink, 4);
}

function note(slide, x, y, w, h, label, body, color = C.ink) {
  addPanel(slide, x, y, w, h, "#F7F7F7", "#D3D3D3");
  addText(slide, label, x + 18, y + 18, w - 36, 28, { size: 18, bold: true, color });
  addText(slide, body, x + 18, y + 58, w - 36, h - 70, { size: 18, color: C.muted });
}

function arrow(slide, x1, y1, x2, y2, color = C.rule) {
  const left = Math.min(x1, x2);
  const top = Math.min(y1, y2) - 1;
  const width = Math.max(2, Math.abs(x2 - x1));
  const height = Math.max(2, Math.abs(y2 - y1) || 2);
  slide.shapes.add({
    geometry: "rect",
    position: { left, top, width, height },
    fill: color,
    line: { style: "solid", fill: color, width: 0 },
  });
}

function processBox(slide, x, y, w, title, body, color = C.ink) {
  addPanel(slide, x, y, w, 130, "#F7F7F7", "#D3D3D3");
  addText(slide, title, x + 18, y + 18, w - 36, 28, { size: 19, bold: true, color });
  addText(slide, body, x + 18, y + 54, w - 36, 62, { size: 16, color: C.muted });
}

async function renderAndSave(presentation, finalPath, previewDir) {
  await mkdir(path.dirname(finalPath), { recursive: true });
  await mkdir(previewDir, { recursive: true });
  for (const [index, slide] of presentation.slides.items.entries()) {
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await writeFile(`${previewDir}/slide-${String(index + 1).padStart(2, "0")}.png`, Buffer.from(await png.arrayBuffer()));
  }
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(finalPath);
}

async function buildStarvationDeck() {
  const p = deck();
  cover(
    p,
    "Starvation and alkane detectors",
    "Pseudomonas putida detector strains for nutrient limitation and hydrocarbon contamination.",
    "Short partner update"
  );

  let s = slideBase(p, "Starvation detectors", "Dose response is established for Fe and N", "GFP-based detector strains show clear condition-dependent activation.");
  await addImage(s, `${chartDir}/pvdA_Fe_response.png`, 54, 210, 560, 270, "pvdA iron starvation detector dose-response", "contain");
  await addImage(s, `${chartDir}/glnK_N_response.png`, 666, 210, 560, 270, "glnK nitrogen starvation detector dose-response", "contain");
  note(s, 54, 520, 360, 105, "pvdA / Fe", "Expression increases as iron availability drops; strongest response is under -Fe conditions.", C.blue);
  note(s, 460, 520, 360, 105, "glnK / N", "Expression increases as nitrogen concentration decreases, with the highest response at 2 mM N.", C.green);
  note(s, 866, 520, 360, 105, "Phosphate", "Two promoters were tested without sufficient specificity; a third construct is under construction.", C.amber);

  s = slideBase(p, "Endpoint comparison", "13.3 h readout separates responsive detector states", "The endpoint graph provides an easy partner-facing summary of detector performance.");
  await addImage(s, `${chartDir}/normalized_expression_13_3h.png`, 72, 212, 740, 330, "Normalized detector expression at 13.3 hours", "contain");
  note(s, 858, 218, 330, 96, "Fe detector", "pvdA: 28,182 at 20 mM Fe to 244,316 under -Fe.", C.blue);
  note(s, 858, 338, 330, 96, "N detector", "glnK: 11,819 at 10 mM N to 202,038 at 2 mM N.", C.green);
  note(s, 858, 458, 330, 96, "Interpretation", "The working detectors are ready for transfer into additional readout formats.", C.ink);

  s = slideBase(p, "Readout transfer", "The detector platform is being moved beyond GFP", "Working starvation detectors are now being adapted to partner measurement systems.");
  processBox(s, 72, 250, 250, "GFP strains", "Validated Fe and N detector response in P. putida.", C.green);
  arrow(s, 330, 315, 418, 315, C.rule);
  processBox(s, 430, 205, 300, "Amperometric format", "Transferred toward electrochemical measurements in Hadar's lab.", C.blue);
  processBox(s, 430, 365, 300, "Luciferase format", "A parallel luminescent reporter set is being built for Ramez's lab.", C.highlight);
  arrow(s, 738, 268, 842, 268, C.rule);
  arrow(s, 738, 428, 842, 428, C.rule);
  processBox(s, 858, 285, 300, "Partner-ready outputs", "Validated detector logic packaged into readouts that match downstream measurement workflows.", C.ink);

  s = slideBase(p, "Alkane detector", "Partially built and expected to be ready soon", "This branch is more complex because the alkane sensing genes are plasmid-borne in environmental strains.");
  processBox(s, 72, 255, 250, "Source biology", "Relevant alkane sensing genes are not native to P. putida.", C.amber);
  arrow(s, 330, 320, 405, 320, C.rule);
  processBox(s, 420, 255, 250, "Plasmids in hand", "Environmental-strain plasmids carrying the target components are available.", C.blue);
  arrow(s, 678, 320, 753, 320, C.rule);
  processBox(s, 768, 255, 250, "Construct assembly", "Detector includes a receptor and reporter gene.", C.green);
  arrow(s, 1026, 320, 1090, 320, C.rule);
  processBox(s, 1040, 420, 178, "Next", "Complete build and move to functional testing.", C.ink);
  addText(s, "Current status: partially built", 72, 515, 610, 40, { size: 24, bold: true, color: C.highlight });
  addText(s, "Expected output: a P. putida detector for alkane-associated fuel contamination in soil.", 72, 562, 760, 58, { size: 21, color: C.muted });

  await renderAndSave(p, outputs.starvation, outputs.previewStarvation);
}

async function buildUpoDeck() {
  const p = deck();
  cover(
    p,
    "UPO19 enzyme",
    "Codon-optimized UPO19 expression and localization analysis in Pseudomonas putida.",
    "Short partner update"
  );

  let s = slideBase(p, "Construct design", "Native candidates were redesigned for P. putida expression", "Original enzyme plasmids were rejected because their GC content was too low for robust P. putida expression.");
  processBox(s, 70, 260, 220, "Strains received", "All Liyant strains were received and plasmids were sequenced.", C.ink);
  arrow(s, 298, 325, 362, 325);
  processBox(s, 375, 260, 230, "Rejected set", "Original GC content was around 30%, while P. putida is closer to 60%.", C.amber);
  arrow(s, 613, 325, 677, 325);
  processBox(s, 690, 260, 230, "UPO19 redesigned", "Protein sequence retained; codons optimized for P. putida.", C.green);
  arrow(s, 928, 325, 992, 325);
  processBox(s, 1005, 260, 210, "Expression builds", "SP for secretion and His-tag for purification were added.", C.blue);
  note(s, 180, 470, 400, 105, "Vectors", "UPO19 was inserted into pBBR1mcs-2 and pJN105 under arabinose-inducible expression.", C.blue);
  note(s, 700, 470, 360, 105, "Current status", "Constructs were built and sent for sequencing; results are pending.", C.highlight);

  s = slideBase(p, "Coomassie fractionation", "Three cellular fractions were analyzed", "Supernatant, periplasmic extraction, and whole-cell lysate were tested as part of the UPO19 localization workflow.");
  await addImage(s, `${projectDir}/UPO/UPO19 gel.jpeg`, 76, 205, 420, 390, "Coomassie-stained gel with UPO19 fractions", "contain", "image/jpeg");
  note(s, 555, 225, 270, 110, "Fractions", "Supernatant\nPeriplasmic extraction\nWhole-cell lysate", C.ink);
  note(s, 555, 365, 270, 110, "Purpose", "QC of the extraction/fractionation workflow before Western blot interpretation.", C.blue);
  note(s, 875, 270, 300, 150, "Readout", "The Coomassie gel supports the fractionation workflow but the specific UPO19 signal is interpreted from Western blot results.", C.muted);

  s = slideBase(p, "Western blot #1", "UPO19 signal was detected only in whole-cell lysate", "The same three fractions were tested: supernatant, periplasmic extraction, and whole-cell lysate.");
  await addImage(s, `${assetDir}/sunication.png`, 70, 205, 620, 400, "Western blot with UPO19 detected in whole-cell lysate", "contain");
  note(s, 750, 238, 360, 105, "Detected", "Whole-cell lysate only", C.green);
  note(s, 750, 372, 360, 105, "Not detected", "Supernatant and periplasmic extraction under this tested condition.", C.amber);
  note(s, 750, 506, 360, 90, "Interpretation", "UPO19 expression is detectable, but extracellular recovery is not yet established.", C.ink);

  s = slideBase(p, "Western blot #2", "UPO19 signal was detected in the periplasmic extraction", "The second Western blot tested the remaining fractions and showed a periplasm-associated signal.");
  await addImage(s, `${projectDir}/UPO/yossi/CHEMI_06292026_132811/CHEMI_06292026_132811_(Chemi).jpg`, 70, 205, 620, 400, "Western blot with UPO19 detected in periplasmic extraction", "contain", "image/jpeg");
  note(s, 750, 238, 360, 105, "Detected", "Periplasmic extraction only", C.green);
  note(s, 750, 372, 360, 105, "Not detected", "No visible UPO19 signal in the other tested fraction.", C.amber);
  note(s, 750, 506, 360, 90, "Implication", "The secretion signal may support periplasmic localization, with secretion to supernatant still requiring optimization.", C.ink);

  s = slideBase(p, "Next work package", "Confirm expression, localization, and activity", "The immediate goal is to turn construct completion into a transferable enzyme workflow.");
  processBox(s, 96, 260, 260, "1. Sequencing", "Confirm both pBBR1mcs-2 and pJN105 UPO19 constructs.", C.blue);
  arrow(s, 365, 325, 430, 325);
  processBox(s, 445, 260, 260, "2. Western blot", "Repeat and refine fraction testing to quantify localization.", C.green);
  arrow(s, 714, 325, 779, 325);
  processBox(s, 795, 260, 260, "3. Activity test", "Send confirmed protein/material to Algain for activity testing.", C.highlight);
  note(s, 246, 485, 760, 95, "Partner-facing output", "Codon-optimized UPO19 constructs plus preliminary protein localization evidence; activity validation remains the next decision point.", C.ink);

  await renderAndSave(p, outputs.upo, outputs.previewUpo);
}

await buildStarvationDeck();
await buildUpoDeck();

console.log(JSON.stringify(outputs, null, 2));
