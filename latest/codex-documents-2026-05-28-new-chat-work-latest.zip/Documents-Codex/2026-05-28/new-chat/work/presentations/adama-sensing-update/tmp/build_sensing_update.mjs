import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const W = 1280;
const H = 720;
const FINAL_PPTX =
  "C:/Users/Popovtzer lab/.codex/אדמה ירוקה/אדמה ירוקה - עדכון חישה ודטקטורים.pptx";
const TMP_DIR =
  "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat/work/presentations/adama-sensing-update/tmp";
const PREVIEW_DIR = path.join(TMP_DIR, "preview");
const QA_DIR = path.join(TMP_DIR, "qa");
const SOURCE_NOTES = path.join(TMP_DIR, "source-notes.txt");

const charts = {
  pvdA:
    "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat/starvation_chart_exports/pvdA_Fe_response.png",
  glnK:
    "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat/starvation_chart_exports/glnK_N_response.png",
  endpoint:
    "C:/Users/Popovtzer lab/Documents/Codex/2026-05-28/new-chat/starvation_chart_exports/normalized_expression_13_3h.png",
};

const C = {
  ink: "#111111",
  muted: "#555555",
  quiet: "#7A7A7A",
  rule: "#B8BCC4",
  panel: "#EDEDED",
  panel2: "#F6F6F6",
  canvas: "#FFFFFF",
  blue: "#1F6F8B",
  green: "#286B3F",
  orange: "#B45309",
  red: "#A63A2A",
};

const presentation = Presentation.create({ slideSize: { width: W, height: H } });

async function imageBytes(filePath) {
  const bytes = await fs.readFile(filePath);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

function addText(slide, text, x, y, w, h, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    fontFace: "Arial",
    fontSize: opts.size ?? 24,
    bold: opts.bold ?? false,
    color: opts.color ?? C.ink,
    alignment: opts.align ?? "right",
  };
  return shape;
}

function addPanel(slide, x, y, w, h, fill = C.panel2, line = "#D6D6D6") {
  return slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: 1 },
  });
}

function addRule(slide, x, y, w, color = C.rule, weight = 1) {
  slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height: weight },
    fill: color,
    line: { style: "solid", fill: color, width: 0 },
  });
}

function addHeader(slide, kicker, title, subtitle = "") {
  addText(slide, kicker, 72, 34, 360, 24, {
    size: 13,
    bold: true,
    color: C.quiet,
    align: "left",
  });
  addText(slide, title, 410, 68, 798, 58, {
    size: 40,
    bold: true,
    color: C.ink,
  });
  if (subtitle) {
    addText(slide, subtitle, 408, 128, 800, 30, {
      size: 18,
      color: C.muted,
    });
  }
  addRule(slide, 72, 174, 1136);
}

function addFooter(slide, n) {
  addText(slide, `אדמה ירוקה | חישה ודטקטורים | ${n}`, 72, 662, 340, 20, {
    size: 12,
    color: C.quiet,
    align: "left",
  });
}

function addCallout(slide, title, body, x, y, w, h, accent = C.ink) {
  addPanel(slide, x, y, w, h, C.panel2, "#DADADA");
  slide.shapes.add({
    geometry: "rect",
    position: { left: x + w - 7, top: y, width: 7, height: h },
    fill: accent,
    line: { style: "solid", fill: accent, width: 0 },
  });
  addText(slide, title, x + 24, y + 20, w - 52, 34, {
    size: 24,
    bold: true,
    color: accent,
  });
  addText(slide, body, x + 24, y + 64, w - 52, h - 76, {
    size: 18,
    color: C.muted,
  });
}

function addStatusLine(slide, label, status, next, y, accent) {
  addPanel(slide, 92, y, 1096, 74, C.canvas, "#D7D7D7");
  slide.shapes.add({
    geometry: "rect",
    position: { left: 1180, top: y, width: 8, height: 74 },
    fill: accent,
    line: { style: "solid", fill: accent, width: 0 },
  });
  addText(slide, label, 960, y + 18, 190, 30, {
    size: 21,
    bold: true,
    color: accent,
  });
  addText(slide, status, 548, y + 18, 360, 34, {
    size: 18,
    color: C.ink,
  });
  addText(slide, next, 118, y + 18, 376, 34, {
    size: 18,
    color: C.muted,
  });
}

function addSmallDot(slide, x, y, color) {
  slide.shapes.add({
    geometry: "ellipse",
    position: { left: x, top: y, width: 9, height: 9 },
    fill: color,
    line: { style: "solid", fill: color, width: 0 },
  });
}

function addBullets(slide, items, x, y, w, color = C.ink) {
  let top = y;
  for (const item of items) {
    addText(slide, item, x, top, w - 22, 38, {
      size: 20,
      color,
    });
    addSmallDot(slide, x + w - 8, top + 12, color);
    top += 52;
  }
}

async function addChart(slide, filePath, x, y, w, h, alt) {
  slide.images.add({
    blob: await imageBytes(filePath),
    contentType: "image/png",
    alt,
    fit: "contain",
    position: { left: x, top: y, width: w, height: h },
  });
}

function notes(slide, lines) {
  slide.speakerNotes.textFrame.setText([
    "[Sources]",
    ...lines,
  ]);
}

function titleSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addPanel(slide, 0, 0, 1280, 720, "#F7FAF5", "#F7FAF5");
  addPanel(slide, 862, 0, 418, 720, "#E7F2E5", "#E7F2E5");
  addText(slide, "אדמה ירוקה", 640, 172, 510, 64, {
    size: 58,
    bold: true,
    color: C.green,
  });
  addText(slide, "עדכון קצר: חישה ודטקטורים", 548, 252, 602, 48, {
    size: 34,
    bold: true,
    color: C.ink,
  });
  addText(slide, "סטטוס דטקטורי הרעבה, לוציפראז, פוספט ואלקנים", 454, 316, 696, 34, {
    size: 22,
    color: C.muted,
  });
  addRule(slide, 766, 390, 384, C.green, 4);
  addText(slide, "מעבדת בנין | בר-אילן", 72, 630, 330, 22, {
    size: 16,
    bold: true,
    color: C.quiet,
    align: "left",
  });
  notes(slide, [
    "Content based on user-provided project status in this Codex thread.",
  ]);
}

async function statusSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addHeader(
    slide,
    "סיכום ביצוע",
    "שני דטקטורי הרעבה כבר עברו לשלב פורמט קריאה מתקדם",
    "חנקן וברזל פעילים; פוספט ואלקנים עדיין בבנייה/ייצוב"
  );
  addCallout(
    slide,
    "מה עובד",
    "שני הפרומוטורים הפעילים של הרעבה, חנקן וברזל, נותנים תגובה ברורה במערכת המקורית.",
    788,
    226,
    400,
    158,
    C.green
  );
  addCallout(
    slide,
    "מה התקדם",
    "הצלחנו להעביר את שני הפרומוטורים הפעילים למערכת מבוססת לוציפראז.",
    440,
    226,
    300,
    158,
    C.blue
  );
  addCallout(
    slide,
    "מה עדיין פתוח",
    "פוספט ואלקנים נשארים רכיבי פיתוח: פוספט בבנייה נוספת, ואלקנים עדיין לא יציב.",
    92,
    226,
    300,
    158,
    C.orange
  );
  addPanel(slide, 92, 438, 1096, 84, "#EFF7EF", "#C9DEC8");
  addText(
    slide,
    "מסר מרכזי: פלטפורמת החישה מתקדמת משלב GFP לשלב קריאה ישים יותר, אך נדרש עדיין פתרון יציבות לאלקנים וסיום בניית פרומוטורי הפוספט.",
    132,
    462,
    1010,
    42,
    { size: 23, bold: true, color: C.green }
  );
  addFooter(slide, 2);
  notes(slide, [
    "Content based on user-provided project status in this Codex thread.",
  ]);
}

async function evidenceSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addHeader(
    slide,
    "תוצרים עיקריים לתקופה",
    "דטקטורי חנקן וברזל מציגים תגובת מינון ברורה",
    "הגרפים מוצגים כתמיכה לכך ששני הפרומוטורים הפעילים הם בסיס טוב להעברה ללוציפראז"
  );
  await addChart(
    slide,
    charts.pvdA,
    92,
    210,
    520,
    272,
    "pvdA iron starvation detector response"
  );
  await addChart(
    slide,
    charts.glnK,
    668,
    210,
    520,
    272,
    "glnK nitrogen starvation detector response"
  );
  addText(slide, "pvdA | רעב לברזל", 360, 500, 240, 28, {
    size: 20,
    bold: true,
    color: C.blue,
  });
  addText(slide, "glnK | רעב לחנקן", 948, 500, 230, 28, {
    size: 20,
    bold: true,
    color: C.green,
  });
  addText(
    slide,
    "שתי המערכות הפעילות הן כרגע הבסיס להעברה לפורמט לוציפראז ולתיאום ניסויי המשך עם ראמז.",
    214,
    560,
    852,
    34,
    { size: 22, bold: true, color: C.ink, align: "center" }
  );
  addFooter(slide, 3);
  notes(slide, [
    `Local chart asset: ${charts.pvdA}`,
    `Local chart asset: ${charts.glnK}`,
    "Interpretation based on user-provided project status in this Codex thread.",
  ]);
}

function transferSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addHeader(
    slide,
    "שיתופי פעולה והעברת ידע",
    "שני הפרומוטורים הפעילים כבר במערכת לוציפראז",
    "העברה לראמז תתואם בשבוע הבא"
  );
  addPanel(slide, 92, 230, 1096, 92, "#F6F6F6", "#DADADA");
  addText(slide, "1", 1050, 250, 42, 42, {
    size: 30,
    bold: true,
    color: C.green,
    align: "center",
  });
  addText(slide, "העברה טכנולוגית", 820, 250, 210, 34, {
    size: 26,
    bold: true,
    color: C.ink,
  });
  addText(slide, "שני הפרומוטורים הפעילים של הרעבה הועברו בהצלחה למערכת מבוססת לוציפראז.", 190, 248, 590, 38, {
    size: 22,
    color: C.muted,
  });

  addPanel(slide, 92, 350, 1096, 92, "#F6F6F6", "#DADADA");
  addText(slide, "2", 1050, 370, 42, 42, {
    size: 30,
    bold: true,
    color: C.blue,
    align: "center",
  });
  addText(slide, "שותף יעד", 850, 370, 180, 34, {
    size: 26,
    bold: true,
    color: C.ink,
  });
  addText(slide, "נתאם העברה לראמז בשבוע הבא, כולל זנים/קונסטרקטים ותנאי מדידה ראשוניים.", 190, 368, 590, 38, {
    size: 22,
    color: C.muted,
  });

  addPanel(slide, 92, 482, 1096, 56, "#EAF4F7", "#C8DDE5");
  addText(slide, "תוצר צפוי: התחלת בדיקות לוציפראז בשותפות, עם פרוטוקול מדידה מוסכם וקריטריונים לאימות אות.", 142, 496, 994, 26, {
    size: 22,
    bold: true,
    color: C.blue,
  });
  addFooter(slide, 4);
  notes(slide, [
    "Content based on user-provided project status in this Codex thread.",
  ]);
}

function bottlenecksSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addHeader(
    slide,
    "שינויים ועדכונים בתוכנית העבודה",
    "פוספט ואלקנים הם צווארי הבקבוק",
    "העבודה תתועד כהפרדה בין דטקטורים פעילים לבין רכיבי פיתוח"
  );
  addStatusLine(
    slide,
    "פוספט",
    "שני פרומוטורים נוספים להרעבה של פוספט עדיין בבנייה.",
    "סיום בנייה ואז בדיקת ספציפיות מול תנאי הרעבה.",
    224,
    C.orange
  );
  addStatusLine(
    slide,
    "אלקנים",
    "אנחנו עדיין מתקשים לייצר קונסטרקט יציב של דטקטור האלקנים.",
    "להמשיך אופטימיזציית בנייה/יציבות לפני מעבר לפונקציה.",
    326,
    C.red
  );
  addStatusLine(
    slide,
    "חנקן וברזל",
    "שני הפרומוטורים הפעילים כבר הועברו למערכת לוציפראז.",
    "להתמקד באימות ביצועים בפורמט החדש.",
    428,
    C.green
  );
  addFooter(slide, 5);
  notes(slide, [
    "Content based on user-provided project status in this Codex thread.",
  ]);
}

function planSlide() {
  const slide = presentation.slides.add();
  slide.background.fill = C.canvas;
  addHeader(
    slide,
    "תוכנית קצרה להמשך",
    "השלב הבא: העברה, אימות וייצוב",
    "המטרה היא להפוך את הדטקטורים הפעילים למערכת מדידה שימושית אצל השותפים"
  );
  addBullets(
    slide,
    [
      "שבוע הבא: תיאום העברה לראמז של מערכת הלוציפראז עם שני הפרומוטורים הפעילים.",
      "לאחר ההעברה: בדיקת אות, רקע, דינמיקה ותנאי אינדוקציה בפורמט לוציפראז.",
      "פוספט: השלמת שני הפרומוטורים הנוספים ובדיקת ספציפיות מול תנאי הרעבה.",
      "אלקנים: המשך פתרון יציבות הקונסטרקט לפני הרחבת ניסויי תגובה.",
      "תיעוד: הכנת סט זנים/פלסמידים, תנאי גידול ופרוטוקול מדידה להעברה חוזרת."
    ],
    156,
    218,
    968,
    C.ink
  );
  addRule(slide, 376, 604, 530, C.green, 4);
  addFooter(slide, 6);
  notes(slide, [
    "Content based on user-provided project status in this Codex thread.",
  ]);
}

titleSlide();
await statusSlide();
await evidenceSlide();
transferSlide();
bottlenecksSlide();
planSlide();

await fs.mkdir(PREVIEW_DIR, { recursive: true });
await fs.mkdir(QA_DIR, { recursive: true });
await fs.mkdir(path.dirname(FINAL_PPTX), { recursive: true });
await fs.writeFile(
  SOURCE_NOTES,
  [
    "Deck source notes",
    "No web research used.",
    "Project status and narrative based on user-provided updates in this Codex thread.",
    `Local chart asset: ${charts.pvdA}`,
    `Local chart asset: ${charts.glnK}`,
    `Local chart asset: ${charts.endpoint}`,
  ].join("\n"),
  "utf8"
);

for (const [index, slide] of presentation.slides.items.entries()) {
  const stem = `slide-${String(index + 1).padStart(2, "0")}`;
  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await fs.writeFile(path.join(PREVIEW_DIR, `${stem}.png`), Buffer.from(await png.arrayBuffer()));
  const layout = await slide.export({ format: "layout" });
  await fs.writeFile(path.join(QA_DIR, `${stem}.layout.json`), await layout.text(), "utf8");
}

const montage = await presentation.export({ format: "webp", montage: true, scale: 1 });
await fs.writeFile(path.join(PREVIEW_DIR, "montage.webp"), Buffer.from(await montage.arrayBuffer()));

const inspect = await presentation.inspect({
  kind: "slide,textbox,shape,image,notes,layout",
  maxChars: 20000,
});
await fs.writeFile(path.join(QA_DIR, "inspect.ndjson"), inspect.ndjson, "utf8");

const pptx = await PresentationFile.exportPptx(presentation);
await pptx.save(FINAL_PPTX);

console.log(
  JSON.stringify(
    {
      final: FINAL_PPTX,
      slides: presentation.slides.count,
      previewDir: PREVIEW_DIR,
      qaDir: QA_DIR,
    },
    null,
    2
  )
);
