from __future__ import annotations

from pathlib import Path
from openpyxl import load_workbook


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
PATH = Path.home() / ".codex" / PROJECT / "starvation" / "YOSSI 13.8.26.xlsx"


def is_num(v) -> bool:
    return isinstance(v, (int, float))


def main() -> None:
    wb = load_workbook(PATH, data_only=True, read_only=True)
    ws = wb.active
    print("dims", ws.max_row, ws.max_column)
    for r in range(1, ws.max_row + 1):
        vals = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
        nnums = sum(1 for v in vals if is_num(v))
        ntext = sum(1 for v in vals if isinstance(v, str) and v.strip())
        labels = [str(v) for v in vals if isinstance(v, str) and v.strip()][:8]
        if nnums >= 8 or any(x in " ".join(labels) for x in ["Results", "Time", "pupx", "Control", "GFP", "Groth", "Bitmap"]):
            print(r, "nums", nnums, "text", ntext, "labels", " | ".join(labels).encode("unicode_escape").decode("ascii"))
    print("merged", len(ws.merged_cells.ranges))
    for rng in list(ws.merged_cells.ranges)[:40]:
        print("merge", str(rng))


if __name__ == "__main__":
    main()
