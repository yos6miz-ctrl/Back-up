from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
SOURCE_NAME = "YOSSI 13.8.26.xlsx"
OUT_NAME = "YOSSI 13.8.26 inner-well plate layouts.xlsx"
ROWS = list("BCDEFG")
COLS = list(range(2, 12))

BLUE = "1F4E79"
DARK = "1F2937"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREEN = "E2F0D9"
LIGHT_GRAY = "F2F2F2"
WHITE = "FFFFFF"
BORDER = Side(style="thin", color="C7D2E4")


def excel_time_to_text(value) -> str:
    if hasattr(value, "strftime"):
        return value.strftime("%H:%M:%S")
    if isinstance(value, (int, float)):
        total_seconds = round(float(value) * 24 * 3600)
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    return str(value)


def read_block(ws, header_row: int, first_data_row: int, last_data_row: int) -> list[dict]:
    raw_rows = list(ws.iter_rows(min_row=header_row, max_row=last_data_row, values_only=True))
    headers = list(raw_rows[0])
    idx = {str(v): i for i, v in enumerate(headers) if v}
    output = []
    for read_no, row in enumerate(raw_rows[first_data_row - header_row :], start=1):
        rec = {"read": read_no, "time": row[1], "time_text": excel_time_to_text(row[1]), "temp": row[2]}
        for plate_row in ROWS:
            for plate_col in COLS:
                well = f"{plate_row}{plate_col}"
                rec[well] = row[idx[well]]
        output.append(rec)
    return output


def build_label_map() -> dict[str, str]:
    labels: dict[str, str] = {}
    groups = [
        ("M9", 1, "pupxA"),
        ("M9", 2, "pupxB"),
        ("M9", 3, "Control"),
        ("M9 0.5P", 4, "pupxA"),
        ("M9 0.5P", 5, "pupxB"),
        ("M9 0.5P", 6, "Control"),
        ("M9 -P", 7, "pupxA"),
        ("M9 -P", 8, "pupxB"),
        ("M9 -P", 9, "Control"),
    ]
    for plate_row in ROWS:
        for condition, plate_col, construct in groups:
            labels[f"{plate_row}{plate_col}"] = f"{condition} | {construct}"
        for plate_col in [10, 11, 12]:
            labels[f"{plate_row}{plate_col}"] = ""
    return labels


def style_plate(ws, start_row: int, start_col: int, data_range: str, title_fill: str) -> None:
    for col in range(start_col, start_col + len(COLS) + 1):
        ws.column_dimensions[get_column_letter(col)].width = 12
    for row in range(start_row, start_row + len(ROWS) + 4):
        ws.row_dimensions[row].height = 22
    title = ws.cell(start_row, start_col)
    title.font = Font(bold=True, size=13, color=WHITE)
    title.fill = PatternFill("solid", fgColor=title_fill)
    title.alignment = Alignment(horizontal="center")
    for row in ws.iter_rows(min_row=start_row + 1, max_row=start_row + len(ROWS) + 2, min_col=start_col, max_col=start_col + len(COLS)):
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(left=BORDER, right=BORDER, top=BORDER, bottom=BORDER)
    for cell in ws[start_row + 1][start_col - 1 : start_col + len(COLS)]:
        cell.font = Font(bold=True, color=BLUE)
        cell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    for r in range(start_row + 2, start_row + len(ROWS) + 2):
        cell = ws.cell(r, start_col)
        cell.font = Font(bold=True, color=BLUE)
        cell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    ws.conditional_formatting.add(
        data_range,
        ColorScaleRule(start_type="min", start_color="F7FBFF", mid_type="percentile", mid_value=50, mid_color="9ECAE1", end_type="max", end_color="08519C"),
    )


def add_plate(ws, start_row: int, start_col: int, title: str, values: dict, number_format: str, fill: str) -> None:
    ws.merge_cells(start_row=start_row, start_column=start_col, end_row=start_row, end_column=start_col + len(COLS))
    ws.cell(start_row, start_col, title)
    ws.cell(start_row + 1, start_col, "")
    for j, col_no in enumerate(COLS, start=start_col + 1):
        ws.cell(start_row + 1, j, col_no)
    for i, row_name in enumerate(ROWS, start=start_row + 2):
        ws.cell(i, start_col, row_name)
        for j, plate_col in enumerate(COLS, start=start_col + 1):
            well = f"{row_name}{plate_col}"
            cell = ws.cell(i, j, values[well])
            cell.number_format = number_format
    data_range = f"{get_column_letter(start_col + 1)}{start_row + 2}:{get_column_letter(start_col + len(COLS))}{start_row + len(ROWS) + 1}"
    style_plate(ws, start_row, start_col, data_range, fill)


def add_map_sheet(wb: Workbook, labels: dict[str, str]) -> None:
    ws = wb.create_sheet("Plate map")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Inner-well plate map from first growth-curve table"
    ws["A1"].font = Font(bold=True, size=15, color=BLUE)
    ws["A3"] = ""
    for j, col in enumerate(COLS, start=2):
        ws.cell(3, j, col)
    for i, row_name in enumerate(ROWS, start=4):
        ws.cell(i, 1, row_name)
        for j, plate_col in enumerate(COLS, start=2):
            ws.cell(i, j, labels[f"{row_name}{plate_col}"])
    for row in ws.iter_rows(min_row=3, max_row=3 + len(ROWS), min_col=1, max_col=1 + len(COLS)):
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(left=BORDER, right=BORDER, top=BORDER, bottom=BORDER)
            if cell.row == 3 or cell.column == 1:
                cell.fill = PatternFill("solid", fgColor=LIGHT_BLUE)
                cell.font = Font(bold=True, color=BLUE)
            elif cell.value:
                cell.fill = PatternFill("solid", fgColor=LIGHT_GREEN if "Control" not in str(cell.value) else LIGHT_GRAY)
    for col in range(1, 2 + len(COLS)):
        ws.column_dimensions[get_column_letter(col)].width = 15
    for row in range(3, 4 + len(ROWS)):
        ws.row_dimensions[row].height = 34


def add_long_sheet(wb: Workbook, name: str, rows: list[dict], channel: str) -> None:
    ws = wb.create_sheet(name)
    ws.sheet_view.showGridLines = False
    headers = ["read", "time", "temp", "well", channel]
    for c, header in enumerate(headers, 1):
        cell = ws.cell(1, c, header)
        cell.font = Font(bold=True, color=WHITE)
        cell.fill = PatternFill("solid", fgColor=BLUE)
        cell.alignment = Alignment(horizontal="center")
    r = 2
    for record in rows:
        for plate_row in ROWS:
            for plate_col in COLS:
                well = f"{plate_row}{plate_col}"
                ws.cell(r, 1, record["read"])
                ws.cell(r, 2, record["time_text"])
                ws.cell(r, 3, record["temp"])
                ws.cell(r, 4, well)
                ws.cell(r, 5, record[well])
                r += 1
    for col, width in enumerate([8, 12, 10, 8, 14], 1):
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:E{r-1}"


def main() -> None:
    source = Path.home() / ".codex" / PROJECT / "starvation" / SOURCE_NAME
    out = Path.home() / ".codex" / PROJECT / "starvation" / OUT_NAME
    src_wb = load_workbook(source, data_only=True, read_only=True)
    src_ws = src_wb["Plate 1 - Sheet1"]
    od_rows = read_block(src_ws, 51, 52, 69)
    gfp_rows = read_block(src_ws, 87, 88, 105)
    labels = build_label_map()

    wb = Workbook()
    readme = wb.active
    readme.title = "README"
    readme.sheet_view.showGridLines = False
    readme["A1"] = "YOSSI 13.8.26 raw inner-well plate layouts"
    readme["A1"].font = Font(bold=True, size=16, color=BLUE)
    readme["A3"] = "Source"
    readme["B3"] = str(source)
    readme["A4"] = "What this file contains"
    readme["B4"] = "Raw OD595 and raw GFP values arranged as inner-well plate maps for every time point in the source file. Edge row/column wells A, H, 1, and 12 are excluded."
    readme["A5"] = "Reads included"
    readme["B5"] = f"{len(od_rows)} OD595 inner-well layouts and {len(gfp_rows)} GFP inner-well layouts."
    readme["A6"] = "Important"
    readme["B6"] = "No subtraction and no division are applied in these plate-layout sheets, so values remain raw measured values."
    for row in range(3, 7):
        readme.cell(row, 1).font = Font(bold=True, color=BLUE)
    readme.column_dimensions["A"].width = 22
    readme.column_dimensions["B"].width = 120

    add_map_sheet(wb, labels)

    od_ws = wb.create_sheet("OD595 plates")
    od_ws.sheet_view.showGridLines = False
    od_ws["A1"] = "OD595 raw inner-well plates"
    od_ws["A1"].font = Font(bold=True, size=15, color=BLUE)
    row_start = 3
    for record in od_rows:
        add_plate(od_ws, row_start, 1, f"Read {record['read']:02d} | {record['time_text']} | OD595", record, "0.000", BLUE)
        row_start += len(ROWS) + 4

    gfp_ws = wb.create_sheet("GFP plates")
    gfp_ws.sheet_view.showGridLines = False
    gfp_ws["A1"] = "GFP raw inner-well plates"
    gfp_ws["A1"].font = Font(bold=True, size=15, color=BLUE)
    row_start = 3
    for record in gfp_rows:
        add_plate(gfp_ws, row_start, 1, f"Read {record['read']:02d} | {record['time_text']} | GFP 488/528", record, "#,##0", "548235")
        row_start += len(ROWS) + 4

    add_long_sheet(wb, "OD595 long", od_rows, "OD595")
    add_long_sheet(wb, "GFP long", gfp_rows, "GFP")

    wb.save(out)
    print(str(out).encode("unicode_escape").decode("ascii"))
    print("od_reads", len(od_rows), "gfp_reads", len(gfp_rows))


if __name__ == "__main__":
    main()
