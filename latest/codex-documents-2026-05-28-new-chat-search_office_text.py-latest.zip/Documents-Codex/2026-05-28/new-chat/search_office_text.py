from __future__ import annotations

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


TERMS = ("pstS", "pho", "phosphate", "phosph", "פוספט", "זרחן")
PROJECT = Path.home() / ".codex" / "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
TAG_RE = re.compile(r"<[^>]+>")


def clean_xml_text(raw: bytes) -> str:
    text = raw.decode("utf-8", errors="ignore")
    text = TAG_RE.sub(" ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def iter_zip_text(path: Path):
    try:
        with zipfile.ZipFile(path) as zf:
            for name in zf.namelist():
                if not name.endswith(".xml"):
                    continue
                if not any(part in name for part in ("word/", "ppt/", "xl/")):
                    continue
                yield name, clean_xml_text(zf.read(name))
    except zipfile.BadZipFile:
        return


def main() -> None:
    for path in sorted(PROJECT.rglob("*")):
        if path.suffix.lower() not in {".docx", ".pptx", ".xlsx"}:
            continue
        hits: list[tuple[str, str]] = []
        for member, text in iter_zip_text(path):
            lower = text.lower()
            if any(term.lower() in lower for term in TERMS):
                for term in TERMS:
                    pos = lower.find(term.lower())
                    if pos >= 0:
                        start = max(0, pos - 180)
                        end = min(len(text), pos + 240)
                        hits.append((member, text[start:end]))
                        break
        if hits:
            print("\nFILE", str(path).encode("unicode_escape").decode("ascii"))
            for member, snippet in hits[:20]:
                print(" MEMBER", member)
                print("  ", snippet.encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
