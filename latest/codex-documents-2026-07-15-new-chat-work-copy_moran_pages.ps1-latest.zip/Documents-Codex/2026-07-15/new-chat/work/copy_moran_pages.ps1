$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$docPath = (Resolve-Path 'outputs\Teads_TA_Interview_Assignment_clean.docx').Path
$qaDir = Join-Path (Resolve-Path 'work').Path 'moran_page_images'
New-Item -ItemType Directory -Path $qaDir -Force | Out-Null
$stagePath = Join-Path (Resolve-Path 'work').Path 'copy_moran_stage.txt'

$word = $null
$doc = $null
try {
    Set-Content -LiteralPath $stagePath -Value 'starting Word'
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($docPath, $false, $true)
    $doc.Repaginate()
    $totalPages = $doc.ComputeStatistics(2)
    Set-Content -LiteralPath $stagePath -Value "TOTAL_PAGES=$totalPages"
    for ($pageNo = 1; $pageNo -le $totalPages; $pageNo++) {
        Add-Content -LiteralPath $stagePath -Value "copying page $pageNo"
        $range = $doc.GoTo(1, 1, $pageNo)
        $range.Select()
        $pageRange = $word.Selection.Bookmarks.Item('\Page').Range
        $emfPath = Join-Path $qaDir ("page-{0:D2}.emf" -f $pageNo)
        [System.IO.File]::WriteAllBytes($emfPath, [byte[]]$pageRange.EnhMetaFileBits)
        $image = [System.Drawing.Image]::FromFile($emfPath)
        try {
            $output = Join-Path $qaDir ("page-{0:D2}.png" -f $pageNo)
            $image.Save($output, [System.Drawing.Imaging.ImageFormat]::Png)
        }
        finally {
            $image.Dispose()
            Remove-Item -LiteralPath $emfPath -Force
        }
    }
    Add-Content -LiteralPath $stagePath -Value 'complete'
    "TOTAL_PAGES=$totalPages"
}
finally {
    if ($doc -ne $null) { $doc.Close(0) }
    if ($word -ne $null) { $word.Quit() }
    if ($doc -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) }
    if ($word -ne $null) { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
