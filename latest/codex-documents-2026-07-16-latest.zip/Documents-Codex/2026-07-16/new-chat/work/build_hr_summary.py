from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-07-16\new-chat\outputs\סיכום ניסיון HR - מורן בן דוד.docx")

BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
NAVY = "0B2545"
MUTED = "5B6573"
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
BORDER = "CBD5E1"
WHITE = "FFFFFF"
BLACK = "000000"

FONT = "Calibri"
CONTENT_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120


def set_rtl_paragraph(paragraph, alignment=WD_ALIGN_PARAGRAPH.RIGHT):
    paragraph.alignment = alignment
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def set_run_font(run, size=None, bold=None, color=None, italic=None):
    run.font.name = FONT
    r_pr = run._element.get_or_add_rPr()
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):
        r_fonts.set(qn(f"w:{attr}"), FONT)
    rtl = r_pr.find(qn("w:rtl"))
    if rtl is None:
        rtl = OxmlElement("w:rtl")
        r_pr.append(rtl)
    rtl.set(qn("w:val"), "1")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def set_style_font(style, size, color=BLACK, bold=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor.from_string(color)
    r_pr = style.element.get_or_add_rPr()
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):
        r_fonts.set(qn(f"w:{attr}"), FONT)


def set_style_rtl(style):
    p_pr = style.element.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")
    jc = p_pr.find(qn("w:jc"))
    if jc is None:
        jc = OxmlElement("w:jc")
        p_pr.append(jc)
    jc.set(qn("w:val"), "right")


def keep_with_next(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    el = p_pr.find(qn("w:keepNext"))
    if el is None:
        el = OxmlElement("w:keepNext")
        p_pr.append(el)


def keep_together(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    el = p_pr.find(qn("w:keepLines"))
    if el is None:
        el = OxmlElement("w:keepLines")
        p_pr.append(el)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.find(qn("w:tcMar"))
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table, color=BORDER, size=6, inside=True):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    names = ["top", "start", "bottom", "end"]
    if inside:
        names += ["insideH", "insideV"]
    for name in names:
        edge = borders.find(qn(f"w:{name}"))
        if edge is None:
            edge = OxmlElement(f"w:{name}")
            borders.append(edge)
        edge.set(qn("w:val"), "single")
        edge.set(qn("w:sz"), str(size))
        edge.set(qn("w:space"), "0")
        edge.set(qn("w:color"), color)


def set_table_geometry(table, widths_dxa, indent_dxa=TABLE_INDENT_DXA, rtl=True):
    assert sum(widths_dxa) == CONTENT_WIDTH_DXA
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.RIGHT
    tbl_pr = table._tbl.tblPr

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(CONTENT_WIDTH_DXA))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")

    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    if rtl:
        bidi = tbl_pr.find(qn("w:bidiVisual"))
        if bidi is None:
            bidi = OxmlElement("w:bidiVisual")
            tbl_pr.append(bidi)
        bidi.set(qn("w:val"), "1")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for i, (cell, width) in enumerate(zip(row.cells, widths_dxa)):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            cell.width = Inches(width / 1440)
            set_cell_margins(cell)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = tr_pr.find(qn("w:tblHeader"))
    if tbl_header is None:
        tbl_header = OxmlElement("w:tblHeader")
        tr_pr.append(tbl_header)
    tbl_header.set(qn("w:val"), "true")


def set_cell_text(cell, text, bold=False, color=BLACK, size=10.5, align=WD_ALIGN_PARAGRAPH.RIGHT):
    cell.text = ""
    p = cell.paragraphs[0]
    set_rtl_paragraph(p, align)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.05
    run = p.add_run(text)
    set_run_font(run, size=size, bold=bold, color=color)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def add_field(paragraph, field_code):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {field_code} "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])
    set_run_font(run, size=9, color=MUTED)


def create_bullet_num_id(doc):
    numbering = doc.part.numbering_part.element
    abs_ids = [int(el.get(qn("w:abstractNumId"))) for el in numbering.findall(qn("w:abstractNum"))]
    num_ids = [int(el.get(qn("w:numId"))) for el in numbering.findall(qn("w:num"))]
    abstract_id = max(abs_ids, default=-1) + 1
    num_id = max(num_ids, default=0) + 1

    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)

    lvl = OxmlElement("w:lvl")
    lvl.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "bullet")
    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "•")
    lvl_jc = OxmlElement("w:lvlJc")
    lvl_jc.set(qn("w:val"), "right")
    p_pr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "720")
    tabs.append(tab)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:right"), "720")
    ind.set(qn("w:hanging"), "360")
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:after"), "160")
    spacing.set(qn("w:line"), "280")
    spacing.set(qn("w:lineRule"), "auto")
    p_pr.extend([tabs, ind, spacing])
    r_pr = OxmlElement("w:rPr")
    r_fonts = OxmlElement("w:rFonts")
    r_fonts.set(qn("w:ascii"), FONT)
    r_fonts.set(qn("w:hAnsi"), FONT)
    r_pr.append(r_fonts)
    lvl.extend([start, num_fmt, lvl_text, lvl_jc, p_pr, r_pr])
    abstract.append(lvl)
    numbering.append(abstract)

    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    abstract_ref = OxmlElement("w:abstractNumId")
    abstract_ref.set(qn("w:val"), str(abstract_id))
    num.append(abstract_ref)
    numbering.append(num)
    return num_id


def add_bullet(doc, text, num_id):
    p = doc.add_paragraph()
    set_rtl_paragraph(p)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.line_spacing = 1.167
    p_pr = p._p.get_or_add_pPr()
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id_el = OxmlElement("w:numId")
    num_id_el.set(qn("w:val"), str(num_id))
    num_pr.extend([ilvl, num_id_el])
    p_pr.append(num_pr)
    run = p.add_run(text)
    set_run_font(run, size=11, color=BLACK)
    keep_together(p)
    return p


def add_mixed_paragraph(doc, label, text, after=6, size=11):
    p = doc.add_paragraph()
    set_rtl_paragraph(p)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.10
    r1 = p.add_run(label)
    set_run_font(r1, size=size, bold=True, color=NAVY)
    r2 = p.add_run(text)
    set_run_font(r2, size=size, color=BLACK)
    keep_together(p)
    return p


def add_heading(doc, text, level):
    p = doc.add_paragraph(text, style=f"Heading {level}")
    set_rtl_paragraph(p)
    for run in p.runs:
        set_run_font(run)
    keep_with_next(p)
    return p


def add_role_block(doc, heading, period_line, bullets, num_id):
    add_heading(doc, heading, 2)
    p = doc.add_paragraph()
    set_rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.10
    r = p.add_run(period_line)
    set_run_font(r, size=10.5, bold=True, color=MUTED)
    keep_with_next(p)
    for bullet in bullets:
        add_bullet(doc, bullet, num_id)


def build_document():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Inches(8.5)
    sec.page_height = Inches(11)
    sec.top_margin = Inches(1)
    sec.bottom_margin = Inches(1)
    sec.left_margin = Inches(1)
    sec.right_margin = Inches(1)
    sec.header_distance = Inches(0.492)
    sec.footer_distance = Inches(0.492)

    props = doc.core_properties
    props.title = "סיכום ניסיון מקצועי במשאבי אנוש - מורן בן דוד"
    props.subject = "סיכום ניסיון HR, Talent Acquisition ו-People Operations"
    props.author = "Moran Ben David"
    props.keywords = "HR, Talent Acquisition, Recruitment, People Operations, Employee Experience"

    styles = doc.styles
    normal = styles["Normal"]
    set_style_font(normal, 11, BLACK)
    set_style_rtl(normal)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    title_style = styles["Title"]
    set_style_font(title_style, 24, NAVY, True)
    set_style_rtl(title_style)
    title_style.paragraph_format.space_before = Pt(0)
    title_style.paragraph_format.space_after = Pt(4)

    subtitle_style = styles["Subtitle"]
    set_style_font(subtitle_style, 12, MUTED)
    set_style_rtl(subtitle_style)
    subtitle_style.paragraph_format.space_before = Pt(0)
    subtitle_style.paragraph_format.space_after = Pt(14)

    h1 = styles["Heading 1"]
    set_style_font(h1, 16, BLUE, True)
    set_style_rtl(h1)
    h1.paragraph_format.space_before = Pt(16)
    h1.paragraph_format.space_after = Pt(8)
    h1.paragraph_format.keep_with_next = True

    h2 = styles["Heading 2"]
    set_style_font(h2, 13, BLUE, True)
    set_style_rtl(h2)
    h2.paragraph_format.space_before = Pt(12)
    h2.paragraph_format.space_after = Pt(6)
    h2.paragraph_format.keep_with_next = True

    h3 = styles["Heading 3"]
    set_style_font(h3, 12, DARK_BLUE, True)
    set_style_rtl(h3)
    h3.paragraph_format.space_before = Pt(8)
    h3.paragraph_format.space_after = Pt(4)
    h3.paragraph_format.keep_with_next = True

    # Quiet memo-masthead running header and footer.
    hp = sec.header.paragraphs[0]
    set_rtl_paragraph(hp)
    hp.paragraph_format.space_after = Pt(0)
    hr = hp.add_run("מורן בן דוד  |  סיכום ניסיון מקצועי ב-HR")
    set_run_font(hr, size=9, bold=True, color=MUTED)

    fp = sec.footer.paragraphs[0]
    set_rtl_paragraph(fp, WD_ALIGN_PARAGRAPH.CENTER)
    fr = fp.add_run("מסמך מסכם  |  עמוד ")
    set_run_font(fr, size=9, color=MUTED)
    add_field(fp, "PAGE")
    fr2 = fp.add_run(" מתוך ")
    set_run_font(fr2, size=9, color=MUTED)
    add_field(fp, "NUMPAGES")

    title = doc.add_paragraph("סיכום ניסיון מקצועי במשאבי אנוש", style="Title")
    set_rtl_paragraph(title)
    for run in title.runs:
        set_run_font(run, size=24, bold=True, color=NAVY)
    keep_with_next(title)

    subtitle = doc.add_paragraph("מורן בן דוד | HR, Talent Acquisition & People Operations", style="Subtitle")
    set_rtl_paragraph(subtitle)
    for run in subtitle.runs:
        set_run_font(run, size=12, color=MUTED)
    keep_with_next(subtitle)

    meta = doc.add_paragraph()
    set_rtl_paragraph(meta)
    meta.paragraph_format.space_after = Pt(14)
    mr = meta.add_run("מבוסס על קורות החיים שסופקו | אומדן נכון ליולי 2026 | לשימוש מקצועי ובכפוף לשמירה על סודיות")
    set_run_font(mr, size=9.5, color=MUTED)

    metrics = doc.add_table(rows=1, cols=3)
    metric_data = [
        ("ניסיון HR כולל", "כ-13 שנים", "2013 - היום"),
        ("גיוס ו-Talent Acquisition", "כ-8 שנים", "2018 - היום"),
        ("People Experience / Operations", "כ-8 שנים", "2013 - 2021"),
    ]
    for i, (label, value, years) in enumerate(metric_data):
        cell = metrics.rows[0].cells[i]
        cell.text = ""
        set_cell_shading(cell, LIGHT_BLUE if i != 1 else LIGHT_GRAY)
        set_cell_margins(cell, top=120, bottom=120, start=140, end=140)
        p1 = cell.paragraphs[0]
        set_rtl_paragraph(p1, WD_ALIGN_PARAGRAPH.CENTER)
        p1.paragraph_format.space_after = Pt(3)
        r1 = p1.add_run(label)
        set_run_font(r1, size=9.5, bold=True, color=DARK_BLUE)
        p2 = cell.add_paragraph()
        set_rtl_paragraph(p2, WD_ALIGN_PARAGRAPH.CENTER)
        p2.paragraph_format.space_after = Pt(2)
        r2 = p2.add_run(value)
        set_run_font(r2, size=16, bold=True, color=NAVY)
        p3 = cell.add_paragraph()
        set_rtl_paragraph(p3, WD_ALIGN_PARAGRAPH.CENTER)
        p3.paragraph_format.space_after = Pt(0)
        r3 = p3.add_run(years)
        set_run_font(r3, size=9, color=MUTED)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    set_table_geometry(metrics, [3120, 3120, 3120])
    set_table_borders(metrics, color=BORDER, size=6, inside=True)

    add_heading(doc, "תמונה מקצועית כוללת", 1)
    p = doc.add_paragraph()
    set_rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.10
    rr = p.add_run(
        "כ-13 שנות ניסיון רציף במגוון עולמות משאבי האנוש - החל מרווחה, חוויית עובד ותמיכה ב-HRBP, "
        "דרך People Operations, ועד גיוס ו-Talent Acquisition מקצה לקצה בסביבה טכנולוגית גלובלית. "
        "הניסיון משלב עבודה אסטרטגית ותפעולית, שותפות עם מנהלים, שימוש בנתונים ובמערכות ATS והטמעת כלי AI בתהליכי גיוס."
    )
    set_run_font(rr, size=11, color=BLACK)

    add_heading(doc, "רצף הניסיון ומשך כל תקופה", 1)
    timeline = doc.add_table(rows=1, cols=4)
    headers = ["תקופה", "ארגון", "תפקיד / תחום", "משך משוער"]
    for i, header in enumerate(headers):
        set_cell_text(timeline.rows[0].cells[i], header, bold=True, color=WHITE, size=10, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(timeline.rows[0].cells[i], DARK_BLUE)
    set_repeat_table_header(timeline.rows[0])
    rows = [
        ("2023 - היום", "Yotpo", "Talent Acquisition Specialist", "כ-3 שנים"),
        ("2021 - 2023", "Yotpo", "Talent Acquisition Coordinator", "כ-2 שנים"),
        ("2018 - 2021", "DriveNets", "גיוס ו-People Operations", "כ-3 שנים"),
        ("2013 - 2018", "yes", "חוויית עובד, רווחה ותיאום HR", "כ-5 שנים"),
    ]
    for row_idx, row_data in enumerate(rows, start=1):
        cells = timeline.add_row().cells
        fill = WHITE if row_idx % 2 else LIGHT_GRAY
        for i, value in enumerate(row_data):
            align = WD_ALIGN_PARAGRAPH.CENTER if i in (0, 1, 3) else WD_ALIGN_PARAGRAPH.RIGHT
            set_cell_text(cells[i], value, color=BLACK, size=10, align=align)
            set_cell_shading(cells[i], fill)
    set_table_geometry(timeline, [1750, 1400, 4260, 1950])
    set_table_borders(timeline, color=BORDER, size=5, inside=True)

    note = doc.add_paragraph()
    set_rtl_paragraph(note)
    note.paragraph_format.space_before = Pt(4)
    note.paragraph_format.space_after = Pt(6)
    nr = note.add_run(
        "הערת חישוב: קורות החיים מציינים שנים בלבד, ללא חודשים; לכן כל המשכים מעוגלים. "
        "תקופות המומחיות בגיוס וב-People Operations חופפות בחלקן ואין לחבר ביניהן לצורך חישוב הניסיון הכולל."
    )
    set_run_font(nr, size=9, italic=True, color=MUTED)

    add_heading(doc, "תחומי מומחיות מרכזיים", 1)
    add_mixed_paragraph(doc, "גיוס: ", "ניהול גיוס מקצה לקצה, איתור מועמדים ממוקד, ראיונות טלפוניים, תיאום ראיונות, ניהול פידבק, ממליצים והצעות.")
    add_mixed_paragraph(doc, "שותפות עסקית וחוויית מועמד: ", "עבודה עם מנהלים להגדרת תפקידים וגורמי הצלחה, בניית צבר מועמדים ושיפור מתמיד של חוויית המועמד.")
    add_mixed_paragraph(doc, "People & Employee Experience: ", "רווחה, אירועי חברה, מתנות וחגים, תקציבים וספקים, תמיכה במנהלים ובעובדים ומענה בנושאי HR לאורך מחזור חיי העובד.")
    add_mixed_paragraph(doc, "דאטה, מערכות וחדשנות: ", "Greenhouse, Comeet, Monday.com, LinkedIn Recruiter, כלי אנליטיקה לגיוס וכלי AI מתקדמים לאיתור ולייעול תהליכים.")
    add_mixed_paragraph(doc, "השכלה: ", "B.A. במדעי ההתנהגות ומשאבי אנוש, אוניברסיטת בר-אילן (2011 - 2014).", after=0)

    page_break = doc.add_paragraph()
    page_break.add_run().add_break(WD_BREAK.PAGE)

    add_heading(doc, "פירוט הניסיון המקצועי ב-HR", 1)
    num_id = create_bullet_num_id(doc)

    add_role_block(
        doc,
        "Yotpo | Talent Acquisition Specialist",
        "2023 - היום | משך משוער: כ-3 שנים",
        [
            "הובלת תהליכי גיוס מלאים בישראל ותמיכה בתהליכי גיוס מקצה לקצה בארה\"ב ובבולגריה, למגוון פונקציות ורמות בכירות.",
            "בניית אסטרטגיות איתור ממוקדות, ניהול צבר מועמדים ושמירה על חוויית מועמד רציפה ואיכותית.",
            "שותפות עם מנהלים מגייסים להגדרת תפקידים, Key Success Factors וסדרי עדיפויות בהתאם ליעדים העסקיים.",
            "שימוש ב-ATS ובאנליטיקה לשיפור time-to-hire ו-quality-of-hire, והטמעת כלי AI מתקדמים בתהליכי הגיוס ובתרבות הארגונית.",
        ],
        num_id,
    )

    add_role_block(
        doc,
        "Yotpo | Talent Acquisition Coordinator",
        "2021 - 2023 | משך משוער: כ-2 שנים",
        [
            "תמיכה בחמישה מגייסים באמצעות תיאום יומנים וראיונות, תקשורת עם מועמדים ומעקב אחר משימות ותהליכים.",
            "ניהול חוויית המועמד מקצה לקצה, לרבות סינון קורות חיים וראיונות טלפוניים ראשוניים.",
            "מעקב ודיווח אחר מדדי גיוס, איסוף פידבק וסיוע בתקשורת הנוגעת להצעות עבודה.",
        ],
        num_id,
    )

    add_role_block(
        doc,
        "DriveNets | Talent Acquisition Coordinator & People Operations Specialist",
        "2018 - 2021 | משך משוער: כ-3 שנים",
        [
            "עבודה יומיומית עם מועמדים, מגייסים ומנהלים בתפקידים בישראל ובעולם; ראיונות טלפוניים, תיאום ראיונות טכניים וניהוליים ומעקב מלא.",
            "ניהול תהליך הגיוס, לרבות ישיבות סיכום ופנייה לממליצים, תוך שימוש במערכות Monday ו-Comeet.",
            "בניית מערכת יחסים שקופה ואמינה עם מועמדים ושיפור חוויית המועמד לאורך התהליך.",
            "תכנון וניהול פעילויות People Experience, בהן אירועי חברה, הרמות כוסית, ארוחות ומתנות.",
        ],
        num_id,
    )

    add_role_block(
        doc,
        "yes | People Experience Specialist & HR Coordinator",
        "2013 - 2018 | משך כולל בארגון: כ-5 שנים; חלוקת השנים בין שני הכובעים אינה מצוינת בקורות החיים",
        [
            "אחריות מקצה לקצה על תוכנית הרווחה והמוטיבציה השנתית של החטיבה: אירועים, מתנות, חגים ופעילויות גיבוש, כולל תקציב וספקים.",
            "מעורבות במחזור חיי העובד - גיוס, פיתוח קריירה, ניוד פנימי וקידומים, וכן טיפול בנושאים אישיים.",
            "יישום פעילויות רווחה בארבעה אתרים ותמיכה ב-HRBP בהכוונה, ייעוץ וליווי מנהלים ועובדים בנושאי HR.",
            "ניתוח רבעוני של נתוני HR עבור הנהלת החטיבה, עבודה מול ממשקים רבים וסיוע בפרויקטים מטעם המנכ\"ל הזמני.",
        ],
        num_id,
    )

    add_heading(doc, "סיכום", 1)
    p = doc.add_paragraph()
    set_rtl_paragraph(p)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.10
    sr = p.add_run(
        "הניסיון המצטבר מציג התפתחות מקצועית ברורה מעולמות הרווחה וחוויית העובד אל People Operations ואל הובלת גיוס, "
        "עם שילוב חזק של יכולות תפעול, שותפות עם מנהלים, אוריינטציה נתונית וחדשנות טכנולוגית."
    )
    set_run_font(sr, size=11, color=BLACK)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print("DOCX_CREATED")


if __name__ == "__main__":
    build_document()
