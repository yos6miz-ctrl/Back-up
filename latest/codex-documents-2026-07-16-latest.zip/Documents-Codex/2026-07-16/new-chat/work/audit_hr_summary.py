import os
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Inches, Pt
from lxml import etree


p = Path(os.environ["DOCX_PATH"])
errors = []


def expect(condition, message):
    if not condition:
        errors.append(message)


with ZipFile(p) as z:
    bad = z.testzip()
    if bad:
        errors.append(f"bad_zip_member:{bad}")
    for name in z.namelist():
        if name.endswith((".xml", ".rels")):
            try:
                etree.fromstring(z.read(name))
            except Exception as exc:
                errors.append(f"xml:{name}:{exc}")

doc = Document(p)
sec = doc.sections[0]
expect(len(doc.sections) == 1, f"sections={len(doc.sections)}")
expect(sec.page_width == Inches(8.5), f"page_width={sec.page_width}")
expect(sec.page_height == Inches(11), f"page_height={sec.page_height}")
expect(
    all(x == Inches(1) for x in (sec.top_margin, sec.bottom_margin, sec.left_margin, sec.right_margin)),
    "margins_not_1in",
)
expect(len(doc.tables) == 2, f"tables={len(doc.tables)}")

style_checks = {
    "Normal": (11, 0, 6),
    "Heading 1": (16, 16, 8),
    "Heading 2": (13, 12, 6),
    "Heading 3": (12, 8, 4),
}
for name, (size, before, after) in style_checks.items():
    style = doc.styles[name]
    expect(round(style.font.size.pt, 2) == size, f"{name}_size={style.font.size.pt}")
    expect(round((style.paragraph_format.space_before or Pt(0)).pt, 2) == before, f"{name}_before")
    expect(round((style.paragraph_format.space_after or Pt(0)).pt, 2) == after, f"{name}_after")

for table_index, table in enumerate(doc.tables, 1):
    properties = table._tbl.tblPr
    width_node = properties.find(qn("w:tblW"))
    indent_node = properties.find(qn("w:tblInd"))
    grid_widths = [int(col.get(qn("w:w"))) for col in table._tbl.tblGrid.findall(qn("w:gridCol"))]
    expect(
        width_node is not None
        and width_node.get(qn("w:w")) == "9360"
        and width_node.get(qn("w:type")) == "dxa",
        f"table{table_index}_tblW",
    )
    expect(indent_node is not None and indent_node.get(qn("w:w")) == "120", f"table{table_index}_tblInd")
    expect(sum(grid_widths) == 9360, f"table{table_index}_grid_sum={sum(grid_widths)}")
    for row_index, row in enumerate(table.rows):
        row_widths = []
        for cell_xml in row._tr.findall(qn("w:tc")):
            width = cell_xml.find(qn("w:tcPr") + "/" + qn("w:tcW"))
            if width is not None:
                row_widths.append(int(width.get(qn("w:w"))))
        expect(row_widths == grid_widths, f"table{table_index}_row{row_index}_widths={row_widths}")

body_paragraphs = list(doc.paragraphs)
all_paragraphs = body_paragraphs + [
    paragraph
    for table in doc.tables
    for row in table.rows
    for cell in row.cells
    for paragraph in cell.paragraphs
]
text = "\n".join(paragraph.text for paragraph in all_paragraphs)
required = [
    "כ-13 שנים",
    "כ-8 שנים",
    "Talent Acquisition Specialist",
    "DriveNets",
    "Greenhouse",
    "אוניברסיטת בר-אילן",
    "חלוקת השנים בין שני הכובעים אינה מצוינת",
]
for item in required:
    expect(item in text, f"missing:{item}")
for marker in ("[[", "{{", "turn0", "codex-file-citation", "PLACEHOLDER", "TODO"):
    expect(marker not in text, f"placeholder:{marker}")

numbered_count = 0
fake_bullets = []
rtl_missing = []
for index, paragraph in enumerate(all_paragraphs):
    properties = paragraph._p.pPr
    if properties is not None and properties.find(qn("w:numPr")) is not None:
        numbered_count += 1
    stripped = paragraph.text.strip()
    if stripped.startswith(("•", "- ")):
        fake_bullets.append(stripped[:50])
    if stripped and (properties is None or properties.find(qn("w:bidi")) is None):
        style_bidi = None
        if paragraph.style:
            style_properties = paragraph.style.element.get_or_add_pPr()
            style_bidi = style_properties.find(qn("w:bidi"))
        if style_bidi is None:
            rtl_missing.append((index, paragraph.style.name if paragraph.style else "", stripped[:40]))

expect(numbered_count == 15, f"numbered_bullets={numbered_count}")
expect(not fake_bullets, f"fake_bullets={fake_bullets}")
expect(not rtl_missing, f"rtl_missing={rtl_missing[:5]}")

print(f"FILE_BYTES={p.stat().st_size}")
print(f"BODY_PARAGRAPHS={len(body_paragraphs)} TABLES={len(doc.tables)} REAL_BULLETS={numbered_count}")
print(f"TEXT_CHARS={len(text)}")
print("AUDIT=" + ("PASS" if not errors else "FAIL"))
for error in errors:
    print("ERROR", error)
