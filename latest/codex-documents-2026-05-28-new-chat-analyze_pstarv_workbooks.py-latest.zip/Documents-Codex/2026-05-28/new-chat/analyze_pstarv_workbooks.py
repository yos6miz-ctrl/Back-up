from pathlib import Path
import re
import json
import statistics as stats

from openpyxl import load_workbook

ROOT = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")


def fmt(v):
    if v is None:
        return ""
    if isinstance(v, float):
        return round(v, 4)
    return str(v)


def dump_rows(path, n=36, max_col=26):
    wb = load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    print("\n==", path.name, "==")
    print("sheets", wb.sheetnames, "max", ws.max_row, ws.max_column, "charts", len(ws._charts))
    for r in range(1, min(n, ws.max_row) + 1):
        row = [fmt(ws.cell(r, c).value) for c in range(1, min(max_col, ws.max_column) + 1)]
        print(r, json.dumps(row, ensure_ascii=False))


for path in sorted(ROOT.glob("*P starv*.xlsx"), key=lambda x: x.stat().st_mtime):
    dump_rows(path)


def summarize_endpoint_new(path):
    wb = load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    print("\nEndpoint NEW summary")
    for c, h in enumerate(headers, 1):
        if h and "puxpB" in str(h):
            growth = [ws.cell(r, c).value for r in range(2, 6) if isinstance(ws.cell(r, c).value, (int, float))]
            fluo = [ws.cell(r, c).value for r in range(8, 12) if isinstance(ws.cell(r, c).value, (int, float))]
            if growth and fluo:
                print(h, "OD", round(stats.mean(growth), 4), "GFP", round(stats.mean(fluo), 1), "GFP/OD", round(stats.mean(fluo)/stats.mean(growth), 1))


def summarize_17(path):
    wb = load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    print("\n17.8 summary")
    for c, h in enumerate(headers, 1):
        if h and "puxpB" in str(h):
            growth = [ws.cell(r, c).value for r in range(2, 6) if isinstance(ws.cell(r, c).value, (int, float))]
            fluo = [ws.cell(r, c).value for r in range(8, 12) if isinstance(ws.cell(r, c).value, (int, float))]
            print(h, "OD", round(stats.mean(growth), 4), "GFP", round(stats.mean(fluo), 1), "GFP/OD", round(stats.mean(fluo)/stats.mean(growth), 1))


summarize_17(ROOT / "YOSSI P starv 17.8.26.xlsx")
summarize_endpoint_new(ROOT / "YOSSI  P starv 18.8 NEW.xlsx")
