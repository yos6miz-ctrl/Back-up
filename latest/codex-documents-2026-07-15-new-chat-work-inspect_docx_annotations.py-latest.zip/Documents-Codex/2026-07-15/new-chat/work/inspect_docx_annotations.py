from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

from lxml import etree


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}


def text_of(node: etree._Element) -> str:
    return "".join(node.xpath(".//w:t/text() | .//w:delText/text()", namespaces=NS))


def inspect(path: Path) -> dict:
    rows: list[dict] = []
    with zipfile.ZipFile(path) as zf:
        xml_parts = [
            name
            for name in zf.namelist()
            if name == "word/document.xml"
            or name.startswith("word/header") and name.endswith(".xml")
            or name.startswith("word/footer") and name.endswith(".xml")
            or name.startswith("word/footnotes") and name.endswith(".xml")
            or name.startswith("word/endnotes") and name.endswith(".xml")
        ]
        for part in xml_parts:
            root = etree.fromstring(zf.read(part))
            paragraphs = root.xpath(".//w:p", namespaces=NS)
            for idx, paragraph in enumerate(paragraphs):
                highlights = []
                for run in paragraph.xpath(".//w:r", namespaces=NS):
                    highlight = run.find("w:rPr/w:highlight", NS)
                    if highlight is not None:
                        highlights.append(
                            {
                                "color": highlight.get(f"{{{W}}}val"),
                                "text": text_of(run),
                            }
                        )
                comment_ids = sorted(
                    {
                        n.get(f"{{{W}}}id")
                        for n in paragraph.xpath(
                            ".//w:commentRangeStart | .//w:commentRangeEnd | .//w:commentReference",
                            namespaces=NS,
                        )
                        if n.get(f"{{{W}}}id") is not None
                    }
                )
                if highlights or comment_ids:
                    rows.append(
                        {
                            "part": part,
                            "paragraph_index": idx,
                            "paragraph_text": text_of(paragraph),
                            "highlights": highlights,
                            "comment_ids": comment_ids,
                            "has_drawing": bool(paragraph.xpath(".//w:drawing | .//w:pict", namespaces=NS)),
                        }
                    )
        counts: dict[str, int] = {}
        for row in rows:
            for item in row["highlights"]:
                counts[item["color"]] = counts.get(item["color"], 0) + 1
        return {"file": str(path), "highlight_run_counts": counts, "annotated_paragraphs": rows}


if __name__ == "__main__":
    source = Path(sys.argv[1])
    result = inspect(source)
    print(json.dumps(result, indent=2, ensure_ascii=False))
