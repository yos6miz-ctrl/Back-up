$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$base = Join-Path $env:USERPROFILE ".codex\אדמה ירוקה"
$source = Join-Path $base "דוח טכנולוגי - טיוטה ממולאת V3.doc"
$output = Join-Path $base "V2\דוח טכנולוגי - גרסת נתוני הרעבה מעודכנת.doc"
$pdfOutput = Join-Path $base "V2\דוח טכנולוגי - גרסת נתוני הרעבה מעודכנת.pdf"
$workspace = "C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat"
$figBase = Join-Path $workspace "adama_v3_figures"
$chartBase = Join-Path $workspace "starvation_chart_exports"
$plasmidMap = Join-Path $workspace "plasmid_map_deck.jpg"

function Set-CellText {
    param($Table, [int]$Row, [int]$Column, [string]$Text)
    $range = $Table.Cell($Row, $Column).Range
    $range.End--
    $range.Text = $Text
    $range.ParagraphFormat.ReadingOrder = 1
    $range.ParagraphFormat.Alignment = 2
    $range.Font.Name = "Arial"
    $range.Font.NameBi = "Arial"
    $range.Font.Size = 10
    $range.Font.SizeBi = 10
}

function Append-Paragraph {
    param($Cell, [string]$Text, [int]$FontSize = 10, [bool]$Bold = $false)
    $range = $Cell.Range
    $range.End--
    $range.Collapse(0)
    $range.InsertAfter("`r" + $Text)
    $range.Font.Name = "Arial"
    $range.Font.NameBi = "Arial"
    $range.Font.Size = $FontSize
    $range.Font.SizeBi = $FontSize
    $range.Font.Bold = $(if ($Bold) { 1 } else { 0 })
    $range.ParagraphFormat.ReadingOrder = 1
    $range.ParagraphFormat.Alignment = 2
}

function Append-Picture {
    param($Doc, $Cell, [string]$Path, [string]$Caption, [double]$WidthPoints = 430)
    Append-Paragraph $Cell $Caption 9 $true
    $range = $Cell.Range
    $range.End--
    $range.Collapse(0)
    $range.InsertParagraphAfter()
    $range.Collapse(0)
    $pic = $Doc.InlineShapes.AddPicture($Path, $false, $true, $range)
    $pic.LockAspectRatio = -1
    $pic.Width = $WidthPoints
    Append-Paragraph $Cell "" 8 $false
}

$word = $null
$doc = $null
try {
    Copy-Item -LiteralPath $source -Destination $output -Force
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Open($output, $false, $false, $false)

    if ($doc.Comments.Count -gt 0) { $doc.DeleteAllComments() }

    $detectorDescription = "נבנו ונבדקו דטקטורים לתנאי הרעבה. בניסוי מיום 10.6.2026 בוצעה מדידה קינטית של ביטוי מנורמל עבור pvdA תחת סדרת ריכוזי ברזל ועבור glnK תחת סדרת ריכוזי חנקן. בשני הדטקטורים התקבלה תגובת מינון ברורה: ככל שריכוז היסוד ירד, האות עלה. ב-13.3 שעות אות pvdA עלה מ-28,182 ב-20 mM Fe ל-244,316 ללא ברזל, ואות glnK עלה מ-11,819 ב-10 mM N ל-202,038 ב-2 mM N. עבור פוספט נבדקו שני פרומוטורים ללא תגובה ספציפית מספקת, ולכן נבנה קונסטרקט שלישי."
    Set-CellText $doc.Tables.Item(8) 3 6 $detectorDescription

    $milestoneStatus = "בביצוע. דטקטורי pvdA לברזל ו-glnK לחנקן הציגו תגובת מינון קינטית ברורה בסדרת ריכוזים. ב-13.3 שעות התקבלו אותות מרביים של 244,316 ללא ברזל ושל 202,038 ב-2 mM חנקן. עבור פוספט נבדקו שני פרומוטורים ללא ספציפיות מספקת וקונסטרקט שלישי נמצא בבנייה. דטקטור האלקנים נמצא בבנייה. מועד אבן הדרך טרם הגיע."
    Set-CellText $doc.Tables.Item(10) 2 4 $milestoneStatus

    $achTable = $doc.Tables.Item(11)
    $achCell = $achTable.Cell(1,1)
    $baseText = $achCell.Range.Text -replace "`r`a$", ""
    $figureStart = $baseText.IndexOf("איור 1.")
    if ($figureStart -ge 0) { $baseText = $baseText.Substring(0, $figureStart).TrimEnd() }
    $oldResultPattern = "במדידות קינטיות מנורמלות ל-OD595 התקבלה תגובה חזקה וברורה לדטקטור ברזל ולדטקטור חנקן ביחס לביקורת M9 מתאימה לכל דטקטור\."
    $newResultText = "בניסוי העדכני מיום 10.6.2026 בוצעה מדידה קינטית מנורמלת לדטקטור pvdA תחת סדרת ריכוזי ברזל ולדטקטור glnK תחת סדרת ריכוזי חנקן. נצפתה תגובת מינון ברורה: ב-13.3 שעות אות pvdA עלה מ-28,182 ב-20 mM Fe ל-244,316 ללא ברזל, ואות glnK עלה מ-11,819 ב-10 mM N ל-202,038 ב-2 mM N. התוצאות תומכות בפעילות הדטקטורים ובהגברת האות עם החמרת ההרעבה."
    $baseText = [regex]::Replace($baseText, $oldResultPattern, $newResultText)
    Set-CellText $achTable 1 1 $baseText
    $achCell = $achTable.Cell(1,1)

    Append-Picture $doc $achCell (Join-Path $figBase "enzyme_strain_rejection_gc.png") "איור 1. סינון רצפי האנזימים המקוריים: הרצפים נדחו לביטוי ישיר ב-P. putida עקב GC נמוך וחוסר התאמה למאכסן." 420
    Append-Picture $doc $achCell (Join-Path $figBase "upo19_construction_workflow.png") "איור 2. אסטרטגיית בניית UPO19 מותאם: שמירת רצף החלבון, אופטימיזציית קודונים, אות הפרשה ו-His-tag." 430
    Append-Picture $doc $achCell $plasmidMap "איור 3. קונסטרקטים ראשוניים של UPO19 במערכות pJN105 ו-pBBR1mcs-2." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "pvdA_Fe_response.png") "איור 4. תגובת דטקטור pvdA לאורך זמן תחת סדרת ריכוזי ברזל. הירידה בזמינות הברזל מלווה בעלייה באות המנורמל." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "glnK_N_response.png") "איור 5. תגובת דטקטור glnK לאורך זמן תחת סדרת ריכוזי חנקן. הירידה בריכוז החנקן מלווה בעלייה באות המנורמל." 430
    Append-Picture $doc $achCell (Join-Path $chartBase "normalized_expression_13_3h.png") "איור 6. השוואת הביטוי המנורמל לאחר 13.3 שעות בכל תנאי הברזל והחנקן שנבדקו." 430

    $doc.Save()
    Write-Output ("OUTPUT={0}" -f $output)
    Write-Output ("PAGES={0}" -f $doc.ComputeStatistics(2))
    Write-Output ("INLINE_SHAPES={0}" -f $doc.InlineShapes.Count)
    Write-Output ("COMMENTS={0}" -f $doc.Comments.Count)
    $doc.Close($false)
    $word.Quit()
}
finally {
    if ($doc) { [Runtime.InteropServices.Marshal]::ReleaseComObject($doc) | Out-Null }
    if ($word) { [Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
