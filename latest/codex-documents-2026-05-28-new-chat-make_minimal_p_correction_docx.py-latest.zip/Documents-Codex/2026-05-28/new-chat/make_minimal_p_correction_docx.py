from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.enum.text import WD_BREAK
from docx.table import Table


PROJECT = "\u05d0\u05d3\u05de\u05d4 \u05d9\u05e8\u05d5\u05e7\u05d4"
BASE_DIR = (
    Path.home()
    / "OneDrive - Bar Ilan University (1)"
    / "Banin Lab Files"
    / "Lab members"
    / "Yosi"
    / "sensor"
    / PROJECT
    / "Detectors"
    / "starvation"
)
SOURCE = BASE_DIR / "M9 5.docx"
OUTPUT = BASE_DIR / "M9 5 - minimal P correction.docx"


def set_table_text(table, rows: list[list[str]]) -> None:
    while len(table.rows) > len(rows):
        row = table.rows[-1]
        row._element.getparent().remove(row._element)
    while len(table.rows) < len(rows):
        table.add_row()
    for r_idx, row_values in enumerate(rows):
        cells = table.rows[r_idx].cells
        for c_idx, value in enumerate(row_values):
            cells[c_idx].text = value


def paragraph_after(element, text: str, style=None):
    p = element.add_paragraph()
    p.text = text
    if style is not None:
        p.style = style
    p_xml = p._p
    p_xml.getparent().remove(p_xml)
    element._body._body.append(p_xml)
    return p


def move_block_after(block, anchor):
    block_xml = block._element
    block_xml.getparent().remove(block_xml)
    anchor.addnext(block_xml)
    return block_xml


def main() -> None:
    doc = Document(SOURCE)

    p_table = doc.tables[2]
    p_rows = [
        ["Component", "MW", "Final conc. in 5x", "Grams for 250 mL"],
        ["NH4Cl", "53.491", "100 mM", "1.34 g"],
        ["NaCl", "58.44", "43 mM", "0.63 g"],
        ["KCl", "74.55", "99 mM", "1.85 g"],
        ["Dextrose / Glucose", "180.16", "55 mM", "2.48 g"],
        ["MOPS", "209.26", "250 mM", "13.08 g"],
    ]
    set_table_text(p_table, p_rows)

    # Insert a minimal stock-prep block immediately after the M9 -P table,
    # cloning the original table formatting so the document keeps its format.
    page_break = doc.add_paragraph()
    page_break.add_run().add_break(WD_BREAK.PAGE)
    move_block_after(page_break, p_table._element)

    heading = doc.add_paragraph("100 mM phosphate stock")
    heading.style = doc.paragraphs[6].style
    move_block_after(heading, page_break._p)

    stock_tbl_xml = deepcopy(p_table._element)
    heading._p.addnext(stock_tbl_xml)
    stock_table = Table(stock_tbl_xml, p_table._parent)
    stock_rows = [
        ["Component", "MW", "Final conc. in stock", "Amount for 10 mL"],
        ["Na2HPO4", "141.96", "35.3 mM", "50.1 mg"],
        ["KH2PO4", "136.08", "64.7 mM", "88.0 mg"],
    ]
    set_table_text(stock_table, stock_rows)

    note = doc.add_paragraph("Prepare in ddH2O, adjust pH to 7.0-7.2 if needed, bring to 10 mL, and sterile-filter. For M9 -P, add phosphate separately from this stock if needed.")
    note.style = doc.paragraphs[9].style
    move_block_after(note, stock_table._element)

    doc.save(OUTPUT)
    print(str(OUTPUT).encode("unicode_escape").decode("ascii"))


if __name__ == "__main__":
    main()
