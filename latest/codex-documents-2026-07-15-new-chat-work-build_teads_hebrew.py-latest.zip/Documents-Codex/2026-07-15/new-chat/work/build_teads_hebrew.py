from __future__ import annotations

import re
import zipfile
from copy import deepcopy
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor


ROOT = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-07-15\new-chat")
SOURCE = ROOT / "outputs" / "Teads_TA_Interview_Assignment_clean_English.docx"
OUTPUT = ROOT / "outputs" / "Teads_TA_Interview_Assignment_clean_Hebrew.docx"
TEMP = ROOT / "work" / "Teads_TA_Interview_Assignment_clean_Hebrew_temp.docx"
ASSETS = ROOT / "work" / "assets"


HE = {
    # Cover and section navigation.
    "LEAD TECHNICAL TALENT\nACQUISITION SPECIALIST": "מוביל/ת גיוס\nטאלנט טכנולוגי",
    "Interview assignment • Israel, France & Slovenia": "מטלת ראיון • ישראל, צרפת וסלובניה",
    "PART 1": "חלק 1",
    "Source five prospects for the Cloud Engineer — platform-focused role—and build the market around them": "איתור חמישה מועמדים לתפקיד Cloud Engineer — platform-focused ובניית מפת השוק סביבם",
    "Exact sourcing searches": "חיפושים מדויקים לאיתור מועמדים",
    "SEARCH": "חיפוש",
    "EXACT QUERY": "שאילתה מדויקת",
    "LinkedIn Boolean": "LinkedIn Boolean",
    "Google X-ray": "Google X-ray",
    "Filters: Israel; current or past Platform, SRE or DevOps titles; 5–12 years as a guide; relevant companies. Use Open to Work only to prioritize. Never filter on protected characteristics.": "מסננים: ישראל; תפקידי Platform, SRE או DevOps בהווה או בעבר; 5–12 שנות ניסיון כאינדיקציה בלבד; חברות רלוונטיות. יש להשתמש ב-Open to Work רק לצורך תעדוף, ולעולם לא לסנן לפי מאפיינים מוגנים.",
    "Simple sourcing process": "תהליך איתור מועמדים פשוט",
    "1. Define must-haves → 2. Map target companies → 3. Search LinkedIn/Google/GitHub → 4. Use AI to organize evidence → 5. Manually check → 6. Contact candidates.": "1. הגדרת דרישות חובה\n2. מיפוי חברות יעד\n3. חיפוש ב-LinkedIn, ב-Google וב-GitHub\n4. שימוש ב-AI לארגון הראיות\n5. בדיקה ידנית\n6. פנייה למועמדים.",
    "Tools: LinkedIn Recruiter, Google X-ray, GitHub Search, ChatGPT/Claude, Greenhouse.": "כלים: LinkedIn Recruiter, Google X-ray, GitHub Search, ChatGPT/Claude, Greenhouse.",
    "Company adjacency map": "מפת חברות סמוכות",
    "PART 1 • SHORTLIST": "חלק 1 • רשימה מצומצמת",
    "Five prospects to validate": "חמישה מועמדים לבדיקה",
    "Exact LLM evidence prompt": "פרומפט מדויק לבדיקת ראיות באמצעות LLM",
    "AI-assisted hidden talent-pool discovery prompt": "פרומפט AI לאיתור מאגרי טאלנט סמויים",
    "Multi-channel local campaign • 16-day sequence": "קמפיין מקומי רב-ערוצי • רצף של 16 ימים",
    "PART 2 • DATA VISIBILITY & REPORTING": "חלק 2 • נראות נתונים ודיווח",
    "Exact metrics, definitions and decision rules": "מדדים, הגדרות וכללי החלטה מדויקים",
    "The preceding landscape page is the requested standalone stakeholder one-pager; the definitions below make it consistent across Product, R&D, Israel, France and Slovenia.": "עמוד הרוחב הקודם הוא ה-One-Pager העצמאי שנועד לבעלי העניין; ההגדרות שלהלן יוצרות אחידות בין Product, R&D, ישראל, צרפת וסלובניה.",
    "What the weekly hiring dashboard should show": "מה צריך להופיע בדשבורד הגיוס השבועי",
    "PART 2 • FUNNEL DESIGN": "חלק 2 • תכנון משפך",
    "Separate funnels, explicit math": "משפכים נפרדים וחישוב מפורש",
    "Each target-state cohort back-solves from three accepts. Sourced quality and fast decisions must improve together.": "כל קוהורט יעד מחושב לאחור משלוש קבלות להצעה. איכות האיתור ומהירות ההחלטה חייבות להשתפר יחד.",
    "Product track • illustrative monthly target": "מסלול Product • יעד חודשי להמחשה",
    "R&D track • illustrative monthly target": "מסלול R&D • יעד חודשי להמחשה",
    "Target elapsed time: ~31 calendar days if stages flow without queues. The largest designed choke point is case/panel → offer; monitor panel hours, case withdrawal and candidate-stated offer-decline reasons separately.": "זמן יעד כולל: כ-31 ימים קלנדריים כאשר אין המתנה בין שלבים. צוואר הבקבוק המרכזי הוא תרגיל/פאנל ← הצעה; יש למדוד בנפרד שעות פאנל, פרישה מהתרגיל וסיבות דחיית הצעה כפי שנמסרו על ידי המועמד/ת.",
    "Target elapsed time: ~34 calendar days. Track candidate-stated offer-decline reasons separately from panel rejections and approval delays.": "זמן יעד כולל: כ-34 ימים קלנדריים. יש למדוד סיבות דחיית הצעה כפי שנמסרו על ידי המועמד/ת בנפרד מדחייה בפאנל ומעיכובי אישור.",
    "PART 2 • BOTTLENECKS": "חלק 2 • צווארי בקבוק",
    "Where Teads is most likely to lose time—and the practical fix": "היכן Teads צפויה לאבד זמן — ומהו הפתרון המעשי",
    "Location-aware operating choices": "החלטות תפעוליות לפי מיקום",
    "PART 3 • LOCAL EMPLOYER BRANDING": "חלק 3 • מיתוג מעסיק מקומי",
    "Teads Israel: current status and action plan": "Teads ישראל: תמונת מצב ותוכנית פעולה",
    "A focused assessment of the local employer brand, followed by short-term actions and long-term community plays.": "בחינה ממוקדת של מותג המעסיק המקומי, ולאחריה פעולות קצרות טווח ומהלכים קהילתיים ארוכי טווח.",
    "Current-status audit — what candidates can see today": "בדיקת מצב נוכחי — מה מועמדים יכולים לראות היום",
    "This audit compares publicly visible employer-brand strengths with gaps that may affect candidate trust and conversion. ‘Public proof’ is evidence already visible to candidates; ‘gap / risk’ is a hypothesis Teads should validate with employees, candidate feedback and recruiting data before using it in messaging.": "הבדיקה משווה בין חוזקות של מותג המעסיק הנראות לציבור לבין פערים שעשויים להשפיע על אמון המועמדים ועל ההמרה. ״הוכחה ציבורית״ היא מידע שכבר גלוי למועמדים; ״פער / סיכון״ הוא השערה שעל Teads לאמת באמצעות עובדים, משוב מועמדים ונתוני גיוס לפני שימוש במסרים.",
    "PART 3 • ACTION PLAN": "חלק 3 • תוכנית פעולה",
    "Short-term, low-cost actions and long-term plays": "פעולות קצרות טווח ובעלות נמוכה לצד מהלכים ארוכי טווח",
    "Potential partners: AWS User Group Israel, DevOpsDays Tel Aviv, she codes, Tsofen, Olim in Tech and Israel Tech Challenge. Partnership requires co-design, consent and reciprocal value—not extracting candidate lists.": "שותפים אפשריים: AWS User Group Israel, DevOpsDays Tel Aviv, she codes, Tsofen, Olim in Tech ו-Israel Tech Challenge. שותפות דורשת תכנון משותף, הסכמה וערך הדדי — לא איסוף רשימות מועמדים.",
    "Three employer-brand ideas to test": "שלושה רעיונות למיתוג מעסיק שכדאי לבדוק",

    # Cover cards and Part 1 calibration.
    "Market mapping\nCloud Engineer — platform-focused": "מיפוי שוק\nCloud Engineer — platform-focused",
    "Stakeholder one-pager\nTech & Product": "One-Pager לבעלי עניין\nTech & Product",
    "Employer brand\nIsrael": "מיתוג מעסיק\nישראל",
    "Role calibration": "כיול התפקיד",
    "Must-have evidence: substantial AWS or Azure workloads, Terraform/IaC, programming and automation, design/documentation, and collaboration. Bonus evidence: highly available high-traffic multi-region systems and adtech/e-commerce. The work connects AWS/Azure to on-prem, global networking and automated provisioning.": "ראיות חובה: עבודה משמעותית עם AWS או Azure, ‏Terraform/IaC, תכנות ואוטומציה, תכנון/תיעוד ושיתוף פעולה. יתרון: מערכות מרובות אזורים, עתירות תעבורה ובזמינות גבוהה, וכן adtech/e-commerce. התפקיד מחבר AWS/Azure לסביבות on-prem, לרשת גלובלית ולהקצאה אוטומטית.",
    "TIER": "רמה",
    "TARGET COMPANIES": "חברות יעד",
    "WHY": "למה",
    "1 • Adtech / high scale": "1 • Adtech / קנה מידה גבוה",
    "2 • Platform / infrastructure": "2 • Platform / תשתיות",
    "3 • Commerce / fintech": "3 • מסחר / פינטק",
    "Closest domain, streaming, bidding/measurement and latency parallels.": "הדמיון הגבוה ביותר בדומיין, streaming, bidding/measurement ו-latency.",
    "Large SaaS, hybrid estates, networking, developer platforms and operational rigor.": "SaaS בקנה מידה גדול, סביבות hybrid, רשתות, פלטפורמות מפתחים ומשמעת תפעולית.",
    "Multi-region availability, regulated workloads, traffic spikes and production ownership.": "זמינות מרובת אזורים, עומסים מפוקחים, קפיצות תעבורה ואחריות על production.",
    "PUBLIC EVIDENCE": "ראיות ציבוריות",
    "VALIDATE": "מה לאמת",
    "OUTREACH ANGLE": "זווית פנייה",
    "PROVISIONAL FIT": "התאמה ראשונית",

    # Candidate evidence and outreach.
    "Senior DevOps & Platform Engineer / Cloud Infrastructure Architect; Israel. Strongest explicit multi-cloud, IaC and network-testing evidence in the public profile.": "Senior DevOps & Platform Engineer / Cloud Infrastructure Architect בישראל. בפרופיל הציבורי מופיעות הראיות המפורשות החזקות ביותר ל-multi-cloud, ‏IaC ובדיקות רשת.",
    "Public profile references AWS, Azure, Kubernetes and Terraform.": "הפרופיל הציבורי מציין AWS, Azure, Kubernetes ו-Terraform.",
    "Content includes Terratest/Go and AKS/EKS/GKE.": "התוכן כולל Terratest/Go ו-AKS/EKS/GKE.",
    "Network evidence includes VNet/subnets/private link testing.": "ראיות הרשת כוללות בדיקות VNet, ‏subnets ו-private link.",
    "Depth at high traffic and multi-region operations.": "עומק בעבודה עם תעבורה גבוהה ותפעול multi-region.",
    "On-prem integration and current hands-on IC scope.": "אינטגרציה עם on-prem והיקף העבודה המעשי הנוכחי כ-IC.",
    "Availability and Netanya hybrid fit.": "זמינות והתאמה למודל ההיברידי בנתניה.",
    "The rare multi-cloud + testable infrastructure problem: build safe provisioning and networking across three public clouds and data centers.": "אתגר נדיר של multi-cloud ותשתיות ניתנות לבדיקה: בניית provisioning ורשת בטוחים בשלושה עננים ציבוריים ובמרכזי נתונים.",
    "AppsFlyer platform engineer in Israel; directly adjacent advertising/measurement environment with Kubernetes and Kafka reliability signals.": "מהנדס/ת Platform ב-AppsFlyer בישראל; סביבה סמוכה ישירות לעולמות פרסום ומדידה, עם סימני אמינות ב-Kubernetes וב-Kafka.",
    "Platform engineering and cloud-based solutions in public summary.": "בתקציר הציבורי מופיעים platform engineering ופתרונות מבוססי cloud.",
    "AppsFlyer platform group combines software and DevOps.": "קבוצת ה-Platform ב-AppsFlyer משלבת software ו-DevOps.",
    "Published/shared work on Kubernetes stateful applications and Kafka leader-election trade-offs.": "עבודה שפורסמה או שותפה על יישומי Kubernetes stateful ועל trade-offs בבחירת leader ב-Kafka.",
    "Terraform and AWS/Azure depth.": "עומק ב-Terraform וב-AWS/Azure.",
    "Global networking / on-prem experience.": "ניסיון ברשת גלובלית וב-on-prem.",
    "Current level, location and interest.": "רמה נוכחית, מיקום ועניין בתפקיד.",
    "Move from adjacent adtech scale to a foundation role where reliability choices affect approximately 2 million ad requests/second and four engineering hubs.": "מעבר מסקייל adtech סמוך לתפקיד תשתית בסיס, שבו החלטות אמינות משפיעות על כ-2 מיליון בקשות פרסום בשנייה ועל ארבעה מרכזי פיתוח.",
    "FundGuard DevOps engineer in Israel with unusually specific public evidence across AWS, EKS, networking, FinOps and incidents.": "מהנדס/ת DevOps ב-FundGuard בישראל, עם ראיות ציבוריות מפורטות במיוחד ל-AWS, ‏EKS, רשתות, FinOps וטיפול בתקלות.",
    "Describes multi-region AWS failover and VPC-peering debugging.": "מתאר/ת failover ב-AWS בסביבת multi-region ו-debugging של VPC peering.",
    "Reports EKS cost work, on-call/SRE and Kafka incident ownership.": "מציג/ה עבודה על עלויות EKS, אחריות on-call/SRE ובעלות על תקלות Kafka.",
    "Hashtags and narrative reference Kubernetes, Terraform and infrastructure as code.": "ה-hashtags והתיאור מתייחסים ל-Kubernetes, ‏Terraform ול-infrastructure as code.",
    "Azure and on-prem evidence.": "ראיות ל-Azure ול-on-prem.",
    "Scale and architecture decision ownership.": "בעלות על החלטות ארכיטקטורה וקנה מידה.",
    "Current title/tenure and Netanya schedule.": "תפקיד וותק נוכחיים והתאמה ללוח העבודה בנתניה.",
    "A broader platform charter: turn ‘glue work’ into owned cloud-foundation products, standards and automation.": "מנדט Platform רחב יותר: להפוך ״עבודת חיבור״ למוצרי cloud foundation, סטנדרטים ואוטומציה בבעלות ברורה.",
    "Taboola DevOps/SRE in the Tel Aviv District; seven years of stated experience building scalable, secure and reliable systems in direct adtech adjacency.": "DevOps/SRE ב-Taboola באזור תל אביב; שבע שנות ניסיון מוצהרות בבניית מערכות מאובטחות, אמינות ו-scalable בסביבת adtech ישירה.",
    "Public summary explicitly states DevOps/SRE and seven years.": "התקציר הציבורי מציין במפורש DevOps/SRE ושבע שנות ניסיון.",
    "Taboola provides direct adtech/high-scale adjacency.": "Taboola מספקת התאמה ישירה ל-adtech ולקנה מידה גבוה.",
    "Public activity references Terraform/Pulumi, Kubernetes, GitOps, load balancing and networking topics.": "הפעילות הציבורית מתייחסת ל-Terraform/Pulumi, ‏Kubernetes, ‏GitOps, איזון עומסים ורשתות.",
    "Owned—not merely followed—technology evidence.": "ראיות לבעלות טכנולוגית — לא רק למעקב או השתתפות.",
    "AWS/Azure and hybrid networking depth.": "עומק ב-AWS/Azure וברשתות hybrid.",
    "Programming, current remit and commute.": "תכנות, תחום האחריות הנוכחי והגעה למשרד.",
    "A peer adtech infrastructure challenge with a wider multi-cloud/on-prem foundation remit and global hub collaboration.": "אתגר תשתיות adtech מקביל, עם אחריות רחבה יותר על multi-cloud/on-prem ושיתוף פעולה בין מרכזים גלובליים.",
    "Exploratory adjacent-pool prospect—included to demonstrate market expansion beyond direct adtech matches. Senior DevOps & Platform Engineer in Israel with AWS and cloud-native certification signals.": "מועמד/ת ניסיוני/ת ממאגר סמוך, שנכלל/ה כדי להדגים הרחבת שוק מעבר להתאמות adtech ישירות. Senior DevOps & Platform Engineer בישראל עם סימני הסמכה ב-AWS וב-cloud-native.",
    "Public profile highlights AWS and platform/DevOps work.": "הפרופיל הציבורי מדגיש AWS ועבודת Platform/DevOps.",
    "HashiCorp Terraform Associate, KCNA and AWS Solutions Architect certifications are listed.": "מופיעות הסמכות HashiCorp Terraform Associate, ‏KCNA ו-AWS Solutions Architect.",
    "Current-company context suggests self-hosted infrastructure exposure (inference).": "ההקשר של החברה הנוכחית מצביע על חשיפה אפשרית לתשתיות self-hosted (הסקה בלבד).",
    "Azure and enterprise-scale proof.": "ראיות ל-Azure ולקנה מידה ארגוני.",
    "Networking, multi-region and high-traffic ownership.": "בעלות על רשתות, multi-region ותעבורה גבוהה.",
    "Coding depth and Netanya practicality.": "עומק ב-coding והיתכנות עבודה בנתניה.",
    "Own the automation and reliability bridge between public cloud and self-managed infrastructure at measurable global scale.": "לקחת בעלות על גשר האוטומציה והאמינות בין public cloud לתשתיות בניהול עצמי, בקנה מידה גלובלי מדיד.",

    # Updated shortlist candidates.
    "Autodesk senior DevOps engineer in Israel with 7+ years of experience, public multi-region AWS automation evidence and relevant Computer Science academic education.": "מהנדס DevOps בכיר ב-Autodesk בישראל, עם יותר משבע שנות ניסיון, ראיות ציבוריות לאוטומציית AWS מרובת אזורים והשכלה אקדמית רלוונטית במדעי המחשב.",
    "LinkedIn states 7+ years in senior DevOps roles.": "LinkedIn מציין יותר משבע שנות ניסיון בתפקידי DevOps בכירים.",
    "Public material covers multi-region AWS-account deployments, IaC, Terraform and Spinnaker.": "תוכן ציבורי מתאר פריסות מרובות אזורים בין חשבונות AWS, וכן IaC, Terraform ו-Spinnaker.",
    "Computer Science B.Sc. study is listed at the College of Management Academic Studies.": "לימודי B.Sc. במדעי המחשב מופיעים במסלול האקדמי של המסלול האקדמי המכללה למינהל.",
    "Degree completion and current hands-on scope.": "השלמת התואר והיקף העבודה המעשית כיום.",
    "Azure, on-prem and production-networking depth.": "עומק ב-Azure, ב-on-prem וברשתות production.",
    "Own Teads' multi-cloud foundation, applying proven multi-region automation to global networking and provisioning at ad-serving scale.": "לקחת בעלות על תשתית ה-multi-cloud של Teads וליישם אוטומציה מוכחת מרובת אזורים ברשת גלובלית וב-provisioning בקנה המידה של פלטפורמת פרסום.",
    "Senior individual-contributor DevOps profile now at NVIDIA, with public SAP software-lifecycle experience and university education at Ben-Gurion University.": "פרופיל DevOps בכיר במסלול מומחה/ית מקצועי/ת, כיום ב-NVIDIA, עם ניסיון ציבורי במחזור חיי תוכנה ב-SAP והשכלה אוניברסיטאית באוניברסיטת בן-גוריון.",
    "LinkedIn describes senior DevOps work at SAP and software-lifecycle development.": "LinkedIn מתאר עבודת DevOps בכירה ב-SAP ופיתוח לאורך מחזור חיי התוכנה.",
    "Current NVIDIA and prior SAP experience provide large-enterprise engineering adjacency.": "הניסיון הנוכחי ב-NVIDIA והקודם ב-SAP מספק סמיכות לסביבות הנדסיות ארגוניות גדולות.",
    "Ben-Gurion University education is listed for 2007–2011.": "השכלה באוניברסיטת בן-גוריון מופיעה לשנים 2007–2011.",
    "Degree field/completion and current IC remit.": "תחום התואר, השלמתו והאחריות המקצועית הנוכחית כ-IC.",
    "AWS/Azure, Terraform, Kubernetes and networking depth.": "עומק ב-AWS/Azure, ב-Terraform, ב-Kubernetes וברשתות.",
    "Architecture ownership and Netanya schedule.": "בעלות על החלטות ארכיטקטורה והתאמה לשגרת העבודה בנתניה.",
    "Offer a hands-on step from enterprise lifecycle DevOps into ownership of Teads' global cloud foundation and reliability problems.": "להציע מעבר מעשי מ-DevOps של מחזור חיים ארגוני לבעלות על תשתית הענן הגלובלית ואתגרי האמינות של Teads.",
    "Tenure-matched Staff DevOps prospect in Israel: public experience records show every listed role lasting at least 2 years 4 months across Bitsight/Cybersixgill and Ex Libris.": "מועמד/ת Staff DevOps בישראל עם התאמה ליציבות תעסוקתית: רשומות ניסיון ציבוריות מציגות לפחות שנתיים וארבעה חודשים בכל תפקיד רשום ב-Bitsight/Cybersixgill וב-Ex Libris.",
    "Staff/Senior DevOps and cloud-production progression is public.": "התקדמות מתפקידי cloud-production ל-Senior/Staff DevOps מתועדת בפומבי.",
    "Each listed role spans at least 2 years 4 months; Ex Libris totals nearly eight years.": "כל תפקיד רשום נמשך לפחות שנתיים וארבעה חודשים; התקופה הכוללת ב-Ex Libris היא כמעט שמונה שנים.",
    "Software Engineering education is listed at Jerusalem College of Engineering.": "השכלה בהנדסת תוכנה מופיעה במכללה האקדמית להנדסה עזריאלי בירושלים.",
    "Manually confirm dates in LinkedIn Recruiter before outreach.": "לאמת ידנית את התאריכים ב-LinkedIn Recruiter לפני פנייה.",
    "AWS/Azure, Terraform, Kubernetes and networking evidence.": "ראיות ל-AWS/Azure, ל-Terraform, ל-Kubernetes ולרשתות.",
    "Staff-level scope, motivation and Netanya fit.": "היקף אחריות ברמת Staff, מוטיבציה והתאמה לנתניה.",
    "A stable long-tenure progression into a platform charter where cloud reliability and internal developer enablement have global impact.": "התקדמות יציבה וארוכת טווח לתפקיד Platform שבו אמינות הענן והעצמת המפתחים משפיעות בקנה מידה גלובלי.",
    "Wix senior DevOps engineer with 7+ years across Wix, Redis and MAMRAM; the public record adds recognized-company depth and strong cloud-native signals.": "מהנדס DevOps בכיר ב-Wix עם יותר משבע שנות ניסיון ב-Wix, Redis וממר״ם; הרשומה הציבורית מוסיפה ניסיון בחברות מוכרות וסימני cloud-native חזקים.",
    "LinkedIn states 7+ years and current senior DevOps work at Wix.": "LinkedIn מציין יותר משבע שנות ניסיון ועבודת Senior DevOps נוכחית ב-Wix.",
    "A public career post lists Docker, Kubernetes, Jenkins, Ansible, Python, Linux and CI/CD.": "פוסט קריירה ציבורי מציין Docker, Kubernetes, Jenkins, Ansible, Python, Linux ו-CI/CD.",
    "Earlier experience includes Redis and four years in MAMRAM.": "הניסיון הקודם כולל Redis וארבע שנים בממר״ם.",
    "Terraform, Azure and on-prem/global-networking depth.": "עומק ב-Terraform, ב-Azure, ב-on-prem וברשת גלובלית.",
    "Current architecture ownership and production scale.": "בעלות נוכחית על ארכיטקטורה וקנה המידה של סביבת production.",
    "Apply cloud-native automation from recognized platform companies to an ad platform operating at measurable global scale.": "ליישם אוטומציית cloud-native מחברות Platform מוכרות בפלטפורמת פרסום הפועלת בקנה מידה גלובלי מדיד.",

    # Prompts and campaign.
    "Exact AI evidence-review prompt (LLM = large language model)": "פרומפט מדויק לבדיקת ראיות באמצעות AI ‏(LLM = מודל שפה גדול)",
    "An LLM is the AI model behind tools such as ChatGPT or Claude. Here it organizes supplied public evidence into a reviewable structure; it does not make the hiring decision.": "LLM הוא מודל ה-AI שמפעיל כלים כגון ChatGPT או Claude. כאן הוא מארגן את הראיות הציבוריות שסופקו למבנה שניתן לבדיקה; הוא אינו מקבל את החלטת הגיוס.",
    "Output: prioritized adjacent talent pools that feed the company map, Boolean searches, public-artifact research and referral strategy.": "פלט: מאגרי טאלנט סמוכים ומתועדפים המזינים את מפת החברות, חיפושי Boolean, מחקר של תוצרים ציבוריים ואסטרטגיית הפניות.",
    "DAY": "יום",
    "CHANNEL": "ערוץ",
    "MESSAGE / ASSET": "מסר / נכס",
    "SUCCESS SIGNAL": "מדד הצלחה",
    "Warm graph": "רשת קשרים חמה",
    "Ask Teads engineers and adjacent-company alumni for a specific introduction using the role scorecard.": "לבקש ממהנדסי Teads ומבוגרי חברות סמוכות היכרות ממוקדת על בסיס scorecard התפקיד.",
    "Intro accepted or evidence added": "ההיכרות התקבלה או נוספה ראיה",
    "LinkedIn InMail": "LinkedIn InMail",
    "Open with one real platform problem (for example, safe provisioning across AWS/Azure and data centers), cite one verified public-profile signal, and invite a 20-minute conversation with the hiring architect.": "לפתוח בבעיה אמיתית מעולם ה-Platform, למשל provisioning בטוח בין AWS/Azure למרכזי נתונים; לציין סימן אחד מאומת מהפרופיל הציבורי ולהזמין לשיחה של 20 דקות עם הארכיטקט/ית המגייס/ת.",
    "Reply / positive reply": "תגובה / תגובה חיובית",
    "Connection note": "הודעת התחברות",
    "Short Hebrew or English note; no duplicate pitch.": "הודעה קצרה בעברית או באנגלית, ללא חזרה על אותו pitch.",
    "Connection accepted": "החיבור אושר",
    "Lawful email": "דוא״ל על בסיס חוקי",
    "Only where a legitimate professional address and basis exist; send a one-page technical brief and opt-out.": "רק כאשר קיימים כתובת מקצועית תקפה ובסיס מתאים; לשלוח תקציר טכני של עמוד אחד ואפשרות הסרה.",
    "Brief opened / reply": "התקציר נפתח / התקבלה תגובה",
    "Proof touch": "פניית הוכחה",
    "Share a relevant engineering article or invite the candidate to a short ‘150ms Reliability Lab’: a practical discussion about keeping ad responses below the ~150-millisecond (0.15-second) target during failures.": "לשתף מאמר הנדסי רלוונטי או להזמין ל-‘150ms Reliability Lab’ קצר: דיון מעשי על שמירת זמן תגובת פרסום מתחת ליעד של כ-150 מילישניות (0.15 שנייה) בזמן תקלות.",
    "Content engagement": "מעורבות בתוכן",
    "Phone / WhatsApp": "טלפון / WhatsApp",
    "Only when supplied by the prospect, a trusted referral or explicit opt-in.": "רק כאשר הפרטים נמסרו על ידי המועמד/ת, הפניה מהימנה או opt-in מפורש.",
    "Conversation booked": "נקבעה שיחה",
    "Close loop": "סגירת מעגל",
    "Respectful final note; offer talent-community content; record opt-out and next-contact date.": "הודעת סיום מכבדת; להציע תוכן לקהילת הטאלנט ולתעד opt-out ותאריך קשר הבא.",
    "Clear yes / no / later": "כן / לא / מאוחר יותר באופן ברור",
    "Recruiter InMail": "InMail של המגייס/ת",
    "Recruiter: cite one verified signal and connect it to the role. ‘Your work on [signal] stood out; this role owns [matching platform problem]. Open to a 20-minute conversation with the hiring architect?’": "המגייס/ת: לציין סימן מאומת אחד ולחבר אותו לתפקיד. ׳העבודה שלך על [סימן] בלטה; התפקיד אחראי על [בעיית Platform תואמת]. מתאים לך לשוחח 20 דקות עם הארכיטקט/ית המגייס/ת?׳",
    "Relevant VP follow-up": "פניית המשך של VP רלוונטי/ת",
    "Only if there is no reply, via LinkedIn or lawful professional email: ‘I lead [org] at Teads. Your [evidence] maps to [business priority/impact]. If relevant, I would value a brief confidential conversation—no pressure if timing is not right.’": "רק אם לא התקבלה תגובה, דרך LinkedIn או דוא״ל מקצועי על בסיס חוקי: ׳אני מוביל/ה את [הארגון] ב-Teads. הניסיון שלך ב-[ראיה] מתחבר ל-[עדיפות/השפעה עסקית]. אם ההיקף רלוונטי, אשמח לשיחה קצרה ודיסקרטית — ללא לחץ אם העיתוי אינו מתאים.׳",
    "Reply / conversation": "תגובה / שיחה",
    "This is a branching sequence, not seven mandatory touches. Select referral, recruiter or opt-in channels according to response and lawful contact basis; the recruiter and VP coordinate one follow-up, then stop or close the loop.": "זהו רצף מסתעף, לא שבע פניות חובה. בוחרים הפניה, פנייה של המגייס/ת או opt-in לפי תגובת המועמד/ת והבסיס החוקי. המגייס/ת וה-VP מתאמים המשך אחד ואז עוצרים.",

    # Stakeholder one-pager.
    "HIRING EFFICIENCY — TECH & PRODUCT   |   Standalone leadership report": "יעילות גיוס — TECH & PRODUCT   |   דוח הנהלה עצמאי",
    "ILLUSTRATIVE TARGET-STATE • NOT TEADS ATS PERFORMANCE • example assumes 2 recruiters × 3 accepts/month • replace with Greenhouse/HRIS data": "מצב יעד להמחשה • לא ביצועי ATS של TEADS • הדוגמה מניחה 2 מגייסים × 3 קבלות בחודש • יש להחליף בנתוני Greenhouse/HRIS",
    "FORECAST BY RECRUITER / HIRING TRACK": "תחזית לפי מגייס/ת ומסלול גיוס",
    "PART 2 • BONUS DELIVERABLE": "חלק 2 • תוצר בונוס",
    "STAKEHOLDER ONE-PAGER": "ONE-PAGER לבעלי עניין",
    "Standalone hiring-efficiency report • ready to send to the Lead P&C BP and Engineering VP": "דוח עצמאי על יעילות הגיוס • מוכן לשליחה ל-Lead P&C BP ול-VP Engineering",
    "OPEN REQS": "משרות פתוחות",
    "2 open >30 days": "2 פתוחות מעל 30 יום",
    "HIRES THIS MONTH / TARGET": "גיוסים החודש / יעד",
    "67% to plan": "67% מהתוכנית",
    "FORECAST ACCEPTS": "תחזית קבלות להצעה",
    "−0.2 vs target": "0.2− מול היעד",
    "MEDIAN DAYS OPEN": "חציון ימים פתוחים",
    "target ≤30d": "יעד ≤30 יום",
    "OFFER ACCEPTANCE": "קבלת הצעה",
    "target ≥80%": "יעד ≥80%",
    "FEEDBACK SLA": "SLA למשוב",
    "82% compliant": "82% עמידה",
    "RECRUITER / TRACK": "מגייס/ת / מסלול",
    "TARGET": "יעד",
    "PROBABILITY-WEIGHTED FORECAST": "תחזית משוקללת הסתברות",
    "ON TRACK?": "במסלול?",
    "NEXT STEP": "הצעד הבא",
    "Recruiter A • Product": "מגייס/ת A • Product",
    "Recruiter B • R&D": "מגייס/ת B • R&D",
    "NEEDS ACTION": "נדרשת פעולה",
    "ON TRACK": "במסלול",
    "Move one more qualified Product candidate to the final panel; decide within 24 hours.": "להעביר מועמד/ת Product מתאים/ה נוסף/ת לפאנל הסופי ולקבל החלטה בתוך 24 שעות.",
    "Keep interview slots available and discuss motivation and offer expectations early.": "לשמור חלונות ריאיון זמינים ולדון מוקדם במוטיבציה ובציפיות מההצעה.",
    "Forecast: 5.8 accepts against a target of 6 — Product requires one additional panel-ready candidate.": "תחזית: 5.8 קבלות להצעה מול יעד של 6 — מסלול Product דורש מועמד/ת נוסף/ת שמוכן/ה לפאנל.",
    "Forecast: 5.8 accepts against a target of 6 — Product requires one additional panel-ready candidate.\nHM discussion: 1) Product is 0.4 below plan—add one panel-ready candidate. 2) R&D needs 40% more qualified leads for the same three accepts—intensify evidence-led sourcing and referrals. 3) Panel-to-offer is weakest (Product 44%; R&D 33%)—simplify assessment, calibrate the bar and decide within 24–48 hours.": "תחזית: 5.8 קבלות מול יעד 6 — ל-Product חסר/ה מועמד/ת אחד/ת מוכן/ה לפאנל.\nלדיון עם המנהל/ת המגייס/ת: 1) Product נמוך ב-0.4 מהתוכנית — להוסיף מועמד/ת מוכן/ה לפאנל. 2) R&D דורש 40% יותר לידים לאותן שלוש קבלות — לחזק sourcing והפניות מבוססי ראיות. 3) פאנל→הצעה הוא המעבר החלש (Product ‏44%; R&D ‏33%) — לפשט הערכה, לכייל ולהחליט בתוך 24–48 שעות.",
    "PRODUCT BOTTLENECK": "צוואר בקבוק — PRODUCT",
    "R&D BOTTLENECK": "צוואר בקבוק — R&D",
    "Primary loss: Case/panel → offer is 44%.\nOffer → accept is 75% (1 of 4 lost): record the candidate-stated reason—compensation, competing offer, scope/level, work model/commute, timing or other.\nFix: Use one ≤90-minute task/live option, decide the same day and code every decline.": "נשירה עיקרית: תרגיל/פאנל ← הצעה — 44%.\nהצעה ← קבלה — 75% (אובדן של 1 מתוך 4): יש לתעד את הסיבה שמסר/ה המועמד/ת — שכר, הצעה מתחרה, היקף/רמה, מודל עבודה/נסיעה, תזמון או אחר.\nפתרון: משימה אחת של עד 90 דקות או חלופה חיה, החלטה באותו יום וקידוד כל דחייה.",
    "Primary loss: Panel → offer is 33%.\nOffer → accept is 75% (1 of 4 lost): use the same candidate-stated reason taxonomy; do not assume the cause.\nFix: Use one 60-minute practical, reserve interview slots, decide within 48 hours and code every decline.": "נשירה עיקרית: פאנל ← הצעה — 33%.\nהצעה ← קבלה — 75% (אובדן של 1 מתוך 4): להשתמש באותה טקסונומיה המבוססת על דברי המועמד/ת ולא להניח את הסיבה.\nפתרון: תרגיל מעשי אחד של 60 דקות, חלונות ריאיון שמורים, החלטה בתוך 48 שעות וקידוד כל דחייה.",
    "LOCATION DROP-OFF HEATMAP • ILLUSTRATIVE": "מפת חום לנשירה לפי מיקום • להמחשה",
    "Primary drop-off: IL commute/hybrid • FR language/location • SI senior-pool size": "נשירה עיקרית: IL נסיעה/hybrid • FR שפה/מיקום • SI גודל מאגר senior",
    "Recruiter → HM/tech": "מגייס/ת ← HM/טכני",
    "HM/tech → panel": "HM/טכני ← פאנל",
    "Panel → offer": "פאנל ← הצעה",
    "Forecast = Σ(active candidates counted once at furthest stage × historical P(accepted | stage, track, location, source)).": "תחזית = Σ(כל מועמד/ת פעיל/ה נספר/ת פעם אחת בשלב המתקדם ביותר × הסתברות היסטורית P(קבלה | שלב, מסלול, מיקום, מקור)).",
    "In plain English: each active candidate is counted once at their most advanced stage and weighted by the historical likelihood that a similar candidate—based on stage, role, location and source—will ultimately accept an offer.": "במילים פשוטות: כל מועמד/ת פעיל/ה נספר/ת פעם אחת בשלב המתקדם ביותר ומקבל/ת משקל לפי הסבירות ההיסטורית שמועמד/ת דומה — לפי שלב, תפקיד, מיקום ומקור — יקבל/תקבל בסופו של דבר הצעה.",
    "Metric assumptions: illustrative target-state, not Teads ATS actuals; two recruiters with three accepted hires each per month; active candidates counted once at their furthest stage; conversion history segmented by track, location and source; 30-day requisition target, 24-hour feedback SLA and 80% offer-acceptance target; duplicates and candidate-requested pauses excluded.": "הנחות המדדים: מצב יעד להמחשה ולא נתוני ATS בפועל של Teads; שני מגייסים עם שלושה גיוסים שקיבלו הצעה לכל מגייס/ת בחודש; כל מועמד/ת פעיל/ה נספר/ת פעם אחת בשלב המתקדם ביותר; היסטוריית ההמרה מפולחת לפי מסלול, מיקום ומקור; יעד של 30 יום למשרה, SLA של 24 שעות למשוב ויעד קבלת הצעה של 80%; כפילויות והשהיות שביקשו מועמדים אינן נכללות.",
    "Product funnel assumptions: one monthly cohort; 100 manually verified qualified leads; target of three accepts; conversions are illustrative back-solved targets, not Teads history; one ≤90-minute case/live option; reserved interview capacity; elapsed time excludes candidate-requested pauses.": "הנחות משפך Product: קוהורט חודשי אחד; 100 לידים מתאימים שנבדקו ידנית; יעד של שלוש קבלות; שיעורי ההמרה הם יעדי המחשה שחושבו לאחור ולא היסטוריית Teads; תרגיל אחד של עד 90 דקות או חלופה חיה; קיבולת ראיונות שמורה; הזמן הכולל אינו כולל השהיות שביקשו מועמדים.",
    "R&D funnel assumptions: one monthly cohort; 140 qualified leads for a narrower skill pool; target of three accepts; conversions are illustrative back-solved targets, not Teads history; one 60-minute practical; reserved cross-hub technical panels; elapsed time excludes candidate-requested pauses.": "הנחות משפך R&D: קוהורט חודשי אחד; 140 לידים מתאימים בשל מאגר מיומנויות צר יותר; יעד של שלוש קבלות; שיעורי ההמרה הם יעדי המחשה שחושבו לאחור ולא היסטוריית Teads; תרגיל מעשי אחד של 60 דקות; פאנלים טכניים בין מרכזים ששוריינו מראש; הזמן הכולל אינו כולל השהיות שביקשו מועמדים.",

    # Dashboard definitions and funnel tables.
    "BUSINESS QUESTION": "שאלה עסקית",
    "WHAT TO TRACK": "מה למדוד",
    "VIEW BY": "פילוח לפי",
    "Are we hiring fast enough?": "האם אנחנו מגייסים מהר מספיק?",
    "Open roles; hires this month/quarter; forecast versus target; days open": "משרות פתוחות; גיוסים החודש/הרבעון; תחזית מול יעד; מספר ימים פתוחים",
    "Product/R&D; country; recruiter; level": "Product/R&D; מדינה; מגייס/ת; רמה",
    "Do we have enough qualified candidates?": "האם יש מספיק מועמדים מתאימים?",
    "Candidates at each stage; pipeline coverage; source results; inactive candidates": "מועמדים בכל שלב; כיסוי pipeline; תוצאות לפי מקור; מועמדים לא פעילים",
    "Role; source; location; stage; age": "תפקיד; מקור; מיקום; שלב; ותק בתהליך",
    "Where are candidates waiting?": "היכן מועמדים ממתינים?",
    "Time to kickoff and first shortlist; days in each stage; scheduling, feedback and offer time": "זמן מ-kickoff לרשימה ראשונה; ימים בכל שלב; זמן תיאום, משוב והצעה",
    "Role and location; typical time and slowest cases": "תפקיד ומיקום; זמן טיפוסי והמקרים האיטיים ביותר",
    "Are we using time well?": "האם הזמן מנוצל היטב?",
    "Applications, interviews and interviewer hours per hire; source results; recruiter workload; cost per hire": "מועמדויות, ראיונות ושעות מראיינים לכל גיוס; תוצאות מקור; עומס מגייס/ת; עלות לגיוס",
    "Source; role difficulty; new/replacement": "מקור; קושי התפקיד; חדש/החלפה",
    "Are we making strong hires?": "האם הגיוסים איכותיים?",
    "Offer acceptance; decline/withdrawal reasons; candidate feedback; 90-day retention/ramp; manager satisfaction": "קבלת הצעה; סיבות דחייה/פרישה; משוב מועמדים; שימור והשתלבות ב-90 יום; שביעות רצון מנהל/ת",
    "Cohort; source; recruiter; role; location": "קוהורט; מקור; מגייס/ת; תפקיד; מיקום",
    "STAGE": "שלב",
    "COUNT": "כמות",
    "PASS-THROUGH": "שיעור מעבר",
    "AVG TIME": "זמן ממוצע",
    "DROP-OFF / BOTTLENECK": "נשירה / צוואר בקבוק",
    "IMPROVEMENT": "שיפור",
    "Qualified leads": "לידים מתאימים",
    "7d to engage": "7 ימים ליצירת קשר",
    "Low relevance or no response": "רלוונטיות נמוכה או ללא תגובה",
    "Adtech/CTV adjacency map; evidence-led messages; referrals": "מפת קרבה ל-Adtech/CTV; מסרים מבוססי ראיות; הפניות",
    "Recruiter screen": "שיחת מגייס/ת",
    "Work model / scope / compensation mismatch": "פער במודל עבודה / היקף / שכר",
    "Share range and Netanya/work-model expectations before call": "לשתף טווח וציפיות לגבי נתניה/מודל עבודה לפני השיחה",
    "HM screen": "שיחת מנהל/ת מגייס/ת",
    "Unclear level or platform/domain bar": "רמה או רף Platform/domain לא ברורים",
    "Scorecard with 3 outcomes + 5 evidence signals": "Scorecard עם 3 תוצאות ו-5 סימני ראיה",
    "Case / panel": "תרגיל / פאנל",
    "Take-home burden; scheduling; inconsistent rubric": "עומס משימת בית; תיאום; rubric לא אחיד",
    "≤90-min sample/live option; pre-book panels; rubric anchors": "דוגמה של עד 90 דקות/חלופה חיה; פאנלים קבועים מראש; עוגני rubric",
    "Offer": "הצעה",
    "Late compensation alignment; slow approval": "תיאום שכר מאוחר; אישור איטי",
    "Pre-close at panel; same-day debrief; 48h approval": "Pre-close בפאנל; debrief באותו יום; אישור בתוך 48 שעות",
    "Accept": "קבלה",
    "Reason unknown until candidate confirms": "הסיבה אינה ידועה עד לאישור המועמד/ת",
    "Code: compensation; competing offer; scope/level; work model/commute; timing; other": "קוד: שכר; הצעה מתחרה; היקף/רמה; מודל עבודה/נסיעה; תזמון; אחר",
    "Title-only matches; no reply": "התאמות לפי תואר בלבד; ללא תגובה",
    "Skill-evidence map; optional public artifacts; referrals": "מפת ראיות לכישורים; תוצרים ציבוריים אופציונליים; הפניות",
    "Netanya commute, hybrid or scope mismatch": "פער בנסיעה לנתניה, hybrid או היקף התפקיד",
    "Share office cadence and role boundaries before call": "לשתף תדירות משרד וגבולות תפקיד לפני השיחה",
    "Technical screen": "ריאיון טכני",
    "Scheduling and abstract trivia": "תיאום ושאלות תאורטיות מדי",
    "60-min production scenario; weekly interviewer pods": "תרחיש production של 60 דקות; צוותי מראיינים שבועיים",
    "Panel": "פאנל",
    "Duplicate tests; cross-hub coordination": "בדיקות כפולות; תיאום בין מרכזים",
    "Map each competency once; parallelize; 24h feedback": "למפות כל יכולת פעם אחת; להריץ במקביל; משוב בתוך 24 שעות",
    "Calibration variance; approval latency": "שונות בכיול; עיכוב באישור",
    "Evidence-based debrief; no extra round; 48h decision": "Debrief מבוסס ראיות; ללא סבב נוסף; החלטה בתוך 48 שעות",

    # Bottlenecks and location choices.
    "LIKELY BOTTLENECK": "צוואר בקבוק סביר",
    "TEADS-SPECIFIC SIGNAL": "סימן ייחודי ל-TEADS",
    "DIAGNOSTIC": "אבחון",
    "ACTION": "פעולה",
    "Post-merger calibration": "כיול לאחר המיזוג",
    "The 2025 combination and name change can increase role-scope or team-identity ambiguity.": "השילוב ושינוי השם ב-2025 עלולים להגביר עמימות לגבי היקף התפקיד או זהות הצוות.",
    "High HM-screen rejection variance; reopened reqs; changed scorecards": "שונות גבוהה בדחיות HM; פתיחה מחדש של משרות; scorecards שהשתנו",
    "60-minute kickoff with role outcomes, level anchors and ‘must have now vs learn’ split; monthly calibration council": "Kickoff של 60 דקות עם תוצאות תפקיד, עוגני רמה והפרדה בין ״חובה עכשיו״ ל״ניתן ללמוד״; פורום כיול חודשי",
    "Rare platform scope": "היקף Platform נדיר",
    "The role combines AWS/Azure, on-prem, global networking, IaC and high scale.": "התפקיד משלב AWS/Azure, ‏on-prem, רשת גלובלית, IaC וקנה מידה גבוה.",
    "Many applicants but low technical-screen pass; repeated missing evidence": "מועמדויות רבות אך שיעור מעבר טכני נמוך; ראיות חסרות שחוזרות על עצמן",
    "Map adjacent pools; score evidence, not exact title; publish a technical ‘day in the life’": "למפות מאגרים סמוכים; לדרג ראיות ולא תואר מדויק; לפרסם ״יום בחיים״ טכני",
    "Interview inflation": "עודף ראיונות",
    "External data shows 39 Engineering and 42 Product interviews per hire.": "נתונים חיצוניים מצביעים על 39 ראיונות Engineering ו-42 ראיונות Product לכל גיוס.",
    "High interviewer hours/hire; same competency tested twice": "שעות מראיינים רבות לכל גיוס; אותה יכולת נבדקת פעמיים",
    "Competency-to-interviewer map; one structured practical; eliminate redundant round": "מפת יכולת-מראיין; תרגיל מובנה אחד; ביטול סבב מיותר",
    "Cross-hub scheduling": "תיאום בין מרכזים",
    "Technical teams operate across Netanya, Ljubljana, Paris and Montpellier.": "הצוותים הטכניים פועלים בנתניה, לובליאנה, פריז ומונפלייה.",
    "Scheduling lag >3 business days; feedback SLA misses by hub": "עיכוב תיאום מעל 3 ימי עסקים; חריגות SLA למשוב לפי מרכז",
    "Reserved interviewer pods by track/time zone; auto-escalate at 24h": "צוותי מראיינים שמורים לפי מסלול/אזור זמן; הסלמה אוטומטית לאחר 24 שעות",
    "Netanya / hybrid clarity": "בהירות לגבי נתניה / hybrid",
    "Public materials indicate hybrid work; the annual report describes three office days/two remote.": "חומרים ציבוריים מצביעים על עבודה היברידית; הדוח השנתי מתאר שלושה ימים במשרד ושניים מרחוק.",
    "Israel withdrawal before screen or after work-model disclosure": "פרישה בישראל לפני שיחת הסינון או לאחר חשיפת מודל העבודה",
    "State office cadence, location and interview path in the first message/job page; offer commute-sensitive slots": "לציין תדירות משרד, מיקום ומסלול ראיונות בהודעה הראשונה/עמוד המשרה; להציע חלונות המתחשבים בנסיעה",
    "Brand transition": "מעבר מותג",
    "The company combined two legacy brands and changed its corporate name in 2025.": "החברה שילבה שני מותגים ותיקים ושינתה את שמה התאגידי ב-2025.",
    "Candidates ask ‘Outbrain or Teads?’; lower close confidence": "מועמדים שואלים ״Outbrain או Teads?״; פחות ביטחון בשלב הסגירה",
    "One approved integration narrative with roadmap proof, team stability facts and honest unknowns": "סיפור אינטגרציה מאושר אחד, עם הוכחות roadmap, עובדות על יציבות הצוות ואי-ודאות מוצגת בכנות",
    "LOCATION": "מיקום",
    "LOCAL WATCH-OUT": "נקודת תשומת לב מקומית",
    "PROCESS CHOICE": "בחירת תהליך",
    "MEASURE": "מדידה",
    "Israel • Netanya": "ישראל • נתניה",
    "Commute and a three-day office rhythm; Sunday–Thursday operating context; periods of reserve/care disruption": "נסיעה ושגרה של שלושה ימים במשרד; שבוע עבודה ראשון–חמישי; תקופות מילואים או הפרעות טיפוליות",
    "Disclose work model early; flexible interview slots; opt-in WhatsApp only; never penalize service/care gaps": "לחשוף מוקדם את מודל העבודה; חלונות ריאיון גמישים; WhatsApp רק ב-opt-in; לא להעניש על פערי מילואים/טיפול",
    "Pre-screen withdrawals; schedule lag; acceptance; candidate feedback": "פרישה לפני סינון; עיכוב בתיאום; קבלת הצעה; משוב מועמדים",
    "France • Paris / Montpellier": "צרפת • פריז / מונפלייה",
    "Two hubs and possible bilingual candidate journey; candidates need contract/location clarity": "שני מרכזים ומסע מועמד אפשרי בשתי שפות; נדרשת בהירות לגבי חוזה ומיקום",
    "Choose French/English touchpoints; clear home hub and interview language; local P&C review of messaging": "לבחור נקודות מגע בצרפתית/אנגלית; להבהיר מרכז בית ושפת ריאיון; בדיקת מסרים על ידי P&C מקומי",
    "Reply and withdrawal by language/hub; days in approval": "תגובה ופרישה לפי שפה/מרכז; ימים באישור",
    "Slovenia • Ljubljana": "סלובניה • לובליאנה",
    "Smaller senior platform pool and cross-border competition": "מאגר Senior Platform קטן יותר ותחרות חוצת גבולות",
    "Prioritize referrals, community mapping and adjacent Central European talent; publish English technical content": "לתעדף הפניות, מיפוי קהילות וטאלנט סמוך במרכז אירופה; לפרסם תוכן טכני באנגלית",
    "Qualified leads per week; referral yield; aging by skill": "לידים מתאימים לשבוע; תפוקת הפניות; ותק בתהליך לפי skill",

    # Employer-brand audit and actions.
    "STRENGTH TO AMPLIFY": "חוזקה שכדאי להעצים",
    "PUBLIC PROOF": "הוכחה ציבורית",
    "GAP / RISK TO SOLVE": "פער / סיכון לטיפול",
    "Exceptional engineering scale": "קנה מידה הנדסי חריג",
    "Company role materials cite ~2 million ad requests/sec, 100 billion events/day, responses below 150 milliseconds and 18 million predictions/sec.": "חומרי התפקיד של החברה מציינים כ-2 מיליון בקשות פרסום בשנייה, 100 מיליארד אירועים ביום, תגובה מתחת ל-150 מילישניות ו-18 מיליון תחזיות בשנייה.",
    "Current employer content can lead with office/perks; technical proof should become the hero.": "תוכן המעסיק הנוכחי עלול להוביל עם משרד והטבות; ההוכחה הטכנית צריכה להיות במרכז.",
    "Ownership culture": "תרבות של בעלות",
    "‘You build it, you run it, you monitor it’; 400+ engineers across four hubs.": "״בנית — באחריותך להריץ ולנטר״; יותר מ-400 מהנדסים בארבעה מרכזים.",
    "Needs local engineer voices, specific decisions and honest trade-offs.": "נדרשים קולות של מהנדסים מקומיים, החלטות קונקרטיות ו-trade-offs כנים.",
    "Visible local signals": "סימנים מקומיים גלויים",
    "Hybrid work, Netanya office content, parking and pet-friendly signals are visible publicly.": "עבודה היברידית, תוכן על משרד נתניה, חניה וידידותיות לבעלי חיים גלויים לציבור.",
    "Perks cannot substitute for level clarity, interview transparency and career evidence.": "הטבות אינן תחליף לבהירות ברמה, לשקיפות בתהליך הראיונות ולראיות להתפתחות קריירה.",
    "Brand-transition clarity": "בהירות במעבר המותג",
    "The combined company adopted the Teads name in 2025.": "החברה המשולבת אימצה את השם Teads ב-2025.",
    "Candidates may still ask what changed after the combination; recruiters need one honest, approved explanation.": "מועמדים עדיין עשויים לשאול מה השתנה לאחר השילוב; המגייסים זקוקים להסבר אחד, כן ומאושר.",
    "Large review footprint": "נוכחות רחבה באתרי ביקורות",
    "Glassdoor snapshot: 3.7/5, 689 reviews and 74% recommend; anonymous sentiment is directional.": "תמונת מצב ב-Glassdoor: ‏3.7/5, ‏689 ביקורות ו-74% ממליצים; תחושות אנונימיות הן אינדיקציה בלבד.",
    "Mixed post-merger commentary can create uncertainty; respond with themes and actions, never review manipulation.": "תגובות מעורבות לאחר המיזוג עלולות ליצור אי-ודאות; יש להגיב באמצעות נושאים ופעולות, ולעולם לא באמצעות מניפולציה של ביקורות.",
    "WHEN": "מתי",
    "WHAT TO DO": "מה לעשות",
    "WHY IT MATTERS": "למה זה חשוב",
    "OWNER / MEASURE": "אחריות / מדד",
    "Interview 12 employees, review candidate drop-off and public feedback, and publish one clear FAQ about Teads after the combination.": "לראיין 12 עובדים, לבחון נשירת מועמדים ומשוב ציבורי ולפרסם FAQ ברור אחד על Teads לאחר השילוב.",
    "Gives recruiters and candidates one consistent explanation.": "מספק למגייסים ולמועמדים הסבר עקבי אחד.",
    "TA + P&C + Comms / five evidence-based themes; FAQ use": "TA + P&C + Comms / חמישה נושאים מבוססי ראיות; שימוש ב-FAQ",
    "Rewrite Israel job pages with the mission, technical scale, first-90-day goals, work model, interview stages and decision timing.": "לכתוב מחדש את עמודי המשרות בישראל עם המשימה, קנה המידה הטכני, יעדי 90 הימים הראשונים, מודל העבודה, שלבי הריאיון וזמני ההחלטה.",
    "Helps candidates decide earlier whether the role fits.": "מסייע למועמדים להחליט מוקדם יותר אם התפקיד מתאים.",
    "TA + hiring manager / qualified applications; early withdrawals": "TA + מנהל/ת מגייס/ת / מועמדויות מתאימות; פרישות מוקדמות",
    "Create a volunteer group of 8–12 engineers and product employees who can share approved, honest stories.": "להקים קבוצת מתנדבים של 8–12 מהנדסים ואנשי Product שיוכלו לשתף סיפורים כנים ומאושרים.",
    "Lets candidates hear directly from employees.": "מאפשר למועמדים לשמוע ישירות מעובדים.",
    "Engineering + Product + employer brand / two local stories per month": "Engineering + Product + מיתוג מעסיק / שני סיפורים מקומיים בחודש",
    "Run short talks explaining how Teads engineers design systems for approximately 2 million ad requests every second, plus honest updates about the company combination.": "לקיים הרצאות קצרות המסבירות כיצד מהנדסי Teads מתכננים מערכות לכ-2 מיליון בקשות פרסום בכל שנייה, לצד עדכונים כנים על שילוב החברות.",
    "Turns Teads’ real engineering scale into a clear local story.": "הופך את קנה המידה ההנדסי האמיתי של Teads לסיפור מקומי ברור.",
    "Ambassadors / attendance; completion; qualified conversations": "שגרירים / נוכחות; השלמה; שיחות איכותיות",
    "Run a quarterly reliability challenge focused on keeping mocked ad requests below the ~150-millisecond (0.15-second) response-time target, with AWS User Group Israel or DevOpsDays Tel Aviv.": "לקיים אתגר אמינות רבעוני המתמקד בשמירת בקשות פרסום מדומות מתחת ליעד תגובה של כ-150 מילישניות (0.15 שנייה), עם AWS User Group Israel או DevOpsDays Tel Aviv.",
    "Shows the real technical problem while giving value to the community.": "מציג את הבעיה הטכנית האמיתית תוך מתן ערך לקהילה.",
    "DevRel + Platform / participant NPS; opt-in community; qualified leads; recruiter-screen conversion; hires influenced": "DevRel + Platform / ‏NPS משתתפים; קהילת opt-in; לידים מתאימים; המרה לשיחת מגייס/ת; גיוסים שהושפעו",
    "Run Open Internet Build Nights with she codes, Tsofen and Olim in Tech.": "לקיים Open Internet Build Nights עם she codes, ‏Tsofen ו-Olim in Tech.",
    "Builds long-term community relationships and widens access.": "בונה קשרים קהילתיים ארוכי טווח ומרחיב נגישות.",
    "P&C + partners / participation; return rate; qualified-pool reach where lawful": "P&C + שותפים / השתתפות; שיעור חזרה; הגעה למאגר מתאים בכפוף לדין",
    "Create a Netanya engineering fellowship or open-source education partnership.": "להקים תוכנית עמיתים הנדסית בנתניה או שותפות חינוכית ב-open source.",
    "Builds local reputation beyond open jobs.": "בונה מוניטין מקומי מעבר למשרות פתוחות.",
    "CTO org + P&C / contributions; brand search; hires influenced": "ארגון CTO + P&C / תרומות; חיפושי מותג; גיוסים שהושפעו",
    "Event participation, return rate and NPS are leading indicators. The final impact will be measured through source-attributed qualified leads, positive response rate, recruiter-screen conversion, offer acceptance and hires influenced for the Netanya hub.": "השתתפות באירועים, שיעור חזרה ו-NPS הם מדדים מקדימים. ההשפעה הסופית תימדד באמצעות לידים מתאימים המיוחסים למקור, שיעור תגובה חיובית, המרה לשיחת מגייס/ת, קבלת הצעות וגיוסים שהושפעו עבור מרכז נתניה.",
    "150ms RELIABILITY CHALLENGE": "אתגר אמינות של 150ms",
    "A quarterly hands-on session where Teads engineers and guests keep a mocked ad request below ~150 milliseconds (0.15 seconds) during failures. It teaches; it is not a candidate test.": "מפגש מעשי רבעוני שבו מהנדסי Teads ואורחים שומרים בקשת פרסום מדומה מתחת לכ-150 מילישניות (0.15 שנייה) בזמן תקלות. זהו מפגש לימודי, לא מבחן מועמדים.",
    "OPEN-INTERNET BUILD NIGHT": "ערב בנייה ל-OPEN INTERNET",
    "Teads engineers and community partners work together on public tools or tutorials. Participants learn and may opt into future contact.": "מהנדסי Teads ושותפים קהילתיים עובדים יחד על כלים ציבוריים או מדריכים. המשתתפים לומדים ויכולים לבחור להצטרף לקשר עתידי.",
    "WHAT CHANGED AT TEADS": "מה השתנה ב-TEADS",
    "A leader and engineer explain one post-combination system change, the trade-off and what comes next. Candidates get a clear, honest story.": "מנהל/ת ומהנדס/ת מסבירים שינוי מערכת אחד לאחר השילוב, את ה-trade-off ואת הצעד הבא. המועמדים מקבלים סיפור ברור וכן.",

    # Headers.
    "TEADS • TECHNICAL TALENT ACQUISITION": "TEADS • גיוס טאלנט טכנולוגי",
    "BONUS ONE-PAGER • HIRING EFFICIENCY — TECH & PRODUCT": "ONE-PAGER בונוס • יעילות גיוס — TECH & PRODUCT",
    "PART 2 • HIRING EFFICIENCY": "חלק 2 • יעילות גיוס",
    "PART 3 • EMPLOYER BRAND ISRAEL": "חלק 3 • מיתוג מעסיק ישראל",
}

# Hebrew candidate cards use shorter phrasing so each card remains a single,
# readable visual unit in the original fixed-width layout.
HE.update({
    "Senior DevOps & Platform Engineer / Cloud Infrastructure Architect; Israel. Strongest explicit multi-cloud, IaC and network-testing evidence in the public profile.": "Senior DevOps & Platform Engineer בישראל; ראיות חזקות ל-multi-cloud, ‏IaC ובדיקות רשת.",
    "Public profile references AWS, Azure, Kubernetes and Terraform.": "AWS, Azure, Kubernetes ו-Terraform בפרופיל הציבורי.",
    "Content includes Terratest/Go and AKS/EKS/GKE.": "Terratest/Go ו-AKS/EKS/GKE בתוכן הציבורי.",
    "Network evidence includes VNet/subnets/private link testing.": "בדיקות VNet, ‏subnets ו-private link.",
    "Depth at high traffic and multi-region operations.": "עומק ב-high-traffic וב-multi-region.",
    "On-prem integration and current hands-on IC scope.": "אינטגרציית on-prem ועבודת IC מעשית.",
    "Availability and Netanya hybrid fit.": "זמינות והתאמה ל-hybrid בנתניה.",
    "The rare multi-cloud + testable infrastructure problem: build safe provisioning and networking across three public clouds and data centers.": "אתגר multi-cloud נדיר: provisioning ורשת בטוחים בשלושה עננים ובמרכזי נתונים.",
    "AppsFlyer platform engineer in Israel; directly adjacent advertising/measurement environment with Kubernetes and Kafka reliability signals.": "מהנדס/ת Platform ב-AppsFlyer בישראל; ניסיון סמוך ל-adtech עם Kubernetes ו-Kafka.",
    "Platform engineering and cloud-based solutions in public summary.": "Platform engineering ופתרונות cloud בתקציר הציבורי.",
    "AppsFlyer platform group combines software and DevOps.": "קבוצת Platform משלבת software ו-DevOps.",
    "Published/shared work on Kubernetes stateful applications and Kafka leader-election trade-offs.": "תוכן על Kubernetes stateful ועל trade-offs ב-Kafka.",
    "Terraform and AWS/Azure depth.": "עומק ב-Terraform וב-AWS/Azure.",
    "Global networking / on-prem experience.": "ניסיון ברשת גלובלית וב-on-prem.",
    "Current level, location and interest.": "רמה נוכחית, מיקום ועניין.",
    "Move from adjacent adtech scale to a foundation role where reliability choices affect approximately 2 million ad requests/second and four engineering hubs.": "מעבר מ-adtech לתפקיד תשתית המשפיע על כ-2 מיליון בקשות פרסום בשנייה וארבעה מרכזי פיתוח.",
    "FundGuard DevOps engineer in Israel with unusually specific public evidence across AWS, EKS, networking, FinOps and incidents.": "מהנדס/ת DevOps ב-FundGuard בישראל; ראיות מפורטות ל-AWS, ‏EKS, רשתות, FinOps ותקלות.",
    "Describes multi-region AWS failover and VPC-peering debugging.": "AWS failover ב-multi-region ו-debugging של VPC peering.",
    "Reports EKS cost work, on-call/SRE and Kafka incident ownership.": "עלויות EKS, אחריות on-call/SRE ותקלות Kafka.",
    "Hashtags and narrative reference Kubernetes, Terraform and infrastructure as code.": "Kubernetes, ‏Terraform ו-infrastructure as code.",
    "Azure and on-prem evidence.": "ראיות ל-Azure ול-on-prem.",
    "Scale and architecture decision ownership.": "בעלות על החלטות scale וארכיטקטורה.",
    "Current title/tenure and Netanya schedule.": "תפקיד/וותק והתאמה לנתניה.",
    "A broader platform charter: turn ‘glue work’ into owned cloud-foundation products, standards and automation.": "מנדט Platform רחב: להפוך עבודת חיבור למוצרי cloud foundation, סטנדרטים ואוטומציה.",
    "Taboola DevOps/SRE in the Tel Aviv District; seven years of stated experience building scalable, secure and reliable systems in direct adtech adjacency.": "DevOps/SRE ב-Taboola באזור תל אביב; שבע שנות ניסיון מוצהרות במערכות אמינות ו-scalable ב-adtech.",
    "Public summary explicitly states DevOps/SRE and seven years.": "DevOps/SRE ושבע שנות ניסיון מצוינים במפורש.",
    "Taboola provides direct adtech/high-scale adjacency.": "התאמה ישירה ל-adtech ו-high-scale.",
    "Public activity references Terraform/Pulumi, Kubernetes, GitOps, load balancing and networking topics.": "Terraform/Pulumi, ‏Kubernetes, ‏GitOps, איזון עומסים ורשתות.",
    "Owned—not merely followed—technology evidence.": "ראיות לבעלות טכנולוגית בפועל.",
    "AWS/Azure and hybrid networking depth.": "עומק ב-AWS/Azure וברשתות hybrid.",
    "Programming, current remit and commute.": "תכנות, אחריות נוכחית ונסיעה.",
    "A peer adtech infrastructure challenge with a wider multi-cloud/on-prem foundation remit and global hub collaboration.": "אתגר תשתיות adtech עם אחריות רחבה ל-multi-cloud/on-prem ושיתוף בין מרכזים.",
    "Exploratory adjacent-pool prospect—included to demonstrate market expansion beyond direct adtech matches. Senior DevOps & Platform Engineer in Israel with AWS and cloud-native certification signals.": "מועמד/ת ניסיוני/ת ממאגר סמוך; Senior DevOps & Platform Engineer בישראל עם סימני הסמכה ב-AWS וב-cloud-native.",
    "Public profile highlights AWS and platform/DevOps work.": "AWS ועבודת Platform/DevOps בפרופיל הציבורי.",
    "HashiCorp Terraform Associate, KCNA and AWS Solutions Architect certifications are listed.": "הסמכות Terraform Associate, ‏KCNA ו-AWS Solutions Architect.",
    "Current-company context suggests self-hosted infrastructure exposure (inference).": "הקשר החברה מצביע על חשיפה אפשרית ל-self-hosted (הסקה).",
    "Azure and enterprise-scale proof.": "ראיות ל-Azure ול-enterprise scale.",
    "Networking, multi-region and high-traffic ownership.": "בעלות על רשתות, multi-region ו-high-traffic.",
    "Coding depth and Netanya practicality.": "עומק ב-coding והיתכנות בנתניה.",
    "Own the automation and reliability bridge between public cloud and self-managed infrastructure at measurable global scale.": "בעלות על גשר האוטומציה והאמינות בין public cloud לתשתיות בניהול עצמי.",
})


KEEP_EXACT = {
    "Rotem Hochman",
    "Tal Asulin",
    "Erez Neiderman",
    "Ashraf Hamad",
    "Tal Ayalon",
    "Taboola, AppsFlyer, Similarweb, Nexxen/Tremor, Perion, Playtika, Unity/ironSource, Minute Media",
    "Wix, monday.com, JFrog, BMC, Amdocs, NICE, CyberArk, Check Point, Cato Networks, Akamai",
    "Rapyd, eToro, Payoneer, Riskified, Forter, Melio, Global-e, Yotpo, FundGuard",
    "(\"platform engineer\" OR \"site reliability engineer\" OR SRE OR DevOps) AND (AWS OR Azure) AND (Terraform OR IaC) AND (Kubernetes OR networking OR \"hybrid cloud\")",
    "site:linkedin.com/in (\"platform engineer\" OR \"site reliability engineer\" OR SRE OR DevOps) (AWS OR Azure) (Terraform OR IaC) (Israel OR \"Tel Aviv\" OR Netanya)",
    "IL", "FR", "SI", "LinkedIn InMail", "LinkedIn Boolean", "Google X-ray",
}


def all_table_paragraphs(table):
    for row in table.rows:
        for cell in row.cells:
            yield from cell.paragraphs
            for nested in cell.tables:
                yield from all_table_paragraphs(nested)


def document_paragraphs(doc):
    yield from doc.paragraphs
    for table in doc.tables:
        yield from all_table_paragraphs(table)
    for section in doc.sections:
        yield from section.header.paragraphs


def translate_long_prompts(text: str) -> str | None:
    if text.startswith("Act as a skeptical technical sourcer."):
        return (
            "פעל/י כ-sourcer טכנולוגי ספקן. יש להשתמש רק בראיות מתוך הקטעים וה-URLs הציבוריים שסופקו.\n"
            "Role JSON: {must_haves:[AWS_or_Azure, Terraform_IaC, programming_automation, design_documentation, collaboration], bonuses:[HA_high_traffic, multi_region, adtech_ecommerce], location:Netanya_hybrid}\n"
            "ראיות מועמד/ת: <יש להדביק קטעים ציבוריים מדויקים + URLs>\n"
            "יש להחזיר JSON עם: candidate_name, location_evidence, current_company_title_evidence, must_have_evidence[], bonus_evidence[], missing_or_unverified[], risk_flags[], provisional_score_out_of_20, source_urls[], confidence. יש לכתוב 'unknown' כאשר המידע אינו מפורש. אין להסיק גיל, מוצא, מצב משפחתי, דת, רקע צבאי, שכר, נכונות לנסוע או סטטוס חיפוש עבודה. יש להוריד ציון להתאמות המבוססות רק על תואר ולהסביר כל ציון במשפט אחד."
        )
    if text.startswith("Using the Cloud Engineer — platform-focused scorecard and the seed companies"):
        return (
            "באמצעות ה-scorecard של Cloud Engineer — platform-focused וחברות הזרע AppsFlyer, Taboola, Wix, Cato Networks ו-Rapyd, יש לזהות 10 מאגרי טאלנט סמוכים בישראל על בסיס בעיות טכניות דומות ולא על בסיס תואר תפקיד מדויק.\n"
            "לכל מאגר יש לספק: חברות רלוונטיות, תארי תפקיד חלופיים, סימני cloud ותשתיות אפשריים, מקורות ציבוריים לחיפוש, מחרוזות Boolean ל-LinkedIn, שאילתות Google X-ray, רעיונות לחיפוש ב-GitHub והסבר מדוע המאגר עלול להיות מוזנח.\n"
            "יש להשתמש רק במידע מקצועי ציבורי. אין להסיק מאפיינים מוגנים, ואין להתייחס להיעדר פעילות GitHub כראיה שלילית. כל פרופיל חייב לעבור אימות ידני לפני פנייה."
        )
    return None


def translate(text: str) -> str:
    if text in HE:
        return HE[text]
    prompt = translate_long_prompts(text)
    if prompt is not None:
        return prompt
    match = re.fullmatch(r"(\d+ / 20)\nPROVISIONAL FIT", text)
    if match:
        return f"{match.group(1)}\nהתאמה ראשונית"
    if text in {"3d", "4d", "6d", "7d", "8d"}:
        return text[:-1] + " ימים"
    if text == "21d":
        return "21 ימים"
    if text == "24h":
        return "24 שעות"
    duration = re.fullmatch(r"(\d+)–(\d+) (days|months)", text)
    if duration:
        unit = "ימים" if duration.group(3) == "days" else "חודשים"
        return f"{duration.group(1)}–{duration.group(2)} {unit}"
    return text


def replace_paragraph_text(paragraph, new_text: str) -> None:
    first_rpr = None
    for run in paragraph.runs:
        if run._r.rPr is not None:
            first_rpr = deepcopy(run._r.rPr)
            break
    ppr = paragraph._p.pPr
    for child in list(paragraph._p):
        if child is not ppr:
            paragraph._p.remove(child)
    run = paragraph.add_run(new_text)
    if first_rpr is not None:
        if run._r.rPr is not None:
            run._r.remove(run._r.rPr)
        run._r.insert(0, first_rpr)


def set_paragraph_rtl(paragraph, rtl: bool = True) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    bidi = ppr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        ppr.append(bidi)
    bidi.set(qn("w:val"), "1" if rtl else "0")
    if rtl and paragraph.alignment not in {WD_ALIGN_PARAGRAPH.CENTER, WD_ALIGN_PARAGRAPH.JUSTIFY}:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in paragraph.runs:
        rpr = run._r.get_or_add_rPr()
        rfonts = rpr.find(qn("w:rFonts"))
        if rfonts is None:
            rfonts = OxmlElement("w:rFonts")
            rpr.insert(0, rfonts)
        for attr in ("ascii", "hAnsi", "cs"):
            rfonts.set(qn(f"w:{attr}"), "Arial")
        # Paragraph-level bidi is sufficient and lets Word correctly order mixed
        # Hebrew/Latin technical terms. Forcing every run to RTL can make long
        # English tokens collide inside narrow table cells.
        rtl_node = rpr.find(qn("w:rtl"))
        if rtl_node is not None:
            rpr.remove(rtl_node)


def set_table_rtl(table) -> None:
    tbl_pr = table._tbl.tblPr
    bidi = tbl_pr.find(qn("w:bidiVisual"))
    if bidi is None:
        bidi = OxmlElement("w:bidiVisual")
        tbl_pr.append(bidi)
    bidi.set(qn("w:val"), "1")
    for row in table.rows:
        for cell in row.cells:
            for nested in cell.tables:
                set_table_rtl(nested)


def reverse_hebrew_for_pillow(text: str) -> str:
    return text[::-1]


def draw_right(draw, xy, text, font, fill):
    visual = reverse_hebrew_for_pillow(text)
    bbox = draw.textbbox((0, 0), visual, font=font)
    draw.text((xy[0] - (bbox[2] - bbox[0]), xy[1]), visual, fill=fill, font=font)


def make_hebrew_funnel(path: Path, title: str, stages, counts, colors) -> None:
    width, height = 1400, 470
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 25)
    bold = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 27)
    title_font = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 31)
    draw_right(draw, (1375, 18), title, title_font, "#0B1437")
    label_right = 1368
    center_x = 600
    max_funnel = 650
    min_funnel = 190
    max_count = max(counts)
    row_top, segment_h = 82, 58
    import math
    funnel_widths = [max(min_funnel, int(max_funnel * math.sqrt(count / max_count))) for count in counts]
    for idx, (stage, count, color) in enumerate(zip(stages, counts, colors)):
        y_top = row_top + idx * segment_h
        top_w = funnel_widths[idx]
        bottom_w = funnel_widths[idx + 1] if idx + 1 < len(funnel_widths) else max(min_funnel - 45, int(top_w * 0.78))
        polygon = [
            (center_x - top_w // 2, y_top),
            (center_x + top_w // 2, y_top),
            (center_x + bottom_w // 2, y_top + segment_h - 3),
            (center_x - bottom_w // 2, y_top + segment_h - 3),
        ]
        draw.polygon(polygon, fill="#" + color)
        draw_right(draw, (label_right, y_top + 12), stage, regular, "#1E2633")
        count_text = str(count)
        bbox = draw.textbbox((0, 0), count_text, font=bold)
        draw.text((center_x - (bbox[2] - bbox[0]) / 2, y_top + 10), count_text, fill="white", font=bold)
    image.save(path, "PNG", optimize=True)


def replace_media(docx_path: Path, replacements: dict[str, Path]) -> None:
    final_path = OUTPUT
    with zipfile.ZipFile(docx_path, "r") as source_zip, zipfile.ZipFile(final_path, "w", zipfile.ZIP_DEFLATED) as target_zip:
        for info in source_zip.infolist():
            if info.filename in replacements:
                target_zip.writestr(info, replacements[info.filename].read_bytes())
            else:
                target_zip.writestr(info, source_zip.read(info.filename))


def main() -> None:
    doc = Document(SOURCE)
    untranslated: list[str] = []
    for paragraph in document_paragraphs(doc):
        original = paragraph.text
        if not original:
            continue
        if original == "TEADS  /  PEOPLE + TECHNOLOGY":
            for run in paragraph.runs:
                run.text = run.text.replace("PEOPLE + TECHNOLOGY", "אנשים + טכנולוגיה")
            set_paragraph_rtl(paragraph, rtl=True)
            continue
        score_match = re.fullmatch(r"(\d+) / 20\nPROVISIONAL FIT", original)
        if score_match:
            ppr = paragraph._p.pPr
            for child in list(paragraph._p):
                if child is not ppr:
                    paragraph._p.remove(child)
            first = paragraph.add_run(f"{score_match.group(1)} / 20")
            first.bold = True
            first.font.size = Pt(16)
            first.font.color.rgb = RGBColor(255, 255, 255)
            second = paragraph.add_run("\nהתאמה ראשונית")
            second.font.size = Pt(7.5)
            second.font.color.rgb = RGBColor(255, 255, 255)
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_paragraph_rtl(paragraph, rtl=True)
            # Keep the numeric score visually left-to-right inside the RTL card.
            first_rpr = first._r.get_or_add_rPr()
            first_rtl = OxmlElement("w:rtl")
            first_rtl.set(qn("w:val"), "0")
            first_rpr.append(first_rtl)
            first_lang = OxmlElement("w:lang")
            first_lang.set(qn("w:val"), "en-US")
            first_rpr.append(first_lang)
            continue
        translated = translate(original)
        if translated != original:
            replace_paragraph_text(paragraph, translated)
        ltr = original in KEEP_EXACT or original.startswith("(\"platform engineer\"")
        set_paragraph_rtl(paragraph, rtl=not ltr)
        if translated == original and re.search(r"[A-Za-z]{3,}", original):
            if original not in KEEP_EXACT and not re.fullmatch(r"[\d\s/%+.−—<>≤≥]+", original):
                untranslated.append(original)

    # Preserve page-number fields by translating footer text run-by-run.
    for section in doc.sections:
        for paragraph in section.footer.paragraphs:
            for run in paragraph.runs:
                if "TEADS INTERVIEW ASSIGNMENT" in run.text:
                    run.text = run.text.replace("TEADS INTERVIEW ASSIGNMENT", "מטלת ראיון TEADS")
                if "15 JULY 2026" in run.text:
                    run.text = run.text.replace("15 JULY 2026", "15 ביולי 2026")
            set_paragraph_rtl(paragraph, rtl=True)

    # The two translated cards on the second shortlist page contain more
    # mixed Hebrew/Latin text than their English originals. Keep the same
    # wording while tightening only those cards so Word does not overflow the
    # fixed visual panels during rendering.
    for table_index, table in enumerate(doc.tables):
        table_text = "\n".join(cell.text for row in table.rows for cell in row.cells)
        if not any(name in table_text for name in ("Ashraf Hamad", "Tal Ayalon")):
            continue
        related_tables = [table]
        if table_index + 1 < len(doc.tables):
            related_tables.append(doc.tables[table_index + 1])
        for related_index, related in enumerate(related_tables):
            for row in related.rows:
                for cell in row.cells:
                    if related_index == 1:
                        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            if related_index == 0:
                                if "/ 20" in paragraph.text:
                                    run.font.size = Pt(14 if "/ 20" in run.text else 7)
                                elif paragraph.text not in {"Ashraf Hamad", "Tal Ayalon"}:
                                    run.font.size = Pt(7.2)
                            else:
                                run.font.size = Pt(7)

    doc.core_properties.title = "מטלת ראיון — מוביל/ת גיוס טאלנט טכנולוגי ב-Teads"
    doc.core_properties.subject = "איתור Cloud Engineering, יעילות גיוס ומיתוג מעסיק בישראל"
    doc.save(TEMP)

    product_chart = ASSETS / "he_product_target_funnel.png"
    rd_chart = ASSETS / "he_rd_target_funnel.png"
    make_hebrew_funnel(
        product_chart,
        "מוצר • קוהורט יעד חודשי",
        ["לידים מתאימים", "שיחת מגייס/ת", "שיחת מנהל/ת", "תרגיל / פאנל", "הצעה", "קבלה"],
        [100, 32, 18, 9, 4, 3],
        ["1B63FF", "3978FF", "5B8FFF", "7EA8FF", "FF7A78", "2E8B57"],
    )
    make_hebrew_funnel(
        rd_chart,
        "מחקר ופיתוח • קוהורט יעד חודשי",
        ["לידים מתאימים", "שיחת מגייס/ת", "ריאיון טכני", "פאנל", "הצעה", "קבלה"],
        [140, 42, 24, 12, 4, 3],
        ["1B63FF", "3978FF", "5B8FFF", "7EA8FF", "FF7A78", "2E8B57"],
    )
    replace_media(TEMP, {"word/media/image1.png": product_chart, "word/media/image2.png": rd_chart})
    TEMP.unlink(missing_ok=True)
    print(OUTPUT)
    print("UNTRANSLATED_ITEMS", len(set(untranslated)))
    for item in sorted(set(untranslated)):
        print("-", item.replace("\n", " | "))


if __name__ == "__main__":
    main()
