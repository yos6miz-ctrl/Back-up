from pathlib import Path
import re

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


BASE = Path(r"C:\Users\Popovtzer lab\.codex\אדמה ירוקה")
OUT = BASE / "01_דוחות" / "דוח אבני דרך - דירוג פרומוטורים משובטים - סופי משולב.docx"
MEDIA = Path(r"C:\Users\Popovtzer lab\Documents\Codex\2026-05-28\new-chat\docx_media_extract2")
RTL_MARK = "\u200f"
LTR_MARK = "\u200e"
NBSP = "\u00a0"
LRE = "\u202a"
PDF = "\u202c"


def ltr_token(text):
    return f"{LRE}{text}{PDF}{RTL_MARK}"


def unit(value, symbol):
    return ltr_token(f"{value}{NBSP}{symbol}")


def stabilize_mixed_text(text):
    text = str(text)
    protected = []

    def stash(value):
        protected.append(value)
        return f"\ue000{len(protected) - 1}\ue001"

    text = re.sub(r"\u202a[^\u202c]*\u202c\u200f?", lambda m: stash(m.group(0)), text)

    def repl_mm(match):
        return stash(unit(match.group(1), "mM"))

    def repl_um(match):
        return stash(unit(match.group(1), "\u00b5M"))

    text = re.sub(r"(\d+(?:\.\d+)?)\s+מילימולר", repl_mm, text)
    text = re.sub(r"(\d+(?:\.\d+)?)\s+מיקרומולר", repl_um, text)
    text = re.sub(r"(?<![\ue000\w])([A-Za-z][A-Za-z0-9_.-]*(?:\.[A-Za-z0-9_-]+)*)(?![\w\ue001])", lambda m: stash(ltr_token(m.group(1))), text)
    text = re.sub(r"(?<![\ue000\w])(\d+(?:\.\d+)?:\d+(?:\.\d+)?)(?![\w\ue001])", lambda m: stash(ltr_token(m.group(1))), text)

    for idx, value in enumerate(protected):
        text = text.replace(f"\ue000{idx}\ue001", value)
    return text


def stabilize_hebrew_punctuation(text):
    text = stabilize_mixed_text(text)
    if not text:
        return text
    for mark in [".", ":", ";", "?", "!"]:
        text = text.replace(f"{mark} ", f"{mark}{RTL_MARK} ")
    if text[-1] in ".:;?!":
        text += RTL_MARK
    return text


def set_rtl(paragraph, align=WD_ALIGN_PARAGRAPH.RIGHT):
    if align == WD_ALIGN_PARAGRAPH.RIGHT:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    else:
        paragraph.alignment = align
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        p_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def set_ltr(paragraph, align=WD_ALIGN_PARAGRAPH.LEFT):
    paragraph.alignment = align
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = p_pr.find(qn("w:bidi"))
    if bidi is not None:
        p_pr.remove(bidi)


def run_style(run, size=10.5, bold=False, color=None):
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def add_paragraph(doc, text, size=10.5, bold=False, color=None, after=5):
    p = doc.add_paragraph()
    set_rtl(p)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(stabilize_hebrew_punctuation(text))
    run_style(r, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level=1):
    size = 15 if level == 1 else 12.5
    match = re.match(r"^(\d+(?:\.\d+)?)-\s*(.+)$", str(text))
    if match:
        p = doc.add_paragraph()
        set_rtl(p)
        p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
        p.paragraph_format.space_after = Pt(4)
        heading_text = f"{stabilize_hebrew_punctuation(match.group(2))} {LRE}{match.group(1)}-{PDF}"
        r = p.add_run(heading_text)
        run_style(r, size=size, bold=True, color=(31, 78, 121))
        return p
    p = add_paragraph(doc, text, size=size, bold=True, color=(31, 78, 121), after=4)
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    return p


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def remove_table_borders(table):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "nil")


def set_cell_width(cell, width_cm):
    tc_pr = cell._tc.get_or_add_tcPr()
    width = tc_pr.find(qn("w:tcW"))
    if width is None:
        width = OxmlElement("w:tcW")
        tc_pr.append(width)
    width.set(qn("w:w"), str(int(width_cm * 567)))
    width.set(qn("w:type"), "dxa")


def set_cell(cell, text, header=False, ltr=False, center=False):
    cell.text = ""
    p = cell.paragraphs[0]
    if ltr:
        set_ltr(p, WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT)
    else:
        set_rtl(p, WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.RIGHT)
    p.paragraph_format.space_after = Pt(0)
    display_text = str(text) if ltr else stabilize_hebrew_punctuation(text)
    r = p.add_run(display_text)
    run_style(r, size=9.0 if not header else 9.3, bold=header)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    if header:
        shade(cell, "D9EAF7")


def make_table_rtl(table):
    tbl_pr = table._tbl.tblPr
    bidi = tbl_pr.find(qn("w:bidiVisual"))
    if bidi is None:
        bidi = OxmlElement("w:bidiVisual")
        tbl_pr.append(bidi)
    bidi.set(qn("w:val"), "1")


def add_table(doc, headers, rows, ltr_cols=None, center_cols=None):
    ltr_cols = set(ltr_cols or [])
    center_cols = set(center_cols or [])
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.RIGHT
    make_table_rtl(table)
    for idx, header in enumerate(headers):
        set_cell(table.rows[0].cells[idx], header, header=True, center=True)
    for values in rows:
        row = table.add_row()
        for idx, value in enumerate(values):
            set_cell(row.cells[idx], value, ltr=idx in ltr_cols, center=idx in center_cols)
    doc.add_paragraph()
    return table


def add_image(doc, image_name, width_cm, caption):
    path = MEDIA / image_name
    if not path.exists():
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run().add_picture(str(path), width=Cm(width_cm))
    add_paragraph(doc, caption, size=9.2, color=(80, 80, 80), after=8)


def page_break(doc):
    doc.add_page_break()


def main():
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Cm(1.6)
    section.bottom_margin = Cm(1.6)
    section.left_margin = Cm(1.7)
    section.right_margin = Cm(1.7)

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:cs"), "Arial")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    normal_ppr = normal._element.get_or_add_pPr()
    normal_bidi = normal_ppr.find(qn("w:bidi"))
    if normal_bidi is None:
        normal_bidi = OxmlElement("w:bidi")
        normal_ppr.append(normal_bidi)
    normal_bidi.set(qn("w:val"), "1")

    for container, text in [(section.header, "דוח אבני דרך | אדמה ירוקה"), (section.footer, "מעבדת בנין, בר-אילן")]:
        p = container.paragraphs[0]
        p.text = text
        set_rtl(p)
        for r in p.runs:
            run_style(r, size=9.5, color=(90, 90, 90))

    title = add_paragraph(doc, "דוח אבני דרך", size=18, bold=True, after=2)
    subtitle = add_paragraph(doc, "בנין: דירוג ראשוני של פרומוטורים משובטים", size=12.5, bold=True, color=(80, 80, 80), after=10)

    add_table(
        doc,
        ["שדה", "פרטים"],
        [
            ["פרויקט", "אדמה ירוקה - רכיב החישה והדטקטורים"],
            ["אבן דרך", "דירוג ראשוני של פרומוטורים משובטים בשייק פלאסק עם ביטוי אנזימטי או פעילות ביולוגית"],
            ["תאריך סטטוס", "אוגוסט 2026"],
            ["מקורות נתונים", "קובצי מדידות חנקן, ברזל ופוספט; גרפים שהופקו מהמדידות; עדכוני סטטוס מהמעבדה"],
        ],
    )

    add_table(
        doc,
        ["תקציר מנהלים"],
        [
            ["קיימות תוצאות כמותיות לשלושה פרומוטורים פעילים שנכנסו לדירוג."],
            ["בדטקטורי החישה הפעילים התקבלו תגובות חזקות וברורות, עם אות מדיד ויחס אות לרעש שעומד בסף הנדרש."],
            ["במקביל נבחנו מועמדים נוספים. רק מועמדים שהציגו תגובה ספציפית מספקת נכללו בדירוג הכמותי."],
            ["דטקטור האלקנים עדיין נמצא בשלב ייצוב הקונסטרקט ולכן טרם נכלל בדירוג הכמותי."],
            ["מתוך שני דטקטורים המיועדים להעברה לשלב הבא, דטקטור אחד כבר מוכן וממתין להעברה."],
        ],
    )

    add_heading(doc, "1- הגדרת אבן הדרך והמדדים")
    add_paragraph(doc, "אבן הדרך עוסקת בדירוג ראשוני של פרומוטורים משובטים בתנאי שייק פלאסק, באמצעות ביטוי אנזימטי או פעילות ביולוגית. מטרת הדירוג היא הערכה כמותית של עוצמת הפרומוטור.")
    add_paragraph(doc, "מדד כמותי ראשון: לפחות 80 אחוז מהקונסטרוקטים יציגו פעילות נמדדת.")
    add_paragraph(doc, "מדד כמותי שני: דירוג ברור של לפחות ארבעה פרומוטורים.")
    add_paragraph(doc, "מדד כמותי שלישי: כל פרומוטור מדורג צריך לעמוד בסף יחס אות לרעש של 3:1 או יותר.")

    add_heading(doc, "2- סטטוס עמידה במדדי אבן הדרך")
    add_table(
        doc,
        ["מדד אבן הדרך", "תוצאה", "סטטוס"],
        [
            ["פעילות נמדדת בלפחות 80 אחוז מהקונסטרוקטים", "שלושת הקונסטרוקטים הפעילים שהגיעו למדידה כמותית הציגו פעילות ברורה. מועמדי סקר שלא עברו סינון מופיעים בנפרד.", "הושג עבור הקונסטרוקטים הפעילים שנמדדו"],
            ["דירוג ברור של לפחות ארבעה פרומוטורים", "קיים דירוג כמותי לשלושה פרומוטורים פעילים. דטקטור אחד מתוך שניים מוכן וממתין להעברה. דטקטור האלקנים עדיין אינו יציב ולכן טרם נוסף לדירוג.", "חלקי; נדרש פרומוטור פעיל נוסף"],
            ["יחס אות לרעש", "שלושת הפרומוטורים הפעילים עברו את סף היחס הנדרש.", "הושג עבור שלושת הפרומוטורים הפעילים"],
        ],
    )

    page_break(doc)
    add_heading(doc, "3- תוצאות כמותיות זמינות")
    add_paragraph(doc, "המדידות נותחו על בסיס אות מנורמל לאחר חיסור רקע ובקרה רלוונטית. יחס אות לרעש חושב בין אות בתנאי השראה או מחסור לבין אות בסיס באותה סדרת מדידה.")
    add_table(
        doc,
        ["יעד חישה", "קוד פרומוטור", "תנאי בסיס", "אות בסיס", "תנאי השראה או מחסור", "אות שיא", "יחס אות לרעש", "מסקנה"],
        [
            ["חנקן", "glnK", "חנקן, 10 מילימולר", "11,819", "חנקן, 2 מילימולר", "202,038", "17.1:1", "פעיל; עומד במדד"],
            ["ברזל", "pvdA", "ברזל, 20 מילימולר", "28,182", "ללא ברזל", "244,316", "8.7:1", "פעיל; עומד במדד"],
            ["פוספט", "uxpB", "פוספט מלא, 34 מילימולר", "10,481", "פוספט, 100 מיקרומולר", "48,226 ± 3,867", "4.6:1", "פעיל; עומד במדד"],
        ],
        ltr_cols={1, 3, 5, 6},
        center_cols={1, 3, 5, 6},
    )
    add_paragraph(doc, "שלושה מועמדי פוספט נוספים נבדקו אך לא הציגו תגובה ספציפית מספקת. בדטקטורי האלקנים, אחד מוכן להעברה והשני עדיין בבנייה.")

    add_heading(doc, "4- דירוג ראשוני של הפרומוטורים הפעילים")
    add_table(
        doc,
        ["דירוג", "יעד חישה", "קוד פרומוטור", "יחס אות לרעש", "פירוש"],
        [
            ["1", "חנקן", "glnK", "17.1:1", "תגובה חזקה וברורה עם ירידת זמינות החנקן."],
            ["2", "ברזל", "pvdA", "8.7:1", "תגובה מדורגת עם ירידת זמינות הברזל."],
            ["3", "פוספט", "uxpB", "4.6:1", "תגובה כמותית ברורה בריכוז 100 מיקרומולר של פוספט."],
        ],
        ltr_cols={2, 3},
        center_cols={0, 2, 3},
    )

    add_heading(doc, "5- פירוט תוצאות לפי דטקטור")
    add_heading(doc, "5.1- דטקטור ברזל", level=2)
    add_paragraph(doc, "בדטקטור הברזל נמדדה תגובת מינון ברורה. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מן 28,182 בתנאי ברזל גבוה עד 244,316 ללא ברזל. יחס האות לרעש הוא 8.7:1 בקירוב.")
    add_table(doc, ["יעד חישה", "קוד פרומוטור"], [["ברזל", "pvdA"]], ltr_cols={1}, center_cols={1})

    add_heading(doc, "5.2- דטקטור חנקן", level=2)
    add_paragraph(doc, "בדטקטור החנקן נמדדה תגובה חזקה לירידת זמינות החנקן. בנקודת הזמן 13.3 שעות, האות הממוצע עלה מן 11,819 בתנאי חנקן גבוה עד 202,038 בתנאי חנקן נמוך. יחס האות לרעש הוא 17.1:1 בקירוב.")
    add_table(doc, ["יעד חישה", "קוד פרומוטור"], [["חנקן", "glnK"]], ltr_cols={1}, center_cols={1})

    add_heading(doc, "5.3- דטקטור פוספט", level=2)
    add_paragraph(doc, "בדטקטור הפוספט נמדדה תגובה כמותית לאחר הורדת ריכוז הפוספט. הריכוזים המדויקים שנבדקו מופיעים בטבלת הסיכום ובאיור 4.")
    add_paragraph(doc, "נקודת השיא הכמותית בסדרת הזמן התקבלה בקריאה 12. הערכים המדויקים וסטיות התקן מוצגים בטבלת הסיכום ובאיור 4. יחס האות לרעש שנבחר לדירוג הוא 4.6:1.")

    add_heading(doc, "5.4- דטקטור אלקנים", level=2)
    add_paragraph(doc, "דטקטור האלקנים נמצא עדיין בשלב בנייה וייצוב. מאחר שהקונסטרקט עדיין אינו יציב, אין בשלב זה מדידה כמותית תקפה שמאפשרת דירוג מול הפרומוטורים הפעילים.")

    add_heading(doc, "6- נתוני סיכום כמותיים")
    add_table(
        doc,
        ["יעד חישה", "קוד", "תנאי", "ממוצע ביטוי מנורמל", "סטיית תקן", "מספר חזרות"],
        [
            ["ברזל", "pvdA", "ברזל, 20 מילימולר", "28,182", "4,876", "6"],
            ["ברזל", "pvdA", "ברזל, 10 מילימולר", "52,434", "4,517", "6"],
            ["ברזל", "pvdA", "ברזל, 5 מילימולר", "118,102", "11,172", "6"],
            ["ברזל", "pvdA", "ברזל, 2.5 מילימולר", "179,519", "16,418", "6"],
            ["ברזל", "pvdA", "ללא ברזל", "244,316", "6,774", "6"],
            ["חנקן", "glnK", "חנקן, 10 מילימולר", "11,819", "1,546", "6"],
            ["חנקן", "glnK", "חנקן, 8 מילימולר", "15,387", "1,427", "6"],
            ["חנקן", "glnK", "חנקן, 6 מילימולר", "71,645", "6,172", "6"],
            ["חנקן", "glnK", "חנקן, 4 מילימולר", "127,657", "13,806", "6"],
            ["חנקן", "glnK", "חנקן, 2 מילימולר", "202,038", "8,603", "6"],
            ["פוספט", "uxpB", "פוספט מלא, 34 מילימולר", "10,481", "654", "6"],
            ["פוספט", "uxpB", "פוספט, 100 מיקרומולר", "48,226", "3,867", "6"],
        ],
        ltr_cols={1, 3, 4, 5},
        center_cols={1, 3, 4, 5},
    )

    add_heading(doc, "7- גרפים תומכים")
    add_image(doc, "image1.png", 15.2, "איור 1- תגובת דטקטור הברזל לאורך זמן. האות עולה עם ירידת זמינות הברזל.")
    add_image(doc, "image2.png", 15.2, "איור 2- תגובת דטקטור החנקן לאורך זמן. האות עולה עם ירידת זמינות החנקן.")
    add_image(doc, "image3.png", 15.2, "איור 3- השוואת ביטוי מנורמל בנקודת זמן 13.3 שעות עבור דטקטורי הברזל והחנקן.")
    add_image(doc, "image4.png", 15.8, "איור 4- תגובת דטקטור הפוספט בסדרת ריכוזים. הערכים מוצגים כממוצע ± סטיית תקן, שש חזרות.")

    add_heading(doc, "8- פערים ותוכנית המשך")
    add_paragraph(doc, "להמשיך ייצוב ובדיקת קונסטרקט דטקטור האלקנים כדי לאפשר מדידה כמותית ודירוג.")
    add_paragraph(doc, "לתאם את העברת הדטקטור המוכן לשלב הבא. בשלב זה דטקטור אחד מתוך שניים מוכן וממתין להעברה.")
    add_paragraph(doc, "להרחיב את הדירוג הכמותי לפרומוטור פעיל נוסף לאחר השלמת ייצוב מערכת האלקנים או בחירת מועמד חלופי.")
    add_paragraph(doc, "לאמת את מדד 80 אחוז פעילות נמדדת לאחר שכל הקונסטרוקטים המתוכננים יעברו מדידה באותו פורמט.")
    add_paragraph(doc, "לשמור הפרדה בדיווח בין תוצאות פלואורסצנציה קיימות לבין תוצאות לוציפראז לאחר העברה לראמז.")

    add_heading(doc, "9- מסקנה")
    add_paragraph(doc, "הנתונים תומכים בהתקדמות משמעותית באבן הדרך. שלושה פרומוטורים פעילים מציגים פעילות ביולוגית נמדדת, תגובת מינון ברורה ויחס אות לרעש גבוה מהסף הנדרש.")
    add_paragraph(doc, "הדוח כולל דירוג כמותי בשלושה צירי חישה מרכזיים: חנקן, ברזל ופוספט. השלמת הדירוג לארבעה פרומוטורים תלויה בייצוב דטקטור האלקנים או בבחירת מועמד נוסף.")

    page_break(doc)
    add_heading(doc, "נספח: מקורות נתונים והנחות עיבוד")
    add_paragraph(doc, "מקורות הנתונים כוללים את קובצי המדידה של חנקן, ברזל ופוספט, את הגרפים שהופקו מהגיליונות ואת עדכוני הסטטוס שנמסרו מהמעבדה.")
    add_table(
        doc,
        ["סוג מקור", "שם קובץ"],
        [
            ["חנקן וברזל", "yossi_20260610.xlsx"],
            ["פוספט", "YOSSI P starv 17.8.26.xlsx"],
            ["פוספט", "YOSSI P starv 18.8.xlsx"],
            ["פוספט", "YOSSI P starv 18.8 NEW.xlsx"],
        ],
        ltr_cols={1},
    )
    add_paragraph(doc, "הנחת עיבוד: יחס אות לרעש חושב כאות ממוצע בתנאי אינדוקציה או מחסור החזק ביותר חלקי אות ממוצע בתנאי בסיס מתאים באותה סדרת מדידה.")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
